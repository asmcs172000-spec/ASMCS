import { useEffect, useState } from "react";
import { FileJson } from "lucide-react";
import type { SavedGroup } from "./ConstellationGroup";

export type ConfigFile = {
  id: string;
  name: string;
  size: number;
  groupId: string;
};

function buildConfigFileForGroup(group: SavedGroup): ConfigFile {
  const content = JSON.stringify(
    {
      groupId: group.id,
      groupName: group.name,
      satellites: group.satelliteIds,
      generatedAt: new Date().toISOString(),
    },
    null,
    2,
  );

  const safeName = group.name.trim().replace(/\s+/g, "_") || "group";

  return {
    id: `cfg-${group.id}`,
    name: `${safeName}_config`,
    size: new Blob([content]).size,
    groupId: group.id,
  };
}

type Props = {
  groups: SavedGroup[];
  activeGroupId?: string | null;
  onOpenFile?: (groupId: string) => void;
};

export default function MissionConfigFilesPanel({
  groups,
  activeGroupId,
  onOpenFile,
}: Props) {
  const [configFiles, setConfigFiles] = useState<ConfigFile[]>([]);

  useEffect(() => {
    setConfigFiles((prev) =>
      groups.map((g) => {
        const prior = prev.find((f) => f.groupId === g.id);
        const fresh = buildConfigFileForGroup(g);
        return prior ? { ...fresh, id: prior.id } : fresh;
      }),
    );
  }, [groups]);

  return (
    <div className="flex min-h-0 flex-1 flex-col p-4">
      <div className="mb-3 flex items-center justify-between">
        <h2 className="globe-section-title text-base">Mission Config Files</h2>
        <span className="rounded-full border border-emerald-400/20 bg-emerald-400/10 px-2.5 py-1 text-xs font-bold text-emerald-300">
          {configFiles.length} LOADED
        </span>
      </div>

      <div className="min-h-0 flex-1 space-y-1 overflow-y-auto">
        {configFiles.length === 0 && (
          <div className="text-sm text-[oklch(0.6_0.01_260)]">
            No config files yet — create a constellation group to generate one.
          </div>
        )}

        {configFiles.map((f) => {
          const isOpen = activeGroupId === f.groupId;
          return (
            <button
  key={f.id}
  type="button"
  onClick={() => onOpenFile?.(f.groupId)}
  className={`flex w-full items-center gap-2 rounded-md border px-2.5 py-2 text-left outline-none transition-colors focus:outline-none focus-visible:ring-1 focus-visible:ring-[oklch(0.75_0.12_220)]/50 ${
    isOpen
      ? "border-[oklch(0.75_0.12_220)]/45 bg-[oklch(0.75_0.12_220)]/10"
      : "border-white/5 bg-white/[0.02] hover:border-[oklch(0.75_0.12_220)]/30 hover:bg-[oklch(0.75_0.12_220)]/5"
  }`}
>
              <FileJson className="size-3.5 shrink-0 text-[oklch(0.5_0.01_260)]" />
              <span className="flex-1 truncate text-sm text-[oklch(0.85_0_0)]">{f.name}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}