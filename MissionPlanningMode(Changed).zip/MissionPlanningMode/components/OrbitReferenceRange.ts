import * as satellite from "satellite.js";

// ─── Geometry ─────────────────────────────────────────────────────────────
//
// This file is a standalone copy of the subset of `satelliteRangeUtils.ts`
// that `OrbitReference.tsx` depends on: `findPasses`, `formatUtc`,
// `computeForwardCaptureArea`, the capture-range constants, the default
// ground stations, and their supporting types/helpers.
//
// CORRECT RANGE MODEL
// --------------------
// The only physically correct way to get slant range, elevation, and
// azimuth between a ground point and a satellite is to propagate the
// satellite's real TLE (SGP4) to the instant in question, convert both
// positions into a common Earth-fixed frame (ECEF), and solve the real
// look-angle triangle. That is exactly what the internal `rangeAtTime`
// helper below does via satellite.js's `eciToEcf` + `ecfToLookAngles`.
//
// CAPTURE-AREA MODEL (forward, spatial — no ground station, no time search)
// --------------------------------------------------------------------------
// The capture area is NOT tied to any ground station or fixed reference
// point. At the exact instant the user selects, we:
//   1. Read the satellite's real TLE position (lat/lon/altitude) at that
//      instant.
//   2. Read its heading (direction of travel) at that same instant.
//   3. Looking AHEAD along that heading — spatially ahead, same instant,
//      no propagating through future time — find the ground point where
//      the satellite's slant range would be exactly `minRangeKm`. That is
//      where capture starts. Similarly find the `maxRangeKm` point, where
//      the capture window ends.
// This is pure spherical geometry (law of cosines on the Earth-centered
// triangle satellite/Earth-center/ground-point) evaluated at ONE moment in
// time. See `computeForwardCaptureArea`. `minRangeKm`/`maxRangeKm` are now
// user-adjustable — `CAPTURE_RANGE_MIN_KM`/`CAPTURE_RANGE_MAX_KM` are just
// the defaults.

const EARTH_RADIUS_KM = 6378.137; // WGS84 equatorial radius

/** Default capture range window: capture runs while slant range to the
 *  ground point sits inside this band. The user can override both ends
 *  (see `computeForwardCaptureArea`'s `minRangeKm`/`maxRangeKm` params). */
export const CAPTURE_RANGE_MIN_KM = 900;
export const CAPTURE_RANGE_MAX_KM = 1100;

/** Sane bounds for the user-facing "minimum range" control. */
export const MIN_RANGE_FLOOR_KM = 300;
export const MIN_RANGE_STEP_KM = 10;

// ─── Types ────────────────────────────────────────────────────────────────

export type TleEntry = {
  name: string;
  tle1: string;
  tle2: string;
  color?: string;
};

/** Any point on the ground the satellite's range can be measured against —
 *  used for ground-station passes and for Spot/Area targets. */
export type GroundPoint = {
  name: string;
  lat: number;
  lon: number;
  color?: string;
};

export type Pass = {
  aos: Date;
  los: Date;
  maxElevationDeg: number;
  rangeAtMaxElevationKm: number;
};

export const DEFAULT_GROUND_STATIONS: GroundPoint[] = [
  { name: "Rawalpindi GS", lat: 33.6167, lon: 73.0992, color: "#7dd3fc" },
  { name: "Azerbaijan GS", lat: 40.39, lon: 49.29, color: "#fef08a" },
  { name: "Turkey GS", lat: 41.1037, lon: 29.0261, color: "#f472b6" },
];

const toDeg = (rad: number) => (rad * 180) / Math.PI;
const toRad = (deg: number) => (deg * Math.PI) / 180;

// 30s step: passes/scans are minutes long, and AOS/LOS are refined down to
// sub-second precision by binary search afterwards anyway, so a coarser
// step here just means fewer SGP4 propagations without losing accuracy.
const STEP_SECONDS = 30;

function normalizeLon(lon: number): number {
  while (lon > 180) lon -= 360;
  while (lon < -180) lon += 360;
  return lon;
}

type RangeSnapshot = {
  elevationDeg: number;
  rangeKm: number;
  azimuthDeg: number;
};

/** Single shared low-level lookup: real elevation/range/azimuth of a
 *  propagated satrec as seen from `point` at instant `t`. */
function lookAnglesAt(
  satrec: satellite.SatRec,
  point: GroundPoint,
  t: Date,
): RangeSnapshot | null {
  const geodetic = {
    latitude: satellite.degreesToRadians(point.lat),
    longitude: satellite.degreesToRadians(point.lon),
    height: 0,
  };
  const gmst = satellite.gstime(t);
  const pv = satellite.propagate(satrec, t);
  if (!pv?.position) return null;
  const look = satellite.ecfToLookAngles(geodetic, satellite.eciToEcf(pv.position, gmst));
  return {
    elevationDeg: toDeg(look.elevation),
    rangeKm: look.rangeSat,
    azimuthDeg: toDeg(look.azimuth),
  };
}

function elevationAt(satrec: satellite.SatRec, point: GroundPoint, t: Date): number {
  return lookAnglesAt(satrec, point, t)?.elevationDeg ?? -180;
}

/** Actual (propagated) slant range, elevation, and azimuth of `tle` as seen
 * from ground point `point` at a single instant `t`. */
function rangeAtTime(tle: TleEntry, point: GroundPoint, t: Date): RangeSnapshot | null {
  const satrec = satellite.twoline2satrec(tle.tle1, tle.tle2);
  return lookAnglesAt(satrec, point, t);
}

/** @deprecated Flat-Earth, fixed-altitude approximation. Kept only as the
 *  fallback used internally by `findPasses` when a snapshot lookup fails. */
function slantRangeKm(elevationDeg: number, altitudeKm: number = 551): number {
  if (elevationDeg <= 0) return Infinity;
  const elevRad = (elevationDeg * Math.PI) / 180;
  return altitudeKm / Math.sin(elevRad);
}

function refineCrossing(satrec: satellite.SatRec, point: GroundPoint, t1: Date, t2: Date): Date {
  let lo = t1.getTime();
  let hi = t2.getTime();
  while (hi - lo > 1000) {
    const mid = (lo + hi) / 2;
    const elevLo = elevationAt(satrec, point, new Date(lo));
    const elevMid = elevationAt(satrec, point, new Date(mid));
    if (elevLo * elevMid <= 0) hi = mid;
    else lo = mid;
  }
  return new Date(hi);
}

/** Every AOS/LOS pass of `tle` over `point` within [start, end] (horizon 0°).
 *  Used for the ground-station comms-pass list.
 *
 *  `stepSeconds` controls the coarse scan resolution (default 30s) — AOS/LOS
 *  are always refined to sub-second precision afterwards via bisection, so
 *  a coarser step only reduces the number of SGP4 propagations, not the
 *  accuracy of the result. Callers doing a UI-driven scan over many hours
 *  should keep this at the default or larger; pass a smaller value only if
 *  you need to catch passes shorter than the step itself. */
export function findPasses(
  tle: TleEntry,
  point: GroundPoint,
  start: Date,
  end: Date,
  stepSeconds: number = STEP_SECONDS,
): Pass[] {
  const satrec = satellite.twoline2satrec(tle.tle1, tle.tle2);
  const passes: Pass[] = [];

  let inPass = false;
  let passStart: Date | null = null;
  let maxElev = -90;
  let maxElevTime: Date | null = null;
  let prevTime: Date | null = null;

  for (let t = new Date(start); t <= end; t = new Date(t.getTime() + stepSeconds * 1000)) {
    const elev = elevationAt(satrec, point, t);

    if (elev >= 0 && !inPass) {
      inPass = true;
      passStart = prevTime ? refineCrossing(satrec, point, prevTime, t) : new Date(t);
      maxElev = elev;
      maxElevTime = new Date(t);
    }
    if (inPass && elev > maxElev) {
      maxElev = elev;
      maxElevTime = new Date(t);
    }
    if (elev < 0 && inPass) {
      inPass = false;
      const los = prevTime ? refineCrossing(satrec, point, t, prevTime) : new Date(t);
      if (passStart) {
        const peakTime = maxElevTime ?? passStart;
        const snapshot = rangeAtTime(tle, point, peakTime);
        passes.push({
          aos: passStart,
          los,
          maxElevationDeg: maxElev,
          rangeAtMaxElevationKm: snapshot ? snapshot.rangeKm : slantRangeKm(maxElev),
        });
      }
      passStart = null;
      maxElev = -90;
      maxElevTime = null;
    }
    prevTime = new Date(t);
  }

  return passes;
}

// ─── Forward capture-area geometry (spatial, single instant) ──────────────

/** Great-circle initial bearing (degrees, 0=N, clockwise) from point 1 to
 *  point 2. */
function initialBearingDeg(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const φ1 = toRad(lat1), φ2 = toRad(lat2);
  const Δλ = toRad(lon2 - lon1);
  const y = Math.sin(Δλ) * Math.cos(φ2);
  const x = Math.cos(φ1) * Math.sin(φ2) - Math.sin(φ1) * Math.cos(φ2) * Math.cos(Δλ);
  return (toDeg(Math.atan2(y, x)) + 360) % 360;
}

/** Destination point given a start lat/lon, bearing, and angular distance
 *  (radians — the central angle at Earth's center, not a km distance). */
function destinationPoint(lat1: number, lon1: number, bearingDeg: number, angularDistRad: number) {
  const φ1 = toRad(lat1), λ1 = toRad(lon1), θ = toRad(bearingDeg);
  const φ2 = Math.asin(
    Math.sin(φ1) * Math.cos(angularDistRad) + Math.cos(φ1) * Math.sin(angularDistRad) * Math.cos(θ),
  );
  const λ2 =
    λ1 +
    Math.atan2(
      Math.sin(θ) * Math.sin(angularDistRad) * Math.cos(φ1),
      Math.cos(angularDistRad) - Math.sin(φ1) * Math.sin(φ2),
    );
  return { lat: toDeg(φ2), lon: normalizeLon(toDeg(λ2)) };
}

/** Central angle (radians) between the sub-satellite point and a ground
 *  point that would produce slant range `rangeKm`, given the satellite's
 *  current altitude `altKm`. Spherical-Earth law of cosines on the
 *  satellite/Earth-center/ground-point triangle. */
function angularDistanceForRange(rangeKm: number, altKm: number): number {
  const Rs = EARTH_RADIUS_KM + altKm; // satellite's distance from Earth's center
  const Re = EARTH_RADIUS_KM;
  let cosTheta = (Rs * Rs + Re * Re - rangeKm * rangeKm) / (2 * Rs * Re);
  cosTheta = Math.max(-1, Math.min(1, cosTheta));
  return Math.acos(cosTheta);
}

export type ForwardCaptureArea = {
  /** Satellite's own real TLE position at the selected instant. */
  satelliteLat: number;
  satelliteLon: number;
  altitudeKm: number;
  /** Direction of travel (degrees, 0=N, clockwise) at that instant. */
  headingDeg: number;
  /** Ground point ahead of the satellite where slant range = `minRangeKm` —
   *  capture starts here. */
  startLat: number;
  startLon: number;
  startRangeKm: number;
  /** Ground point ahead where slant range = `maxRangeKm` — capture window
   *  ends here. */
  endLat: number;
  endLon: number;
  endRangeKm: number;
};

/**
 * At the EXACT instant `t` the user selected: read the satellite's real TLE
 * position and heading, then — purely spatially, at that same instant, no
 * time propagation — find the ground point ahead of it (along its heading)
 * where slant range is `minRangeKm` (capture start) and `maxRangeKm`
 * (capture end).
 *
 * `minRangeKm`/`maxRangeKm` default to the standard 900/1100 km band but
 * are fully user-adjustable — e.g. a UI input for "minimum range" should
 * feed straight into `minRangeKm` here.
 *
 * No ground station, no external reference point, no time-search. Returns
 * null only if the TLE can't be propagated at `t`.
 */
export function computeForwardCaptureArea(
  tle: TleEntry,
  t: Date,
  minRangeKm: number = CAPTURE_RANGE_MIN_KM,
  maxRangeKm: number = CAPTURE_RANGE_MAX_KM,
): ForwardCaptureArea | null {
  const satrec = satellite.twoline2satrec(tle.tle1, tle.tle2);
  const pv = satellite.propagate(satrec, t);
  if (!pv?.position) return null;

  const gmst = satellite.gstime(t);
  const gd = satellite.eciToGeodetic(pv.position, gmst);
  const satLat = toDeg(gd.latitude);
  const satLon = normalizeLon(toDeg(gd.longitude));
  const altKm = gd.height;

  // Heading at this instant: sample 1 second later along the real
  // propagated orbit and take the bearing between the two sub-satellite
  // points. This is the satellite's actual direction of travel right now,
  // derived from the TLE — not an assumption.
  const t2 = new Date(t.getTime() + 1000);
  const pv2 = satellite.propagate(satrec, t2);
  if (!pv2?.position) return null;
  const gd2 = satellite.eciToGeodetic(pv2.position, satellite.gstime(t2));
  const lat2 = toDeg(gd2.latitude);
  const lon2 = normalizeLon(toDeg(gd2.longitude));
  const heading = initialBearingDeg(satLat, satLon, lat2, lon2);

  const thetaStart = angularDistanceForRange(minRangeKm, altKm);
  const thetaEnd = angularDistanceForRange(maxRangeKm, altKm);

  const startPoint = destinationPoint(satLat, satLon, heading, thetaStart);
  const endPoint = destinationPoint(satLat, satLon, heading, thetaEnd);

  return {
    satelliteLat: satLat,
    satelliteLon: satLon,
    altitudeKm: altKm,
    headingDeg: heading,
    startLat: startPoint.lat,
    startLon: startPoint.lon,
    startRangeKm: minRangeKm,
    endLat: endPoint.lat,
    endLon: endPoint.lon,
    endRangeKm: maxRangeKm,
  };
}

export function formatUtc(d: Date): string {
  const day = d.getUTCDate().toString().padStart(2, "0");
  const month = d.toLocaleString("en-US", { month: "short", timeZone: "UTC" });
  const year = d.getUTCFullYear();
  const h = d.getUTCHours().toString().padStart(2, "0");
  const m = d.getUTCMinutes().toString().padStart(2, "0");
  const s = d.getUTCSeconds().toString().padStart(2, "0");
  return `${day} ${month} ${year}, ${h}:${m}:${s} UTC`;
}