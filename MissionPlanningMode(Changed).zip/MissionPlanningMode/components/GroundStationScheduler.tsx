import { useEffect, useMemo, useState, type ReactNode } from "react";
import { ChevronDown, ChevronUp } from "lucide-react";
import { findPasses, OTHER_SAT_FALLBACK_COLORS, type GroundPoint, type TleEntry } from "./SpotModeRange";

/** How long a single satellite's download takes inside a GS pass. */
const DOWNLOAD_SECONDS = 180;
const GS_SCAN_HOURS = 36;
/** Above this many satellites the permutation list gets unwieldy — only the default order is offered. */
const MAX_REORDER_SATS = 4;

type Props = {
  groundStations: GroundPoint[];
  satelliteIds: string[];
  tleData: TleEntry[];
  /** Passes are searched from this instant (the capture orbit / orbit-reference time). */
  anchorTime: Date;
  /** Existing config state — station selection maps onto these two fields. */
  downloadInGsPass: boolean;
  onToggleDownloadInGsPass: (checked: boolean) => void;
  selectedGsName: string | null;
  onSelectGsName: (name: string) => void;
  /** Rendered under "Possible orders" in the right-hand column (the save card). */
  children?: ReactNode;
};

type SatPass = { name: string; color: string; aos: Date; los: Date; offsetSec: number };
type StationPlan = { station: GroundPoint; sats: SatPass[]; aos: Date | null; windowSec: number };

const MONO = "mp-mono";

function mmss(totalSeconds: number) {
  const s = Math.max(0, Math.round(totalSeconds));
  return `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;
}
const hhmm = (d: Date) => d.toISOString().slice(11, 16);
const hhmmss = (d: Date) => d.toISOString().slice(11, 19);

function permutations<T>(items: T[]): T[][] {
  if (items.length <= 1) return [items];
  return items.flatMap((item, i) =>
    permutations([...items.slice(0, i), ...items.slice(i + 1)]).map((rest) => [item, ...rest]),
  );
}

export default function GroundStationScheduler({
  groundStations,
  satelliteIds,
  tleData,
  anchorTime,
  downloadInGsPass,
  onToggleDownloadInGsPass,
  selectedGsName,
  onSelectGsName,
  children,
}: Props) {
  const [order, setOrder] = useState<string[]>(() => groundStations.map((g) => g.name));
  const [selected, setSelected] = useState<string[]>(() =>
    downloadInGsPass && selectedGsName ? [selectedGsName] : [],
  );
  const [orderIdx, setOrderIdx] = useState(0);

  // The saved config fields stay the source of truth for the primary station
  // (they can change underneath us: a config load, or a range edit that clears
  // the GS pick). Extra ticked stations are local to this view.
  useEffect(() => {
    if (!downloadInGsPass || !selectedGsName) {
      setSelected([]);
    } else if (!selected.includes(selectedGsName)) {
      setSelected([selectedGsName]);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [downloadInGsPass, selectedGsName]);

  const selectedInOrder = order.filter((n) => selected.includes(n));

  // Write a new selection back into the existing config fields: download is
  // on when any station is ticked, and the first ticked station is the one saved.
  const commit = (nextOrder: string[], nextSelected: string[]) => {
    setOrder(nextOrder);
    setSelected(nextSelected);
    setOrderIdx(0);
    const primary = nextOrder.find((n) => nextSelected.includes(n)) ?? null;
    if (!!primary !== downloadInGsPass) onToggleDownloadInGsPass(!!primary);
    if ((primary ?? "") !== (selectedGsName ?? "")) onSelectGsName(primary ?? "");
  };
  const primaryGs = selectedInOrder[0] ?? null;

  const groupTles = useMemo(
    () => tleData.filter((t) => satelliteIds.includes(t.name)),
    [tleData, satelliteIds],
  );

  // Re-scan at most once a minute of anchor change.
  const anchorMinute = Math.floor(anchorTime.getTime() / 60000);
  const plans: StationPlan[] = useMemo(() => {
    const start = new Date(anchorMinute * 60000);
    const end = new Date(start.getTime() + GS_SCAN_HOURS * 3600 * 1000);
    return groundStations.map((station) => {
      const firstPasses = groupTles
        .map((tle, i) => {
          const p = findPasses(tle, station, start, end).find((x) => x.aos.getTime() >= start.getTime());
          return p
            ? {
                name: tle.name,
                color: tle.color ?? OTHER_SAT_FALLBACK_COLORS[i % OTHER_SAT_FALLBACK_COLORS.length],
                aos: p.aos,
                los: p.los,
              }
            : null;
        })
        .filter((p): p is Omit<SatPass, "offsetSec"> => p !== null)
        .sort((a, b) => a.aos.getTime() - b.aos.getTime());
      const lead = firstPasses[0];
      return {
        station,
        aos: lead?.aos ?? null,
        windowSec: lead ? (lead.los.getTime() - lead.aos.getTime()) / 1000 : 0,
        sats: firstPasses.map((p) => ({ ...p, offsetSec: lead ? (p.aos.getTime() - lead.aos.getTime()) / 1000 : 0 })),
      };
    });
  }, [groundStations, groupTles, anchorMinute]);

  const planByName = Object.fromEntries(plans.map((p) => [p.station.name, p]));
  const orderGs = primaryGs ?? order[0];
  const orderPlan = planByName[orderGs];

  // Possible download orders at the first selected station: satellites
  // download one after another (DOWNLOAD_SECONDS each), each no earlier than
  // its own AOS and finishing before its own LOS.
  const orders = useMemo(() => {
    const sats = orderPlan?.sats ?? [];
    if (sats.length === 0) return [];
    const leadAos = sats[0].aos.getTime();
    const perms = sats.length <= MAX_REORDER_SATS ? permutations(sats) : [sats];
    return perms.map((seq) => {
      let t = 0;
      let fits = true;
      for (const s of seq) {
        const start = Math.max(t, s.offsetSec);
        t = start + DOWNLOAD_SECONDS;
        if (t > (s.los.getTime() - leadAos) / 1000) fits = false;
      }
      return { seq, end: t, fits };
    });
  }, [orderPlan]);
  const fitCount = orders.filter((o) => o.fits).length;
  const activeOrderIdx = orders[orderIdx]?.fits ? orderIdx : orders.findIndex((o) => o.fits);
  const reorderOk = fitCount > 1;

  const move = (i: number, dir: -1 | 1) => {
    const j = i + dir;
    if (j < 0 || j >= order.length) return;
    const next = [...order];
    [next[i], next[j]] = [next[j], next[i]];
    commit(next, selected);
  };
  const toggle = (name: string) =>
    commit(order, selected.includes(name) ? selected.filter((n) => n !== name) : [...selected, name]);

  // Layout: stations on the left (wide), order options + save stacked on
  // the right; stacks into one column on narrow screens.
  return (
    <div className="col-span-full grid min-w-0 grid-cols-[repeat(auto-fit,minmax(min(360px,100%),1fr))] items-start gap-4">
      <section className="mp-card">
        <div className="mp-card-head flex-wrap">
          <span className="font-semibold">Ground station scheduling &amp; re-ordering</span>
          <span className={`${MONO} whitespace-nowrap text-[11px] font-semibold text-[var(--mp-accent)]`}>
            {selectedInOrder.length} SELECTED FOR DOWNLOAD
          </span>
        </div>
        <div className="flex flex-col gap-2 px-3 pb-3.5 pt-2.5">
          {order.map((name, i) => {
            const plan = planByName[name];
            if (!plan) return null;
            const on = selected.includes(name);
            return (
              <div
                key={name}
                className="overflow-hidden rounded-lg border"
                style={{
                  borderColor: on ? "rgba(77,163,255,.3)" : "var(--mp-border)",
                  background: on ? "rgba(77,163,255,.06)" : "transparent",
                }}
              >
                <div className="grid grid-cols-[auto_22px_minmax(0,1fr)_auto_auto] items-center gap-3 px-3 py-2.5">
                  <div className="flex flex-col">
                    <button
                      type="button"
                      title="Move up"
                      disabled={i === 0}
                      onClick={() => move(i, -1)}
                      className="text-[var(--mp-text-2)] disabled:text-[#3a4550]"
                    >
                      <ChevronUp className="size-3.5" />
                    </button>
                    <button
                      type="button"
                      title="Move down"
                      disabled={i === order.length - 1}
                      onClick={() => move(i, 1)}
                      className="text-[var(--mp-text-2)] disabled:text-[#3a4550]"
                    >
                      <ChevronDown className="size-3.5" />
                    </button>
                  </div>
                  <button
                    type="button"
                    role="checkbox"
                    aria-checked={on}
                    aria-label={`Download at ${name}`}
                    onClick={() => toggle(name)}
                    className={`${MONO} grid size-4 place-items-center rounded border-[1.5px] text-[11px] font-bold text-[#06182c]`}
                    style={{
                      borderColor: on ? "var(--mp-accent)" : "#4a5866",
                      background: on ? "var(--mp-accent)" : "transparent",
                    }}
                  >
                    {on ? "✓" : ""}
                  </button>
                  <div className="flex min-w-0 flex-col gap-px">
                    <span className="flex items-center gap-2 font-semibold">
                      <span className={`${MONO} text-[11px] text-[var(--mp-text-3)]`}>
                        {on ? String(selectedInOrder.indexOf(name) + 1).padStart(2, "0") : "—"}
                      </span>
                      <span className="truncate">{name}</span>
                    </span>
                    <span className={`${MONO} text-[11px] text-[var(--mp-text-3)]`}>
                      {plan.station.lat.toFixed(4)}°N {plan.station.lon.toFixed(4)}°E
                    </span>
                  </div>
                  <div className="flex flex-col items-end gap-px">
                    <span className={`${MONO} whitespace-nowrap text-[12.5px] font-semibold`}>
                      {plan.aos ? `AOS ${hhmm(plan.aos)}Z` : "No pass"}
                    </span>
                    <span className={`${MONO} whitespace-nowrap text-[11px] text-[var(--mp-text-3)]`}>
                      {plan.aos ? `window ${mmss(plan.windowSec)}` : `next ${GS_SCAN_HOURS}h`}
                    </span>
                  </div>
                  <span className="size-[9px] rounded-full" style={{ background: plan.station.color ?? "#7dd3fc" }} />
                </div>
                {plan.sats.length > 0 && (
                  <div className="flex flex-col border-t border-[var(--mp-border-row)] py-1 pl-16 pr-3">
                    {plan.sats.map((s, k) => (
                      <div
                        key={s.name}
                        className="grid grid-cols-[10px_minmax(0,1fr)_auto_auto] items-center gap-2.5 py-[5px] text-xs"
                      >
                        <span className="size-[7px] rounded-full" style={{ background: s.color }} />
                        <span className="flex min-w-0 items-center gap-2">
                          <span className="truncate">{s.name}</span>
                          {k === 0 && (
                            <span
                              className={`${MONO} rounded-[3px] border border-[rgba(77,163,255,.4)] px-1 text-[9.5px] font-semibold tracking-[0.06em] text-[var(--mp-accent)]`}
                            >
                              LEAD
                            </span>
                          )}
                        </span>
                        <span className={`${MONO} text-[11.5px] text-[var(--mp-text-2)]`}>+{mmss(s.offsetSec)}</span>
                        <span className={`${MONO} text-[11.5px] text-[var(--mp-text-3)]`}>{hhmmss(s.aos)}Z</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>

      <div className="flex min-w-0 flex-col gap-4">
      <section className="mp-card">
        <div className="mp-card-head">
          <span className="min-w-0 truncate font-semibold">Possible orders · {orderGs}</span>
          <span
            className={`${MONO} whitespace-nowrap rounded border px-[7px] py-[3px] text-[10.5px] font-semibold`}
            style={{
              color: reorderOk ? "var(--mp-ok)" : "var(--mp-warn)",
              borderColor: reorderOk ? "var(--mp-ok)" : "var(--mp-warn)",
            }}
          >
            {reorderOk ? "RE-ORDERING POSSIBLE" : "FIXED ORDER"}
          </span>
        </div>
        <div className="flex flex-col gap-1.5 px-4 py-3">
          {orders.length === 0 ? (
            <span className="text-xs text-[var(--mp-text-3)]">
              No satellite of this group passes over {orderGs} in the next {GS_SCAN_HOURS}h.
            </span>
          ) : (
            <>
              <span className="text-xs text-[var(--mp-text-3)]">
                {(reorderOk ? `${fitCount} of ${orders.length} download orders fit` : "Only one order fits") +
                  ` in the ${mmss(orderPlan?.windowSec ?? 0)} pass window (${mmss(DOWNLOAD_SECONDS)} per satellite).`}
              </span>
              {orders.map((o, i) => {
                const on = i === activeOrderIdx;
                return (
                  <button
                    key={o.seq.map((s) => s.name).join(">")}
                    type="button"
                    role="radio"
                    aria-checked={on}
                    disabled={!o.fits}
                    onClick={() => setOrderIdx(i)}
                    className="grid grid-cols-[14px_minmax(0,1fr)_auto] items-center gap-2.5 rounded-md border px-[11px] py-[9px] text-left disabled:cursor-not-allowed disabled:opacity-50"
                    style={{
                      background: on ? "var(--mp-selected)" : "transparent",
                      borderColor: on ? "var(--mp-selected-border)" : "var(--mp-border)",
                    }}
                  >
                    <span
                      className="size-3 rounded-full border-[1.5px] shadow-[inset_0_0_0_2.5px_#10161c]"
                      style={{
                        borderColor: on ? "var(--mp-accent)" : "#4a5866",
                        background: on ? "var(--mp-accent)" : "transparent",
                      }}
                    />
                    <span className={`${MONO} truncate text-[12.5px]`}>
                      {o.seq.map((s) => s.name).join(" → ")}
                      {i === 0 ? "  (default)" : ""}
                    </span>
                    <span
                      className={`${MONO} whitespace-nowrap text-[11px]`}
                      style={{ color: o.fits ? "var(--mp-ok)" : "var(--mp-err-text)" }}
                    >
                      {o.fits ? `ends +${mmss(o.end)}` : "exceeds window"}
                    </span>
                  </button>
                );
              })}
            </>
          )}
        </div>
      </section>
      {children}
      </div>
    </div>
  );
}
