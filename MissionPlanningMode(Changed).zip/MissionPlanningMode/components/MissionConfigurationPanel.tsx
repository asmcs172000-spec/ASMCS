import { useState, type ReactNode } from "react";
import { AlertCircle, ChevronLeft } from "lucide-react";
import Georeference from "./Georeference";
import OrbitReference from "./OrbitReference";
import GroundStationScheduler from "./GroundStationScheduler";
import { DEFAULT_GROUND_STATIONS } from "./SpotModeRange";
import type { TleEntry, GroundStation } from "./satelliteRangeUtils";
import type { FrequencySegment } from "./FrequencyAndTime";
import type * as Cesium from "cesium";
import type { RectangleBounds } from "./useTargetPicker";
import type { MissionPanelSection, SelectedOrbitInfo } from "./Georeference";
import { setVizPaused } from "./vizPlayback";

const POLARIZATION_OPTIONS = [
  { id: "0", label: "0°" },
  { id: "45", label: "45°", badge: "AUTO" },
  { id: "90", label: "90°" },
  { id: "custom", label: "Custom (0–90°)" },
  { id: "freefly", label: "Free Fly" },
];

const MISSION_TYPE_OPTIONS = [
  { id: "capture", label: "Capture" },
  { id: "download", label: "Download" },
  { id: "both", label: "Both" },
];

const TARGET_AREA_OPTIONS = [
  { id: "georeference", label: "Geo Reference", sub: "Plan on a target location, using a marker or a rectangle" },
  { id: "orbit", label: "Orbit Reference", sub: "Plan from a date and time on the orbit (1–2 satellites)" },
];

const CAPTURE_SUBTYPE_OPTIONS: { id: "ESLINT" | "COMINT"; label: string }[] = [
  { id: "ESLINT", label: "ESLINT" },
  { id: "COMINT", label: "COMINT" },
];

// ── Wizard steps: the four parameter groups of a mission config file ──
export const MISSION_STEPS = [
  "Polarization and Mission Type",
  "Planning Reference",
  "Orbits and Visualization",
  "Ground Stations and Downloading",
];
const SECTION_FOR_STEP: MissionPanelSection[] = ["reference", "reference", "orbits", "downlink"];

const MONO = "mp-mono";

export type TargetAreaMode = "georeference" | "orbit" | null;

type Props = {
  groupName: string;
  allowOrbitReference: boolean;

  /** Wizard position (0-based) and the furthest step reached — owned by the parent. */
  step: number;
  maxStep: number;
  onStepChange: (step: number) => void;

  selectedPolarization: string;
  onSelectPolarization: (id: string) => void;
  customPolarization: number;
  onCustomPolarizationChange: (value: number) => void;
  /** Fixed sensor off-nadir/incidence angle (deg), derived by the parent
   *  from selectedPolarization/customPolarization. Forwarded straight
   *  through to Georeference's Spot capture-range calculation. */
  lookAngleDeg: number;

  selectedMissionType: string | null;
  onSelectMissionType: (id: string) => void;

  targetAreaMode: TargetAreaMode;
  onSelectTargetAreaMode: (mode: TargetAreaMode) => void;

  targetLat: number | null;
  targetLon: number | null;
  onTargetLatChange: (lat: number | null) => void;
  onTargetLonChange: (lon: number | null) => void;

  selectedDate: Date;
  onSelectedDateChange: (date: Date) => void;
  hour24: number;
  minute: number;
  second: number;
  onTimeChange: (hour24: number, minute: number, second: number) => void;

  satelliteIds: string[];
  tleData: TleEntry[];
  groundStations?: GroundStation[];

  selectedOrbitIndex: number | null;
  onSelectOrbit: (index: number) => void;

  downloadInGsPass: boolean;
  onToggleDownloadInGsPass: (checked: boolean) => void;

  selectedGsName: string | null;
  onSelectGsName: (name: string) => void;
  viewerRef: React.MutableRefObject<Cesium.Viewer | null>;
  viewerReady: boolean;
  onTargetRectangleChange?: (bounds: RectangleBounds | null) => void;

  frequencySegments: FrequencySegment[];
  onFrequencySegmentsChange: (segments: FrequencySegment[]) => void;
  /** Strip/Orbit-mode visualization (ground-track swath moving with the
   *  satellite). Used for OrbitReference only. */
  onVisualizeFrequency?: (segments: FrequencySegment[]) => void;
  onBackFromFrequency?: () => void;
  /** Spot-mode visualization (fixed target, pendulum-swinging satellites,
   *  overlapping fixed swath squares). Used for Georeference only. */
  onVisualizeSpotFrequency?: (segments: FrequencySegment[]) => void;
  onBackFromSpotFrequency?: () => void;

  // ── Save configuration ──
  onSaveConfiguration: () => void;
  isSaving?: boolean;
  saveError?: string | null;

  selectedCaptureSubType: "ESLINT" | "COMINT" | null;
  onSelectCaptureSubType: (v: "ESLINT" | "COMINT" | null) => void;
  onOrbitTimeChange?: (info: SelectedOrbitInfo | null) => void;

  /** Satellite colours, keyed by name (for the step 3 legend). */
  satelliteColors?: Record<string, string>;

  /** Closes the config file and returns to the constellation/file list. */
  onClose?: () => void;
};

function mmss(totalSeconds: number) {
  const s = Math.max(0, Math.round(totalSeconds));
  return `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;
}

function pad2(n: number) {
  return n.toString().padStart(2, "0");
}

export default function MissionConfigurationPanel({
  groupName,
  allowOrbitReference,
  step,
  maxStep,
  onStepChange,
  selectedPolarization,
  onSelectPolarization,
  customPolarization,
  onCustomPolarizationChange,
  lookAngleDeg,
  selectedMissionType,
  onSelectMissionType,
  targetAreaMode,
  onSelectTargetAreaMode,
  targetLat,
  targetLon,
  onTargetLatChange,
  onTargetLonChange,
  selectedDate,
  onSelectedDateChange,
  hour24,
  minute,
  second,
  onTimeChange,
  satelliteIds,
  tleData,
  groundStations,
  selectedOrbitIndex,
  onSelectOrbit,
  downloadInGsPass,
  onToggleDownloadInGsPass,
  selectedGsName,
  onSelectGsName,
  viewerRef,
  viewerReady,
  onTargetRectangleChange,
  frequencySegments,
  onFrequencySegmentsChange,
  onVisualizeFrequency,
  onBackFromFrequency,
  onVisualizeSpotFrequency,
  onBackFromSpotFrequency,
  onSaveConfiguration,
  isSaving,
  saveError,
  selectedCaptureSubType,
  onSelectCaptureSubType,
  onOrbitTimeChange,
  onClose,
}: Props) {
  // Selected Geo-reference orbit window — anchors the step 4 GS pass search.
  const [orbitWindow, setOrbitWindow] = useState<SelectedOrbitInfo | null>(null);
  const handleOrbitTimeChange = (info: SelectedOrbitInfo | null) => {
    setOrbitWindow(info);
    onOrbitTimeChange?.(info);
  };

  // If orbit reference becomes disallowed while it was selected, the
  // parent should ideally reset targetAreaMode — this component just
  // avoids rendering the now-unavailable panel.
  const effectiveTargetAreaMode: TargetAreaMode =
    targetAreaMode === "orbit" && !allowOrbitReference ? null : targetAreaMode;

  const section = SECTION_FOR_STEP[step];
  const lastStep = step === MISSION_STEPS.length - 1;
  const fileName = `MissionConfig_${groupName.trim().replace(/\s+/g, "_")}.txt`;
  const stations = groundStations ?? DEFAULT_GROUND_STATIONS;

  // ── Derived labels for the step rail + review ──
  const polLabel =
    selectedPolarization === "custom"
      ? `Custom ${customPolarization}°`
      : POLARIZATION_OPTIONS.find((o) => o.id === selectedPolarization)?.label ?? "—";
  const typeLabel = MISSION_TYPE_OPTIONS.find((o) => o.id === selectedMissionType)?.label ?? null;
  const usedSeconds = frequencySegments.reduce((sum, s) => sum + s.durationSeconds, 0);
  const orbitDateTime = new Date(
    Date.UTC(selectedDate.getFullYear(), selectedDate.getMonth(), selectedDate.getDate(), hour24, minute, second),
  );
  const orbitTimeLabel = `${selectedDate.getFullYear()}-${pad2(selectedDate.getMonth() + 1)}-${pad2(selectedDate.getDate())} ${pad2(hour24)}:${pad2(minute)}:${pad2(second)}`;

  const referenceLabel =
    effectiveTargetAreaMode === "georeference"
      ? targetLat !== null && targetLon !== null
        ? `Geo · ${targetLat.toFixed(2)}, ${targetLon.toFixed(2)}`
        : "Geo · no target"
      : effectiveTargetAreaMode === "orbit"
        ? `Orbit · ${orbitTimeLabel}`
        : null;
  const gsLabel = downloadInGsPass && selectedGsName ? selectedGsName : "No GS download";
  const orbitLabel =
    effectiveTargetAreaMode === "georeference"
      ? orbitWindow
        ? `${orbitWindow.satelliteName} · ${orbitWindow.aos.toISOString().slice(11, 19)}Z`
        : "No orbit selected"
      : effectiveTargetAreaMode === "orbit"
        ? `From ${orbitTimeLabel}`
        : "Choose a reference first";

  const doneCount = Math.min(MISSION_STEPS.length, maxStep + (lastStep ? 1 : 0));

  const typeNote =
    selectedMissionType === "capture"
      ? "Capture only: data stays onboard until a later download."
      : selectedMissionType === "download"
        ? "Download only: no capture is planned. Ground stations are chosen in step 4."
        : selectedMissionType === "both"
          ? "Capture, then download in the selected ground-station pass."
          : "Choose what this mission does.";

  const review: { k: string; v: string; missing: boolean; go?: number }[] = [
    { k: "Satellites", v: satelliteIds.join(", ") || "—", missing: satelliteIds.length === 0 },
    { k: "Polarization", v: polLabel, missing: false, go: 0 },
    {
      k: "Mission type",
      v: typeLabel
        ? typeLabel + (selectedMissionType === "capture" ? ` · ${selectedCaptureSubType ?? "missing"}` : "")
        : "missing",
      missing: !typeLabel || (selectedMissionType === "capture" && !selectedCaptureSubType),
      go: 0,
    },
    { k: "Reference", v: referenceLabel ?? "missing", missing: !referenceLabel, go: 1 },
    {
      k: "Frequency plan",
      v: frequencySegments.length > 0 ? `${frequencySegments.length} seg · ${mmss(usedSeconds)}` : "missing",
      missing: frequencySegments.length === 0,
      go: 1,
    },
    { k: "Orbit", v: orbitLabel, missing: false, go: 2 },
    { k: "Ground stations", v: downloadInGsPass && selectedGsName ? selectedGsName : "None", missing: false, go: 3 },
  ];

  // Anchor for the GS pass search: the end of the chosen capture orbit, or the
  // orbit-reference time, otherwise now.
  const gsAnchor =
    effectiveTargetAreaMode === "georeference" && orbitWindow
      ? orbitWindow.los
      : effectiveTargetAreaMode === "orbit" && orbitDateTime.getTime() > Date.now()
        ? orbitDateTime
        : new Date();

  return (
    <div className="flex min-h-0 min-w-0 flex-1">
      {/* ── Step rail ── */}
      <nav className="mp-chrome flex w-[clamp(210px,18vw,270px)] shrink-0 flex-col border-r border-[var(--mp-border)]">
        <div className="flex min-w-0 flex-col gap-[3px] border-b border-[var(--mp-border)] px-4 pb-3 pt-4">
          <div className="flex items-center justify-between gap-2">
            <span className="mp-label">MISSION CONFIG FILE</span>
            {onClose && (
              <button
                type="button"
                onClick={onClose}
                title="Back to config files"
                className="flex items-center gap-0.5 rounded px-1 text-[11px] text-[var(--mp-text-3)] hover:text-[var(--mp-text)]"
              >
                <ChevronLeft className="size-3.5" />
                Files
              </button>
            )}
          </div>
          <span className="truncate font-semibold" title={fileName}>
            {fileName}
          </span>
        </div>

        <div className="flex flex-1 flex-col gap-1 overflow-y-auto px-2.5 py-3.5">
          {MISSION_STEPS.map((title, i) => {
            const current = i === step;
            const done = i <= maxStep && !current;
            return (
              <button
                key={title}
                type="button"
                onClick={() => onStepChange(i)}
                className="grid grid-cols-[30px_minmax(0,1fr)] gap-3 rounded-lg border px-2.5 py-[11px] text-left transition-colors"
                style={{
                  background: current ? "rgba(77,163,255,.12)" : "transparent",
                  borderColor: current ? "rgba(77,163,255,.35)" : "transparent",
                }}
              >
                <span
                  className={`${MONO} grid size-7 place-items-center rounded-full border text-xs font-semibold`}
                  style={{
                    background: current ? "var(--mp-accent)" : done ? "#163326" : "transparent",
                    color: current ? "#05202f" : done ? "var(--mp-ok)" : "var(--mp-text-3)",
                    borderColor: current ? "var(--mp-accent)" : done ? "#2a6247" : "#33404b",
                  }}
                >
                  {done ? "✓" : i + 1}
                </span>
                <span
                  className="self-center font-semibold leading-[1.3]"
                  style={{ color: current || done ? "var(--mp-text)" : "var(--mp-text-2)" }}
                >
                  {title}
                </span>
              </button>
            );
          })}
        </div>

        <div className="flex flex-col gap-1.5 border-t border-[var(--mp-border)] px-4 py-3">
          <div className="flex justify-between text-xs">
            <span className="text-[var(--mp-text-2)]">Progress</span>
            <span className={MONO}>
              {doneCount} / {MISSION_STEPS.length}
            </span>
          </div>
          <div className="h-1.5 overflow-hidden rounded-[3px] bg-[rgba(5,9,13,.6)]">
            <div
              className="h-full bg-[var(--mp-accent)] transition-[width] duration-300"
              style={{ width: `${(doneCount / MISSION_STEPS.length) * 100}%` }}
            />
          </div>
        </div>
      </nav>

      {/* ── Step content ── */}
      <div className="flex min-h-0 min-w-0 flex-1 flex-col border-r border-[var(--mp-border)]">
        <div className="mp-chrome border-b border-[var(--mp-border)] px-6 py-4">
          <span className="text-[20px] font-semibold tracking-[-0.005em]">{MISSION_STEPS[step]}</span>
        </div>

        <div className="mp-cards min-h-0 flex-1 overflow-y-auto overflow-x-hidden px-6 py-5 [color-scheme:dark]">
          {/* Step 1 — polarization + mission type */}
          {step === 0 && (
            <>
              <Card
                title="Polarization settings"
                right={<span className={`${MONO} whitespace-nowrap text-[11px] text-[var(--mp-text-3)]`}>Look angle {lookAngleDeg}°</span>}
              >
                <div className="flex flex-col gap-1.5">
                  {POLARIZATION_OPTIONS.map((opt) => {
                    const on = selectedPolarization === opt.id;
                    return (
                      <button
                        key={opt.id}
                        type="button"
                        onClick={() => onSelectPolarization(opt.id)}
                        className="flex items-center gap-2.5 rounded-md border px-3 py-2.5 text-left transition-colors"
                        style={{
                          background: on ? "var(--mp-selected)" : "transparent",
                          borderColor: on ? "var(--mp-selected-border)" : "var(--mp-border)",
                        }}
                      >
                        <Radio on={on} />
                        <span className="flex-1 font-medium">{opt.label}</span>
                        {opt.badge && (
                          <span
                            className={`${MONO} rounded-[3px] border border-[#275a44] bg-[#132a20] px-1.5 py-0.5 text-[9.5px] font-semibold tracking-[0.06em] text-[var(--mp-ok)]`}
                          >
                            {opt.badge}
                          </span>
                        )}
                      </button>
                    );
                  })}
                  {selectedPolarization === "custom" && (
                    <div className="flex items-center gap-3 rounded-md border border-[var(--mp-border)] px-3 py-2.5">
                      <input
                        type="range"
                        min={0}
                        max={90}
                        value={customPolarization}
                        onChange={(e) => onCustomPolarizationChange(Number(e.target.value))}
                        className="flex-1 accent-[var(--mp-accent)]"
                      />
                      <span className={`${MONO} w-9 text-right text-[12.5px] font-semibold`}>{customPolarization}°</span>
                    </div>
                  )}
                </div>
              </Card>

              <Card title="Mission type">
                <div className="flex flex-col gap-3.5">
                  <div className="grid grid-cols-3 gap-1.5">
                    {MISSION_TYPE_OPTIONS.map((opt) => (
                      <OptionTile
                        key={opt.id}
                        active={selectedMissionType === opt.id}
                        onClick={() => {
                          onSelectMissionType(opt.id);
                          // Leaving Capture clears any chosen sub-type so a stale
                          // ESLINT/COMINT selection doesn't linger under Download/Both.
                          if (opt.id !== "capture") onSelectCaptureSubType(null);
                        }}
                        className="px-1.5 py-3.5"
                      >
                        {opt.label}
                      </OptionTile>
                    ))}
                  </div>

                  {/* ESLINT / COMINT — only relevant once Capture is chosen. */}
                  {selectedMissionType === "capture" && (
                    <div className="flex flex-col gap-2">
                      <span className="mp-label">CAPTURE TYPE</span>
                      <div className="grid grid-cols-2 gap-1.5">
                        {CAPTURE_SUBTYPE_OPTIONS.map((opt) => {
                          const active = selectedCaptureSubType === opt.id;
                          return (
                            <OptionTile
                              key={opt.id}
                              active={active}
                              onClick={() => onSelectCaptureSubType(active ? null : opt.id)}
                              className={`${MONO} p-[11px] text-[12.5px]`}
                            >
                              {opt.label}
                            </OptionTile>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  <div className="rounded-md border border-[var(--mp-border)] bg-[var(--mp-input)] px-3 py-2.5 text-xs text-[var(--mp-text-2)]">
                    {typeNote}
                  </div>
                </div>
              </Card>
            </>
          )}

          {/* Step 2 — reference choice */}
          {step === 1 && (
            <Card title="Select planning reference" wide>
              <div className="grid grid-cols-[repeat(auto-fit,minmax(200px,1fr))] gap-2">
                {TARGET_AREA_OPTIONS.map((opt) => {
                  const disabled = opt.id === "orbit" && !allowOrbitReference;
                  const on = effectiveTargetAreaMode === opt.id;
                  return (
                    <button
                      key={opt.id}
                      type="button"
                      disabled={disabled}
                      onClick={() => onSelectTargetAreaMode(opt.id as TargetAreaMode)}
                      title={disabled ? "Orbit Reference is only offered for groups with 1–2 satellites" : undefined}
                      className="flex flex-col gap-[3px] rounded-lg border px-3.5 py-3 text-left transition-colors disabled:cursor-not-allowed disabled:opacity-40"
                      style={{
                        background: on ? "var(--mp-selected)" : "rgba(255,255,255,.025)",
                        borderColor: on ? "var(--mp-selected-border)" : "var(--mp-border)",
                      }}
                    >
                      <span className="font-semibold" style={{ color: on ? "var(--mp-text)" : "var(--mp-text-2)" }}>
                        {opt.label}
                      </span>
                      <span className="text-[11.5px] text-[var(--mp-text-3)]">{opt.sub}</span>
                    </button>
                  );
                })}
              </div>
              {!allowOrbitReference && (
                <div className="mt-3 rounded-md border border-[var(--mp-border)] bg-[var(--mp-input)] px-3 py-2.5 text-xs text-[var(--mp-text-2)]">
                  Orbit Reference is only offered for groups with 1–2 satellites. Larger groups plan with Geo Reference.
                </div>
              )}
            </Card>
          )}

          {/* Steps 2–4 share one mounted Georeference / OrbitReference
              instance so its scans and selections survive step changes; the
              `section` prop only decides which of its blocks are visible.
              Step 4 uses the station scheduler below instead. */}
          <div hidden={step === 0 || step === 3} className="mp-inner col-span-full min-w-0">
            {effectiveTargetAreaMode === "georeference" && (
              <Georeference
                section={section}
                lat={targetLat}
                lon={targetLon}
                onLatChange={onTargetLatChange}
                onLonChange={onTargetLonChange}
                satelliteIds={satelliteIds}
                tleData={tleData}
                groundStations={groundStations}
                lookAngleDeg={lookAngleDeg}
                selectedOrbitIndex={selectedOrbitIndex}
                onSelectOrbit={onSelectOrbit}
                downloadInGsPass={downloadInGsPass}
                onToggleDownloadInGsPass={onToggleDownloadInGsPass}
                selectedGsName={selectedGsName}
                onSelectGsName={onSelectGsName}
                viewerRef={viewerRef}
                viewerReady={viewerReady}
                onTargetRectangleChange={onTargetRectangleChange}
                frequencySegments={frequencySegments}
                onFrequencySegmentsChange={onFrequencySegmentsChange}
                onVisualizeFrequency={onVisualizeSpotFrequency}
                onBackFromFrequency={onBackFromSpotFrequency}
                onOrbitTimeChange={handleOrbitTimeChange}
              />
            )}

            {effectiveTargetAreaMode === "orbit" && allowOrbitReference && (
              <OrbitReference
                section={section}
                selectedDate={selectedDate}
                onSelectedDateChange={onSelectedDateChange}
                hour24={hour24}
                minute={minute}
                second={second}
                onTimeChange={onTimeChange}
                satelliteIds={satelliteIds}
                tleData={tleData}
                groundStations={groundStations}
                downloadInGsPass={downloadInGsPass}
                onToggleDownloadInGsPass={onToggleDownloadInGsPass}
                selectedGsName={selectedGsName}
                onSelectGsName={onSelectGsName}
                frequencySegments={frequencySegments}
                onFrequencySegmentsChange={onFrequencySegmentsChange}
                onVisualizeFrequency={onVisualizeFrequency}
                onBackFromFrequency={onBackFromFrequency}
                onPauseFrequency={(paused) => setVizPaused(viewerRef.current, paused)}
                viewerRef={viewerRef}
                viewerReady={viewerReady}
              />
            )}

            {!effectiveTargetAreaMode && step === 2 && (
              <Notice>
                Choose a planning reference first.{" "}
                <button type="button" onClick={() => onStepChange(1)} className="text-[var(--mp-accent)] hover:text-[#9ad3f6]">
                  Go to step 2 →
                </button>
              </Notice>
            )}
          </div>

          {/* Step 4 — ground stations + save */}
          {step === 3 && (
            <GroundStationScheduler
                groundStations={stations}
                satelliteIds={satelliteIds}
                tleData={tleData}
                anchorTime={gsAnchor}
                downloadInGsPass={downloadInGsPass}
                onToggleDownloadInGsPass={onToggleDownloadInGsPass}
                selectedGsName={selectedGsName}
                onSelectGsName={onSelectGsName}
              >
              <Card title="Save configuration file" bodyClassName="px-4 pb-3.5 pt-1.5">
                <div className="flex flex-col">
                  {review.map((r) => (
                    <button
                      key={r.k}
                      type="button"
                      onClick={() => r.go !== undefined && onStepChange(r.go)}
                      className="grid grid-cols-[auto_minmax(0,1fr)] gap-2.5 border-b border-[var(--mp-border-row)] py-[9px] text-left"
                    >
                      <span className="whitespace-nowrap text-[var(--mp-text-2)]">{r.k}</span>
                      <span
                        className={`${MONO} truncate text-right text-[12.5px]`}
                        style={{ color: r.missing ? "var(--mp-err-text)" : "var(--mp-text)" }}
                      >
                        {r.v}
                      </span>
                    </button>
                  ))}
                  {saveError && (
                    <div
                      role="alert"
                      className="mt-3 flex min-w-0 items-start gap-2 rounded-md border border-[#5a2a24] bg-[#2a1715] px-3 py-2.5 text-xs text-[var(--mp-err-text)]"
                    >
                      <AlertCircle className="mt-0.5 size-3.5 shrink-0" aria-hidden="true" />
                      <span className="min-w-0 break-words">{saveError}</span>
                    </div>
                  )}
                </div>
              </Card>
            </GroundStationScheduler>
          )}
        </div>

        {/* ── Footer nav ── */}
        <div className="mp-chrome flex items-center gap-2.5 border-t border-[var(--mp-border)] px-6 py-3.5">
          <button
            type="button"
            onClick={() => onStepChange(Math.max(0, step - 1))}
            disabled={step === 0}
            className="whitespace-nowrap rounded-md border border-[#33404b] px-4 py-[9px] hover:bg-white/[0.04] disabled:cursor-default disabled:opacity-35"
          >
            ← Back
          </button>
          <div className="flex flex-1 justify-center gap-1.5">
            {MISSION_STEPS.map((title, i) => (
              <span
                key={title}
                className="h-1.5 rounded-[3px] transition-all"
                style={{
                  width: i === step ? 22 : 8,
                  background: i === step ? "var(--mp-accent)" : i < step ? "#2c4a60" : "#2a323b",
                }}
              />
            ))}
          </div>
          <button
            type="button"
            onClick={lastStep ? onSaveConfiguration : () => onStepChange(step + 1)}
            disabled={lastStep && isSaving}
            className="mp-btn-primary truncate"
          >
            {lastStep ? (isSaving ? "Saving…" : "Save configuration file") : `Next: ${MISSION_STEPS[step + 1]} →`}
          </button>
        </div>
      </div>
    </div>
  );
}

function Card({
  title,
  right,
  wide,
  bodyClassName = "px-4 py-3.5",
  children,
}: {
  title: string;
  right?: ReactNode;
  wide?: boolean;
  bodyClassName?: string;
  children: ReactNode;
}) {
  return (
    <section className={`mp-card ${wide ? "col-span-full" : ""}`}>
      <div className="mp-card-head">
        <span className="font-semibold">{title}</span>
        {right}
      </div>
      <div className={`min-w-0 ${bodyClassName}`}>{children}</div>
    </section>
  );
}

function Notice({ children }: { children: ReactNode }) {
  return (
    <div className="rounded-md border border-[rgba(77,163,255,.25)] bg-[rgba(77,163,255,.08)] px-3 py-2.5 text-xs text-[var(--mp-text-2)]">
      {children}
    </div>
  );
}

function Radio({ on }: { on: boolean }) {
  return (
    <span
      className="size-3.5 shrink-0 rounded-full border-[1.5px] shadow-[inset_0_0_0_3px_#10161c]"
      style={{ borderColor: on ? "var(--mp-accent)" : "#4a5866", background: on ? "var(--mp-accent)" : "transparent" }}
    />
  );
}

function OptionTile({
  active,
  onClick,
  className = "",
  children,
}: {
  active: boolean;
  onClick: () => void;
  className?: string;
  children: ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`rounded-md border text-center font-semibold transition-colors ${className}`}
      style={{
        background: active ? "var(--mp-selected)" : "rgba(255,255,255,.025)",
        borderColor: active ? "var(--mp-selected-border)" : "var(--mp-border)",
        color: active ? "var(--mp-text)" : "var(--mp-text-2)",
      }}
    >
      {children}
    </button>
  );
}
