import { useEffect, useMemo, useState } from "react";
import {
  Square,
  Waypoints,
  Satellite as SatelliteIcon,
  ChevronDown,
  ChevronUp,
  Info,
  CheckCircle2,
  AlertTriangle,
  Layers,
  Eye,
  Radio,
} from "lucide-react";
import type * as Cesium from "cesium";
import type { RectangleBounds } from "./useTargetPicker";
import { formatUtc, findPasses, type TleEntry, type GroundStation } from "./SpotModeRange";
import {
  planStripCapture,
  formatCoveragePercent,
  stripGateSummary,
  DEFAULT_MIN_ELEVATION_DEG,
  AOS_LEAD_SECONDS,
  FORMATION_WINDOW_SECONDS,
  type StripCapturePlanResult,
} from "./GeoReferenceStripModeRange";
import { FrequencyPlanTable, type FrequencySegment } from "./FrequencyAndTime";
import { CaptureLimits, type MissionPanelSection } from "./Georeference";
import { fallbackColorForName, OTHER_SAT_FALLBACK_COLORS } from "./SpotModeRange";
import { rectangleAreaKm2 } from "./areaFromBounds";

import {
  visualizeStripCapture,
  clearStripVisualization,
} from "./GeoReferenceStripOrbitPlanAnimation";

// ─────────────────────────────────────────────────────────────────────────
// No more fixed 36h cutoff. We start with a modest search window and
// keep doubling it (INITIAL → INITIAL*2 → INITIAL*4 → ...) until we either
// find at least one qualifying pass or hit MAX_SCAN_HOURS.
//
// Initial search window: 3 days. The generator-based fix in
// GeoReferenceStripModeRange.ts (scanMissionStarts) is what
// actually removed the post-Confirm lag — it made the AOS scan a single
// continuous pass over the window instead of repeatedly rescanning from
// near-scratch on every zero-coverage candidate. That fix means widening
// this window back out to 3 days no longer reintroduces the freeze; it
// just means the scan naturally covers more ground before the auto-expand
// effect below would otherwise have to kick in and double it.
// ─────────────────────────────────────────────────────────────────────────
const INITIAL_SCAN_HOURS = 24 * 3; // 3 days
const MAX_SCAN_HOURS = 24 * 14; // 14 days safety ceiling

const SCAN_DEBOUNCE_MS = 400;
const MAX_PLANS_SHOWN_COLLAPSED = 3;
const MAX_GS_PASSES_SHOWN_COLLAPSED = 3;

export type SelectedGsPassInfo = { station: string; aos: Date; los: Date };

type Props = {
  /** Which wizard step's blocks are visible (see Georeference). */
  section?: MissionPanelSection;
  rectangleBounds: RectangleBounds;
  onBoundsFieldChange: (field: keyof RectangleBounds, raw: string) => void;
  onFieldFocus?: () => void;

  satelliteIds: string[];
  tleData: TleEntry[];

  minRangeKm: number;
  maxRangeKm: number;
  onMinRangeChange: (v: number) => void;
  onMaxRangeChange: (v: number) => void;
  /** Legacy prop — no longer used to cap the search. Kept optional so
   *  existing callers (Georeference.tsx) don't need to change their
   *  signature; StripMode now manages its own expanding window. */
  scanHours?: number;
  frequencySegments: FrequencySegment[];
  onFrequencySegmentsChange: (segments: FrequencySegment[]) => void;

  /** Index into planResult.orbits (one orbit = leader + other satellites). */
  selectedPassIndex: number | null;
  onSelectPass: (index: number) => void;

  viewerRef: React.MutableRefObject<Cesium.Viewer | null>;
  onBack?: () => void;
  onPlanResultChange?: (planResult: StripCapturePlanResult | null) => void;

  groundStations: GroundStation[];
  downloadInGsPass: boolean;
  onToggleDownloadInGsPass: (checked: boolean) => void;
  selectedGsName: string | null;
  onSelectGsName: (name: string) => void;
  onGsPassTimeChange?: (info: SelectedGsPassInfo | null) => void;
};

function formatOffsetMs(ms: number) {
  const sign = ms < 0 ? "-" : "+";
  const totalSec = Math.round(Math.abs(ms) / 1000);
  const m = Math.floor(totalSec / 60);
  const s = totalSec % 60;
  return `${sign}${m}m ${s.toString().padStart(2, "0")}s`;
}

function formatDuration(ms: number) {
  const totalSec = Math.max(0, Math.round(ms / 1000));
  const h = Math.floor(totalSec / 3600);
  const m = Math.floor((totalSec % 3600) / 60);
  const s = totalSec % 60;
  if (h > 0) return `${h}h ${m.toString().padStart(2, "0")}m`;
  return `${m}m ${s.toString().padStart(2, "0")}s`;
}

/** Seconds -> "m:ss". */
function formatClock(sec: number) {
  const s = Math.max(0, Math.round(sec));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
}

/** "HH:MM:SS UTC" — compact time for per-satellite rows (date is on the orbit row). */
function formatTimeUtc(d: Date) {
  return `${d.toISOString().slice(11, 19)} UTC`;
}

const fmtKm2 = (v: number) => v.toLocaleString(undefined, { maximumFractionDigits: 0 });

function Stat({ label, value, tone }: { label: string; value: string; tone?: "good" }) {
  return (
    <div className="rounded-md border border-white/5 bg-white/[0.02] px-2.5 py-2">
      <div className="text-[10px] font-medium uppercase tracking-wider text-[var(--gm-muted)]">{label}</div>
      <div className={`mt-0.5 font-mono text-sm font-semibold ${tone === "good" ? "text-emerald-300" : "text-[oklch(0.95_0_0)]"}`}>
        {value}
      </div>
    </div>
  );
}

function TimeCell({ label, date, warn, tone }: { label: string; date: Date; warn?: boolean; tone?: "good" }) {
  return (
    <div className="flex min-w-0 flex-col">
      <span className="truncate text-[10px] font-medium uppercase tracking-wider text-[var(--gm-muted)]">{label}</span>
      <span
        className={`font-mono text-xs ${warn ? "text-amber-200" : tone === "good" ? "text-emerald-300" : "text-[oklch(0.9_0_0)]"}`}
      >
        {date.toISOString().slice(11, 19)}
      </span>
    </div>
  );
}

/** Human label for the current search window, e.g. "36h" or "3d 12h". */
function formatWindowLabel(hours: number) {
  if (hours < 24) return `${hours}h`;
  const days = Math.floor(hours / 24);
  const rem = hours % 24;
  return rem === 0 ? `${days}d` : `${days}d ${rem}h`;
}

export default function GeoReferenceStripMode({
  section,
  rectangleBounds,
  onBoundsFieldChange,
  onFieldFocus,
  satelliteIds,
  tleData,
  minRangeKm,
  maxRangeKm,
  onMinRangeChange,
  onMaxRangeChange,
  frequencySegments,
  onFrequencySegmentsChange,
  selectedPassIndex,
  onSelectPass,
  viewerRef,
  onBack,
  onPlanResultChange,
  groundStations,
  downloadInGsPass,
  onToggleDownloadInGsPass,
  selectedGsName,
  onSelectGsName,
  onGsPassTimeChange,
}: Props) {
  const hideFor = (s: MissionPanelSection) => !!section && section !== s;
  const [showAllPlans, setShowAllPlans] = useState(false);
  const [expandedPlanIndex, setExpandedPlanIndex] = useState<number | null>(0);
  const [showAllGsPasses, setShowAllGsPasses] = useState(false);

  // Local, self-expanding search window instead of a fixed prop.
  const [windowHours, setWindowHours] = useState(INITIAL_SCAN_HOURS);

  // ── Confirm-gated frequency plan ──────────────────────────────────────
  // The user edits `frequencySegments` freely (fast, local, no orbit
  // search runs). Only once they click "Confirm Frequency Plan" in
  // <FrequencyPlanTable> does `confirmedSegments` get set, and ONLY THEN
  // does planStripCapture run. Editing after that clears it again. This
  // is what stops the planner from being evaluated against an
  // incomplete/mid-edit plan (e.g. a freshly-added 0-duration segment),
  // which is what was producing the "0% coverable" result.
  const [confirmedSegments, setConfirmedSegments] = useState<FrequencySegment[] | null>(null);

  const groupTles = useMemo(
    () => tleData.filter((t) => satelliteIds.includes(t.name)),
    [tleData, satelliteIds],
  );

  const tleByName = useMemo(
    () => Object.fromEntries(groupTles.map((t) => [t.name, t])),
    [groupTles],
  );

  // ── AOI area: exactly the same formula the animation will use. ──
  const aoiAreaKm2 = useMemo(
    () => rectangleAreaKm2(rectangleBounds),
    [rectangleBounds],
  );

  const now = useMemo(() => new Date(), []);
  const scanEnd = useMemo(
    () => new Date(now.getTime() + windowHours * 60 * 60 * 1000),
    [now, windowHours],
  );

  // Minimum elevation of the satellite as seen from the AOI (user input).
  const [minElevationDeg, setMinElevationDeg] = useState(DEFAULT_MIN_ELEVATION_DEG);

  // Tilt is not an input: it follows from the entered ranges (tilt = acos(H / range)).
  const gate = useMemo(
    () => stripGateSummary(minRangeKm, maxRangeKm, minElevationDeg),
    [minRangeKm, maxRangeKm, minElevationDeg],
  );

  const [debouncedBounds, setDebouncedBounds] = useState(rectangleBounds);
  const [debouncedMinRangeKm, setDebouncedMinRangeKm] = useState(minRangeKm);
  const [debouncedMaxRangeKm, setDebouncedMaxRangeKm] = useState(maxRangeKm);
  const [debouncedMinElevationDeg, setDebouncedMinElevationDeg] = useState(minElevationDeg);

  useEffect(() => {
    const id = setTimeout(() => {
      setDebouncedBounds(rectangleBounds);
      setDebouncedMinRangeKm(minRangeKm);
      setDebouncedMaxRangeKm(maxRangeKm);
      setDebouncedMinElevationDeg(minElevationDeg);
    }, SCAN_DEBOUNCE_MS);
    return () => clearTimeout(id);
  }, [rectangleBounds, minRangeKm, maxRangeKm, minElevationDeg]);

  // Whenever the actual search inputs change (new rectangle, new range
  // band, new elevation, or a newly CONFIRMED plan), the previous expanded
  // window no longer means anything — reset back to the initial window.
  useEffect(() => {
    setWindowHours(INITIAL_SCAN_HOURS);
  }, [debouncedBounds, debouncedMinRangeKm, debouncedMaxRangeKm, debouncedMinElevationDeg, confirmedSegments]);

  const isScanPending =
    debouncedBounds !== rectangleBounds ||
    debouncedMinRangeKm !== minRangeKm ||
    debouncedMaxRangeKm !== maxRangeKm ||
    debouncedMinElevationDeg !== minElevationDeg;

  // planStripCapture only ever runs against a CONFIRMED plan — never the
  // live-edited `frequencySegments`. No confirmed plan yet -> no search.
  const planResult: StripCapturePlanResult | null = useMemo(() => {
    if (groupTles.length === 0 || !confirmedSegments) return null;
    return planStripCapture(
      groupTles,
      debouncedBounds,
      now,
      scanEnd,
      debouncedMinRangeKm,
      debouncedMaxRangeKm,
      confirmedSegments,
      { minElevationDeg: debouncedMinElevationDeg },
    );
  }, [
    groupTles, debouncedBounds, now, scanEnd,
    debouncedMinRangeKm, debouncedMaxRangeKm, debouncedMinElevationDeg, confirmedSegments,
  ]);

  // Auto-expansion: if we found nothing in the current window and we
  // haven't hit the safety ceiling yet, double the window. Only runs once
  // a plan has actually been confirmed (planResult stays null otherwise).
  useEffect(() => {
    if (isScanPending) return;
    if (groupTles.length === 0) return;
    if (!confirmedSegments) return;
    if (planResult && planResult.orbits.length > 0) return;
    if (windowHours >= MAX_SCAN_HOURS) return;
    const id = setTimeout(() => {
      setWindowHours((h) => Math.min(MAX_SCAN_HOURS, h * 2));
    }, 50);
    return () => clearTimeout(id);
  }, [planResult, isScanPending, groupTles.length, confirmedSegments, windowHours]);

  const isExpandingSearch =
    !isScanPending &&
    groupTles.length > 0 &&
    !!confirmedSegments &&
    (!planResult || planResult.orbits.length === 0) &&
    windowHours < MAX_SCAN_HOURS;

  useEffect(() => {
    onSelectPass(0);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [debouncedBounds, debouncedMinRangeKm, debouncedMaxRangeKm, debouncedMinElevationDeg, confirmedSegments]);

  // Report the latest combined plan up to Georeference.tsx so it can
  // drive the "Visualize on Map (frequency)" constellation sweep.
  useEffect(() => {
    onPlanResultChange?.(planResult);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [planResult]);

  const orbits = planResult?.orbits ?? [];
  const visibleOrbits = showAllPlans ? orbits : orbits.slice(0, MAX_PLANS_SHOWN_COLLAPSED);

  // Downlink is searched after the whole capture plan (latest LOS).
  const stripCutoffTime = useMemo(() => {
    if (!planResult || planResult.orbits.length === 0) return null;
    return planResult.orbits[planResult.orbits.length - 1].los;
  }, [planResult]);

  const gsSourceTle = useMemo(() => {
    const leaderName =
      (selectedPassIndex !== null ? orbits[selectedPassIndex]?.leaderName : undefined) ??
      orbits[0]?.leaderName;
    return groupTles.find((t) => t.name === leaderName) ?? groupTles[0] ?? null;
  }, [groupTles, orbits, selectedPassIndex]);

  // GS search also uses the same expanding window, from the strip cutoff
  // forward, rather than a fixed 36h cap.
  const gsScanEnd = useMemo(
    () => new Date(now.getTime() + Math.max(windowHours, INITIAL_SCAN_HOURS) * 60 * 60 * 1000),
    [now, windowHours],
  );

  const gsPassesForStrip = useMemo(() => {
    if (!stripCutoffTime || !gsSourceTle) return [];
    return groundStations
      .flatMap((gs) =>
        findPasses(gsSourceTle, gs, now, gsScanEnd).map((p) => ({
          station: gs,
          aos: p.aos,
          los: p.los,
        })),
      )
      .filter((p) => p.aos.getTime() >= stripCutoffTime.getTime())
      .sort((a, b) => a.aos.getTime() - b.aos.getTime());
  }, [stripCutoffTime, gsSourceTle, groundStations, now, gsScanEnd]);

  const visibleGsPasses = showAllGsPasses ? gsPassesForStrip : gsPassesForStrip.slice(0, MAX_GS_PASSES_SHOWN_COLLAPSED);

  useEffect(() => {
    onSelectGsName("");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [debouncedBounds, debouncedMinRangeKm, debouncedMaxRangeKm, debouncedMinElevationDeg]);

  useEffect(() => {
    if (!onGsPassTimeChange) return;
    if (!selectedGsName) {
      onGsPassTimeChange(null);
      return;
    }
    const pass = gsPassesForStrip.find((p) => p.station.name === selectedGsName);
    if (!pass) {
      onGsPassTimeChange(null);
      return;
    }
    onGsPassTimeChange({ station: pass.station.name, aos: pass.aos, los: pass.los });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedGsName, gsPassesForStrip]);

  const handleVisualize = () => {
    const viewer = viewerRef.current;
    if (!viewer || !planResult) return;
    visualizeStripCapture(
      viewer,
      planResult,
      // Leading satellite only, every orbit, one colour per orbit.
      { tleByName, primaryPassIndex: selectedPassIndex ?? 0 },
      { onBack },
    );
  };

  useEffect(() => {
    return () => {
      if (viewerRef.current && !viewerRef.current.isDestroyed()) {
        clearStripVisualization(viewerRef.current);
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const corners: { label: string; latField: keyof RectangleBounds; lonField: keyof RectangleBounds }[] = [
    { label: "Point 1-NW", latField: "north", lonField: "west" },
    { label: "Point 2-NE", latField: "north", lonField: "east" },
    { label: "Point 3-SE", latField: "south", lonField: "east" },
    { label: "Point 4-SW", latField: "south", lonField: "west" },
  ];

  return (
    <div className="space-y-3">
      {/* ── Capture Area Bounds ── */}
      <div hidden={hideFor("reference")} className="rounded-lg border border-white/5 bg-[oklch(0.13_0.02_255)] p-3.5">
        <div className="mb-3 flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wider text-[var(--gm-muted)]">
          <Square className="size-3.5 text-[oklch(0.75_0.12_220)]" />
          Capture area
        </div>

        <div className="grid grid-cols-2 gap-3">
          {corners.map(({ label, latField, lonField }) => (
            <div key={label} className="rounded border border-white/10 bg-white/[0.02] p-2.5">
              <div className="mb-2 text-[10px] font-bold uppercase tracking-wider text-[oklch(0.55_0.02_250)]">
                {label}
              </div>
              <div className="grid grid-cols-2 gap-2">
                <label className="block">
                  <span className="mb-1 block text-[9px] font-bold uppercase tracking-wider text-[oklch(0.5_0.02_250)]">
                    Lat
                  </span>
                  <input
                    type="text"
                    inputMode="decimal"
                    value={rectangleBounds[latField]}
                    onChange={(e) => onBoundsFieldChange(latField, e.target.value)}
                    onFocus={onFieldFocus}
                    className="w-full rounded border border-white/10 bg-[oklch(0.14_0.03_250)]/70 px-2 py-1.5 text-xs font-semibold text-[oklch(0.9_0_0)] focus:outline-none focus:ring-1 focus:ring-[oklch(0.75_0.12_220)]/40"
                  />
                </label>
                <label className="block">
                  <span className="mb-1 block text-[9px] font-bold uppercase tracking-wider text-[oklch(0.5_0.02_250)]">
                    Lon
                  </span>
                  <input
                    type="text"
                    inputMode="decimal"
                    value={rectangleBounds[lonField]}
                    onChange={(e) => onBoundsFieldChange(lonField, e.target.value)}
                    onFocus={onFieldFocus}
                    className="w-full rounded border border-white/10 bg-[oklch(0.14_0.03_250)]/70 px-2 py-1.5 text-xs font-semibold text-[oklch(0.9_0_0)] focus:outline-none focus:ring-1 focus:ring-[oklch(0.75_0.12_220)]/40"
                  />
                </label>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-2.5 flex items-center gap-2 rounded-md border border-white/5 bg-white/[0.02] px-3 py-2 text-xs">
          <Waypoints className="size-3.5 text-[oklch(0.75_0.12_220)]" />
          <span className="text-[var(--gm-muted)]">Operations mode</span>
          <span className="ml-auto font-semibold text-[oklch(0.92_0_0)]">Strip</span>
          <span className="rounded border border-[oklch(0.75_0.12_220)]/30 px-1.5 text-[10px] text-[oklch(0.8_0.1_220)]">auto</span>
        </div>
      </div>

      {/* ── Range, elevation and tilt (first), then frequency scheduling ── */}
      <div hidden={hideFor("reference")}>
        <CaptureLimits
          minRangeKm={minRangeKm}
          maxRangeKm={maxRangeKm}
          minElevationDeg={minElevationDeg}
          onMinRangeChange={onMinRangeChange}
          onMaxRangeChange={onMaxRangeChange}
          onMinElevationChange={setMinElevationDeg}
          minRangeInvalid={(v) => (v >= maxRangeKm ? "Must be below max range" : null)}
          maxRangeInvalid={(v) => (v <= minRangeKm ? "Must be above min range" : null)}
          gate={gate}
        />
      </div>

      {/* ── Frequency and Time ──
          Strip mode passes locked/onConfirm/onEdit here — this is what
          turns on the Confirm/Edit row inside FrequencyPlanTable. Editing
          only touches `frequencySegments` (fast, local); the orbit search
          only fires once `confirmedSegments` is set via Confirm. ── */}
      <div hidden={hideFor("reference")} className={section ? "" : "border-t border-white/5 pt-4"}>
        {!section && (
          <h3 className="mb-2 text-[11px] font-bold uppercase tracking-wider text-[oklch(0.6_0.02_250)]">
            Frequency and Time
          </h3>
        )}
        <FrequencyPlanTable
          segments={frequencySegments}
          onSegmentsChange={onFrequencySegmentsChange}
          locked={confirmedSegments !== null}
          onConfirm={() => setConfirmedSegments(frequencySegments)}
          onEdit={() => setConfirmedSegments(null)}
        />
      </div>

      {/* ── Coverage plan ── */}
      <div hidden={hideFor("orbits")} className="rounded-lg border border-white/5 bg-[oklch(0.13_0.02_255)] p-3.5">
        <div className="mb-3 flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wider text-[var(--gm-muted)]">
          <Layers className="size-3.5 text-[oklch(0.75_0.12_220)]" />
          Coverage plan
          <span
            title={
              `Mission start: swath first touches the rectangle within limits · ` +
              `End: start + plan · AOS: start − ${AOS_LEAD_SECONDS / 60} min · LOS: elevation < ${minElevationDeg}° · ` +
              `satellites within ${FORMATION_WINDOW_SECONDS / 60} min form one orbit · ` +
              `search window ${formatWindowLabel(windowHours)}`
            }
          >
            <Info className="size-3 shrink-0 text-[oklch(0.45_0.02_250)]" />
          </span>
        </div>

        <div className="mb-3 grid grid-cols-3 gap-2">
          <Stat label="AOI" value={`${fmtKm2(aoiAreaKm2)} km²`} />
          <Stat
            label="Covered"
            value={planResult && orbits.length > 0 ? formatCoveragePercent(planResult.totalCoveredFraction) : "—"}
            tone="good"
          />
          <Stat
            label="Remaining"
            value={planResult && orbits.length > 0 ? `${fmtKm2(planResult.remainingAreaKm2)} km²` : "—"}
          />
        </div>

        {!confirmedSegments ? (
          <p className="py-3 text-center text-xs text-[var(--gm-muted)]">Confirm the frequency plan to search for orbits.</p>
        ) : groupTles.length === 0 ? (
          <p className="py-3 text-center text-xs text-[var(--gm-muted)]">No satellites in this constellation group.</p>
        ) : isScanPending ? (
          <p className="py-3 text-center text-xs text-[var(--gm-muted)]">Scanning…</p>
        ) : isExpandingSearch ? (
          <p className="py-3 text-center text-xs text-[var(--gm-muted)]">
            Nothing in the next {formatWindowLabel(windowHours)} — widening search…
          </p>
        ) : !planResult || orbits.length === 0 ? (
          <div className="flex items-center gap-2 rounded-md border border-amber-500/25 bg-amber-500/10 px-3 py-2 text-xs text-amber-200">
            <AlertTriangle className="size-3.5 shrink-0" />
            No pass within {formatWindowLabel(MAX_SCAN_HOURS)} for these limits.
          </div>
        ) : (
          <>
            <div
              className={`mb-3 flex items-center gap-2 rounded-md border px-3 py-2 text-xs ${
                planResult.fullyCovered
                  ? "border-emerald-500/25 bg-emerald-500/10 text-emerald-200"
                  : "border-amber-500/25 bg-amber-500/10 text-amber-200"
              }`}
            >
              {planResult.fullyCovered ? <CheckCircle2 className="size-3.5 shrink-0" /> : <AlertTriangle className="size-3.5 shrink-0" />}
              {planResult.fullyCovered
                ? orbits.length === 1
                  ? "Covered in one orbit."
                  : `Covered in ${orbits.length} orbits.`
                : `${formatCoveragePercent(planResult.totalCoveredFraction)} coverable in ${formatWindowLabel(windowHours)} (${orbits.length} orbit${orbits.length === 1 ? "" : "s"}).`}
            </div>

            <button
              type="button"
              onClick={handleVisualize}
              disabled={!viewerRef.current}
              className="mb-3 flex w-full items-center justify-center gap-1.5 rounded-md border border-[oklch(0.75_0.12_220)]/40 bg-[oklch(0.75_0.12_220)]/10 py-2 text-xs font-semibold tracking-wide text-[oklch(0.88_0.08_220)] transition-colors hover:bg-[oklch(0.75_0.12_220)]/20 disabled:cursor-not-allowed disabled:opacity-50"
            >
              <Eye className="size-3.5" />
              Visualize capture plan
            </button>

            <div className="space-y-2" role="radiogroup" aria-label="Capture orbit plan">
              {visibleOrbits.map((orbit, i) => {
                const active = selectedPassIndex === i;
                const isExpanded = expandedPlanIndex === i;
                const absentSats = groupTles.filter((t) => !orbit.passes.some((p) => p.satelliteName === t.name));

                return (
                  <div
                    key={`${orbit.leaderName}-${orbit.missionStart.getTime()}`}
                    className={`rounded-md border transition-colors ${
                      active ? "border-[oklch(0.75_0.12_220)]/45 bg-[oklch(0.75_0.12_220)]/[0.06]" : "border-white/5 bg-white/[0.02]"
                    }`}
                  >
                    <button
                      type="button"
                      onClick={() => {
                        onSelectPass(i);
                        setExpandedPlanIndex(isExpanded ? null : i);
                      }}
                      className="flex w-full flex-col gap-2 px-3 py-2.5 text-left"
                    >
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-semibold text-[oklch(0.95_0_0)]">Orbit {orbit.index + 1}</span>
                        <span className="truncate text-xs text-[var(--gm-muted)]">
                          {orbit.leaderName}
                          {orbit.passes.length > 1 ? ` +${orbit.passes.length - 1}` : ""} · {orbit.missionStart.toISOString().slice(0, 10)}
                        </span>
                        {orbit.truncatedByLos && (
                          <span
                            title="LOS comes before mission end — sensor keeps capturing until mission end"
                            className="flex shrink-0 items-center gap-1 rounded border border-amber-500/30 bg-amber-500/10 px-1.5 py-px text-[10px] font-medium text-amber-200"
                          >
                            <AlertTriangle className="size-3" /> LOS
                          </span>
                        )}
                        <span className="ml-auto font-mono text-sm font-semibold text-emerald-300">
                          +{formatCoveragePercent(orbit.newlyCoveredFraction)}
                        </span>
                        {isExpanded ? (
                          <ChevronUp className="size-4 shrink-0 text-[var(--gm-muted)]" />
                        ) : (
                          <ChevronDown className="size-4 shrink-0 text-[var(--gm-muted)]" />
                        )}
                      </div>

                      <div className="grid grid-cols-5 gap-2">
                        <TimeCell label="AOS" date={orbit.aos} />
                        <TimeCell label="Mission start" date={orbit.missionStart} />
                        <TimeCell label="Coverage done" date={orbit.aoiCaptureEnd} tone="good" />
                        <TimeCell label="Mission end" date={orbit.missionEnd} />
                        <TimeCell label="LOS" date={orbit.los} warn={orbit.truncatedByLos} />
                      </div>

                      <div className="flex items-center gap-3 font-mono text-[11px] text-[var(--gm-muted)]">
                        <span>
                          Capture time{" "}
                          <span className="font-semibold text-[#7fe3ff]">
                            {formatClock(
                              Math.min(
                                orbit.aoiCaptureSeconds,
                                (orbit.missionEnd.getTime() - orbit.missionStart.getTime()) / 1000,
                              ),
                            )}
                          </span>
                        </span>
                        <div className="h-1 flex-1 overflow-hidden rounded-full bg-white/[0.06]">
                          <div
                            className="h-full rounded-full bg-[oklch(0.72_0.12_220)]"
                            style={{ width: `${Math.min(100, orbit.cumulativeCoveredFraction * 100)}%` }}
                          />
                        </div>
                        <span>
                          Total {formatCoveragePercent(orbit.cumulativeCoveredFraction)} · {fmtKm2(orbit.remainingAreaKm2)} km² left
                        </span>
                      </div>
                    </button>

                    {isExpanded && (
                      <div className="border-t border-white/5 px-3 py-2.5">
                        {orbit.truncatedByLos && (
                          <div className="mb-2 flex items-start gap-2 rounded-md border border-amber-500/25 bg-amber-500/10 px-2.5 py-1.5 text-[11px] text-amber-200">
                            <AlertTriangle className="mt-px size-3.5 shrink-0" />
                            LOS before mission end ({orbit.passes.filter((p) => p.truncatedByLos).map((p) => p.satelliteName).join(", ")}) — capture continues.
                          </div>
                        )}

                        <div className="grid grid-cols-[1fr_auto_auto_auto_auto_auto] items-center gap-x-3 gap-y-1 text-[11px]">
                          <span className="text-[10px] uppercase tracking-wider text-[var(--gm-muted)]">Satellite</span>
                          <span className="text-[10px] uppercase tracking-wider text-[var(--gm-muted)]">Offset</span>
                          <span className="text-[10px] uppercase tracking-wider text-[var(--gm-muted)]">Start</span>
                          <span className="text-[10px] uppercase tracking-wider text-[var(--gm-muted)]" title="Time from this satellite's mission start until its swath leaves the AOI">Capture</span>
                          <span className="text-[10px] uppercase tracking-wider text-[var(--gm-muted)]">Tilt</span>
                          <span className="text-right text-[10px] uppercase tracking-wider text-[var(--gm-muted)]">Adds</span>
                          {orbit.passes.map((p) => {
                            const satTle = groupTles.find((t) => t.name === p.satelliteName);
                            const color = satTle?.color ?? fallbackColorForName(p.satelliteName, OTHER_SAT_FALLBACK_COLORS);
                            const cp = p.capturePoint;
                            const st = p.satelliteState;
                            const tip =
                              `AOS ${formatTimeUtc(p.aos)} · End ${formatTimeUtc(p.missionEnd)} · LOS ${formatTimeUtc(p.los)}\n` +
                              `Starts on ${cp.label}: range ${cp.slantRangeKm.toFixed(0)} km, el ${cp.elevationDeg.toFixed(0)}°, tilt ${cp.tiltDeg.toFixed(1)}°` +
                              (st ? `\nSat at start: ${st.lat.toFixed(2)}°, ${st.lon.toFixed(2)}°, ${st.altitudeKm.toFixed(0)} km, ${st.velocityKmPerSec.toFixed(2)} km/s` : "") +
                              (p.truncatedByLos ? `\nLOS before mission end (alert only)` : "");
                            return (
                              <div key={p.satelliteName} className="contents">
                                <span className="flex min-w-0 cursor-help items-center gap-1.5" title={tip}>
                                  <span className="size-1.5 shrink-0 rounded-full" style={{ background: color }} />
                                  <span className="truncate font-medium text-[oklch(0.92_0_0)]">{p.satelliteName}</span>
                                  {p.truncatedByLos && <AlertTriangle className="size-3 shrink-0 text-amber-300" />}
                                </span>
                                <span className="font-mono text-[var(--gm-muted)]">{p.isLeader ? "lead" : formatOffsetMs(p.offsetFromLeaderMs)}</span>
                                <span className="font-mono text-[oklch(0.85_0_0)]">{formatTimeUtc(p.missionStart).slice(0, 8)}</span>
                                <span className="font-mono text-[#7fe3ff]">{formatClock(Math.min(p.aoiCaptureSeconds, p.missionSeconds))}</span>
                                <span className="font-mono text-[oklch(0.85_0_0)]">
                                  {p.look.tiltDeg.toFixed(1)}° {p.look.side === "left" ? "L" : "R"}
                                </span>
                                <span className="text-right font-mono text-emerald-300">+{formatCoveragePercent(p.newlyCoveredFraction)}</span>
                              </div>
                            );
                          })}
                        </div>

                        {absentSats.length > 0 && (
                          <p className="mt-2 text-[11px] text-[var(--gm-muted)]">
                            No new area: {absentSats.map((t) => t.name).join(", ")}
                          </p>
                        )}

                        <p className="mt-2 text-[11px] text-[var(--gm-muted)]">
                          Swath enters at {orbit.passes[0].entrySideLabel}, leaves at {orbit.passes[0].exitSideLabel} · heading{" "}
                          {orbit.passes[0].orientation.headingDeg.toFixed(0)}°
                        </p>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            {orbits.length > MAX_PLANS_SHOWN_COLLAPSED && (
              <button
                type="button"
                onClick={() => setShowAllPlans((v) => !v)}
                className="mt-2 flex w-full items-center justify-center gap-1 text-xs font-medium text-[oklch(0.75_0.1_220)] hover:text-[oklch(0.88_0.1_220)]"
              >
                {showAllPlans ? "Show fewer" : `Show all ${orbits.length} orbits`}
                <ChevronDown className={`size-3.5 transition-transform ${showAllPlans ? "rotate-180" : ""}`} />
              </button>
            )}
          </>
        )}
      </div>

      {/* ── Strip mode's own Ground Station pass section ── */}
      {planResult && orbits.length > 0 && (
        <div hidden={hideFor("downlink")}>
          <label className="mb-2 flex cursor-pointer items-center gap-2 text-[11px] font-bold uppercase tracking-wider text-[oklch(0.6_0.02_250)]">
            <input
              type="checkbox"
              checked={downloadInGsPass}
              onChange={(e) => onToggleDownloadInGsPass(e.target.checked)}
              className="size-3.5 shrink-0 rounded accent-[oklch(0.75_0.12_220)]"
            />
            <span>Download data in upcoming Ground Station pass and schedule now</span>
          </label>

          {downloadInGsPass && (
            <>
              <div className="mb-2 flex items-center gap-1.5">
                <h3 className="text-[11px] font-bold uppercase tracking-wider text-[oklch(0.6_0.02_250)]">
                  Select Upcoming Ground Station Pass
                </h3>
                <span className="text-[10px] font-semibold normal-case text-[oklch(0.5_0.02_250)]">
                  (after the full capture plan)
                </span>
              </div>

              {!gsSourceTle ? (
                <p className="py-4 text-center text-xs text-[oklch(0.5_0.02_250)]">
                  No satellites selected in this Constellation Group yet.
                </p>
              ) : (
                <>
                  <div className="space-y-2" role="radiogroup" aria-label="Ground station pass">
                    {visibleGsPasses.map((p, idx) => {
                      const checked = selectedGsName === p.station.name;
                      return (
                        <label
                          key={`${p.station.name}-${p.aos.getTime()}-${idx}`}
                          className={`flex cursor-pointer flex-col gap-1.5 rounded-lg border px-3.5 py-3 transition-colors ${
                            checked ? "border-[oklch(0.75_0.12_220)]/50 bg-[oklch(0.75_0.12_220)]/10" : "border-white/5 bg-white/[0.02] hover:border-white/15"
                          }`}
                        >
                          <div className="flex items-center gap-2">
                            <input
                              type="radio"
                              name="strip-gs-pass-selection"
                              checked={checked}
                              onChange={() => onSelectGsName(p.station.name)}
                              className="size-4 shrink-0 accent-[oklch(0.75_0.12_220)]"
                            />
                            <Radio className="size-4 shrink-0 text-[oklch(0.7_0.02_250)]" />
                            <span className="min-w-0 flex-1 truncate text-sm font-semibold text-[oklch(0.9_0_0)]">
                              {p.station.name}
                            </span>
                            <span
                              className="inline-block size-1.5 shrink-0 rounded-full"
                              style={{ background: p.station.color ?? "#7dd3fc" }}
                            />
                          </div>

                          <div className="flex items-center gap-1.5 pl-6 text-xs">
                            <SatelliteIcon className="size-3.5 shrink-0 text-emerald-400" />
                            <span className="min-w-0 truncate font-semibold text-[oklch(0.85_0_0)]">{gsSourceTle.name}</span>
                            <span className="ml-auto whitespace-nowrap text-[oklch(0.6_0.02_250)]">
                              {formatDuration(p.los.getTime() - p.aos.getTime())}
                            </span>
                          </div>

                          <div className="pl-6 text-[11px] text-[var(--gm-muted)]">
                            {p.station.lat.toFixed(4)}° N, {p.station.lon.toFixed(4)}° E
                          </div>

                          <div className="pl-6 text-xs font-medium text-[oklch(0.75_0_0)]">{formatUtc(p.aos)}</div>
                          <div className="pl-6 text-center text-[11px] text-[var(--gm-muted)]">
                            AOS {p.aos.toISOString().slice(11, 19)} · LOS {p.los.toISOString().slice(11, 19)}
                          </div>
                        </label>
                      );
                    })}
                  </div>

                  {gsPassesForStrip.length > MAX_GS_PASSES_SHOWN_COLLAPSED && (
                    <button
                      type="button"
                      onClick={() => setShowAllGsPasses((v) => !v)}
                      className="mt-2 flex w-full items-center justify-center gap-1 text-xs font-semibold text-[oklch(0.7_0.1_220)] hover:text-[oklch(0.85_0.1_220)]"
                    >
                      {showAllGsPasses ? "Show fewer passes" : "View more passes"}
                      <ChevronDown className={`size-3.5 transition-transform ${showAllGsPasses ? "rotate-180" : ""}`} />
                    </button>
                  )}

                  {gsPassesForStrip.length === 0 && (
                    <p className="py-4 text-center text-xs text-[oklch(0.5_0.02_250)]">
                      No ground station passes found for {gsSourceTle.name} after the full capture plan.
                    </p>
                  )}
                </>
              )}
            </>
          )}
        </div>
      )}
    </div>
  );
}
