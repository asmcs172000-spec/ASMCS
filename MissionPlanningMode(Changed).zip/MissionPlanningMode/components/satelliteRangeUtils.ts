import * as satellite from "satellite.js";

// ─── Geometry ─────────────────────────────────────────────────────────────
//
// CORRECT RANGE MODEL
// --------------------
// The only physically correct way to get slant range, elevation, and
// azimuth between a ground point and a satellite is to propagate the
// satellite's real TLE (SGP4) to the instant in question, convert both
// positions into a common Earth-fixed frame (ECEF), and solve the real
// look-angle triangle. That is exactly what `rangeAtTime()` below does via
// satellite.js's `eciToEcf` + `ecfToLookAngles`.
//
// Every "range to a known ground point" surfaced anywhere in this app
// should come from `rangeAtTime()`. Do not introduce a second, independent
// range formula for that purpose.
//
// CAPTURE-AREA MODEL (forward, spatial — no ground station, no time search)
// --------------------------------------------------------------------------
// The capture area is NOT tied to any ground station or fixed reference
// point. At the exact instant the user selects, we:
//   1. Read the satellite's real TLE position (lat/lon/altitude) at that
//      instant.
//   2. Read its heading (direction of travel) at that same instant.
//   3. Looking AHEAD along that heading — spatially ahead, same instant,
//      no propagating through future time — find the ground point where
//      the satellite's slant range would be exactly 900 km. That is where
//      capture starts. Similarly find the 1100 km point, where the capture
//      window ends.
// This is pure spherical geometry (law of cosines on the Earth-centered
// triangle satellite/Earth-center/ground-point) evaluated at ONE moment in
// time. See `computeForwardCaptureArea`.
//
// SPOT-MODE RANGE-GATED ORBITS (Georeference target selection)
// --------------------------------------------------------------------------
// The target's horizon pass (AOS/LOS) is found exactly like a ground
// station pass. Internally, at each time step inside that pass, the real
// slant range to the target (rangeAtTime's underlying calculation) is
// checked against the user's [minRangeKm, maxRangeKm] band — purely to
// find the first instant the range enters that band. That instant becomes
// AOS. Only ONE range number is ever kept or returned per orbit: the range
// at that AOS instant. Every other range sample taken during the internal
// search is scratch work and is discarded immediately — it is never
// stored, displayed, or returned. LOS is always the natural horizon-set
// time and is never affected by range. See `findRangeGatedOrbits`.

export const SATELLITE_ALTITUDE_KM = 551;
const EARTH_RADIUS_KM = 6378.137; // WGS84 equatorial radius

// ── General usable link/imaging envelope ──
export const MIN_LINK_RANGE_KM = 551;   // nadir floor — satellite directly overhead
export const MAX_LINK_RANGE_KM = 1800;  // usable range ceiling

export const MIN_ORBIT_RANGE_KM = 1000; // Georeference orbit-selection threshold
export const MAX_ELEVATION_DEG = 35;    // orbits above this elevation sit too close

/** Is this range physically inside the general usable link/imaging
 *  envelope (551–1800 km), regardless of the narrower capture window? */
export function isWithinLinkRange(rangeKm: number): boolean {
  return rangeKm >= MIN_LINK_RANGE_KM && rangeKm <= MAX_LINK_RANGE_KM;
}

/** Capture range window: capture runs while slant range to the ground
 *  point sits inside this band. */
export const CAPTURE_RANGE_MIN_KM = 900;
export const CAPTURE_RANGE_MAX_KM = 1100;

export function isWithinCaptureWindow(rangeKm: number): boolean {
  return rangeKm >= CAPTURE_RANGE_MIN_KM && rangeKm <= CAPTURE_RANGE_MAX_KM;
}

/** @deprecated Flat-Earth, fixed-altitude approximation. Use `rangeAtTime`. */
export function slantRangeKm(elevationDeg: number, altitudeKm: number = SATELLITE_ALTITUDE_KM): number {
  if (elevationDeg <= 0) return Infinity;
  const elevRad = (elevationDeg * Math.PI) / 180;
  return altitudeKm / Math.sin(elevRad);
}

/** @deprecated See `slantRangeKm`. */
export function groundDistanceKm(elevationDeg: number, altitudeKm: number = SATELLITE_ALTITUDE_KM): number {
  const range = slantRangeKm(elevationDeg, altitudeKm);
  if (!Number.isFinite(range)) return Infinity;
  return Math.sqrt(Math.max(range * range - altitudeKm * altitudeKm, 0));
}

// ─── Types ────────────────────────────────────────────────────────────────

export type TleEntry = {
  name: string;
  tle1: string;
  tle2: string;
  color?: string;
};

/** Any point on the ground the satellite's range can be measured against —
 *  used for ground-station passes and for Spot/Area targets. */
export type GroundPoint = {
  name: string;
  lat: number;
  lon: number;
  color?: string;
};

/** @deprecated alias kept for compatibility. */
export type GroundStation = GroundPoint;

export type Pass = {
  aos: Date;
  los: Date;
  maxElevationDeg: number;
  rangeAtMaxElevationKm: number;
};

export const DEFAULT_GROUND_STATIONS: GroundPoint[] = [
  { name: "Rawalpindi GS", lat: 33.6167, lon: 73.0992, color: "#7dd3fc" },
  { name: "Azerbaijan GS", lat: 40.39, lon: 49.29, color: "#fef08a" },
  { name: "Turkey GS", lat: 41.1037, lon: 29.0261, color: "#f472b6" },
];

export const OTHER_SAT_FALLBACK_COLORS = [
  "#7dd3fc", "#fbbf24", "#f472b6", "#a78bfa", "#34d399", "#fb7185", "#facc15", "#60a5fa",
];

const toDeg = (rad: number) => (rad * 180) / Math.PI;
const toRad = (deg: number) => (deg * Math.PI) / 180;
const STEP_SECONDS = 15;

function normalizeLon(lon: number): number {
  while (lon > 180) lon -= 360;
  while (lon < -180) lon += 360;
  return lon;
}

export type RangeSnapshot = {
  elevationDeg: number;
  rangeKm: number;
  azimuthDeg: number;
};

/** Single shared low-level lookup: real elevation/range/azimuth of a
 *  propagated satrec as seen from `point` at instant `t`. Everything else
 *  in this file that needs real range/elevation goes through this. */
function lookAnglesAt(
  satrec: satellite.SatRec,
  point: GroundPoint,
  t: Date,
): RangeSnapshot | null {
  const geodetic = {
    latitude: satellite.degreesToRadians(point.lat),
    longitude: satellite.degreesToRadians(point.lon),
    height: 0,
  };
  const gmst = satellite.gstime(t);
  const pv = satellite.propagate(satrec, t);
  if (!pv?.position) return null;
  const look = satellite.ecfToLookAngles(geodetic, satellite.eciToEcf(pv.position, gmst));
  return {
    elevationDeg: toDeg(look.elevation),
    rangeKm: look.rangeSat,
    azimuthDeg: toDeg(look.azimuth),
  };
}

function elevationAt(satrec: satellite.SatRec, point: GroundPoint, t: Date): number {
  return lookAnglesAt(satrec, point, t)?.elevationDeg ?? -180;
}

/** Actual (propagated) slant range, elevation, and azimuth of `tle` as seen
 * from ground point `point` at a single instant `t`. */
export function rangeAtTime(tle: TleEntry, point: GroundPoint, t: Date): RangeSnapshot | null {
  const satrec = satellite.twoline2satrec(tle.tle1, tle.tle2);
  return lookAnglesAt(satrec, point, t);
}

function refineCrossing(satrec: satellite.SatRec, point: GroundPoint, t1: Date, t2: Date): Date {
  let lo = t1.getTime();
  let hi = t2.getTime();
  while (hi - lo > 1000) {
    const mid = (lo + hi) / 2;
    const elevLo = elevationAt(satrec, point, new Date(lo));
    const elevMid = elevationAt(satrec, point, new Date(mid));
    if (elevLo * elevMid <= 0) hi = mid;
    else lo = mid;
  }
  return new Date(hi);
}

/** Bisects down to the instant real slant range first enters
 *  [minRangeKm, maxRangeKm], between a known out-of-band instant (t1) and
 *  a known in-band instant (t2). Used only to refine AOS for range-gated
 *  orbits — the result of each probe is discarded immediately, only the
 *  final refined Date is kept. */
function refineRangeEntryCrossing(
  satrec: satellite.SatRec,
  point: GroundPoint,
  t1: Date,
  t2: Date,
  minRangeKm: number,
  maxRangeKm: number,
): Date {
  let lo = t1.getTime();
  let hi = t2.getTime();
  while (hi - lo > 1000) {
    const mid = (lo + hi) / 2;
    const look = lookAnglesAt(satrec, point, new Date(mid));
    const inBand = look ? look.rangeKm >= minRangeKm && look.rangeKm <= maxRangeKm : false;
    if (inBand) hi = mid;
    else lo = mid;
  }
  return new Date(hi);
}

/** Every AOS/LOS pass of `tle` over `point` within [start, end] (horizon 0°).
 *  Used for the ground-station comms-pass list — unrelated to the
 *  capture-area geometry below. */
export function findPasses(tle: TleEntry, point: GroundPoint, start: Date, end: Date): Pass[] {
  const satrec = satellite.twoline2satrec(tle.tle1, tle.tle2);
  const passes: Pass[] = [];

  let inPass = false;
  let passStart: Date | null = null;
  let maxElev = -90;
  let maxElevTime: Date | null = null;
  let prevTime: Date | null = null;

  for (let t = new Date(start); t <= end; t = new Date(t.getTime() + STEP_SECONDS * 1000)) {
    const elev = elevationAt(satrec, point, t);

    if (elev >= 0 && !inPass) {
      inPass = true;
      passStart = prevTime ? refineCrossing(satrec, point, prevTime, t) : new Date(t);
      maxElev = elev;
    }
    if (inPass && elev > maxElev) {
      maxElev = elev;
      maxElevTime = new Date(t);
    }
    if (elev < 0 && inPass) {
      inPass = false;
      const los = prevTime ? refineCrossing(satrec, point, t, prevTime) : new Date(t);
      if (passStart) {
        const peakTime = maxElevTime ?? passStart;
        const snapshot = rangeAtTime(tle, point, peakTime);
        passes.push({
          aos: passStart,
          los,
          maxElevationDeg: maxElev,
          rangeAtMaxElevationKm: snapshot ? snapshot.rangeKm : slantRangeKm(maxElev),
        });
      }
      passStart = null;
      maxElev = -90;
      maxElevTime = null;
    }
    prevTime = new Date(t);
  }

  return passes;
}

// ─── Forward capture-area geometry (spatial, single instant) ──────────────

/** Great-circle initial bearing (degrees, 0=N, clockwise) from point 1 to
 *  point 2. */
function initialBearingDeg(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const φ1 = toRad(lat1), φ2 = toRad(lat2);
  const Δλ = toRad(lon2 - lon1);
  const y = Math.sin(Δλ) * Math.cos(φ2);
  const x = Math.cos(φ1) * Math.sin(φ2) - Math.sin(φ1) * Math.cos(φ2) * Math.cos(Δλ);
  return (toDeg(Math.atan2(y, x)) + 360) % 360;
}

/** Destination point given a start lat/lon, bearing, and angular distance
 *  (radians — the central angle at Earth's center, not a km distance). */
function destinationPoint(lat1: number, lon1: number, bearingDeg: number, angularDistRad: number) {
  const φ1 = toRad(lat1), λ1 = toRad(lon1), θ = toRad(bearingDeg);
  const φ2 = Math.asin(
    Math.sin(φ1) * Math.cos(angularDistRad) + Math.cos(φ1) * Math.sin(angularDistRad) * Math.cos(θ),
  );
  const λ2 =
    λ1 +
    Math.atan2(
      Math.sin(θ) * Math.sin(angularDistRad) * Math.cos(φ1),
      Math.cos(angularDistRad) - Math.sin(φ1) * Math.sin(φ2),
    );
  return { lat: toDeg(φ2), lon: normalizeLon(toDeg(λ2)) };
}

/** Central angle (radians) between the sub-satellite point and a ground
 *  point that would produce slant range `rangeKm`, given the satellite's
 *  current altitude `altKm`. Spherical-Earth law of cosines on the
 *  satellite/Earth-center/ground-point triangle. */
function angularDistanceForRange(rangeKm: number, altKm: number): number {
  const Rs = EARTH_RADIUS_KM + altKm; // satellite's distance from Earth's center
  const Re = EARTH_RADIUS_KM;
  let cosTheta = (Rs * Rs + Re * Re - rangeKm * rangeKm) / (2 * Rs * Re);
  cosTheta = Math.max(-1, Math.min(1, cosTheta));
  return Math.acos(cosTheta);
}

export type ForwardCaptureArea = {
  /** Satellite's own real TLE position at the selected instant. */
  satelliteLat: number;
  satelliteLon: number;
  altitudeKm: number;
  /** Direction of travel (degrees, 0=N, clockwise) at that instant. */
  headingDeg: number;
  /** Ground point ahead of the satellite where slant range = 900 km —
   *  capture starts here. */
  startLat: number;
  startLon: number;
  startRangeKm: number;
  /** Ground point ahead where slant range = 1100 km — capture window ends
   *  here. */
  endLat: number;
  endLon: number;
  endRangeKm: number;
};

/**
 * At the EXACT instant `t` the user selected: read the satellite's real TLE
 * position and heading, then — purely spatially, at that same instant, no
 * time propagation — find the ground point ahead of it (along its heading)
 * where slant range is 900 km (capture start) and 1100 km (capture end).
 *
 * No ground station, no external reference point, no time-search. Returns
 * null only if the TLE can't be propagated at `t`.
 */
export function computeForwardCaptureArea(tle: TleEntry, t: Date): ForwardCaptureArea | null {
  const satrec = satellite.twoline2satrec(tle.tle1, tle.tle2);
  const pv = satellite.propagate(satrec, t);
  if (!pv?.position) return null;

  const gmst = satellite.gstime(t);
  const gd = satellite.eciToGeodetic(pv.position, gmst);
  const satLat = toDeg(gd.latitude);
  const satLon = normalizeLon(toDeg(gd.longitude));
  const altKm = gd.height;

  // Heading at this instant: sample 1 second later along the real
  // propagated orbit and take the bearing between the two sub-satellite
  // points. This is the satellite's actual direction of travel right now,
  // derived from the TLE — not an assumption.
  const t2 = new Date(t.getTime() + 1000);
  const pv2 = satellite.propagate(satrec, t2);
  if (!pv2?.position) return null;
  const gd2 = satellite.eciToGeodetic(pv2.position, satellite.gstime(t2));
  const lat2 = toDeg(gd2.latitude);
  const lon2 = normalizeLon(toDeg(gd2.longitude));
  const heading = initialBearingDeg(satLat, satLon, lat2, lon2);

  const thetaStart = angularDistanceForRange(CAPTURE_RANGE_MIN_KM, altKm);
  const thetaEnd = angularDistanceForRange(CAPTURE_RANGE_MAX_KM, altKm);

  const startPoint = destinationPoint(satLat, satLon, heading, thetaStart);
  const endPoint = destinationPoint(satLat, satLon, heading, thetaEnd);

  return {
    satelliteLat: satLat,
    satelliteLon: satLon,
    altitudeKm: altKm,
    headingDeg: heading,
    startLat: startPoint.lat,
    startLon: startPoint.lon,
    startRangeKm: CAPTURE_RANGE_MIN_KM,
    endLat: endPoint.lat,
    endLon: endPoint.lon,
    endRangeKm: CAPTURE_RANGE_MAX_KM,
  };
}

// ─── Spot-mode range-gated orbits (Georeference target selection) ─────────

/** A horizon pass (found exactly like a ground-station pass) whose AOS has
 *  been pulled forward to the first instant real slant range to the target
 *  enters [minRangeKm, maxRangeKm]. Only that ONE range value is kept —
 *  `rangeAtAosKm`. Every other range sample taken while searching for that
 *  instant is discarded and never surfaced. LOS is the natural horizon-set
 *  time and is never gated by range. */
export type SpotOrbit = Pass & {
  /** Real slant range (km) to the target at the moment AOS qualified.
   *  The only range value reported for this orbit. */
  rangeAtAosKm: number;
};

export function findRangeGatedOrbits(
  tle: TleEntry,
  target: GroundPoint,
  start: Date,
  end: Date,
  minRangeKm: number,
  maxRangeKm: number,
): SpotOrbit[] {
  const satrec = satellite.twoline2satrec(tle.tle1, tle.tle2);
  const orbits: SpotOrbit[] = [];

  let inHorizonPass = false;
  let rangeQualified = false;
  let aos: Date | null = null;
  let aosRangeKm = 0;
  let maxElev = -90;
  let prevTime: Date | null = null;
  let prevInBand = false;

  for (let t = new Date(start); t <= end; t = new Date(t.getTime() + STEP_SECONDS * 1000)) {
    // Internal probe only — elev/rangeKm/inBand here are scratch values
    // used purely to detect the horizon window and the range-entry
    // instant. Nothing from this loop is stored except aosRangeKm, set
    // once, the first time inBand becomes true.
    const look = lookAnglesAt(satrec, target, t);
    const elev = look?.elevationDeg ?? -180;
    const rangeKm = look?.rangeKm ?? Infinity;
    const inBand = rangeKm >= minRangeKm && rangeKm <= maxRangeKm;

    if (elev >= 0 && !inHorizonPass) {
      inHorizonPass = true;
      rangeQualified = false;
      aos = null;
      maxElev = elev;
    }

    if (inHorizonPass) {
      if (elev > maxElev) {
        maxElev = elev;
      }
      // First instant range enters the band during this pass — lock in
      // AOS and its range. Every later step in this same pass no longer
      // touches aosRangeKm.
      if (!rangeQualified && inBand) {
        rangeQualified = true;
        aos =
          prevTime && !prevInBand
            ? refineRangeEntryCrossing(satrec, target, prevTime, t, minRangeKm, maxRangeKm)
            : new Date(t);
        aosRangeKm = rangeKm;
      }
    }

    if (elev < 0 && inHorizonPass) {
      inHorizonPass = false;
      const los = prevTime ? refineCrossing(satrec, target, t, prevTime) : new Date(t);

      if (rangeQualified && aos) {
        orbits.push({
          aos,
          los,
          maxElevationDeg: maxElev,
          rangeAtMaxElevationKm: aosRangeKm, // no separate peak-range probe — reuse the one kept value
          rangeAtAosKm: aosRangeKm,
        });
      }

      rangeQualified = false;
      aos = null;
      maxElev = -90;
    }

    prevTime = new Date(t);
    prevInBand = inBand;
  }

  return orbits;
}

export function fallbackColorForName(name: string, palette: string[]): string {
  let hash = 0;
  for (let i = 0; i < name.length; i++) {
    hash = (hash * 31 + name.charCodeAt(i)) >>> 0;
  }
  return palette[hash % palette.length];
}

export function formatUtc(d: Date): string {
  const day = d.getUTCDate().toString().padStart(2, "0");
  const month = d.toLocaleString("en-US", { month: "short", timeZone: "UTC" });
  const year = d.getUTCFullYear();
  const h = d.getUTCHours().toString().padStart(2, "0");
  const m = d.getUTCMinutes().toString().padStart(2, "0");
  const s = d.getUTCSeconds().toString().padStart(2, "0");
  return `${day} ${month} ${year}, ${h}:${m}:${s} UTC`;
}