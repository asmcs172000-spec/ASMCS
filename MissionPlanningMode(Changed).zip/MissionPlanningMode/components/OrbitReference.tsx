import { useEffect, useMemo, useRef, useState } from "react";
import {
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  CalendarDays,
  Waypoints,
  AlertCircle,
  Radio,
  Crosshair,
  Satellite as SatelliteIcon,
  SlidersHorizontal,
} from "lucide-react";
import * as Cesium from "cesium";
import { tiltFromRangeKm, ORBIT_HEIGHT_KM } from "./GeoReferenceStripModeRange";
import { useVizPlayback } from "./vizPlayback";
import {
  findPasses,
  formatUtc,
  computeForwardCaptureArea,
  CAPTURE_RANGE_MIN_KM,
  CAPTURE_RANGE_MAX_KM,
  MIN_RANGE_FLOOR_KM,
  MIN_RANGE_STEP_KM,
  DEFAULT_GROUND_STATIONS,
  type TleEntry,
  type GroundPoint,
  type ForwardCaptureArea,
} from "./OrbitReferenceRange";
import { FrequencyPlanTable, FrequencyVisualizeNav, type FrequencySegment } from "./FrequencyAndTime";
import type { MissionPanelSection } from "./Georeference";

const WEEKDAY_LABELS = ["SU", "MO", "TU", "WE", "TH", "FR", "SA"];
const MONTH_LABELS = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December",
];
const GS_SCAN_HOURS = 36;
const MAX_PASSES_SHOWN_COLLAPSED = 3;

// GS-pass scanning is expensive (a multi-hour, 30s-step SGP4 scan per
// ground station per satellite). We don't want that scan re-running on
// every keystroke while the user is still adjusting the time spinners, so
// we debounce the instant that feeds the scan by this many ms.
const GS_SCAN_DEBOUNCE_MS = 400;

// Same order/colors as the Constellation Group list so a satellite keeps
// its identity color everywhere in the app.
const SATELLITE_DOT_COLORS = ["#fb7185", "#fbbf24", "#38bdf8", "#4ade80", "#c084fc", "#22d3ee"];
function getSatelliteColor(index: number) {
  return SATELLITE_DOT_COLORS[index % SATELLITE_DOT_COLORS.length];
}

function to12Hour(hour24: number) {
  const period: "AM" | "PM" = hour24 >= 12 ? "PM" : "AM";
  let hour12 = hour24 % 12;
  if (hour12 === 0) hour12 = 12;
  return { hour12, period };
}
function from12Hour(hour12: number, period: "AM" | "PM") {
  let hour24 = hour12 % 12;
  if (period === "PM") hour24 += 12;
  return hour24;
}
function pad2(n: number) {
  return n.toString().padStart(2, "0");
}
// Reads the real UTC fields off the Date object instead of re-echoing the
// raw hour24/minute/second the user typed — those are local-time inputs,
// and `selectedDateTime` (built with Date.UTC) is the actual UTC instant.
function formatLocalUtc(d: Date) {
  const day = d.getUTCDate();
  const month = d.toLocaleString("en-US", { month: "short", timeZone: "UTC" });
  const year = d.getUTCFullYear();
  const { hour12, period } = to12Hour(d.getUTCHours());
  return `${day} ${month} ${year}, ${pad2(hour12)}:${pad2(d.getUTCMinutes())}:${pad2(d.getUTCSeconds())} ${period} UTC`;
}
function daysInMonth(year: number, monthIndex: number) {
  return new Date(year, monthIndex + 1, 0).getDate();
}
function startWeekday(year: number, monthIndex: number) {
  return new Date(year, monthIndex, 1).getDay();
}
function isSameDay(a: Date, b: Date) {
  return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
}
function startOfToday() {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d;
}
function isPastDay(cellDate: Date) {
  const d = new Date(cellDate);
  d.setHours(0, 0, 0, 0);
  return d.getTime() < startOfToday().getTime();
}
function durationLabel(aos: Date, los: Date) {
  const secs = Math.max(0, Math.round((los.getTime() - aos.getTime()) / 1000));
  const m = Math.floor(secs / 60);
  const s = secs % 60;
  return `${m}m ${pad2(s)}s`;
}

// A pass is identified by station + satellite + AOS.
export type SelectedGsPassInfo = {
  station: string;
  satellite: string;
  satelliteColor: string;
  lat: number;
  lon: number;
  aos: Date;
  los: Date;
};

/** What the parent needs to know about the computed capture area. */
export type CaptureAreaInfo = {
  satellite: string;
  satelliteLat: number;
  satelliteLon: number;
  headingDeg: number;
  startLat: number;
  startLon: number;
  startRangeKm: number;
  endLat: number;
  endLon: number;
  endRangeKm: number;
};

type GsPass = {
  station: GroundPoint;
  satellite: string;
  satelliteColor: string;
  aos: Date;
  los: Date;
};

const passKey = (p: GsPass) => `${p.station.name}__${p.satellite}__${p.aos.getTime()}`;

// One satellite's forward capture-area result.
type CapturePlan = {
  name: string;
  color: string;
  area: ForwardCaptureArea | null;
};

type Props = {
  /** Which wizard step's blocks are visible (see Georeference). */
  section?: MissionPanelSection;
  selectedDate: Date;
  onSelectedDateChange: (date: Date) => void;
  hour24: number;
  minute: number;
  second: number;
  onTimeChange: (hour24: number, minute: number, second: number) => void;

  satelliteIds: string[];
  tleData: TleEntry[];
  groundStations?: GroundPoint[];

  downloadInGsPass: boolean;
  onToggleDownloadInGsPass: (checked: boolean) => void;

  selectedGsName: string | null;
  onSelectGsName: (name: string) => void;

  onGsPassTimeChange?: (info: SelectedGsPassInfo | null) => void;
  /** Fired with the computed forward capture area so the parent can kick
   *  off capture. Computed once per selected time — not a live feed. */
  onCaptureAreaChange?: (info: CaptureAreaInfo | null) => void;

  frequencySegments: FrequencySegment[];
  onFrequencySegmentsChange: (segments: FrequencySegment[]) => void;
  onVisualizeFrequency?: (segments: FrequencySegment[]) => void;
  onBackFromFrequency?: () => void;
  onPauseFrequency?: (paused: boolean) => void;
  /** Globe — the capture area is drawn on it in the orbits step. */
  viewerRef?: React.MutableRefObject<Cesium.Viewer | null>;
  viewerReady?: boolean;
  onSaveConfiguration?: () => void;
  isSaving?: boolean;
  saveError?: string | null;
};

export default function OrbitReference({
  section,
  selectedDate,
  onSelectedDateChange,
  hour24,
  minute,
  second,
  onTimeChange,
  satelliteIds,
  tleData,
  groundStations = DEFAULT_GROUND_STATIONS,
  downloadInGsPass,
  onToggleDownloadInGsPass,
  selectedGsName,
  onSelectGsName,
  onGsPassTimeChange,
  onCaptureAreaChange,
  frequencySegments,
  onFrequencySegmentsChange,
  onVisualizeFrequency,
  onBackFromFrequency,
  onPauseFrequency,
  viewerRef,
  viewerReady,
  onSaveConfiguration,
  isSaving,
  saveError,
}: Props) {
  const hideFor = (s: MissionPanelSection) => !!section && section !== s;
  const [viewYear, setViewYear] = useState(selectedDate.getFullYear());
  const [viewMonth, setViewMonth] = useState(selectedDate.getMonth());
  const [dateError, setDateError] = useState<string | null>(null);
  const [showAllPasses, setShowAllPasses] = useState(false);
  const [selectedPassKey, setSelectedPassKey] = useState<string | null>(null);

  // ── User-selectable minimum capture range (km). Maximum stays fixed at
  // CAPTURE_RANGE_MAX_KM; only the near edge of the capture window is
  // adjustable, since that's the edge operators actually tune. ──
  const [minRangeKm, setMinRangeKm] = useState<number>(CAPTURE_RANGE_MIN_KM);
  const [minRangeInput, setMinRangeInput] = useState<string>(String(CAPTURE_RANGE_MIN_KM));
  const minRangeError =
    Number.isNaN(Number(minRangeInput)) || minRangeInput.trim() === ""
      ? "Enter a number."
      : Number(minRangeInput) < MIN_RANGE_FLOOR_KM
        ? `Must be at least ${MIN_RANGE_FLOOR_KM} km.`
        : Number(minRangeInput) >= CAPTURE_RANGE_MAX_KM
          ? `Must be less than the max range (${CAPTURE_RANGE_MAX_KM} km).`
          : null;

  const handleMinRangeInputChange = (raw: string) => {
    setMinRangeInput(raw);
    const n = Number(raw);
    if (!Number.isNaN(n) && raw.trim() !== "" && n >= MIN_RANGE_FLOOR_KM && n < CAPTURE_RANGE_MAX_KM) {
      setMinRangeKm(n);
    }
  };

  const { hour12, period } = to12Hour(hour24);

  const cells: (number | null)[] = [];
  {
    const total = daysInMonth(viewYear, viewMonth);
    const offset = startWeekday(viewYear, viewMonth);
    for (let i = 0; i < offset; i++) cells.push(null);
    for (let d = 1; d <= total; d++) cells.push(d);
  }

  // Built with Date.UTC so hour24/minute/second are treated as UTC clock
  // fields — matching what the "Selected Capture Time (UTC)" label and the
  // GS-pass / capture-area searches below actually mean. Using the plain
  // `new Date(y, m, d, h, mi, s)` constructor here would interpret
  // h/mi/s as *local* time, silently shifting the real instant used for
  // every downstream calculation.
  const selectedDateTime = useMemo(
    () =>
      new Date(
        Date.UTC(selectedDate.getFullYear(), selectedDate.getMonth(), selectedDate.getDate(), hour24, minute, second),
      ),
    [selectedDate, hour24, minute, second],
  );
  const isSelectedInPast = selectedDateTime.getTime() < Date.now();

  useEffect(() => {
    setDateError(isSelectedInPast ? "Invalid date and time." : null);
  }, [isSelectedInPast]);

  // ── Debounced capture instant, used ONLY to gate the expensive GS-pass
  // scan below. The capture-area geometry (computeForwardCaptureArea) is a
  // single cheap lookup and stays wired to the live `selectedDateTime` so
  // it still updates instantly as the user types. ──
  const [debouncedDateTime, setDebouncedDateTime] = useState(selectedDateTime);
  useEffect(() => {
    const id = setTimeout(() => setDebouncedDateTime(selectedDateTime), GS_SCAN_DEBOUNCE_MS);
    return () => clearTimeout(id);
  }, [selectedDateTime]);

  const goPrevMonth = () => {
    if (viewMonth === 0) {
      setViewMonth(11);
      setViewYear((y) => y - 1);
    } else {
      setViewMonth((m) => m - 1);
    }
  };
  const goNextMonth = () => {
    if (viewMonth === 11) {
      setViewMonth(0);
      setViewYear((y) => y + 1);
    } else {
      setViewMonth((m) => m + 1);
    }
  };
  const pickDay = (day: number) => {
    const cellDate = new Date(viewYear, viewMonth, day);
    if (isPastDay(cellDate)) {
      setDateError("Invalid date and time.");
      return;
    }
    setDateError(null);
    onSelectedDateChange(cellDate);
  };

  const setHour12 = (h: number) => onTimeChange(from12Hour(h, period), minute, second);
  const setMinute = (m: number) => onTimeChange(hour24, m, second);
  const setSecond = (s: number) => onTimeChange(hour24, minute, s);
  const setPeriod = (p: "AM" | "PM") => onTimeChange(from12Hour(hour12, p), minute, second);

  const groupTles = useMemo(
    () => tleData.filter((t) => satelliteIds.includes(t.name)),
    [tleData, satelliteIds],
  );
  const referenceTle = groupTles[0] ?? null;

  // ── Upcoming GS passes AFTER the selected capture time. This is a
  // separate, optional comms feature — unrelated to the capture-area
  // geometry below.
  //
  // PERFORMANCE: this used to run on every keystroke in the time spinners
  // (it depended directly on `selectedDateTime`) and unconditionally, even
  // when the "download in GS pass" checkbox was off and nobody could see
  // the results. A 36h scan at a coarse step across every ground station
  // and every satellite is thousands of SGP4 propagations — doing that on
  // every keystroke is what caused the lag. Fixed by:
  //   1. Skipping the scan entirely unless `downloadInGsPass` is checked.
  //   2. Keying off `debouncedDateTime` instead of the live
  //      `selectedDateTime`, so a burst of spinner clicks/typing triggers
  //      one scan after the user pauses, not one scan per keystroke. ──
  const gsPasses = useMemo<GsPass[]>(() => {
    if (!downloadInGsPass || groupTles.length === 0 || isSelectedInPast) return [];
    const windowStart = debouncedDateTime;
    const windowEnd = new Date(debouncedDateTime.getTime() + GS_SCAN_HOURS * 60 * 60 * 1000);

    return groundStations
      .flatMap((gs) =>
        groupTles.flatMap((tle, satIdx) =>
          findPasses(tle, gs, windowStart, windowEnd)
            .filter((p) => p.aos.getTime() >= windowStart.getTime())
            .map((p) => ({
              station: gs,
              satellite: tle.name,
              satelliteColor: getSatelliteColor(satIdx),
              aos: p.aos,
              los: p.los,
            })),
        ),
      )
      .sort((a, b) => a.aos.getTime() - b.aos.getTime());
  }, [downloadInGsPass, groupTles, groundStations, debouncedDateTime, isSelectedInPast]);

  // ── FORWARD CAPTURE AREA: at the exact selected instant, read each
  // satellite's real TLE position + heading, then look spatially AHEAD
  // along that heading to find where slant range is `minRangeKm` (capture
  // start, user-adjustable) and `CAPTURE_RANGE_MAX_KM` (capture end). No
  // ground station, no time-search — this is pure geometry evaluated at
  // one moment, so it stays wired to the live `selectedDateTime` rather
  // than the debounced one — it's cheap enough to recompute every render. ──
  const capturePlans = useMemo<CapturePlan[]>(() => {
    if (isSelectedInPast || groupTles.length === 0) return [];
    return groupTles.map((tle, idx) => ({
      name: tle.name,
      color: getSatelliteColor(idx),
      area: computeForwardCaptureArea(tle, selectedDateTime, minRangeKm, CAPTURE_RANGE_MAX_KM),
    }));
  }, [groupTles, selectedDateTime, isSelectedInPast, minRangeKm]);

  // The plan the app will actually use — the first satellite in the group
  // that produced a valid capture area.
  const activePlan = useMemo(
    () => capturePlans.find((p) => p.area) ?? null,
    [capturePlans],
  );

  // Hand the computed area up to the parent once, when it changes.
  useEffect(() => {
    if (!onCaptureAreaChange) return;
    const area = activePlan?.area;
    if (!area) {
      onCaptureAreaChange(null);
      return;
    }
    onCaptureAreaChange({
      satellite: activePlan!.name,
      satelliteLat: area.satelliteLat,
      satelliteLon: area.satelliteLon,
      headingDeg: area.headingDeg,
      startLat: area.startLat,
      startLon: area.startLon,
      startRangeKm: area.startRangeKm,
      endLat: area.endLat,
      endLon: area.endLon,
      endRangeKm: area.endRangeKm,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activePlan]);

  const visiblePasses = showAllPasses ? gsPasses : gsPasses.slice(0, MAX_PASSES_SHOWN_COLLAPSED);

  // Tilt follows from the range (tilt = acos(H / range)), using the real
  // altitude of the capturing satellite when known.
  const tiltAltitudeKm = activePlan?.area?.altitudeKm ?? ORBIT_HEIGHT_KM;
  const tiltMinDeg = tiltFromRangeKm(minRangeKm, tiltAltitudeKm);
  const tiltMaxDeg = tiltFromRangeKm(CAPTURE_RANGE_MAX_KM, tiltAltitudeKm);

  // ── Capture area on the globe (orbits step only, hidden while an
  //    animation plays): satellite → capture start, and the capture
  //    window from start to end. ──
  const playback = useVizPlayback();
  const showAreaOnGlobe = section === "orbits" && playback.active === null;
  useEffect(() => {
    const viewer = viewerRef?.current;
    if (!viewerReady || !viewer || viewer.isDestroyed() || !showAreaOnGlobe) return;
    const PREFIX = "orbitref-area__";
    capturePlans.forEach((p, i) => {
      const a = p.area;
      if (!a) return;
      const color = Cesium.Color.fromCssColorString(p.color);
      const start = Cesium.Cartesian3.fromDegrees(a.startLon, a.startLat, 0);
      const end = Cesium.Cartesian3.fromDegrees(a.endLon, a.endLat, 0);
      viewer.entities.add({
        id: `${PREFIX}${i}__lead`,
        polyline: {
          positions: [Cesium.Cartesian3.fromDegrees(a.satelliteLon, a.satelliteLat, 0), start],
          width: 2,
          clampToGround: true,
          material: new Cesium.PolylineDashMaterialProperty({ color: color.withAlpha(0.8), dashLength: 12 }),
        },
      });
      viewer.entities.add({
        id: `${PREFIX}${i}__window`,
        polyline: {
          positions: [start, end],
          width: 10,
          clampToGround: true,
          material: new Cesium.PolylineGlowMaterialProperty({ color, glowPower: 0.25 }),
        },
      });
      [
        { pos: start, text: `${p.name} · capture start` },
        { pos: end, text: "capture end" },
      ].forEach((pt, k) =>
        viewer.entities.add({
          id: `${PREFIX}${i}__pt-${k}`,
          position: pt.pos,
          point: { pixelSize: 9, color, outlineColor: Cesium.Color.WHITE, outlineWidth: 1.5, disableDepthTestDistance: Number.POSITIVE_INFINITY },
          label: {
            text: pt.text,
            font: "12px sans-serif",
            style: Cesium.LabelStyle.FILL_AND_OUTLINE,
            fillColor: Cesium.Color.WHITE,
            outlineColor: Cesium.Color.BLACK,
            outlineWidth: 2,
            pixelOffset: new Cesium.Cartesian2(0, -16),
            disableDepthTestDistance: Number.POSITIVE_INFINITY,
          },
        }),
      );
    });
    viewer.scene.requestRender();
    return () => {
      if (viewer.isDestroyed()) return;
      viewer.entities.values
        .filter((e) => typeof e.id === "string" && e.id.startsWith(PREFIX))
        .forEach((e) => viewer.entities.remove(e));
      viewer.scene.requestRender();
    };
  }, [capturePlans, showAreaOnGlobe, viewerReady, viewerRef]);

  useEffect(() => {
    setSelectedPassKey((prev) => (prev && gsPasses.some((p) => passKey(p) === prev) ? prev : null));
  }, [gsPasses]);

  useEffect(() => {
    if (!onGsPassTimeChange) return;

    const pass =
      (selectedPassKey && gsPasses.find((p) => passKey(p) === selectedPassKey)) ||
      (selectedGsName ? gsPasses.find((p) => p.station.name === selectedGsName) : undefined);

    if (!pass) {
      onGsPassTimeChange(null);
      return;
    }

    onGsPassTimeChange({
      station: pass.station.name,
      satellite: pass.satellite,
      satelliteColor: pass.satelliteColor,
      lat: pass.station.lat,
      lon: pass.station.lon,
      aos: pass.aos,
      los: pass.los,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedPassKey, selectedGsName, gsPasses]);

  const selectPass = (p: GsPass) => {
    setSelectedPassKey(passKey(p));
    onSelectGsName(p.station.name);
  };

  return (
    <div className="space-y-4">
      {/* ── Calendar + time ── */}
      <div hidden={hideFor("reference")}>
        <div className="mb-2 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-[oklch(0.6_0.02_250)]">
          <CalendarDays className="size-3.5 text-[oklch(0.75_0.12_220)]" />
          Time After Which You Need to Capture
        </div>

        <div className="rounded-lg border border-white/5 bg-[oklch(0.13_0.02_255)] p-3.5">
          <div className="mb-3 flex items-center justify-between">
            <button type="button" onClick={goPrevMonth} className="rounded p-1 text-[oklch(0.6_0.02_250)] hover:bg-white/5 hover:text-[oklch(0.9_0_0)]">
              <ChevronLeft className="size-4" />
            </button>
            <span className="text-sm font-semibold text-[oklch(0.9_0_0)]">
              {MONTH_LABELS[viewMonth]} {viewYear}
            </span>
            <button type="button" onClick={goNextMonth} className="rounded p-1 text-[oklch(0.6_0.02_250)] hover:bg-white/5 hover:text-[oklch(0.9_0_0)]">
              <ChevronRight className="size-4" />
            </button>
          </div>

          <div className="grid grid-cols-7 gap-x-0.5 gap-y-1 text-center">
            {WEEKDAY_LABELS.map((w) => (
              <span key={w} className="text-[10px] font-bold text-[oklch(0.45_0.02_250)]">
                {w}
              </span>
            ))}
            {cells.map((day, i) => {
              if (day === null) return <span key={`empty-${i}`} />;
              const cellDate = new Date(viewYear, viewMonth, day);
              const active = isSameDay(cellDate, selectedDate);
              const past = isPastDay(cellDate);
              return (
                <button
                  key={day}
                  type="button"
                  disabled={past}
                  onClick={() => pickDay(day)}
                  title={past ? "This date is in the past" : undefined}
                  className={`mx-auto flex size-7 items-center justify-center rounded-full text-xs font-semibold transition-colors ${
                    active
                      ? "bg-[oklch(0.75_0.12_220)] text-[oklch(0.1_0.03_250)]"
                      : past
                        ? "cursor-not-allowed text-[oklch(0.32_0.01_250)]"
                        : "text-[oklch(0.8_0_0)] hover:bg-white/10"
                  }`}
                >
                  {day}
                </button>
              );
            })}
          </div>
        </div>

        <div className="mt-3 rounded-lg border border-white/5 bg-[oklch(0.13_0.02_255)] p-3.5">
          <div className="mb-3 text-[11px] font-bold uppercase tracking-wider text-[oklch(0.7_0.02_250)]">Select Time</div>
          <div className="flex items-center gap-1.5">
            <TimeSpinner value={hour12} min={1} max={12} onChange={setHour12} />
            <span className="pb-4 text-lg font-bold text-[oklch(0.6_0.02_250)]">:</span>
            <TimeSpinner value={minute} min={0} max={59} onChange={setMinute} />
            <span className="pb-4 text-lg font-bold text-[oklch(0.6_0.02_250)]">:</span>
            <TimeSpinner value={second} min={0} max={59} onChange={setSecond} />
            <div className="ml-1 flex flex-col items-center">
              <span className="invisible" aria-hidden="true">
                <ChevronDown className="size-3 rotate-180" />
              </span>
              <PeriodDropdown value={period} onChange={setPeriod} />
              <span className="invisible" aria-hidden="true">
                <ChevronDown className="size-3" />
              </span>
            </div>
          </div>
        </div>

        <div className="mt-3 rounded-lg border border-white/5 bg-[oklch(0.13_0.02_255)] p-3.5">
          <div className="mb-2 text-[11px] font-bold uppercase tracking-wider text-[oklch(0.7_0.02_250)]">
            Selected Capture Time (UTC)
          </div>
          <div
            className={`flex items-center gap-2 rounded border px-3 py-2 text-sm ${
              isSelectedInPast
                ? "border-red-500/40 bg-red-500/[0.06] text-red-300"
                : "border-white/5 bg-white/[0.02] text-[oklch(0.85_0_0)]"
            }`}
          >
            <CalendarDays className="size-4 shrink-0 text-[oklch(0.6_0.02_250)]" />
            {formatLocalUtc(selectedDateTime)}
          </div>
        </div>

        {dateError && (
          <div className="mt-3 flex items-center gap-2 rounded-lg border border-red-500/30 bg-red-500/10 px-3 py-2 text-xs text-red-300">
            <AlertCircle className="size-4 shrink-0" />
            {dateError}
          </div>
        )}

      </div>

      {/* ── Operations mode (auto) ── */}
      <div hidden={hideFor("reference")} className="rounded-lg border border-white/5 bg-white/[0.02] px-3.5 py-3">
        <div className="mb-1.5 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-[oklch(0.6_0.02_250)]">
          <Waypoints className="size-3.5 text-[oklch(0.75_0.12_220)]" />
          Operations Mode
          <span className="rounded-full border border-[oklch(0.75_0.12_220)]/30 bg-[oklch(0.75_0.12_220)]/10 px-1.5 py-0.5 text-[9px] font-semibold normal-case tracking-normal text-[oklch(0.75_0.12_220)]">
            auto
          </span>
        </div>
        <div className="text-sm font-semibold text-[oklch(0.9_0_0)]">Strip</div>
        <p className="mt-0.5 text-[11px] leading-snug text-[var(--gm-muted)]">
          Captures data continuously while the satellite remains in view.
        </p>
      </div>

      {/* ── Ground station pass ── */}
      <div hidden={hideFor("downlink")}>
        <label className="mb-2 flex cursor-pointer items-center gap-2 text-[11px] font-bold uppercase tracking-wider text-[oklch(0.6_0.02_250)]">
          <input
            type="checkbox"
            checked={downloadInGsPass}
            onChange={(e) => onToggleDownloadInGsPass(e.target.checked)}
            className="size-3.5 shrink-0 rounded accent-[oklch(0.75_0.12_220)]"
          />
          <span>Download data in upcoming Ground Station pass and schedule now</span>
        </label>

        {downloadInGsPass && (
          <>
            <div className="mb-2 flex items-center gap-1.5">
              <h3 className="text-[11px] font-bold uppercase tracking-wider text-[oklch(0.6_0.02_250)]">
                Select Upcoming Ground Station Pass
              </h3>
              <span className="text-[10px] font-semibold normal-case text-[oklch(0.5_0.02_250)]">
                (next {GS_SCAN_HOURS}h)
              </span>
            </div>

            {!referenceTle ? (
              <div className="flex flex-col items-center gap-2 py-10 text-center">
                <SatelliteIcon className="size-5 text-[oklch(0.45_0.02_250)]" />
                <p className="text-sm text-[oklch(0.5_0.02_250)]">
                  No satellites selected in this Constellation Group yet.
                </p>
              </div>
            ) : isSelectedInPast ? (
              <p className="py-4 text-center text-xs text-[oklch(0.5_0.02_250)]">
                Fix the capture date/time above first.
              </p>
            ) : debouncedDateTime.getTime() !== selectedDateTime.getTime() ? (
              <p className="py-4 text-center text-xs text-[oklch(0.5_0.02_250)]">Scanning for passes…</p>
            ) : (
              <>
                <div className="space-y-2" role="radiogroup" aria-label="Ground station pass">
                  {visiblePasses.map((p) => {
                    const key = passKey(p);
                    const checked = selectedPassKey
                      ? selectedPassKey === key
                      : selectedGsName === p.station.name;
                    return (
                      <label
                        key={key}
                        className={`flex cursor-pointer flex-col gap-1.5 rounded-lg border px-3.5 py-3 transition-colors ${
                          checked
                            ? "border-[oklch(0.75_0.12_220)]/50 bg-[oklch(0.75_0.12_220)]/10"
                            : "border-white/5 bg-white/[0.02] hover:border-white/15"
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <input
                            type="radio"
                            name="orbitref-gs-pass-selection"
                            checked={checked}
                            onChange={() => selectPass(p)}
                            className="size-4 shrink-0 accent-[oklch(0.75_0.12_220)]"
                          />
                          <Radio className="size-4 shrink-0 text-[oklch(0.7_0.02_250)]" />
                          <span className="min-w-0 flex-1 truncate text-sm font-semibold text-[oklch(0.9_0_0)]">
                            {p.station.name}
                          </span>
                          <span
                            className="inline-block size-1.5 shrink-0 rounded-full"
                            style={{ background: p.station.color ?? "#7dd3fc" }}
                          />
                        </div>

                        <div className="flex items-center gap-1.5 pl-6">
                          <span
                            className="inline-block size-1.5 shrink-0 rounded-full"
                            style={{ background: p.satelliteColor }}
                          />
                          <SatelliteIcon className="size-3 shrink-0 text-[oklch(0.6_0.02_250)]" />
                          <span className="truncate text-[11px] font-semibold text-[oklch(0.82_0_0)]">
                            {p.satellite}
                          </span>
                          <span className="ml-auto shrink-0 text-[10px] text-[var(--gm-muted)]">
                            {durationLabel(p.aos, p.los)}
                          </span>
                        </div>

                        <div className="pl-6 text-xs font-medium text-[oklch(0.75_0_0)]">{formatUtc(p.aos)}</div>
                        <div className="pl-6 text-center text-[11px] text-[var(--gm-muted)]">
                          AOS {p.aos.toISOString().slice(11, 19)} · LOS {p.los.toISOString().slice(11, 19)}
                        </div>
                      </label>
                    );
                  })}
                </div>

                {gsPasses.length > MAX_PASSES_SHOWN_COLLAPSED && (
                  <button
                    type="button"
                    onClick={() => setShowAllPasses((v) => !v)}
                    className="mt-2 flex w-full items-center justify-center gap-1 text-xs font-semibold text-[oklch(0.7_0.1_220)] hover:text-[oklch(0.85_0.1_220)]"
                  >
                    {showAllPasses ? "Show fewer passes" : "View more passes"}
                    <ChevronDown className={`size-3.5 transition-transform ${showAllPasses ? "rotate-180" : ""}`} />
                  </button>
                )}

                {gsPasses.length === 0 && (
                  <p className="py-4 text-center text-xs text-[oklch(0.5_0.02_250)]">
                    No ground station passes found in the {GS_SCAN_HOURS}h after the selected capture time.
                  </p>
                )}
              </>
            )}
          </>
        )}
      </div>

      {/* ── Range and tilt (after date/time, before frequency scheduling) ── */}
      <div hidden={hideFor("reference")} className="rounded-lg border border-white/5 bg-[oklch(0.13_0.02_255)] p-3.5">
        <div className="mb-3 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-[oklch(0.7_0.02_250)]">
          <SlidersHorizontal className="size-3.5 text-[oklch(0.75_0.12_220)]" />
          Range and tilt
        </div>
        <div className="grid grid-cols-2 gap-2">
          <label className="rounded-md border border-white/5 bg-white/[0.02] px-2.5 py-2">
            <span className="block text-[10px] font-medium uppercase tracking-wider text-[var(--gm-muted)]">Min range</span>
            <span className="mt-0.5 flex items-baseline gap-1">
              <input
                id="min-range-input"
                type="number"
                inputMode="numeric"
                min={MIN_RANGE_FLOOR_KM}
                max={CAPTURE_RANGE_MAX_KM - MIN_RANGE_STEP_KM}
                step={MIN_RANGE_STEP_KM}
                value={minRangeInput}
                onChange={(e) => handleMinRangeInputChange(e.target.value)}
                className={`w-24 rounded border px-1.5 py-0.5 text-sm font-semibold text-[oklch(0.95_0_0)] ${
                  minRangeError ? "border-red-500/50" : "border-white/10"
                }`}
              />
              <span className="text-xs text-[var(--gm-muted)]">km</span>
            </span>
            {minRangeError && <span className="mt-1 block text-[11px] text-red-300">{minRangeError}</span>}
          </label>
          <div className="rounded-md border border-white/5 bg-white/[0.02] px-2.5 py-2">
            <span className="block text-[10px] font-medium uppercase tracking-wider text-[var(--gm-muted)]">Max range (fixed)</span>
            <span className="mt-0.5 flex items-baseline gap-1">
              <span className="px-1.5 py-0.5 font-mono text-sm font-semibold text-[oklch(0.95_0_0)]">{CAPTURE_RANGE_MAX_KM}</span>
              <span className="text-xs text-[var(--gm-muted)]">km</span>
            </span>
          </div>
        </div>

        {/* Tilt — follows from the range, shown in its own highlighted blocks. */}
        <div className="mt-2 grid grid-cols-2 gap-2">
          {[
            { label: "Min tilt", value: tiltMinDeg },
            { label: "Max tilt", value: tiltMaxDeg },
          ].map((t) => (
            <div key={t.label} className="rounded-md border border-[rgba(77,163,255,.35)] bg-[rgba(77,163,255,.08)] px-2.5 py-2">
              <span className="block text-[10px] font-semibold uppercase tracking-wider text-[var(--mp-accent)]">{t.label}</span>
              <span className="mt-0.5 block font-mono text-sm font-semibold text-[var(--mp-text)]">{t.value.toFixed(1)}°</span>
            </div>
          ))}
        </div>
      </div>

      {/* ── Frequency and Time ── */}
      <div hidden={hideFor("reference")} className={section ? "" : "border-t border-white/5 pt-4"}>
        {!section && (
          <h3 className="mb-2 text-[11px] font-bold uppercase tracking-wider text-[oklch(0.6_0.02_250)]">
            Frequency and Time
          </h3>
        )}
        <FrequencyPlanTable segments={frequencySegments} onSegmentsChange={onFrequencySegmentsChange} />
      </div>
      <div hidden={hideFor("orbits")} className="space-y-4">
          {/* ── Capture area (step 3, also drawn on the globe): at the exact selected instant, the
              satellite's own TLE position + heading are read, then projected
              forward (spatially, same instant) to the ground point where
              slant range is `minRangeKm`. No ground station, no time-search. ── */}
          {capturePlans.length > 0 && (
            <div className="rounded-lg border border-white/5 bg-[oklch(0.13_0.02_255)] p-3.5">
              <div className="mb-2 flex items-center justify-between gap-2">
                <div className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-[oklch(0.7_0.02_250)]">
                  <Crosshair className="size-3.5 text-[oklch(0.75_0.12_220)]" />
                  Capture Area
                </div>
                <span
                  className={`shrink-0 rounded-full border px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider ${
                    activePlan
                      ? "border-emerald-400/40 bg-emerald-400/10 text-emerald-300"
                      : "border-amber-400/40 bg-amber-400/10 text-amber-300"
                  }`}
                >
                  {activePlan ? "Area found" : "No area found"}
                </span>
              </div>

              {capturePlans.map((p) => (
                <div key={p.name} className="mb-2 rounded border border-white/5 bg-white/[0.02] p-2.5 last:mb-0">
                  <div className="flex items-center gap-2 text-xs font-medium text-[oklch(0.85_0_0)]">
                    <span className="inline-block size-1.5 rounded-full" style={{ background: p.color }} />
                    {p.name}
                  </div>

                  {p.area ? (
                    <div className="mt-1.5 space-y-1 text-[11px] text-[var(--gm-muted)]">
                      <div>
                        Satellite position:{" "}
                        <span className="text-[oklch(0.85_0_0)]">
                          {p.area.satelliteLat.toFixed(3)}°, {p.area.satelliteLon.toFixed(3)}°
                        </span>{" "}
                        · alt {p.area.altitudeKm.toFixed(0)} km · heading {p.area.headingDeg.toFixed(1)}°
                      </div>
                      <div>
                        Capture starts at:{" "}
                        <span className="text-[oklch(0.85_0_0)]">
                          {p.area.startLat.toFixed(3)}°, {p.area.startLon.toFixed(3)}°
                        </span>
                      </div>
                      <div>
                        Range at start:{" "}
                        <span className="font-semibold text-emerald-300">
                          {p.area.startRangeKm.toFixed(0)} km
                        </span>
                      </div>
                    </div>
                  ) : (
                    <div className="mt-1.5 text-[11px] text-amber-300">
                      Could not compute a capture area at this time.
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        <FrequencyVisualizeNav
          segments={frequencySegments}
          onVisualize={onVisualizeFrequency}
          onBack={onBackFromFrequency}
          onPauseChange={onPauseFrequency}
          disabledReason={isSelectedInPast ? "Pick a capture time in the future" : !activePlan ? "No capture area at this time" : null}
        />
      </div>

      {/* ── Save Configuration ── */}
      {onSaveConfiguration && (
        <div hidden={hideFor("downlink")} className="border-t border-white/5 pt-4">
          {saveError && (
            <div
              role="alert"
              className="mb-3 flex min-w-0 items-start gap-2 rounded-md border border-red-400/25 bg-red-500/10 px-3 py-2.5 text-xs leading-4 text-red-200"
            >
              <AlertCircle className="mt-0.5 size-3.5 shrink-0 text-red-300" aria-hidden="true" />
              <span className="min-w-0 break-words">{saveError}</span>
            </div>
          )}
          <button
            type="button"
            onClick={onSaveConfiguration}
            disabled={isSaving}
            className="flex w-full items-center justify-center gap-2 rounded-lg border border-[oklch(0.75_0.12_220)]/40 bg-[oklch(0.75_0.12_220)]/10 py-2 text-xs font-bold uppercase tracking-wider text-[oklch(0.85_0.1_220)] transition-colors hover:bg-[oklch(0.75_0.12_220)]/20 disabled:cursor-not-allowed disabled:opacity-50"
          >
            {isSaving ? "Saving…" : "Save Configuration File"}
          </button>
        </div>
      )}
    </div>
  );
}

function TimeSpinner({
  value,
  min,
  max,
  onChange,
}: {
  value: number;
  min: number;
  max: number;
  onChange: (v: number) => void;
}) {
  const step = (dir: 1 | -1) => {
    let next = value + dir;
    if (next > max) next = min;
    if (next < min) next = max;
    onChange(next);
  };
  return (
    <div className="flex flex-col items-center">
      <button type="button" onClick={() => step(1)} className="text-[oklch(0.5_0.02_250)] hover:text-[oklch(0.9_0_0)]" tabIndex={-1}>
        <ChevronDown className="size-3 rotate-180" />
      </button>
      <input
        type="text"
        inputMode="numeric"
        value={pad2(value)}
        onChange={(e) => {
          const n = Number(e.target.value.replace(/\D/g, ""));
          if (!Number.isNaN(n)) onChange(Math.min(max, Math.max(min, n)));
        }}
        className="w-10 rounded border border-white/10 bg-[oklch(0.14_0.03_250)]/70 py-2 text-center text-sm font-semibold text-[oklch(0.9_0_0)] focus:outline-none focus:ring-1 focus:ring-[oklch(0.75_0.12_220)]/40"
      />
      <button type="button" onClick={() => step(-1)} className="text-[oklch(0.5_0.02_250)] hover:text-[oklch(0.9_0_0)]" tabIndex={-1}>
        <ChevronDown className="size-3" />
      </button>
    </div>
  );
}

function PeriodDropdown({ value, onChange }: { value: "AM" | "PM"; onChange: (p: "AM" | "PM") => void }) {
  const [open, setOpen] = useState(false);
  const rootRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (rootRef.current && !rootRef.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <div ref={rootRef} className="relative">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className="flex items-center gap-1.5 rounded border border-white/10 bg-[oklch(0.14_0.03_250)]/70 py-2 pl-3 pr-2.5 text-sm font-semibold text-[oklch(0.9_0_0)] transition-colors hover:border-white/20 focus:outline-none focus:ring-1 focus:ring-[oklch(0.75_0.12_220)]/40"
      >
        {value}
        <ChevronDown className={`size-3.5 text-[oklch(0.5_0.02_250)] transition-transform ${open ? "rotate-180" : ""}`} />
      </button>

      {open && (
        <div className="absolute right-0 top-[calc(100%+4px)] z-20 w-16 overflow-hidden rounded-lg border border-white/10 bg-[oklch(0.15_0.03_250)] shadow-xl shadow-black/40">
          {(["AM", "PM"] as const).map((p) => (
            <button
              key={p}
              type="button"
              onClick={() => {
                onChange(p);
                setOpen(false);
              }}
              className={`block w-full px-3 py-2 text-left text-sm font-semibold transition-colors ${
                p === value ? "bg-[oklch(0.75_0.12_220)]/15 text-[oklch(0.85_0.1_220)]" : "text-[oklch(0.8_0_0)] hover:bg-white/5"
              }`}
            >
              {p}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}