import * as satellite from "satellite.js";
import {
  ORBIT_HEIGHT_KM,
  DEFAULT_MIN_ELEVATION_DEG,
  tiltFromRangeKm,
  maxRangeForElevationKm,
} from "./GeoReferenceStripModeRange";

// ─── Geometry ─────────────────────────────────────────────────────────────
//
// SPOT-MODE CAPTURE MODEL (same geometry as pass_geometry.html)
// -------------------------------------------------------------
// The user drops a marker (target lat/lon) and enters ONE limit:
//   • a minimum elevation  → the max slant range and the tilt are calculated
//   • a maximum slant range → the min elevation and the tilt are calculated
//
// Earth-center / satellite / target triangle (spherical Earth):
//   R  = Earth radius, a = R + h (satellite distance from Earth's center)
//   θ  = central angle between the sub-satellite point and the target
//
//   range     d   = √(R² + a² − 2·R·a·cosθ)
//   elevation el  = asin((a·cosθ − R) / d)
//   tilt      η   = asin(R·sinθ / d)                    (off-nadir, at the satellite)
//
//   θ from elevation : θ = 90° − el − asin(R·cos(el) / a)
//   θ from range     : θ = acos((R² + a² − d²) / (2·R·a))
//
// So for the entered limit, the other two values follow:
//   min elevation → θ → max range, tilt
//   max range     → θ → min elevation, tilt
//
// In the orbit scan nothing is assumed: every step propagates the real TLE
// (SGP4), converts to ECEF and measures elevation, slant range and tilt (the
// angle at the satellite between nadir and the line of sight) from vectors.
//
// MISSION TIMELINE PER PASS
// -------------------------
//   dummyAos     = missionStart − 5 min   (shown as "AOS" in the list)
//   missionStart = first instant the entered limit is met
//                    elevation mode: elevation ≥ min elevation
//                    range mode    : slant range ≤ max range
//   missionEnd   = missionStart + Σ frequency segment durations (≤ 10 min)
//   los          = first instant after missionStart the limit is no longer met
//                    elevation mode: elevation drops below min elevation
//                    range mode    : slant range exceeds max range
//
// If los < missionEnd the pass is SHORT (`shortPass = true`) and
// `planMissionAcrossPasses()` chains the following passes until the full
// mission duration is covered.
//
// Ground-station comms passes (`findPasses`) are unaffected.

// ── General usable link/imaging envelope ──
export const MIN_LINK_RANGE_KM = 551;   // nadir floor — satellite directly overhead
export const MAX_LINK_RANGE_KM = 1800;  // usable range ceiling

/** Lowest minimum elevation the user may enter (pass_geometry.html: ≥ 5°). */
export const MIN_SPOT_ELEVATION_DEG = 5;
/** Highest minimum elevation the user may enter. */
export const MAX_SPOT_ELEVATION_DEG = 89;
/** Spherical Earth radius used by the pass-geometry formulas (km). */
export const SPOT_EARTH_RADIUS_KM = 6371;

export { ORBIT_HEIGHT_KM, DEFAULT_MIN_ELEVATION_DEG, tiltFromRangeKm, maxRangeForElevationKm };

export const MAX_MISSION_DURATION_SECONDS = 10 * 60;
/** Used until a frequency plan exists (sum of segments = 0). */
export const DEFAULT_MISSION_DURATION_SECONDS = MAX_MISSION_DURATION_SECONDS;
export const DUMMY_AOS_LEAD_MINUTES = 2;

// ─── Types ────────────────────────────────────────────────────────────────

export type TleEntry = {
  name: string;
  tle1: string;
  tle2: string;
  color?: string;
};

/** Any point on the ground the satellite's range can be measured against —
 *  used for ground-station passes and for Spot/Area targets. */
export type GroundPoint = {
  name: string;
  lat: number;
  lon: number;
  color?: string;
};

/** @deprecated alias kept for compatibility. */
export type GroundStation = GroundPoint;

export type Pass = {
  aos: Date;
  los: Date;
  maxElevationDeg: number;
  rangeAtMaxElevationKm: number;
};

export const DEFAULT_GROUND_STATIONS: GroundPoint[] = [
  { name: "Rawalpindi GS", lat: 33.6167, lon: 73.0992, color: "#7dd3fc" },
  { name: "Azerbaijan GS", lat: 40.39, lon: 49.29, color: "#fef08a" },
  { name: "Turkey GS", lat: 41.1037, lon: 29.0261, color: "#f472b6" },
];

export const OTHER_SAT_FALLBACK_COLORS = [
  "#7dd3fc", "#fbbf24", "#f472b6", "#a78bfa", "#34d399", "#fb7185", "#facc15", "#60a5fa",
];

const toDeg = (rad: number) => (rad * 180) / Math.PI;
const toRad = (deg: number) => (deg * Math.PI) / 180;
const clamp = (x: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, x));

// 30s coarse step; every boundary is refined to ~1s by bisection.
const STEP_SECONDS = 30;
// A pass still inside the limit when the scan window ends is followed for
// up to this long so its real LOS can be found (instead of being dropped).
const LOS_EXTENSION_SECONDS = 30 * 60;
const EARTH_MU_KM3_S2 = 398600.4418;

// ─── Pass-geometry formulas (pass_geometry.html) ─────────────────────────

export type PassGeometry = {
  /** Slant range satellite → target (km). */
  rangeKm: number;
  /** Elevation of the satellite seen from the target (deg). */
  elevationDeg: number;
  /** Off-nadir tilt at the satellite toward the target (deg). */
  tiltDeg: number;
  /** Central angle sub-satellite point ↔ target (deg). */
  centralAngleDeg: number;
  /** Ground distance sub-satellite point ↔ target (km). */
  groundDistanceKm: number;
};

/** Range, elevation and tilt for a central angle θ (radians). */
export function geometryFromCentralAngle(thetaRad: number, orbitHeightKm: number = ORBIT_HEIGHT_KM): PassGeometry {
  const R = SPOT_EARTH_RADIUS_KM;
  const a = R + orbitHeightKm;
  const d = Math.sqrt(R * R + a * a - 2 * R * a * Math.cos(thetaRad));
  return {
    rangeKm: d,
    elevationDeg: toDeg(Math.asin(clamp((a * Math.cos(thetaRad) - R) / d, -1, 1))),
    tiltDeg: toDeg(Math.asin(clamp((R * Math.sin(thetaRad)) / d, -1, 1))),
    centralAngleDeg: toDeg(thetaRad),
    groundDistanceKm: R * thetaRad,
  };
}

/** Central angle (radians) at which the target sees the satellite at `elevationDeg`. */
export function centralAngleForElevationRad(elevationDeg: number, orbitHeightKm: number = ORBIT_HEIGHT_KM): number {
  const R = SPOT_EARTH_RADIUS_KM;
  const a = R + orbitHeightKm;
  const e = toRad(elevationDeg);
  return Math.PI / 2 - e - Math.asin(clamp((R * Math.cos(e)) / a, -1, 1));
}

/** Central angle (radians) at which the slant range equals `rangeKm`. */
export function centralAngleForRangeRad(rangeKm: number, orbitHeightKm: number = ORBIT_HEIGHT_KM): number {
  const R = SPOT_EARTH_RADIUS_KM;
  const a = R + orbitHeightKm;
  return Math.acos(clamp((R * R + a * a - rangeKm * rangeKm) / (2 * R * a), -1, 1));
}

/** Min elevation → max slant range (km). */
export function rangeForElevationKm(elevationDeg: number, orbitHeightKm: number = ORBIT_HEIGHT_KM): number {
  return geometryFromCentralAngle(centralAngleForElevationRad(elevationDeg, orbitHeightKm), orbitHeightKm).rangeKm;
}

/** Max slant range → min elevation (deg). */
export function elevationForRangeDeg(rangeKm: number, orbitHeightKm: number = ORBIT_HEIGHT_KM): number {
  return geometryFromCentralAngle(centralAngleForRangeRad(rangeKm, orbitHeightKm), orbitHeightKm).elevationDeg;
}

/** Slant range → tilt (deg) on the spherical model. */
export function tiltForRangeDeg(rangeKm: number, orbitHeightKm: number = ORBIT_HEIGHT_KM): number {
  return geometryFromCentralAngle(centralAngleForRangeRad(rangeKm, orbitHeightKm), orbitHeightKm).tiltDeg;
}

/** Mean orbit height (km) from a TLE's mean motion. Falls back to ORBIT_HEIGHT_KM. */
export function orbitHeightFromTleKm(tle: TleEntry | null | undefined): number {
  if (!tle) return ORBIT_HEIGHT_KM;
  try {
    const rec = getSatrec(tle) as unknown as { no_kozai?: number; no?: number };
    const nRadPerMin = rec.no_kozai ?? rec.no ?? 0;
    if (!(nRadPerMin > 0)) return ORBIT_HEIGHT_KM;
    const n = nRadPerMin / 60; // rad/s
    const a = Math.cbrt(EARTH_MU_KM3_S2 / (n * n));
    const h = a - SPOT_EARTH_RADIUS_KM;
    return Number.isFinite(h) && h > 100 && h < 5000 ? h : ORBIT_HEIGHT_KM;
  } catch {
    return ORBIT_HEIGHT_KM;
  }
}

// ─── The one limit the user enters ────────────────────────────────────────

export type SpotLimitMode = "elevation" | "range";

/** What the user typed: either a minimum elevation (deg) or a maximum range (km). */
export type SpotLimit = { mode: SpotLimitMode; value: number };

/** The entered limit plus everything calculated from it. */
export type SpotLimitGeometry = {
  mode: SpotLimitMode;
  /** Value as typed. */
  enteredValue: number;
  /** Value actually used (after clamping to the allowed span). */
  value: number;
  /** Set when the typed value was clamped. */
  clampNote: string | null;
  orbitHeightKm: number;

  /** Entered (elevation mode) or calculated (range mode). */
  minElevationDeg: number;
  /** Entered (range mode) or calculated (elevation mode). */
  maxRangeKm: number;
  /** Tilt at the limit = the largest tilt used during the window. */
  maxTiltDeg: number;
  /** Ground distance from the sub-satellite point to the target at the limit. */
  groundRadiusKm: number;
  centralAngleDeg: number;

  /** Calculated range is above MAX_LINK_RANGE_KM. */
  rangeAboveCeiling: boolean;
  /** Calculated elevation is below MIN_SPOT_ELEVATION_DEG. */
  elevationBelowFloor: boolean;
};

/** Default min elevation for Spot mode. 15° ≈ 1550 km at 550 km, i.e. inside
 *  the 1800 km link limit (10° would already need ~1815 km). */
export const DEFAULT_SPOT_MIN_ELEVATION_DEG = 15;

export const DEFAULT_SPOT_LIMIT: SpotLimit = { mode: "elevation", value: DEFAULT_SPOT_MIN_ELEVATION_DEG };

/** Allowed span for the value box of each mode. */
export function spotLimitBounds(mode: SpotLimitMode, orbitHeightKm: number = ORBIT_HEIGHT_KM): { min: number; max: number } {
  return mode === "elevation"
    ? { min: MIN_SPOT_ELEVATION_DEG, max: MAX_SPOT_ELEVATION_DEG }
    : { min: Math.ceil(Math.max(orbitHeightKm, 1)), max: MAX_LINK_RANGE_KM };
}

/** Default value when the user switches mode. */
export function defaultSpotLimitValue(mode: SpotLimitMode): number {
  return mode === "elevation" ? DEFAULT_SPOT_MIN_ELEVATION_DEG : MAX_LINK_RANGE_KM;
}

/** Calculates the other limit and the tilt from the one the user entered. */
export function deriveSpotLimit(limit: SpotLimit, orbitHeightKm: number = ORBIT_HEIGHT_KM): SpotLimitGeometry {
  const { min, max } = spotLimitBounds(limit.mode, orbitHeightKm);
  const entered = Number.isFinite(limit.value) ? limit.value : defaultSpotLimitValue(limit.mode);
  const value = clamp(entered, min, max);
  let clampNote: string | null = null;
  if (value !== entered) {
    clampNote =
      limit.mode === "elevation"
        ? `clamped to ${value}° (allowed ${min}°–${max}°)`
        : `clamped to ${value} km (allowed ${min}–${max} km)`;
  }

  const theta =
    limit.mode === "elevation"
      ? centralAngleForElevationRad(value, orbitHeightKm)
      : centralAngleForRangeRad(value, orbitHeightKm);
  const g = geometryFromCentralAngle(theta, orbitHeightKm);

  const minElevationDeg = limit.mode === "elevation" ? value : g.elevationDeg;
  const maxRangeKm = limit.mode === "range" ? value : g.rangeKm;

  return {
    mode: limit.mode,
    enteredValue: entered,
    value,
    clampNote,
    orbitHeightKm,
    minElevationDeg,
    maxRangeKm,
    maxTiltDeg: g.tiltDeg,
    groundRadiusKm: g.groundDistanceKm,
    centralAngleDeg: g.centralAngleDeg,
    rangeAboveCeiling: maxRangeKm > MAX_LINK_RANGE_KM + 0.5,
    elevationBelowFloor: minElevationDeg < MIN_SPOT_ELEVATION_DEG - 0.01,
  };
}

/** Accepts either the raw entered limit or an already derived one. */
export function resolveSpotLimit(
  limit: SpotLimit | SpotLimitGeometry,
  orbitHeightKm: number = ORBIT_HEIGHT_KM,
): SpotLimitGeometry {
  return "maxTiltDeg" in limit ? (limit as SpotLimitGeometry) : deriveSpotLimit(limit, orbitHeightKm);
}

/** Is a measured geometry inside the entered limit? */
export function isInsideSpotLimit(
  limit: Pick<SpotLimitGeometry, "mode" | "minElevationDeg" | "maxRangeKm">,
  g: { elevationDeg: number; rangeKm: number } | null | undefined,
): boolean {
  if (!g) return false;
  if (g.elevationDeg < 0) return false; // never below the horizon
  return limit.mode === "elevation" ? g.elevationDeg >= limit.minElevationDeg : g.rangeKm <= limit.maxRangeKm;
}

/** Tilt limits implied by the entered range limits (Strip-mode formula). */
export function deriveTiltLimitsDeg(
  minRangeKm: number,
  maxRangeKm: number,
): { minTiltDeg: number; maxTiltDeg: number } {
  return {
    minTiltDeg: tiltFromRangeKm(minRangeKm, ORBIT_HEIGHT_KM),
    maxTiltDeg: tiltFromRangeKm(maxRangeKm, ORBIT_HEIGHT_KM),
  };
}

/** Mission duration = sum of the frequency segment durations, capped at
 *  10 min. Falls back to 10 min while no frequency plan exists yet. */
export function missionDurationFromSegments(segments: { durationSeconds: number }[]): number {
  const sum = segments.reduce((s, seg) => s + (Number.isFinite(seg.durationSeconds) ? seg.durationSeconds : 0), 0);
  if (sum <= 0) return DEFAULT_MISSION_DURATION_SECONDS;
  return Math.min(MAX_MISSION_DURATION_SECONDS, sum);
}

// ─── Snapshot (real SGP4 look geometry) ───────────────────────────────────

/** Real geometry of a satellite against a ground point at one instant. */
export type SpotSnapshot = {
  elevationDeg: number;
  rangeKm: number;
  azimuthDeg: number;
  /** Off-nadir tilt toward the target: angle at the satellite between
   *  nadir (toward Earth's center) and the line of sight to the target. */
  tiltDeg: number;
  /** Sub-satellite point and height. */
  subLat: number;
  subLon: number;
  heightKm: number;
};

// ── satrec cache ──
// Georeference calls findPasses/findSpotOrbits repeatedly for the SAME
// satellites, so the parsed SatRec is cached by its exact TLE line pair (a TLE
// update changes the lines and so naturally invalidates the old entry).
const satrecCache = new Map<string, satellite.SatRec>();

function getSatrec(tle: TleEntry): satellite.SatRec {
  const key = `${tle.tle1}|${tle.tle2}`;
  const cached = satrecCache.get(key);
  if (cached) return cached;
  const satrec = satellite.twoline2satrec(tle.tle1, tle.tle2);
  satrecCache.set(key, satrec);
  return satrec;
}

function wrapLon(lon: number) {
  let l = lon;
  while (l > 180) l -= 360;
  while (l < -180) l += 360;
  return l;
}

/** Single shared low-level lookup: elevation, slant range, azimuth and tilt
 *  of a propagated satrec as seen from `point` at instant `t`. */
function snapshotAt(satrec: satellite.SatRec, point: GroundPoint, t: Date): SpotSnapshot | null {
  const geodetic = {
    latitude: satellite.degreesToRadians(point.lat),
    longitude: satellite.degreesToRadians(point.lon),
    height: 0,
  };
  const pv = satellite.propagate(satrec, t);
  if (!pv?.position || typeof pv.position === "boolean") return null;
  const gmst = satellite.gstime(t);
  const satEcf = satellite.eciToEcf(pv.position, gmst);
  const look = satellite.ecfToLookAngles(geodetic, satEcf);
  const tgtEcf = satellite.geodeticToEcf(geodetic);
  const sub = satellite.eciToGeodetic(pv.position, gmst);

  // Tilt: angle between (sat → Earth center) and (sat → target).
  const nx = -satEcf.x, ny = -satEcf.y, nz = -satEcf.z;
  const lx = tgtEcf.x - satEcf.x, ly = tgtEcf.y - satEcf.y, lz = tgtEcf.z - satEcf.z;
  const nLen = Math.hypot(nx, ny, nz);
  const lLen = Math.hypot(lx, ly, lz);
  const cosTilt = nLen > 0 && lLen > 0 ? (nx * lx + ny * ly + nz * lz) / (nLen * lLen) : 1;

  return {
    elevationDeg: toDeg(look.elevation),
    rangeKm: look.rangeSat,
    azimuthDeg: toDeg(look.azimuth),
    tiltDeg: toDeg(Math.acos(clamp(cosTilt, -1, 1))),
    subLat: toDeg(sub.latitude),
    subLon: wrapLon(toDeg(sub.longitude)),
    heightKm: sub.height,
  };
}

/** Public: real elevation / range / tilt of `tle` against `target` at `t`. */
export function spotGeometryAt(tle: TleEntry, target: GroundPoint, t: Date): SpotSnapshot | null {
  return snapshotAt(getSatrec(tle), target, t);
}

/** Evenly spaced samples of the real geometry over [from, to] — for charts. */
export function sampleSpotProfile(
  tle: TleEntry,
  target: GroundPoint,
  from: Date,
  to: Date,
  samples = 60,
): { t: Date; snap: SpotSnapshot }[] {
  const satrec = getSatrec(tle);
  const out: { t: Date; snap: SpotSnapshot }[] = [];
  const a = from.getTime();
  const span = Math.max(1, to.getTime() - a);
  const n = Math.max(2, samples);
  for (let i = 0; i < n; i++) {
    const t = new Date(a + (span * i) / (n - 1));
    const snap = snapshotAt(satrec, target, t);
    if (snap) out.push({ t, snap });
  }
  return out;
}

/** Bisect to the boundary between a known FALSE instant and a known TRUE
 *  instant (either order). Returns the TRUE-side instant, ~1s precision. */
function bisectBoundary(isTrue: (t: Date) => boolean, falseTime: Date, trueTime: Date): Date {
  let a = falseTime.getTime();
  let b = trueTime.getTime();
  while (Math.abs(b - a) > 1000) {
    const mid = (a + b) / 2;
    if (isTrue(new Date(mid))) b = mid;
    else a = mid;
  }
  return new Date(b);
}

// ─── Ground-station passes ────────────────────────────────────────────────

/** Every AOS/LOS pass of `tle` over `point` within [start, end] (horizon 0°).
 *  Used for the ground-station comms-pass list. */
export function findPasses(
  tle: TleEntry,
  point: GroundPoint,
  start: Date,
  end: Date,
  stepSeconds: number = STEP_SECONDS,
): Pass[] {
  const satrec = getSatrec(tle);
  const passes: Pass[] = [];
  const aboveHorizon = (t: Date) => (snapshotAt(satrec, point, t)?.elevationDeg ?? -180) >= 0;

  let inPass = false;
  let passStart: Date | null = null;
  let maxElev = -90;
  let rangeAtMax = 0;
  let prevTime: Date | null = null;

  for (let t = new Date(start); t <= end; t = new Date(t.getTime() + stepSeconds * 1000)) {
    const snap = snapshotAt(satrec, point, t);
    const elev = snap?.elevationDeg ?? -180;

    if (elev >= 0 && !inPass) {
      inPass = true;
      passStart = prevTime ? bisectBoundary(aboveHorizon, prevTime, t) : new Date(t);
      maxElev = elev;
      rangeAtMax = snap?.rangeKm ?? 0;
    }
    if (inPass && snap && elev > maxElev) {
      maxElev = elev;
      rangeAtMax = snap.rangeKm;
    }
    if (elev < 0 && inPass) {
      inPass = false;
      const los = prevTime ? bisectBoundary(aboveHorizon, t, prevTime) : new Date(t);
      if (passStart) {
        passes.push({ aos: passStart, los, maxElevationDeg: maxElev, rangeAtMaxElevationKm: rangeAtMax });
      }
      passStart = null;
      maxElev = -90;
    }
    prevTime = new Date(t);
  }

  return passes;
}

// ─── Spot-mode capture passes (Georeference target selection) ─────────────

export type SpotScanOptions = {
  /** Sum of the frequency segment durations (s). Capped at 600 s. */
  missionDurationSeconds?: number;
  /** Coarse scan step (s). Default 30. */
  stepSeconds?: number;
  /** Orbit height used for the calculated limit. Default: ORBIT_HEIGHT_KM (550 km). */
  orbitHeightKm?: number;
};

/** One upcoming capture opportunity.
 *  `aos` = missionStart and `los` = real LOS (limit lost), so code reading
 *  `aos` / `los` keeps working. */
export type SpotOrbit = Pass & {
  /** Slant range (km) to the target at mission start. */
  rangeAtAosKm: number;

  /** missionStart − 5 min. Shown as "AOS". */
  dummyAos: Date;
  /** First instant the entered limit is met. */
  missionStart: Date;
  /** missionStart + missionDurationSeconds (planned end). */
  missionEnd: Date;

  /** Geometry at mission start. */
  tiltAtStartDeg: number;
  elevationAtStartDeg: number;

  /** Closest approach inside the window (max elevation / min range / min tilt). */
  closestApproach: Date;
  minRangeKm: number;
  tiltAtClosestDeg: number;

  /** Geometry at LOS. */
  elevationAtLosDeg: number;
  rangeAtLosKm: number;
  tiltAtLosDeg: number;

  /** The limit this orbit was found with (entered + calculated values). */
  limit: SpotLimitGeometry;

  /** Requested mission length (s). */
  missionDurationSeconds: number;
  /** Seconds of the mission this pass can deliver (missionStart → LOS, ≤ duration). */
  availableSeconds: number;
  /** True if LOS comes before missionEnd. */
  shortPass: boolean;
  /** Seconds still needed from later passes (0 if complete). */
  remainingSeconds: number;
};

function clampDuration(sec: number | undefined): number {
  const v = sec ?? DEFAULT_MISSION_DURATION_SECONDS;
  if (!Number.isFinite(v)) return DEFAULT_MISSION_DURATION_SECONDS;
  return Math.max(0, Math.min(MAX_MISSION_DURATION_SECONDS, v));
}

/**
 * Upcoming orbits of `tle` over `target` for ONE entered limit
 * (min elevation OR max range). See the timeline at the top of the file.
 */
export function findSpotOrbits(
  tle: TleEntry,
  target: GroundPoint,
  start: Date,
  end: Date,
  limitInput: SpotLimit | SpotLimitGeometry,
  options: SpotScanOptions = {},
): SpotOrbit[] {
  const satrec = getSatrec(tle);
  const orbits: SpotOrbit[] = [];

  const limit = resolveSpotLimit(limitInput, options.orbitHeightKm ?? ORBIT_HEIGHT_KM);
  const stepSeconds = options.stepSeconds ?? STEP_SECONDS;
  const durationSec = clampDuration(options.missionDurationSeconds);

  const isInside = (t: Date) => isInsideSpotLimit(limit, snapshotAt(satrec, target, t));

  let inWindow = false;
  let missionStart: Date | null = null;
  let startSnap: SpotSnapshot | null = null;
  let best: { t: Date; snap: SpotSnapshot } | null = null;
  let prevTime: Date | null = null;
  let prevInside = false;

  const endMs = end.getTime();
  const hardEndMs = endMs + LOS_EXTENSION_SECONDS * 1000;

  for (let ms = start.getTime(); ms <= hardEndMs; ms += stepSeconds * 1000) {
    // Past the scan window: only keep going to close a window already open.
    if (ms > endMs && !inWindow) break;

    const t = new Date(ms);
    const snap = snapshotAt(satrec, target, t);
    const inside = isInsideSpotLimit(limit, snap);

    if (inside && !inWindow && snap) {
      inWindow = true;
      missionStart = prevTime && !prevInside ? bisectBoundary(isInside, prevTime, t) : new Date(t);
      startSnap = snapshotAt(satrec, target, missionStart) ?? snap;
      best = { t, snap };
    }

    if (inWindow && inside && snap && best && snap.rangeKm < best.snap.rangeKm) {
      best = { t, snap };
    }

    if (inWindow && !inside) {
      inWindow = false;
      // Real LOS: the entered limit is no longer met.
      const los = prevTime ? bisectBoundary(isInside, t, prevTime) : new Date(t);
      const losSnap = snapshotAt(satrec, target, los);

      if (missionStart && startSnap && best) {
        const closest = refineClosestApproach(satrec, target, best.t, stepSeconds);
        const startMs = missionStart.getTime();
        const missionEnd = new Date(startMs + durationSec * 1000);
        const passSeconds = Math.max(0, (los.getTime() - startMs) / 1000);
        const availableSeconds = Math.min(durationSec, passSeconds);

        orbits.push({
          aos: missionStart,
          los,
          maxElevationDeg: closest.snap.elevationDeg,
          rangeAtMaxElevationKm: closest.snap.rangeKm,
          rangeAtAosKm: startSnap.rangeKm,

          dummyAos: new Date(startMs - DUMMY_AOS_LEAD_MINUTES * 60 * 1000),
          missionStart,
          missionEnd,

          tiltAtStartDeg: startSnap.tiltDeg,
          elevationAtStartDeg: startSnap.elevationDeg,

          closestApproach: closest.t,
          minRangeKm: closest.snap.rangeKm,
          tiltAtClosestDeg: closest.snap.tiltDeg,

          elevationAtLosDeg: losSnap?.elevationDeg ?? limit.minElevationDeg,
          rangeAtLosKm: losSnap?.rangeKm ?? limit.maxRangeKm,
          tiltAtLosDeg: losSnap?.tiltDeg ?? limit.maxTiltDeg,

          limit,

          missionDurationSeconds: durationSec,
          availableSeconds,
          shortPass: los.getTime() < missionEnd.getTime(),
          remainingSeconds: Math.max(0, durationSec - availableSeconds),
        });
      }

      missionStart = null;
      startSnap = null;
      best = null;
    }

    prevTime = t;
    prevInside = inside;
  }

  return orbits;
}

/** Golden-section search for the minimum range around a coarse sample. */
function refineClosestApproach(
  satrec: satellite.SatRec,
  target: GroundPoint,
  around: Date,
  stepSeconds: number,
): { t: Date; snap: SpotSnapshot } {
  const f = (ms: number) => snapshotAt(satrec, target, new Date(ms))?.rangeKm ?? Infinity;
  let a = around.getTime() - stepSeconds * 1000;
  let b = around.getTime() + stepSeconds * 1000;
  const g = (Math.sqrt(5) - 1) / 2;
  let c = b - g * (b - a);
  let d = a + g * (b - a);
  let fc = f(c);
  let fd = f(d);
  while (b - a > 500) {
    if (fc < fd) {
      b = d; d = c; fd = fc; c = b - g * (b - a); fc = f(c);
    } else {
      a = c; c = d; fc = fd; d = a + g * (b - a); fd = f(d);
    }
  }
  const t = new Date((a + b) / 2);
  const snap = snapshotAt(satrec, target, t) ?? snapshotAt(satrec, target, around)!;
  return { t, snap };
}

/**
 * @deprecated Kept for older callers. Same as findSpotOrbits() with a
 * max-range limit (`maxRangeKm`); `minRangeKm` is ignored.
 */
export function findRangeGatedOrbits(
  tle: TleEntry,
  target: GroundPoint,
  start: Date,
  end: Date,
  _minRangeKm: number,
  maxRangeKm: number,
  options: SpotScanOptions & { minElevationDeg?: number } = {},
): SpotOrbit[] {
  return findSpotOrbits(tle, target, start, end, { mode: "range", value: maxRangeKm }, options);
}

// ─── Multi-pass mission planning ──────────────────────────────────────────

export type MissionAllocation = {
  /** Index into the orbits array passed in. */
  orbitIndex: number;
  /** Capture starts here (this pass's mission start). */
  start: Date;
  /** Capture ends here (mission time used on this pass). */
  end: Date;
  durationSeconds: number;
  /** Seconds into the overall mission where this chunk begins — the
   *  frequency segments are split across passes in this order. */
  planOffsetSeconds: number;
};

export type MissionPlan = {
  allocations: MissionAllocation[];
  totalSeconds: number;
  coveredSeconds: number;
  remainingSeconds: number;
  /** True when the whole mission duration is covered. */
  completed: boolean;
};

/** Chain passes (chronological, from `startIndex`) until the full mission
 *  duration is covered. Each pass contributes missionStart → LOS. */
export function planMissionAcrossPasses(
  orbits: SpotOrbit[],
  startIndex: number = 0,
  totalSeconds?: number,
): MissionPlan {
  const total = clampDuration(totalSeconds ?? orbits[startIndex]?.missionDurationSeconds);
  const allocations: MissionAllocation[] = [];
  let covered = 0;

  for (let i = startIndex; i < orbits.length && covered < total; i++) {
    const o = orbits[i];
    const take = Math.min(o.availableSeconds, total - covered);
    if (take <= 0) continue;
    allocations.push({
      orbitIndex: i,
      start: o.missionStart,
      end: new Date(o.missionStart.getTime() + take * 1000),
      durationSeconds: take,
      planOffsetSeconds: covered,
    });
    covered += take;
  }

  return {
    allocations,
    totalSeconds: total,
    coveredSeconds: covered,
    remainingSeconds: Math.max(0, total - covered),
    completed: covered >= total - 1e-6,
  };
}

// ─── Helpers ──────────────────────────────────────────────────────────────

export function fallbackColorForName(name: string, palette: string[]): string {
  let hash = 0;
  for (let i = 0; i < name.length; i++) {
    hash = (hash * 31 + name.charCodeAt(i)) >>> 0;
  }
  return palette[hash % palette.length];
}

export function formatUtc(d: Date): string {
  const day = d.getUTCDate().toString().padStart(2, "0");
  const month = d.toLocaleString("en-US", { month: "short", timeZone: "UTC" });
  const year = d.getUTCFullYear();
  const h = d.getUTCHours().toString().padStart(2, "0");
  const m = d.getUTCMinutes().toString().padStart(2, "0");
  const s = d.getUTCSeconds().toString().padStart(2, "0");
  return `${day} ${month} ${year}, ${h}:${m}:${s} UTC`;
}
