import { useCallback, useEffect, useRef, useState } from "react";
import * as Cesium from "cesium";

export type PickerMode = "marker" | "rectangle" | null;

export type RectangleBounds = {
  west: number;
  south: number;
  east: number;
  north: number;
};

type UseTargetPickerArgs = {
  viewerRef: React.MutableRefObject<Cesium.Viewer | null> | undefined;
  viewerReady: boolean;
  lat: number | null;
  lon: number | null;
  onLatChange: (v: number | null) => void;
  onLonChange: (v: number | null) => void;
  onRectangleChange?: (bounds: RectangleBounds | null) => void;
};

const MARKER_COLOR = "#ff3b3b";

// Google-Maps-style teardrop pin, built as an inline SVG data URI so no
// external asset is needed. The point of the teardrop (its anchor) sits
// at the bottom-center of the image — used only for point-drop targets.
function buildPinDataUri(color: string): string {
  const svg = `
    <svg xmlns="http://www.w3.org/2000/svg" width="40" height="52" viewBox="0 0 40 52">
      <defs>
        <filter id="pin-shadow" x="-50%" y="-50%" width="200%" height="200%">
          <feDropShadow dx="0" dy="1.5" stdDeviation="1.4" flood-color="#000" flood-opacity="0.45"/>
        </filter>
      </defs>
      <g filter="url(#pin-shadow)">
        <path d="M20 0C9 0 0 9 0 20c0 14 20 32 20 32s20-18 20-32C40 9 31 0 20 0z"
              fill="${color}" stroke="#7a1010" stroke-width="1.5"/>
        <circle cx="20" cy="19" r="7" fill="white"/>
        <circle cx="20" cy="19" r="3.2" fill="${color}"/>
      </g>
    </svg>`;
  return `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(svg)}`;
}

const MARKER_PIN_URI = buildPinDataUri(MARKER_COLOR);

/**
 * The pin is drawn on top of everything (so terrain / tracks never cover it).
 * This keeps it only on the side of the Earth that faces the camera: when the
 * globe is turned and the target goes round the back, the pin hides instead of
 * floating in front of the Earth. On the 2D map it is always shown.
 */
function pinVisible(viewer: Cesium.Viewer, position: Cesium.Cartesian3): Cesium.CallbackProperty {
  const R2 = 6_356_000 * 6_356_000; // polar radius: pins on the visible limb stay shown
  return new Cesium.CallbackProperty(() => {
    if (viewer.isDestroyed()) return false;
    if (viewer.scene.mode !== Cesium.SceneMode.SCENE3D) return true;
    const c = viewer.camera.positionWC;
    const vx = position.x - c.x, vy = position.y - c.y, vz = position.z - c.z;
    const vv = vx * vx + vy * vy + vz * vz;
    if (vv === 0) return true;
    const t = -(c.x * vx + c.y * vy + c.z * vz) / vv;
    if (t <= 0 || t >= 1) return true;
    const x = c.x + t * vx, y = c.y + t * vy, z = c.z + t * vz;
    return x * x + y * y + z * z > R2;
  }, false);
}

export function useTargetPicker({
  viewerRef,
  viewerReady,
  lat,
  lon,
  onLatChange,
  onLonChange,
  onRectangleChange,
}: UseTargetPickerArgs) {
  const [mode, setMode] = useState<PickerMode>(null);

  // Which shape is currently the committed target. Mutually exclusive:
  // dropping a marker clears any rectangle, drawing/editing a rectangle
  // clears the point pin. Georeference uses this to decide whether to
  // show the single lat/lon pair or the 4-box rectangle editor.
  const [shapeKind, setShapeKind] = useState<"point" | "rectangle" | null>(null);
  const [rectangleBounds, setRectangleBoundsState] = useState<RectangleBounds | null>(null);

  const markerEntityRef = useRef<Cesium.Entity | null>(null);
  const rectEntityRef = useRef<Cesium.Entity | null>(null);
  const hoverEntityRef = useRef<Cesium.Entity | null>(null);
  const handlerRef = useRef<Cesium.ScreenSpaceEventHandler | null>(null);
  const drawingRef = useRef(false);
  const startCartoRef = useRef<Cesium.Cartographic | null>(null);

  const onLatChangeRef = useRef(onLatChange);
  const onLonChangeRef = useRef(onLonChange);
  const onRectangleChangeRef = useRef(onRectangleChange);
  useEffect(() => {
    onLatChangeRef.current = onLatChange;
    onLonChangeRef.current = onLonChange;
    onRectangleChangeRef.current = onRectangleChange;
  });

  const getViewer = useCallback((): Cesium.Viewer | null => {
    const viewer = viewerRef?.current ?? null;
    if (!viewer || viewer.isDestroyed()) return null;
    return viewer;
  }, [viewerRef]);

  const clearMarker = useCallback(() => {
    const viewer = getViewer();
    if (viewer && markerEntityRef.current) {
      viewer.entities.remove(markerEntityRef.current);
      markerEntityRef.current = null;
    }
  }, [getViewer]);

  const clearRectangle = useCallback(() => {
    const viewer = getViewer();
    if (viewer && rectEntityRef.current) {
      viewer.entities.remove(rectEntityRef.current);
      rectEntityRef.current = null;
    }
  }, [getViewer]);

  const clearHoverPreview = useCallback(() => {
    const viewer = getViewer();
    if (viewer && hoverEntityRef.current) {
      viewer.entities.remove(hoverEntityRef.current);
      hoverEntityRef.current = null;
    }
  }, [getViewer]);

  // Square that follows the cursor before you click-drag — a guide, like a
  // screenshot tool's crosshair, so you see roughly where a selection will
  // start before you commit to one. Built as a Rectangle entity (same
  // technique as the real selection box) rather than a clamped polyline,
  // since ground-clamped polylines silently fail to render on some
  // terrain/browser combinations.
  const updateHoverPreview = useCallback(
    (carto: Cesium.Cartographic) => {
      const viewer = getViewer();
      if (!viewer) return;
      const size = Cesium.Math.toRadians(0.2);
      const rect = new Cesium.Rectangle(
        carto.longitude - size,
        carto.latitude - size,
        carto.longitude + size,
        carto.latitude + size,
      );

      if (!hoverEntityRef.current) {
        hoverEntityRef.current = viewer.entities.add({
          rectangle: {
            coordinates: rect,
            material: Cesium.Color.TRANSPARENT,
            outline: true,
            outlineColor: Cesium.Color.fromCssColorString(MARKER_COLOR).withAlpha(0.85),
            outlineWidth: 1.5,
            height: 0,
            classificationType: Cesium.ClassificationType.TERRAIN,
          },
        });
      } else if (hoverEntityRef.current.rectangle) {
        hoverEntityRef.current.rectangle.coordinates = new Cesium.ConstantProperty(rect);
      }
      viewer.scene.requestRender();
    },
    [getViewer],
  );

  // ── Keep the marker pin synced to the committed lat/lon, but only
  // while the current target is a point (never during rectangle mode). ──
  useEffect(() => {
    if (!viewerReady) return;
    const viewer = getViewer();
    if (!viewer) return;

    if (shapeKind !== "point" || lat === null || lon === null || Math.abs(lat) > 90 || Math.abs(lon) > 180) {
      clearMarker();
      return;
    }

    const position = Cesium.Cartesian3.fromDegrees(lon, lat, 0);
    if (!markerEntityRef.current) {
      markerEntityRef.current = viewer.entities.add({
        position,
        billboard: {
          show: pinVisible(viewer, position),
          image: MARKER_PIN_URI,
          width: 34,
          height: 44,
          verticalOrigin: Cesium.VerticalOrigin.BOTTOM,
          horizontalOrigin: Cesium.HorizontalOrigin.CENTER,
          disableDepthTestDistance: Number.POSITIVE_INFINITY,
          scaleByDistance: new Cesium.NearFarScalar(1.0e5, 1.2, 8.0e6, 0.5),
        },
      });
    } else {
      markerEntityRef.current.position = new Cesium.ConstantPositionProperty(position);
      if (markerEntityRef.current.billboard) markerEntityRef.current.billboard.show = pinVisible(viewer, position);
    }
    viewer.scene.requestRender();
  }, [lat, lon, shapeKind, viewerReady, getViewer, clearMarker]);

  const updateRectangleEntity = useCallback(
    (rect: Cesium.Rectangle) => {
      const viewer = getViewer();
      if (!viewer) return;
      if (!rectEntityRef.current) {
        rectEntityRef.current = viewer.entities.add({
          rectangle: {
            coordinates: rect,
            material: Cesium.Color.fromCssColorString(MARKER_COLOR).withAlpha(0.18),
            outline: true,
            outlineColor: Cesium.Color.fromCssColorString(MARKER_COLOR),
            outlineWidth: 2,
            height: 0,
            classificationType: Cesium.ClassificationType.TERRAIN,
          },
        });
      } else if (rectEntityRef.current.rectangle) {
        rectEntityRef.current.rectangle.coordinates = new Cesium.ConstantProperty(rect);
      }
      viewer.scene.requestRender();
    },
    [getViewer],
  );

  const finalizeRectangle = useCallback(
    (rect: Cesium.Rectangle) => {
      const west = Cesium.Math.toDegrees(rect.west);
      const south = Cesium.Math.toDegrees(rect.south);
      const east = Cesium.Math.toDegrees(rect.east);
      const north = Cesium.Math.toDegrees(rect.north);
      const bounds: RectangleBounds = { west, south, east, north };

      clearMarker(); // rectangle target never shows a center pin
      setShapeKind("rectangle");
      setRectangleBoundsState(bounds);
      onLatChangeRef.current(Number(((south + north) / 2).toFixed(6)));
      onLonChangeRef.current(Number(((west + east) / 2).toFixed(6)));
      onRectangleChangeRef.current?.(bounds);
    },
    [clearMarker],
  );

  const pickCarto = useCallback((viewer: Cesium.Viewer, pos: Cesium.Cartesian2): Cesium.Cartographic | null => {
    const cartesian = viewer.camera.pickEllipsoid(pos, viewer.scene.globe.ellipsoid);
    return cartesian ? viewer.scene.globe.ellipsoid.cartesianToCartographic(cartesian) : null;
  }, []);

  // ── Attach/detach a ScreenSpaceEventHandler whenever mode changes ──
  useEffect(() => {
    if (handlerRef.current) {
      handlerRef.current.destroy();
      handlerRef.current = null;
    }

    if (!viewerReady || mode === null) return;
    const viewer = getViewer();
    if (!viewer) return;

    const canvas = viewer.scene.canvas;
    canvas.style.cursor = "crosshair";
    const handler = new Cesium.ScreenSpaceEventHandler(canvas);
    handlerRef.current = handler;

    if (mode === "marker") {
      handler.setInputAction((click: Cesium.ScreenSpaceEventHandler.PositionedEvent) => {
        const carto = pickCarto(viewer, click.position);
        if (!carto) return; // missed the globe
        const latDeg = Number(Cesium.Math.toDegrees(carto.latitude).toFixed(6));
        const lonDeg = Number(Cesium.Math.toDegrees(carto.longitude).toFixed(6));

        clearRectangle(); // dropping a marker replaces any existing area
        setShapeKind("point");
        setRectangleBoundsState(null);
        onRectangleChangeRef.current?.(null);
        onLatChangeRef.current(latDeg);
        onLonChangeRef.current(lonDeg);
        setMode(null);
      }, Cesium.ScreenSpaceEventType.LEFT_CLICK);
    }

    if (mode === "rectangle") {
      viewer.scene.screenSpaceCameraController.enableInputs = false;
      clearRectangle();
      clearHoverPreview();

      handler.setInputAction((e: Cesium.ScreenSpaceEventHandler.PositionedEvent) => {
        const carto = pickCarto(viewer, e.position);
        if (!carto) return;
        drawingRef.current = true;
        startCartoRef.current = carto;
        clearHoverPreview(); // hand off from the hover guide to the real box

        // A rectangle with west===east / south===north has zero area, and
        // Cesium won't render it — so pad it by a tiny epsilon to get a
        // small but real box visible the instant you press down, exactly
        // like a screenshot/crop tool.
        const EPS = Cesium.Math.toRadians(0.01); // ~1 km near the equator
        const seedRect = new Cesium.Rectangle(
          carto.longitude - EPS,
          carto.latitude - EPS,
          carto.longitude + EPS,
          carto.latitude + EPS,
        );
        updateRectangleEntity(seedRect);
      }, Cesium.ScreenSpaceEventType.LEFT_DOWN);

      handler.setInputAction((e: Cesium.ScreenSpaceEventHandler.MotionEvent) => {
        const carto = pickCarto(viewer, e.endPosition);
        if (!carto) return;

        if (drawingRef.current && startCartoRef.current) {
          updateRectangleEntity(Cesium.Rectangle.fromCartographicArray([startCartoRef.current, carto]));
        } else {
          // Not dragging yet — show the dashed hover guide following the cursor.
          updateHoverPreview(carto);
        }
      }, Cesium.ScreenSpaceEventType.MOUSE_MOVE);

      handler.setInputAction((e: Cesium.ScreenSpaceEventHandler.PositionedEvent) => {
        if (!drawingRef.current || !startCartoRef.current) return;
        const carto = pickCarto(viewer, e.position) ?? startCartoRef.current;
        const rect = Cesium.Rectangle.fromCartographicArray([startCartoRef.current, carto]);
        updateRectangleEntity(rect);
        finalizeRectangle(rect);
        drawingRef.current = false;
        startCartoRef.current = null;
        viewer.scene.screenSpaceCameraController.enableInputs = true;
        setMode(null);
      }, Cesium.ScreenSpaceEventType.LEFT_UP);
    }

    return () => {
      handler.destroy();
      handlerRef.current = null;
      canvas.style.cursor = "";
      const v = getViewer();
      if (v) v.scene.screenSpaceCameraController.enableInputs = true;
      clearHoverPreview();
    };
  }, [mode, viewerReady, getViewer, pickCarto, clearRectangle, clearHoverPreview, updateHoverPreview, updateRectangleEntity, finalizeRectangle]);

  // ── Programmatically apply rectangle bounds (used by the 4 editable
  // West/South/East/North boxes in Georeference). ──
  const applyRectangleBounds = useCallback(
    (bounds: RectangleBounds) => {
      const rect = Cesium.Rectangle.fromDegrees(bounds.west, bounds.south, bounds.east, bounds.north);
      updateRectangleEntity(rect);
      finalizeRectangle(rect);
    },
    [updateRectangleEntity, finalizeRectangle],
  );

  // ── Called when the user manually edits the single Lat/Lon boxes —
  // that always means "I want a point target now", so drop any rectangle. ──
  const markAsPoint = useCallback(() => {
    if (shapeKind === "rectangle") {
      clearRectangle();
      setRectangleBoundsState(null);
      onRectangleChangeRef.current?.(null);
    }
    setShapeKind("point");
  }, [shapeKind, clearRectangle]);

  const cancel = useCallback(() => {
    clearRectangle();
    clearHoverPreview();
    setMode(null);
  }, [clearRectangle, clearHoverPreview]);

  useEffect(() => () => {
    clearMarker();
    clearRectangle();
    clearHoverPreview();
    if (handlerRef.current) handlerRef.current.destroy();
  }, [clearMarker, clearRectangle, clearHoverPreview]);

  return {
    mode,
    setMode,
    cancel,
    shapeKind,
    rectangleBounds,
    applyRectangleBounds,
    markAsPoint,
  };
}