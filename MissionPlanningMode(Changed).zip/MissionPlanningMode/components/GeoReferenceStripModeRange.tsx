import * as satellite from "satellite.js";
import type { TleEntry } from "./satelliteRangeUtils";
import type { RectangleBounds } from "./useTargetPicker";
import { FREQUENCY_PRESETS, type FrequencySegment, type FrequencyPresetId } from "./FrequencyAndTime";
import { rectangleAreaKm2 } from "./areaFromBounds";

/** Single source of truth for the AOI area (spherical formula in areaFromBounds.ts). */
export { rectangleAreaKm2 };

/* ============================================================================
 * STRIP-CAPTURE PLANNER
 *
 * INPUTS
 *   Rectangle (AOI), min / max slant range, min elevation, frequency plan.
 *   Tilt is derived from range: tilt = acos(H / range), H = 550 km
 *   (552.1 km -> 5.0 deg, 1800 km -> 72.2 deg).
 *
 * FLOW (per satellite of the constellation group)
 *   1. Propagate the TLE. A pass is the time the satellite is above the min
 *      elevation for at least one point of the rectangle.
 *   2. The rectangle is a fine grid of equal-area points. For every point we
 *      know WHEN the satellite passes it and how far it lies to the side of
 *      the ground track (cross-track distance).
 *   3. AIM (whole formation together, as in the original planner): all
 *      satellites of an orbit look sideways with the SAME tilt / side for the
 *      whole pass, so each swath = that satellite's own ground track + the
 *      common look offset. The offset is chosen so the UNION of the formation's
 *      swaths covers as many NOT-yet-covered, reachable points as possible.
 *      Reachable = elevation >= min and range within [min, max].
 *   4. MISSION START = first moment the swath overlaps the rectangle on a point
 *      that meets the limits. The limits are checked ONLY here.
 *      AOS          = mission start - 5 min
 *      MISSION END  = mission start + sum of frequency segment durations
 *      LOS          = elevation drops below the min elevation for the whole
 *                     rectangle (satellite sets). Range / tilt do not matter.
 *      If LOS comes before mission end the pass is flagged (truncatedByLos)
 *      so the UI can alert; the sensor still captures until mission end.
 *   5. CAPTURE: every point the swath sweeps between mission start and mission
 *      end counts (no limit checks during the mission). The swath width
 *      follows the active frequency segment; each segment gives one swept
 *      rectangle per satellite (clipped to the AOI box) for drawing.
 *   6. Later passes only count points not covered before -> new / remaining.
 *
 * CONSTELLATION
 *   Satellites 40-60 km apart rise a few seconds apart. Passes rising within
 *   FORMATION_WINDOW_SECONDS form one ORBIT (earliest = leader, others report
 *   their offset). Because they share one pointing, satellites side by side
 *   (different planes) image overlapping neighbouring strips and satellites
 *   on the same track image the same strip a few seconds apart. Orbits adding
 *   less than MIN_ORBIT_GAIN_FRACTION of the AOI are dropped.
 * ==========================================================================*/

/* ------------------------------------------------------------------ */
/* Configuration                                                      */
/* ------------------------------------------------------------------ */

export const ORBIT_HEIGHT_KM = 550;
export const DEFAULT_MIN_ELEVATION_DEG = 10;
/** Legacy name kept for existing imports. */
export const STRIP_ELEVATION_MIN_DEG = DEFAULT_MIN_ELEVATION_DEG;
export const AOS_LEAD_SECONDS = 5 * 60;
export const FORMATION_WINDOW_SECONDS = 180;
/** Fraction at (or above) which the AOI counts as fully covered. */
export const FULL_COVERAGE_FRACTION = 0.995;
/** Orbits that add less than this fraction of the AOI are not listed. */
export const MIN_ORBIT_GAIN_FRACTION = 0.01;

const EARTH_RADIUS_KM = 6371.0088;
const COARSE_STEP_SECONDS = 30;
const REFINEMENT_MS = 500;
const SET_SCAN_STEP_SECONDS = 10;
const SET_HORIZON_SECONDS = 30 * 60;
const MAX_ORBITS_SAFETY = 60;
/** Visibility / LOS is checked on a VISIBILITY_GRID x VISIBILITY_GRID grid of the rectangle. */
const VISIBILITY_GRID = 5;

/** Approximate number of equal-area cells used to measure AOI coverage. */
const TARGET_SAMPLE_COUNT = 16000;
const MAX_SAMPLES_PER_AXIS = 300;

const toDeg = (r: number) => (r * 180) / Math.PI;
const toRad = (d: number) => (d * Math.PI) / 180;
const clamp = (x: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, x));

/* ------------------------------------------------------------------ */
/* Range <-> tilt <-> ground distance <-> elevation                   */
/* ------------------------------------------------------------------ */

/** Off-nadir tilt for a slant range (flat model): tilt = acos(H / range). */
export function tiltFromRangeKm(rangeKm: number, orbitHeightKm = ORBIT_HEIGHT_KM): number {
  if (!(rangeKm > 0)) return 0;
  return toDeg(Math.acos(clamp(orbitHeightKm / rangeKm, -1, 1)));
}

/** Largest slant range at which a ground point still sees the satellite at >= minElevation. */
export function maxRangeForElevationKm(minElevationDeg: number, orbitHeightKm = ORBIT_HEIGHT_KM): number {
  const R = EARTH_RADIUS_KM;
  const s = Math.sin(toRad(minElevationDeg));
  return -R * s + Math.sqrt((R * s) ** 2 + 2 * R * orbitHeightKm + orbitHeightKm ** 2);
}

/** Ground distance from the sub-satellite point to a point seen at this slant range. */
function groundDistanceForRangeKm(rangeKm: number, orbitHeightKm = ORBIT_HEIGHT_KM): number {
  const R = EARTH_RADIUS_KM;
  const r = R + orbitHeightKm;
  const rho = Math.max(orbitHeightKm, rangeKm);
  return R * Math.acos(clamp((R * R + r * r - rho * rho) / (2 * R * r), -1, 1));
}

/** Slant range to a ground point at this distance from the sub-satellite point. */
function rangeForGroundDistanceKm(groundKm: number, orbitHeightKm = ORBIT_HEIGHT_KM): number {
  const R = EARTH_RADIUS_KM;
  const r = R + orbitHeightKm;
  const theta = groundKm / R;
  return Math.sqrt(R * R + r * r - 2 * R * r * Math.cos(theta));
}

export type StripGateSummary = {
  minRangeKm: number;
  maxRangeKm: number;
  minElevationDeg: number;
  /** Tilt derived from the entered ranges. */
  minTiltDeg: number;
  maxTiltDeg: number;
  /** Range at which the elevation limit is reached. */
  elevationRangeLimitKm: number;
  /** min(maxRange, elevationRangeLimit): the range limit that really applies. */
  effectiveMaxRangeKm: number;
  effectiveMaxTiltDeg: number;
  limitedByElevation: boolean;
};

export function stripGateSummary(
  minRangeKm: number,
  maxRangeKm: number,
  minElevationDeg: number,
  orbitHeightKm = ORBIT_HEIGHT_KM,
): StripGateSummary {
  const elevationRangeLimitKm = maxRangeForElevationKm(minElevationDeg, orbitHeightKm);
  const effectiveMaxRangeKm = Math.min(maxRangeKm, elevationRangeLimitKm);
  return {
    minRangeKm,
    maxRangeKm,
    minElevationDeg,
    minTiltDeg: tiltFromRangeKm(minRangeKm, orbitHeightKm),
    maxTiltDeg: tiltFromRangeKm(maxRangeKm, orbitHeightKm),
    elevationRangeLimitKm,
    effectiveMaxRangeKm,
    effectiveMaxTiltDeg: tiltFromRangeKm(effectiveMaxRangeKm, orbitHeightKm),
    limitedByElevation: elevationRangeLimitKm < maxRangeKm,
  };
}

/* ------------------------------------------------------------------ */
/* Formatting + small geometry helpers shared with the animations     */
/* ------------------------------------------------------------------ */

/**
 * Formats a 0..1 fraction as a percentage WITHOUT rounding small values to 0%.
 *   0.0023 -> "0.23%"   0.00004 -> "<0.01%"   0.037 -> "3.7%"
 *   0.47 -> "47%"       0.9996 -> "99.9%"     1 -> "100%"
 */
export function formatCoveragePercent(fraction: number): string {
  const pct = fraction * 100;
  if (!Number.isFinite(pct) || pct <= 0) return "0%";
  if (pct >= 100) return "100%";
  if (pct >= 99.5) return `${(Math.floor(pct * 10) / 10).toFixed(1)}%`;
  if (pct < 0.01) return "<0.01%";
  if (pct < 1) return `${pct.toFixed(2)}%`;
  if (pct < 10) return `${pct.toFixed(1)}%`;
  return `${pct.toFixed(0)}%`;
}

type LatLon = { lat: number; lon: number };

/** Which part of the rectangle a point is in: "NW part", "north part", "center", ... */
export function rectangleRegionLabel(p: LatLon, b: RectangleBounds): string {
  const fy = (p.lat - b.south) / Math.max(1e-9, b.north - b.south);
  const fx = (p.lon - b.west) / Math.max(1e-9, b.east - b.west);
  const row = fy > 2 / 3 ? "N" : fy < 1 / 3 ? "S" : "";
  const col = fx > 2 / 3 ? "E" : fx < 1 / 3 ? "W" : "";
  if (!row && !col) return "center";
  const names: Record<string, string> = { N: "north", S: "south", E: "east", W: "west" };
  if (row && col) return `${row}${col} part`;
  return `${names[row || col]} part`;
}

/** Clips a polygon (lat/lon) to the rectangle (Sutherland–Hodgman). */
export function clipPolygonToBounds(poly: LatLon[], b: RectangleBounds): LatLon[] {
  type Edge = { inside: (p: LatLon) => boolean; cut: (a: LatLon, c: LatLon) => LatLon };
  const atLon = (lon: number) => (a: LatLon, c: LatLon): LatLon => {
    const f = (lon - a.lon) / (c.lon - a.lon);
    return { lat: a.lat + (c.lat - a.lat) * f, lon };
  };
  const atLat = (lat: number) => (a: LatLon, c: LatLon): LatLon => {
    const f = (lat - a.lat) / (c.lat - a.lat);
    return { lat, lon: a.lon + (c.lon - a.lon) * f };
  };
  const edges: Edge[] = [
    { inside: (p) => p.lon >= b.west, cut: atLon(b.west) },
    { inside: (p) => p.lon <= b.east, cut: atLon(b.east) },
    { inside: (p) => p.lat >= b.south, cut: atLat(b.south) },
    { inside: (p) => p.lat <= b.north, cut: atLat(b.north) },
  ];
  let out = poly;
  for (const e of edges) {
    if (out.length === 0) break;
    const input = out;
    out = [];
    for (let i = 0; i < input.length; i++) {
      const cur = input[i];
      const prev = input[(i + input.length - 1) % input.length];
      const curIn = e.inside(cur);
      const prevIn = e.inside(prev);
      if (curIn) {
        if (!prevIn) out.push(e.cut(prev, cur));
        out.push(cur);
      } else if (prevIn) {
        out.push(e.cut(prev, cur));
      }
    }
  }
  return out;
}

/* ------------------------------------------------------------------ */
/* Public types                                                       */
/* ------------------------------------------------------------------ */

type Vec3 = [number, number, number];

/** The rectangle point that started the mission, with the limits checked there. */
export type AoiCapturePoint = {
  lat: number;
  lon: number;
  /** Part of the rectangle, e.g. "NW part". */
  label: string;
  elevationDeg: number;
  slantRangeKm: number;
  tiltDeg: number;
};

export type StripFootprint = {
  satelliteName: string;
  /** Swept rectangle (clipped to the AOI box):
   *  [0] alongMin/crossMin [1] alongMin/crossMax [2] alongMax/crossMax [3] alongMax/crossMin. */
  corners: LatLon[];
  /** Seconds after THIS pass's mission start at which the swath is at the two ends. */
  tStartSec: number;
  tEndSec: number;
};

export type SegmentCoverage = {
  segmentId: string;
  presetId: FrequencyPresetId;
  startSeconds: number;
  durationSeconds: number;
  swathKm: number;
  footprints: StripFootprint[];
  /** AOI area first imaged during this segment (inside this pass). */
  coveredAreaKm2: number;
  coveredFraction: number;
  /** Same, but only points not covered by earlier passes. */
  newlyCoveredFraction: number;
};

export type SatelliteStateAtStart = {
  lat: number;
  lon: number;
  altitudeKm: number;
  /** Inertial velocity magnitude from SGP4 (km/s). */
  velocityKmPerSec: number;
};

/** Where the sensor looks during the pass (fixed for the pass). */
export type SensorLook = {
  side: "left" | "right";
  /** Distance of the swath centre from the ground track (km). */
  crossTrackOffsetKm: number;
  tiltDeg: number;
  slantRangeKm: number;
};

export type StripPass = {
  satelliteName: string;

  /** Orbit grouping (filled once the orbit is kept). */
  orbitIndex: number;
  isLeader: boolean;
  leaderName: string;
  offsetFromLeaderMs: number;

  /** The four times of the pass. */
  aos: Date;          // missionStart - 5 min
  missionStart: Date; // swath first overlaps the rectangle where limits are met
  missionEnd: Date;   // missionStart + frequency plan length
  los: Date;          // elevation drops below the min elevation (satellite sets)

  /** Frequency plan length (s). */
  missionSeconds: number;
  /** Seconds imaged (= missionSeconds; the sensor is not stopped by LOS). */
  captureSeconds: number;
  /** LOS arrives before mission end (alert only). */
  truncatedByLos: boolean;
  /** Seconds after mission start at which the swath leaves the AOI (last point imaged).
   *  Shorter than missionSeconds when the AOI is crossed before the plan ends. */
  aoiCaptureSeconds: number;
  /** missionStart + aoiCaptureSeconds. */
  aoiCaptureEnd: Date;

  satelliteState: SatelliteStateAtStart | null;
  look: SensorLook;
  capturePoint: AoiCapturePoint;
  entrySideLabel: string;
  exitSideLabel: string;
  orientation: {
    headingDeg: number;
    rectangleTrackAngleDeg: number;
    crossTrackWidthKm: number;
    alongTrackLengthKm: number;
  };

  segmentBreakdown: SegmentCoverage[];

  passCoveredFraction: number;
  passCoveredAreaKm2: number;
  newlyCoveredFraction: number;
  newlyCoveredAreaKm2: number;
  /** Totals after this pass. */
  cumulativeCoveredFraction: number;
  remainingFraction: number;
  remainingAreaKm2: number;

  /** AOI fraction imaged by this pass vs. seconds after its mission start (index = second). */
  coverageCurve: number[];
  /** Same, but only NEW area (what this pass adds to the running total). */
  newCoverageCurve: number[];
};

export type StripOrbit = {
  index: number;
  leaderName: string;
  /** Leader first, then the other satellites by offset. */
  passes: StripPass[];
  aos: Date;
  missionStart: Date;
  /** Latest mission end / LOS / capture end among the members. */
  missionEnd: Date;
  los: Date;
  captureEnd: Date;
  /** At least one satellite lost signal before its mission end. */
  truncatedByLos: boolean;
  /** When the last satellite of the orbit leaves the AOI (target imaged by this orbit). */
  aoiCaptureEnd: Date;
  /** Seconds from the orbit's mission start until aoiCaptureEnd (time needed per orbit). */
  aoiCaptureSeconds: number;
  newlyCoveredFraction: number;
  newlyCoveredAreaKm2: number;
  cumulativeCoveredFraction: number;
  remainingFraction: number;
  remainingAreaKm2: number;
};

export type StripCapturePlanResult = {
  bounds: RectangleBounds;
  aoiAreaKm2: number;
  sampleCount: number;
  orbits: StripOrbit[];
  /** All passes of all orbits, in time order. */
  passes: StripPass[];
  totalCoveredFraction: number;
  totalCoveredAreaKm2: number;
  remainingAreaKm2: number;
  fullyCovered: boolean;
  gate: StripGateSummary;
  missionSeconds: number;
};

export type StripPlannerOptions = {
  minElevationDeg?: number;
  orbitHeightKm?: number;
  aosLeadSeconds?: number;
  formationWindowSeconds?: number;
  minOrbitGainFraction?: number;
  stepSeconds?: number;
};

/* ------------------------------------------------------------------ */
/* Spherical helpers                                                  */
/* ------------------------------------------------------------------ */

function haversineDistanceKm(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const phi1 = toRad(lat1), phi2 = toRad(lat2);
  const dPhi = toRad(lat2 - lat1);
  const dLambda = toRad(lon2 - lon1);
  const a = Math.sin(dPhi / 2) ** 2 + Math.cos(phi1) * Math.cos(phi2) * Math.sin(dLambda / 2) ** 2;
  return EARTH_RADIUS_KM * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function initialBearingDeg(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const phi1 = toRad(lat1), phi2 = toRad(lat2);
  const dLambda = toRad(lon2 - lon1);
  const y = Math.sin(dLambda) * Math.cos(phi2);
  const x = Math.cos(phi1) * Math.sin(phi2) - Math.sin(phi1) * Math.cos(phi2) * Math.cos(dLambda);
  return (toDeg(Math.atan2(y, x)) + 360) % 360;
}

/* ------------------------------------------------------------------ */
/* Satellite cache + propagation                                      */
/* ------------------------------------------------------------------ */

const satrecCache = new Map<string, satellite.SatRec>();
function getSatrec(tle: TleEntry): satellite.SatRec {
  const key = `${tle.tle1}|${tle.tle2}`;
  const cached = satrecCache.get(key);
  if (cached) return cached;
  const rec = satellite.twoline2satrec(tle.tle1, tle.tle2);
  satrecCache.set(key, rec);
  return rec;
}

type SatFrame = {
  position: satellite.EciVec3<number>;
  velocity: satellite.EciVec3<number> | null;
  gmst: satellite.GMSTime;
  ecf: Vec3;
};

function propagateFrame(satrec: satellite.SatRec, t: Date): SatFrame | null {
  const pv = satellite.propagate(satrec, t);
  if (!pv?.position || typeof pv.position === "boolean") return null;
  const gmst = satellite.gstime(t);
  const e = satellite.eciToEcf(pv.position, gmst);
  const velocity = pv.velocity && typeof pv.velocity !== "boolean" ? pv.velocity : null;
  return { position: pv.position, velocity, gmst, ecf: [e.x, e.y, e.z] };
}

function subpointFromFrame(frame: SatFrame): LatLon & { heightKm: number } {
  const geo = satellite.eciToGeodetic(frame.position, frame.gmst);
  return {
    lat: satellite.degreesLat(geo.latitude),
    lon: satellite.degreesLong(geo.longitude),
    heightKm: geo.height,
  };
}

/* ------------------------------------------------------------------ */
/* Look geometry: elevation, slant range, tilt                        */
/* ------------------------------------------------------------------ */

type PointGeo = LatLon & { ecf: Vec3; up: Vec3 };

function makePointGeo(lat: number, lon: number): PointGeo {
  const phi = toRad(lat), lam = toRad(lon);
  const e = satellite.geodeticToEcf({ latitude: phi, longitude: lam, height: 0 });
  return {
    lat, lon,
    ecf: [e.x, e.y, e.z],
    up: [Math.cos(phi) * Math.cos(lam), Math.cos(phi) * Math.sin(lam), Math.sin(phi)],
  };
}

type LookMetrics = { elevationDeg: number; rangeKm: number; tiltDeg: number };

type Gate = { minRangeKm: number; maxRangeKm: number; minElevationDeg: number; orbitHeightKm: number };

function lookMetrics(sat: Vec3, p: PointGeo, orbitHeightKm: number): LookMetrics {
  const dx = sat[0] - p.ecf[0], dy = sat[1] - p.ecf[1], dz = sat[2] - p.ecf[2];
  const range = Math.hypot(dx, dy, dz);
  const elevationDeg = toDeg(Math.asin(clamp((dx * p.up[0] + dy * p.up[1] + dz * p.up[2]) / range, -1, 1)));
  return { elevationDeg, rangeKm: range, tiltDeg: tiltFromRangeKm(range, orbitHeightKm) };
}

/** Capture limits (used only to find the mission start and to aim). Tilt follows from range. */
function meetsGate(m: LookMetrics, g: Gate): boolean {
  return m.elevationDeg >= g.minElevationDeg && m.rangeKm >= g.minRangeKm && m.rangeKm <= g.maxRangeKm;
}

/* ------------------------------------------------------------------ */
/* Visibility (AOS search window) and LOS: elevation only             */
/* ------------------------------------------------------------------ */

function visibilityGrid(bounds: RectangleBounds): PointGeo[] {
  const pts: PointGeo[] = [];
  for (let j = 0; j < VISIBILITY_GRID; j++) {
    const lat = bounds.south + ((bounds.north - bounds.south) * j) / (VISIBILITY_GRID - 1);
    for (let i = 0; i < VISIBILITY_GRID; i++) {
      const lon = bounds.west + ((bounds.east - bounds.west) * i) / (VISIBILITY_GRID - 1);
      pts.push(makePointGeo(lat, lon));
    }
  }
  return pts;
}

/** Satellite is above the min elevation for at least one point of the rectangle. */
function aboveHorizon(frame: SatFrame, pts: PointGeo[], gate: Gate): boolean {
  for (const p of pts) {
    if (lookMetrics(frame.ecf, p, gate.orbitHeightKm).elevationDeg >= gate.minElevationDeg) return true;
  }
  return false;
}

function aboveHorizonAt(satrec: satellite.SatRec, ms: number, pts: PointGeo[], gate: Gate): boolean {
  const frame = propagateFrame(satrec, new Date(ms));
  return frame ? aboveHorizon(frame, pts, gate) : false;
}

/** LOS: first moment after `fromMs` at which the elevation is below the min for every point. */
function findSet(satrec: satellite.SatRec, pts: PointGeo[], fromMs: number, gate: Gate): number {
  const stepMs = SET_SCAN_STEP_SECONDS * 1000;
  let lastOk = fromMs;
  for (let ms = fromMs + stepMs; ms <= fromMs + SET_HORIZON_SECONDS * 1000; ms += stepMs) {
    if (aboveHorizonAt(satrec, ms, pts, gate)) { lastOk = ms; continue; }
    let lo = lastOk;
    let hi = ms;
    while (hi - lo > REFINEMENT_MS) {
      const mid = Math.floor((lo + hi) / 2);
      if (aboveHorizonAt(satrec, mid, pts, gate)) lo = mid; else hi = mid;
    }
    return hi;
  }
  return fromMs + SET_HORIZON_SECONDS * 1000;
}

type SatRecEntry = { tle: TleEntry; satrec: satellite.SatRec };
type RiseCandidate = SatRecEntry & { riseMs: number };

/**
 * Lazily yields every satellite's rise (above min elevation) in time order:
 * one continuous scan of the window for the whole constellation.
 */
function* scanRises(
  satRecs: SatRecEntry[], pts: PointGeo[], start: Date, end: Date, gate: Gate, stepSeconds: number,
): Generator<RiseCandidate> {
  const prevUp = satRecs.map(() => false);
  let prevMs: number | null = null;

  for (let ms = start.getTime(); ms <= end.getTime(); ms += stepSeconds * 1000) {
    const found: RiseCandidate[] = [];
    satRecs.forEach((entry, i) => {
      const up = aboveHorizonAt(entry.satrec, ms, pts, gate);
      if (up && !prevUp[i]) {
        let riseMs = ms;
        if (prevMs !== null) {
          let lo = prevMs;
          let hi = ms;
          while (hi - lo > REFINEMENT_MS) {
            const mid = Math.floor((lo + hi) / 2);
            if (aboveHorizonAt(entry.satrec, mid, pts, gate)) hi = mid; else lo = mid;
          }
          riseMs = hi;
        }
        found.push({ ...entry, riseMs });
      }
      prevUp[i] = up;
    });
    found.sort((a, b) => a.riseMs - b.riseMs);
    yield* found;
    prevMs = ms;
  }
}

/* ------------------------------------------------------------------ */
/* AOI coverage samples (equal-area grid over the real AOI)           */
/* ------------------------------------------------------------------ */

function buildAoiSamples(bounds: RectangleBounds): { samples: PointGeo[]; cellAreaKm2: number; totalAreaKm2: number } {
  const totalAreaKm2 = rectangleAreaKm2(bounds);
  const midLat = (bounds.north + bounds.south) / 2;
  const heightKm = haversineDistanceKm(bounds.south, bounds.west, bounds.north, bounds.west);
  const widthKm = haversineDistanceKm(midLat, bounds.west, midLat, bounds.east);
  const cellKm = Math.sqrt(Math.max(totalAreaKm2, 1) / TARGET_SAMPLE_COUNT);
  const nu = Math.min(MAX_SAMPLES_PER_AXIS, Math.max(1, Math.ceil(widthKm / cellKm)));
  const nv = Math.min(MAX_SAMPLES_PER_AXIS, Math.max(1, Math.ceil(heightKm / cellKm)));

  // Rows evenly spaced in sin(lat) -> every cell has the same area on the sphere.
  const sN = Math.sin(toRad(bounds.north));
  const sS = Math.sin(toRad(bounds.south));
  const samples: PointGeo[] = [];
  for (let j = 0; j < nv; j++) {
    const lat = toDeg(Math.asin(sN - ((j + 0.5) / nv) * (sN - sS)));
    for (let i = 0; i < nu; i++) {
      const lon = bounds.west + ((i + 0.5) / nu) * (bounds.east - bounds.west);
      samples.push(makePointGeo(lat, lon));
    }
  }
  return { samples, cellAreaKm2: totalAreaKm2 / (nu * nv), totalAreaKm2 };
}

/* ------------------------------------------------------------------ */
/* Local along/cross frame anchored at the AOI centre                 */
/* ------------------------------------------------------------------ */

function projectToFrame(lat: number, lon: number, originLat: number, originLon: number, headingRad: number) {
  const kmPerDegLat = 111.32;
  const kmPerDegLon = 111.32 * Math.cos(toRad(originLat));
  const eastKm = (lon - originLon) * kmPerDegLon;
  const northKm = (lat - originLat) * kmPerDegLat;
  return {
    along: eastKm * Math.sin(headingRad) + northKm * Math.cos(headingRad),
    cross: eastKm * Math.cos(headingRad) - northKm * Math.sin(headingRad),
  };
}

function frameToLatLon(originLat: number, originLon: number, headingRad: number, along: number, cross: number): LatLon {
  const kmPerDegLat = 111.32;
  const kmPerDegLon = 111.32 * Math.cos(toRad(originLat));
  const eastKm = along * Math.sin(headingRad) + cross * Math.cos(headingRad);
  const northKm = along * Math.cos(headingRad) - cross * Math.sin(headingRad);
  return { lat: originLat + northKm / kmPerDegLat, lon: originLon + eastKm / kmPerDegLon };
}

/* ------------------------------------------------------------------ */
/* One satellite pass                                                 */
/* ------------------------------------------------------------------ */

type PlanContext = {
  bounds: RectangleBounds;
  segments: FrequencySegment[];
  missionSeconds: number;
  aosLeadSeconds: number;
  gate: Gate;
  visPts: PointGeo[];
  samples: PointGeo[];
  cellAreaKm2: number;
  totalAreaKm2: number;
  centerLat: number;
  centerLon: number;
  /** Points covered by earlier passes. */
  covered: Uint8Array;
  coveredCount: number;
};

type EvaluatedPass = { pass: StripPass; changed: number[] };

/** Segment active at `tau` seconds after mission start (or -1 in a gap / after the plan). */
function segmentAt(segments: FrequencySegment[], tau: number): number {
  for (let i = 0; i < segments.length; i++) {
    const s = segments[i];
    if (tau >= s.startSeconds && tau <= s.startSeconds + s.durationSeconds) return i;
  }
  return -1;
}

/** One satellite's geometry over the AOI for one pass (before the sensor is aimed). */
type PassPrep = {
  cand: RiseCandidate;
  riseMs: number;
  setMs: number;
  ecf: Float64Array;
  sAlong: Float64Array;
  sCross: Float64Array;
  iLo: number;
  iHi: number;
  headingDeg: number;
  headingRad: number;
  /** Seconds after rise at which each AOI point is passed (NaN = not passed). */
  tPass: Float64Array;
  /** Signed cross-track distance of each AOI point from this satellite's ground track. */
  side: Float64Array;
  reachable: Uint8Array;
  aoiAlongMin: number;
  aoiAlongMax: number;
  aoiCrossMin: number;
  aoiCrossMax: number;
};

function preparePass(ctx: PlanContext, cand: RiseCandidate): PassPrep | null {
  const { gate, samples } = ctx;
  const N = samples.length;
  const riseMs = cand.riseMs;
  const setMs = findSet(cand.satrec, ctx.visPts, riseMs, gate);
  if (setMs - riseMs < 5000) return null;
  // Sample past LOS by a full mission length: the sensor keeps capturing until
  // mission end even when LOS comes first (LOS is only an alert).
  const n = Math.floor((setMs + ctx.missionSeconds * 1000 - riseMs) / 1000) + 1;

  // ---- satellite every second over the pass ---------------------------------
  const ecf = new Float64Array(3 * n);
  const subLat = new Float64Array(n);
  const subLon = new Float64Array(n);
  for (let i = 0; i < n; i++) {
    const f = propagateFrame(cand.satrec, new Date(riseMs + i * 1000));
    if (!f) return null;
    ecf[3 * i] = f.ecf[0]; ecf[3 * i + 1] = f.ecf[1]; ecf[3 * i + 2] = f.ecf[2];
    const sp = subpointFromFrame(f);
    subLat[i] = sp.lat; subLon[i] = sp.lon;
  }

  // ---- frame at the AOI centre, along = direction of flight -----------------
  let closest = 0;
  let closestKm = Infinity;
  for (let i = 0; i < n; i++) {
    const dKm = haversineDistanceKm(subLat[i], subLon[i], ctx.centerLat, ctx.centerLon);
    if (dKm < closestKm) { closestKm = dKm; closest = i; }
  }
  const i0 = Math.min(closest, n - 2);
  const headingDeg = initialBearingDeg(subLat[i0], subLon[i0], subLat[i0 + 1], subLon[i0 + 1]);
  const headingRad = toRad(headingDeg);
  const proj = (lat: number, lon: number) => projectToFrame(lat, lon, ctx.centerLat, ctx.centerLon, headingRad);

  const sAlong = new Float64Array(n);
  const sCross = new Float64Array(n);
  for (let i = 0; i < n; i++) {
    const p = proj(subLat[i], subLon[i]);
    sAlong[i] = p.along; sCross[i] = p.cross;
  }
  // Use the stretch of the pass around the rectangle where the track moves
  // forward in this local frame (far away, e.g. over the pole, it can bend back).
  let iLo = closest;
  while (iLo > 0 && sAlong[iLo - 1] < sAlong[iLo]) iLo--;
  let iHi = closest;
  while (iHi < n - 1 && sAlong[iHi + 1] > sAlong[iHi]) iHi++;
  if (iHi - iLo < 4) return null;

  const satAt = (t: number) => {
    const i = clamp(Math.floor(t), iLo, iHi - 1);
    const f = clamp(t - i, 0, 1);
    return {
      along: sAlong[i] + (sAlong[i + 1] - sAlong[i]) * f,
      cross: sCross[i] + (sCross[i + 1] - sCross[i]) * f,
      ecf: [
        ecf[3 * i] + (ecf[3 * i + 3] - ecf[3 * i]) * f,
        ecf[3 * i + 1] + (ecf[3 * i + 4] - ecf[3 * i + 1]) * f,
        ecf[3 * i + 2] + (ecf[3 * i + 5] - ecf[3 * i + 2]) * f,
      ] as Vec3,
    };
  };

  // ---- each rectangle point: when is it passed, how far to the side ---------
  const tPass = new Float64Array(N).fill(NaN); // seconds after rise
  const side = new Float64Array(N);             // signed cross-track distance from the ground track
  const reachable = new Uint8Array(N);
  let aoiAlongMin = Infinity, aoiAlongMax = -Infinity, aoiCrossMin = Infinity, aoiCrossMax = -Infinity;

  for (let k = 0; k < N; k++) {
    const p = proj(samples[k].lat, samples[k].lon);
    aoiAlongMin = Math.min(aoiAlongMin, p.along); aoiAlongMax = Math.max(aoiAlongMax, p.along);
    aoiCrossMin = Math.min(aoiCrossMin, p.cross); aoiCrossMax = Math.max(aoiCrossMax, p.cross);
    if (p.along < sAlong[iLo] || p.along > sAlong[iHi]) continue;
    let lo = iLo, hi = iHi;
    while (hi - lo > 1) { const mid = (lo + hi) >> 1; if (sAlong[mid] <= p.along) lo = mid; else hi = mid; }
    const t = lo + (p.along - sAlong[lo]) / (sAlong[hi] - sAlong[lo]);
    const s = satAt(t);
    tPass[k] = t;
    side[k] = p.cross - s.cross;
    if (meetsGate(lookMetrics(s.ecf, samples[k], gate.orbitHeightKm), gate)) reachable[k] = 1;
  }

  return {
    cand, riseMs, setMs, ecf, sAlong, sCross, iLo, iHi, headingDeg, headingRad,
    tPass, side, reachable, aoiAlongMin, aoiAlongMax, aoiCrossMin, aoiCrossMax,
  };
}

/** Swath-centre offset limits (km from the ground track) allowed by the range / elevation gate. */
function lookOffsetLimits(gate: Gate): { gMin: number; gMax: number } {
  const gMin = groundDistanceForRangeKm(gate.minRangeKm, gate.orbitHeightKm);
  const gMax = groundDistanceForRangeKm(
    Math.min(gate.maxRangeKm, maxRangeForElevationKm(gate.minElevationDeg, gate.orbitHeightKm)),
    gate.orbitHeightKm,
  );
  return { gMin, gMax };
}

/**
 * Where each satellite's ground track lies relative to the leader's (km, + = right
 * of the leader's direction of flight). Measured on AOI points both satellites pass.
 */
function trackOffsetFromLeader(leader: PassPrep, member: PassPrep): number {
  if (leader === member) return 0;
  let sum = 0;
  let count = 0;
  const step = Math.max(1, Math.floor(leader.side.length / 2000));
  for (let k = 0; k < leader.side.length; k += step) {
    if (Number.isNaN(leader.tPass[k]) || Number.isNaN(member.tPass[k])) continue;
    sum += leader.side[k] - member.side[k];
    count++;
  }
  return count > 0 ? sum / count : 0;
}

/**
 * FORMATION AIM (same idea as the original planner): the satellites of one orbit
 * fly as a rigid formation and point their sensors the SAME way (same tilt, same
 * side). Each swath therefore sits at that satellite's own track + the common
 * look offset d, so swaths of satellites 40-60 km apart overlap side by side.
 * d is chosen so the UNION of the formation's swaths covers the most uncovered,
 * reachable AOI points.
 */
function chooseFormationOffset(ctx: PlanContext, preps: PassPrep[], trackOffsets: number[]): number | null {
  const { gate, segments } = ctx;
  const { gMin, gMax } = lookOffsetLimits(gate);
  if (!(gMax > gMin)) return null;
  const half = Math.max(...segments.map((s) => FREQUENCY_PRESETS[s.presetId].swathKm / 2));
  const leader = preps[0];

  // Uncovered points reachable by at least one satellite, positioned in the leader's frame.
  const xs: number[] = [];
  for (let k = 0; k < leader.side.length; k++) {
    if (ctx.covered[k] || Number.isNaN(leader.tPass[k])) continue;
    if (preps.some((p) => p.reachable[k])) xs.push(leader.side[k]);
  }
  if (xs.length === 0) return null;
  xs.sort((a, b) => a - b);
  const lowerBound = (x: number) => {
    let lo = 0, hi = xs.length;
    while (lo < hi) { const mid = (lo + hi) >> 1; if (xs[mid] < x) lo = mid + 1; else hi = mid; }
    return lo;
  };
  const upperBound = (x: number) => {
    let lo = 0, hi = xs.length;
    while (lo < hi) { const mid = (lo + hi) >> 1; if (xs[mid] <= x) lo = mid + 1; else hi = mid; }
    return lo;
  };

  // Swath intervals of the formation for d = 0, merged (they overlap when satellites are close).
  const base = trackOffsets
    .map((c) => [c - half, c + half] as [number, number])
    .sort((a, b) => a[0] - b[0]);
  const merged: [number, number][] = [];
  for (const iv of base) {
    const last = merged[merged.length - 1];
    if (last && iv[0] <= last[1]) last[1] = Math.max(last[1], iv[1]);
    else merged.push([iv[0], iv[1]]);
  }
  const score = (d: number) =>
    merged.reduce((s, [a, b]) => s + upperBound(b + d) - lowerBound(a + d), 0);
  const allowed = (d: number) => (d < 0 ? -1 : 1) * clamp(Math.abs(d), gMin, gMax);

  let best: number | null = null;
  let bestCount = 0;
  const step = Math.max(1, Math.floor(xs.length / 3000));
  for (let i = 0; i < xs.length; i += step) {
    for (const [a, b] of merged) {
      // Candidate offsets that put an edge of the formation band on this point.
      for (const raw of [xs[i] - a, xs[i] - b]) {
        const d = allowed(raw);
        const count = score(d);
        if (count > bestCount || (count === bestCount && best !== null && Math.abs(d) < Math.abs(best))) {
          best = d;
          bestCount = count;
        }
      }
    }
  }
  return bestCount > 0 ? best : null;
}

/** Captures one satellite's pass with the formation's common look offset d. */
function capturePass(ctx: PlanContext, prep: PassPrep, d: number): EvaluatedPass | null {
  const { gate, samples, segments } = ctx;
  const N = samples.length;
  const { cand, riseMs, setMs, ecf, sAlong, sCross, iLo, iHi, headingDeg, headingRad, tPass, side, reachable } = prep;
  const { aoiAlongMin, aoiAlongMax, aoiCrossMin, aoiCrossMax } = prep;
  const toLL = (along: number, cross: number) => frameToLatLon(ctx.centerLat, ctx.centerLon, headingRad, along, cross);
  const satAt = (t: number) => {
    const i = clamp(Math.floor(t), iLo, iHi - 1);
    const f = clamp(t - i, 0, 1);
    return {
      along: sAlong[i] + (sAlong[i + 1] - sAlong[i]) * f,
      cross: sCross[i] + (sCross[i + 1] - sCross[i]) * f,
      ecf: [
        ecf[3 * i] + (ecf[3 * i + 3] - ecf[3 * i]) * f,
        ecf[3 * i + 1] + (ecf[3 * i + 4] - ecf[3 * i + 1]) * f,
        ecf[3 * i + 2] + (ecf[3 * i + 5] - ecf[3 * i + 2]) * f,
      ] as Vec3,
    };
  };

  // ---- mission start: swath first overlaps the rectangle where limits are met ---
  const firstSeg = [...segments].sort((a, b) => a.startSeconds - b.startSeconds)[0];
  const halfStart = FREQUENCY_PRESETS[firstSeg.presetId].swathKm / 2;
  let tStart = Infinity;
  let startCell = -1;
  for (let k = 0; k < N; k++) {
    if (!reachable[k] || Math.abs(side[k] - d) > halfStart) continue;
    if (tPass[k] < tStart) { tStart = tPass[k]; startCell = k; }
  }
  if (startCell < 0) return null;

  const missionSeconds = ctx.missionSeconds;
  const missionStartMs = riseMs + tStart * 1000;
  const losFromStart = (setMs - missionStartMs) / 1000;
  // The sensor captures for the whole frequency plan; LOS before mission end is only an alert.
  const captureSeconds = Math.max(0, Math.min(missionSeconds, iHi - tStart));
  const truncatedByLos = losFromStart < missionSeconds;

  // ---- capture: every point the swath sweeps until capture ends --------------
  const curveLen = Math.ceil(missionSeconds) + 1;
  const passBins = new Array<number>(curveLen).fill(0);
  const newBins = new Array<number>(curveLen).fill(0);
  const segCount = new Array<number>(segments.length).fill(0);
  const segNew = new Array<number>(segments.length).fill(0);
  const changed: number[] = [];
  let coveredCount = 0;
  let lastCell = startCell;
  let lastTau = -Infinity;

  for (let k = 0; k < N; k++) {
    if (Number.isNaN(tPass[k])) continue;
    const tau = tPass[k] - tStart;
    if (tau < -1e-6 || tau > captureSeconds) continue;
    const si = segmentAt(segments, Math.max(0, tau));
    if (si < 0) continue;
    if (Math.abs(side[k] - d) > FREQUENCY_PRESETS[segments[si].presetId].swathKm / 2) continue;

    const bin = clamp(Math.ceil(tau), 0, curveLen - 1);
    coveredCount++;
    passBins[bin]++;
    segCount[si]++;
    if (tau > lastTau) { lastTau = tau; lastCell = k; }
    if (!ctx.covered[k]) {
      ctx.covered[k] = 1;
      changed.push(k);
      newBins[bin]++;
      segNew[si]++;
    }
  }
  ctx.coveredCount += changed.length;
  const newCount = changed.length;

  // ---- footprints: ONE swept rectangle per frequency segment ------------------
  // Like the original planner: the segment's swath, clipped to the AOI's
  // bounding box in the along/cross frame. tStartSec / tEndSec = when the
  // sensor reaches its two along-track ends (seconds after mission start).
  const timeAtAlong = (a: number) => {
    let lo = iLo, hi = iHi;
    while (hi - lo > 1) { const mid = (lo + hi) >> 1; if (sAlong[mid] <= a) lo = mid; else hi = mid; }
    return lo + clamp((a - sAlong[lo]) / (sAlong[hi] - sAlong[lo]), 0, 1);
  };
  const segmentBreakdown: SegmentCoverage[] = segments.map((seg, si) => {
    const half = FREQUENCY_PRESETS[seg.presetId].swathKm / 2;
    const footprints: StripFootprint[] = [];
    const tA = clamp(tStart + Math.max(0, seg.startSeconds), iLo, iHi);
    const tB = clamp(tStart + Math.min(seg.startSeconds + seg.durationSeconds, captureSeconds), iLo, iHi);
    const a0 = Math.max(satAt(tA).along, aoiAlongMin);
    const a1 = Math.min(satAt(tB).along, aoiAlongMax);
    if (tB > tA && a1 > a0) {
      const ta0 = timeAtAlong(a0);
      const ta1 = timeAtAlong(a1);
      const centre = (satAt(ta0).cross + satAt(ta1).cross) / 2 + d;
      const c0 = Math.max(centre - half, aoiCrossMin);
      const c1 = Math.min(centre + half, aoiCrossMax);
      if (c1 > c0) {
        footprints.push({
          satelliteName: cand.tle.name,
          corners: [toLL(a0, c0), toLL(a0, c1), toLL(a1, c1), toLL(a1, c0)],
          tStartSec: ta0 - tStart,
          tEndSec: ta1 - tStart,
        });
      }
    }
    return {
      segmentId: seg.id,
      presetId: seg.presetId,
      startSeconds: seg.startSeconds,
      durationSeconds: seg.durationSeconds,
      swathKm: half * 2,
      footprints,
      coveredAreaKm2: segCount[si] * ctx.cellAreaKm2,
      coveredFraction: segCount[si] / N,
      newlyCoveredFraction: segNew[si] / N,
    };
  });

  const cumulate = (bins: number[]) => {
    let acc = 0;
    return bins.map((c) => { acc += c; return acc / N; });
  };

  // ---- start point, look, satellite state -----------------------------------
  const s0 = satAt(tStart);
  const startMetrics = lookMetrics(s0.ecf, samples[startCell], gate.orbitHeightKm);
  const lookRange = rangeForGroundDistanceKm(Math.abs(d), gate.orbitHeightKm);
  const f0 = propagateFrame(cand.satrec, new Date(missionStartMs));
  const sp0 = f0 ? subpointFromFrame(f0) : null;
  const v0 = f0?.velocity;

  const rectEdgeBearing = initialBearingDeg(ctx.bounds.south, ctx.bounds.west, ctx.bounds.north, ctx.bounds.west);
  let angle = Math.abs(rectEdgeBearing - headingDeg) % 180;
  if (angle > 90) angle = 180 - angle;

  const cumulativeCoveredFraction = ctx.coveredCount / N;
  const pass: StripPass = {
    satelliteName: cand.tle.name,
    orbitIndex: -1,
    isLeader: false,
    leaderName: cand.tle.name,
    offsetFromLeaderMs: 0,
    aos: new Date(missionStartMs - ctx.aosLeadSeconds * 1000),
    missionStart: new Date(missionStartMs),
    missionEnd: new Date(missionStartMs + missionSeconds * 1000),
    los: new Date(setMs),
    missionSeconds,
    captureSeconds,
    truncatedByLos,
    aoiCaptureSeconds: Math.max(0, lastTau),
    aoiCaptureEnd: new Date(missionStartMs + Math.max(0, lastTau) * 1000),
    satelliteState: sp0
      ? {
          lat: sp0.lat,
          lon: sp0.lon,
          altitudeKm: sp0.heightKm,
          velocityKmPerSec: v0 ? Math.hypot(v0.x, v0.y, v0.z) : 0,
        }
      : null,
    look: {
      side: d >= 0 ? "right" : "left",
      crossTrackOffsetKm: Math.abs(d),
      tiltDeg: tiltFromRangeKm(lookRange, gate.orbitHeightKm),
      slantRangeKm: lookRange,
    },
    capturePoint: {
      lat: samples[startCell].lat,
      lon: samples[startCell].lon,
      label: rectangleRegionLabel(samples[startCell], ctx.bounds),
      elevationDeg: startMetrics.elevationDeg,
      slantRangeKm: startMetrics.rangeKm,
      tiltDeg: startMetrics.tiltDeg,
    },
    entrySideLabel: rectangleRegionLabel(samples[startCell], ctx.bounds),
    exitSideLabel: rectangleRegionLabel(samples[lastCell], ctx.bounds),
    orientation: {
      headingDeg,
      rectangleTrackAngleDeg: angle,
      crossTrackWidthKm: aoiCrossMax - aoiCrossMin,
      alongTrackLengthKm: aoiAlongMax - aoiAlongMin,
    },
    segmentBreakdown,
    passCoveredFraction: coveredCount / N,
    passCoveredAreaKm2: coveredCount * ctx.cellAreaKm2,
    newlyCoveredFraction: newCount / N,
    newlyCoveredAreaKm2: newCount * ctx.cellAreaKm2,
    cumulativeCoveredFraction,
    remainingFraction: Math.max(0, 1 - cumulativeCoveredFraction),
    remainingAreaKm2: Math.max(0, ctx.totalAreaKm2 - ctx.coveredCount * ctx.cellAreaKm2),
    coverageCurve: cumulate(passBins),
    newCoverageCurve: cumulate(newBins),
  };
  return { pass, changed };
}

/* ------------------------------------------------------------------ */
/* Orbit grouping (leader + other satellites)                         */
/* ------------------------------------------------------------------ */

function buildOrbit(index: number, passes: StripPass[]): StripOrbit {
  passes.sort((a, b) => a.missionStart.getTime() - b.missionStart.getTime());
  const leader = passes[0];
  for (const p of passes) {
    p.orbitIndex = index;
    p.isLeader = p === leader;
    p.leaderName = leader.satelliteName;
    p.offsetFromLeaderMs = p.missionStart.getTime() - leader.missionStart.getTime();
  }
  const last = passes.reduce((a, b) => (b.cumulativeCoveredFraction > a.cumulativeCoveredFraction ? b : a));
  const maxDate = (f: (p: StripPass) => number) => new Date(Math.max(...passes.map(f)));
  return {
    index,
    leaderName: leader.satelliteName,
    passes,
    aos: leader.aos,
    missionStart: leader.missionStart,
    missionEnd: maxDate((p) => p.missionEnd.getTime()),
    los: maxDate((p) => p.los.getTime()),
    captureEnd: maxDate((p) => p.missionStart.getTime() + p.captureSeconds * 1000),
    truncatedByLos: passes.some((p) => p.truncatedByLos),
    aoiCaptureEnd: maxDate((p) => p.aoiCaptureEnd.getTime()),
    aoiCaptureSeconds:
      (Math.max(...passes.map((p) => p.aoiCaptureEnd.getTime())) - leader.missionStart.getTime()) / 1000,
    newlyCoveredFraction: passes.reduce((s, p) => s + p.newlyCoveredFraction, 0),
    newlyCoveredAreaKm2: passes.reduce((s, p) => s + p.newlyCoveredAreaKm2, 0),
    cumulativeCoveredFraction: last.cumulativeCoveredFraction,
    remainingFraction: last.remainingFraction,
    remainingAreaKm2: last.remainingAreaKm2,
  };
}

/* ------------------------------------------------------------------ */
/* PUBLIC ENTRY POINT                                                 */
/* ------------------------------------------------------------------ */

export function planStripCapture(
  tles: TleEntry[],
  bounds: RectangleBounds,
  start: Date,
  end: Date,
  minRangeKm: number,
  maxRangeKm: number,
  segments: FrequencySegment[],
  options: StripPlannerOptions = {},
): StripCapturePlanResult {
  const minElevationDeg = options.minElevationDeg ?? DEFAULT_MIN_ELEVATION_DEG;
  const orbitHeightKm = options.orbitHeightKm ?? ORBIT_HEIGHT_KM;
  const gate: Gate = { minRangeKm, maxRangeKm, minElevationDeg, orbitHeightKm };
  const { samples, cellAreaKm2, totalAreaKm2 } = buildAoiSamples(bounds);

  const usable = segments.filter((s) => s.durationSeconds > 0 && FREQUENCY_PRESETS[s.presetId]);
  // Mission length = cumulative sum of the frequency segment durations.
  const missionSeconds = usable.reduce((sum, s) => sum + s.durationSeconds, 0);

  const empty: StripCapturePlanResult = {
    bounds,
    aoiAreaKm2: totalAreaKm2,
    sampleCount: samples.length,
    orbits: [],
    passes: [],
    totalCoveredFraction: 0,
    totalCoveredAreaKm2: 0,
    remainingAreaKm2: totalAreaKm2,
    fullyCovered: false,
    gate: stripGateSummary(minRangeKm, maxRangeKm, minElevationDeg, orbitHeightKm),
    missionSeconds,
  };
  if (tles.length === 0 || usable.length === 0 || missionSeconds <= 0) return empty;

  const satRecs: SatRecEntry[] = tles.map((tle) => ({ tle, satrec: getSatrec(tle) }));
  const visPts = visibilityGrid(bounds);
  const ctx: PlanContext = {
    bounds, segments: usable, missionSeconds,
    aosLeadSeconds: options.aosLeadSeconds ?? AOS_LEAD_SECONDS,
    gate, visPts, samples, cellAreaKm2, totalAreaKm2,
    centerLat: (bounds.north + bounds.south) / 2,
    centerLon: (bounds.east + bounds.west) / 2,
    covered: new Uint8Array(samples.length),
    coveredCount: 0,
  };

  const windowMs = (options.formationWindowSeconds ?? FORMATION_WINDOW_SECONDS) * 1000;
  const minGain = options.minOrbitGainFraction ?? MIN_ORBIT_GAIN_FRACTION;
  const orbits: StripOrbit[] = [];
  let pending: RiseCandidate[] = [];
  const isFull = () => ctx.coveredCount / samples.length >= FULL_COVERAGE_FRACTION;

  /** Aims the whole formation together, captures every satellite, keeps the orbit if it adds enough. */
  const closeGroup = () => {
    const preps = pending.map((c) => preparePass(ctx, c)).filter((p): p is PassPrep => p !== null);
    pending = [];
    if (preps.length === 0) return;
    const trackOffsets = preps.map((p) => trackOffsetFromLeader(preps[0], p));
    const d = chooseFormationOffset(ctx, preps, trackOffsets);
    if (d === null) return;
    const group: EvaluatedPass[] = [];
    for (const prep of preps) {
      const evaluated = capturePass(ctx, prep, d);
      if (evaluated) group.push(evaluated);
    }
    const gain = group.reduce((s, g) => s + g.pass.newlyCoveredFraction, 0);
    if (group.length > 0 && gain >= minGain) {
      orbits.push(buildOrbit(orbits.length, group.map((g) => g.pass)));
    } else {
      // Too small to list: give the points back so later orbits can take them.
      for (const g of group) for (const k of g.changed) ctx.covered[k] = 0;
      ctx.coveredCount -= group.reduce((s, g) => s + g.changed.length, 0);
    }
  };

  // Satellites rising within the formation window over the AOI = one orbit.
  const rises = scanRises(satRecs, visPts, start, end, gate, options.stepSeconds ?? COARSE_STEP_SECONDS);
  for (const cand of rises) {
    const sameOrbit =
      pending.length > 0 &&
      cand.riseMs - pending[0].riseMs <= windowMs &&
      !pending.some((p) => p.tle.name === cand.tle.name);
    if (pending.length > 0 && !sameOrbit) {
      closeGroup();
      if (isFull() || orbits.length >= MAX_ORBITS_SAFETY) break;
    }
    pending.push(cand);
  }
  closeGroup();

  const totalCoveredFraction = ctx.coveredCount / samples.length;
  const totalCoveredAreaKm2 = ctx.coveredCount * cellAreaKm2;
  return {
    ...empty,
    orbits,
    passes: orbits.flatMap((o) => o.passes),
    totalCoveredFraction,
    totalCoveredAreaKm2,
    remainingAreaKm2: Math.max(0, totalAreaKm2 - totalCoveredAreaKm2),
    fullyCovered: totalCoveredFraction >= FULL_COVERAGE_FRACTION,
  };
}
