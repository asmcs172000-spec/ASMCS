import { useEffect, useMemo, useState } from "react";
import { Search, Plus, Pencil, Trash2, X, Check, AlertTriangle } from "lucide-react";
import { cn } from "../../../lib/utils";

const SAT_COLORS = ["#f87171", "#fbbf24", "#38bdf8", "#4ade80", "#c084fc", "#f472b6"];

type SatelliteOption = {
  id: string;
  name: string;
  color: string;
};

export type SavedGroup = {
  id: string;
  name: string;
  satelliteIds: string[];
};

type Props = {
  selectedSatIds: Set<string>;
  onToggleSatellite: (id: string) => void;
  onGroupsChange?: (groups: SavedGroup[]) => void;
  // ── TLE data now comes from the parent (single shared fetch across the page) ──
  tleData: { name: string; tle1: string; tle2: string }[];
  tleLoaded: boolean;
  groupConfigStatus?: Record<string, "in-progress" | "completed">;
  // which group's config panel is currently open in the parent
  openConfigGroupId?: string | null;
};

function makeId() {
  return typeof crypto !== "undefined" && "randomUUID" in crypto
    ? crypto.randomUUID()
    : `grp-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

export default function ConstellationGroup({
  selectedSatIds,
  onToggleSatellite,
  onGroupsChange,
  tleData,
  tleLoaded,
  groupConfigStatus,
  openConfigGroupId,
}: Props) {
  // ── Satellite pool: derived from the shared TLE data passed in as a prop ──
  const loadingSats = !tleLoaded;

  const satelliteOptions: SatelliteOption[] = useMemo(
    () =>
      tleData.map((t, i) => ({
        id: t.name,
        name: t.name,
        color: SAT_COLORS[i % SAT_COLORS.length],
      })),
    [tleData],
  );

  const satelliteById = useMemo(() => {
    const map = new Map<string, SatelliteOption>();
    satelliteOptions.forEach((s) => map.set(s.id, s));
    return map;
  }, [satelliteOptions]);

  // Saved groups can predate the Mission Planning exclusion rule. Treat IDs
  // absent from the current (already filtered) TLE options as unavailable so
  // they cannot be re-applied, edited back in, or displayed as group members.
  const availableIds = useMemo(
    () => new Set(satelliteOptions.map((satellite) => satellite.id)),
    [satelliteOptions],
  );
  const availableGroupIds = (ids: string[]) => ids.filter((id) => availableIds.has(id));

  // ── Saved constellation groups ──
  const [groups, setGroups] = useState<SavedGroup[]>([]);
  const [activeGroupId, setActiveGroupId] = useState<string | null>(null);

  // Report the current group list to the parent whenever it changes,
  // so MissionPlanningMode can keep Mission Config Files in sync.
  useEffect(() => {
    onGroupsChange?.(groups);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [groups]);

  // ── Builder (create / edit) state ──
  const [mode, setMode] = useState<"list" | "builder">("list");
  const [editingGroupId, setEditingGroupId] = useState<string | null>(null);
  const [builderName, setBuilderName] = useState("");
  const [builderSelected, setBuilderSelected] = useState<Set<string>>(new Set());
  const [builderSearch, setBuilderSearch] = useState("");
  const [builderError, setBuilderError] = useState<string | null>(null);

  const filteredBuilderSats = useMemo(
    () =>
      satelliteOptions.filter((s) =>
        s.name.toLowerCase().includes(builderSearch.toLowerCase()),
      ),
    [satelliteOptions, builderSearch],
  );

  const openCreate = () => {
    setEditingGroupId(null);
    setBuilderName("");
    setBuilderSelected(new Set());
    setBuilderSearch("");
    setBuilderError(null);
    setMode("builder");
  };

  const openEdit = (group: SavedGroup) => {
    setEditingGroupId(group.id);
    setBuilderName(group.name);
    setBuilderSelected(new Set(availableGroupIds(group.satelliteIds)));
    setBuilderSearch("");
    setBuilderError(null);
    setMode("builder");
  };

  const cancelBuilder = () => {
    setMode("list");
    setEditingGroupId(null);
    setBuilderName("");
    setBuilderSelected(new Set());
    setBuilderError(null);
  };

  const toggleBuilderSat = (id: string) => {
    setBuilderError(null);
    setBuilderSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  // Sync mission selection (selectedSatIds) to match a given group's satellites,
  // replacing whatever the previously-active group had applied.
  const applySelectionForGroup = (newIds: string[], prevIds: string[]) => {
    const newSet = new Set(availableGroupIds(newIds));
    const prevSet = new Set(prevIds);

    prevSet.forEach((id) => {
      if (!newSet.has(id) && selectedSatIds.has(id)) onToggleSatellite(id);
    });
    newSet.forEach((id) => {
      if (!selectedSatIds.has(id)) onToggleSatellite(id);
    });
  };

  const confirmBuilder = () => {
    const name = builderName.trim() || "Untitled Group";
    const satelliteIds = Array.from(builderSelected);
    if (satelliteIds.length === 0) return;

    // ── Validation: block satellites already claimed by ANOTHER group ──
    const realConflicts = satelliteIds.filter((id) => {
      const ownerGroup = groups.find(
        (g) => g.satelliteIds.includes(id) && g.id !== editingGroupId,
      );
      return !!ownerGroup;
    });

    if (realConflicts.length > 0) {
      const firstConflictId = realConflicts[0];
      const conflictOwner = groups.find(
        (g) => g.satelliteIds.includes(firstConflictId) && g.id !== editingGroupId,
      );
      const satName = satelliteById.get(firstConflictId)?.name ?? firstConflictId;
      setBuilderError(
        `Invalid: "${satName}" already exists in another group ("${conflictOwner?.name ?? "Unknown"}")`,
      );
      return;
    }

    if (editingGroupId) {
      const prevGroup = groups.find((g) => g.id === editingGroupId);
      setGroups((prev) =>
        prev.map((g) =>
          g.id === editingGroupId ? { ...g, name, satelliteIds } : g,
        ),
      );
      if (activeGroupId === editingGroupId) {
        applySelectionForGroup(satelliteIds, prevGroup?.satelliteIds ?? []);
      }
    } else {
      const newGroup: SavedGroup = { id: makeId(), name, satelliteIds };
      setGroups((prev) => [...prev, newGroup]);
      const prevActive = groups.find((g) => g.id === activeGroupId);
      applySelectionForGroup(satelliteIds, prevActive?.satelliteIds ?? []);
      setActiveGroupId(newGroup.id);
    }

    cancelBuilder();
  };

  const deleteGroup = (group: SavedGroup) => {
    if (activeGroupId === group.id) {
      applySelectionForGroup([], group.satelliteIds);
      setActiveGroupId(null);
    }
    setGroups((prev) => prev.filter((g) => g.id !== group.id));
  };

  const applyGroup = (group: SavedGroup) => {
    if (activeGroupId === group.id) {
      applySelectionForGroup([], group.satelliteIds);
      setActiveGroupId(null);
      return;
    }
    const prevActive = groups.find((g) => g.id === activeGroupId);
    applySelectionForGroup(group.satelliteIds, prevActive?.satelliteIds ?? []);
    setActiveGroupId(group.id);
  };

  // ── Builder view ──
  if (mode === "builder") {
    return (
      <div className="flex min-h-0 flex-1 flex-col bg-transparent">
        <div className="flex items-center justify-between border-b border-[var(--gm-border)] p-4">
          <h2 className="globe-section-title">
            {editingGroupId ? "Edit Group" : "New Group"}
          </h2>
          <button
            type="button"
            onClick={cancelBuilder}
            className="text-[oklch(0.5_0.01_260)] hover:text-[oklch(0.85_0_0)]"
            title="Cancel"
          >
            <X className="size-4" />
          </button>
        </div>

        <div className="p-3">
          <input
            value={builderName}
            onChange={(e) => setBuilderName(e.target.value)}
            placeholder="Group name..."
            className="w-full rounded border border-[oklch(0.28_0.03_250)] bg-[oklch(0.14_0.03_250)]/70 px-3 py-1.5 text-sm text-[oklch(0.9_0_0)] placeholder:text-[oklch(0.45_0.02_250)] focus:outline-none focus:ring-1 focus:ring-[oklch(0.75_0.12_220)]/40"
          />
        </div>

        <div className="px-3 pb-2">
          <div className="relative">
            <Search className="absolute left-2.5 top-2 size-4 text-[oklch(0.5_0.02_250)]" />
            <input
              value={builderSearch}
              onChange={(e) => setBuilderSearch(e.target.value)}
              placeholder="Search satellites..."
              className="w-full rounded border border-[oklch(0.28_0.03_250)] bg-[oklch(0.14_0.03_250)]/70 px-8 py-1.5 text-sm text-[oklch(0.9_0_0)] placeholder:text-[oklch(0.45_0.02_250)] focus:outline-none focus:ring-1 focus:ring-[oklch(0.75_0.12_220)]/40"
            />
          </div>
        </div>

        {builderError && (
          <div className="mx-3 mb-2 flex items-start gap-2 rounded-lg border border-red-500/30 bg-red-500/10 px-3 py-2 text-xs text-red-300">
            <AlertTriangle className="mt-0.5 size-3.5 shrink-0" />
            <span>{builderError}</span>
          </div>
        )}

        <div className="min-h-0 flex-1 divide-y divide-[oklch(0.22_0.03_250)] overflow-y-auto">
          {loadingSats && (
            <div className="px-4 py-6 text-center text-xs text-[oklch(0.45_0.02_250)]">
              Loading satellites…
            </div>
          )}

          {!loadingSats &&
            filteredBuilderSats.map((s) => {
              const isChecked = builderSelected.has(s.id);
              const ownerGroup = groups.find(
                (g) => g.satelliteIds.includes(s.id) && g.id !== editingGroupId,
              );
              const isTakenElsewhere = !!ownerGroup;

              return (
                <button
                  key={s.id}
                  type="button"
                  onClick={() => toggleBuilderSat(s.id)}
                  className={cn(
                    "group w-full cursor-pointer px-4 py-3 text-left transition-colors hover:bg-white/5",
                    isChecked && "bg-[oklch(0.75_0.12_220)]/10",
                  )}
                >
                  <div className="flex items-center gap-3">
                    <div
                      className="size-1.5 rounded-full"
                      style={{ background: s.color }}
                    />
                    <span className="flex-1 truncate text-sm font-medium text-[oklch(0.95_0_0)]">
                      {s.name}
                    </span>
                    {isTakenElsewhere && (
                      <span className="rounded bg-amber-500/15 px-1.5 py-0.5 text-[9px] font-semibold text-amber-400">
                        in {ownerGroup!.name}
                      </span>
                    )}
                    <span
                      className={cn(
                        "flex size-4 shrink-0 items-center justify-center rounded border text-[10px]",
                        isChecked
                          ? "border-[oklch(0.85_0.1_220)] bg-[oklch(0.85_0.1_220)] text-[oklch(0.1_0.03_250)]"
                          : "border-white/20",
                      )}
                    >
                      {isChecked ? "✓" : ""}
                    </span>
                  </div>
                </button>
              );
            })}

          {!loadingSats && filteredBuilderSats.length === 0 && (
            <div className="px-4 py-6 text-center text-xs text-[oklch(0.45_0.02_250)]">
              No satellites found
            </div>
          )}
        </div>

        <div className="flex shrink-0 items-center gap-2 border-t border-[var(--gm-border)] p-3">
          <button
            type="button"
            onClick={cancelBuilder}
            className="flex h-9 flex-1 items-center justify-center rounded-lg border border-white/10 bg-white/[0.02] text-xs font-semibold text-[oklch(0.72_0.02_250)] transition-colors hover:border-white/20 hover:bg-white/[0.05]"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={confirmBuilder}
            disabled={builderSelected.size === 0}
            className="flex h-9 flex-1 items-center justify-center gap-1.5 rounded-lg border border-[oklch(0.75_0.12_220)]/45 bg-[oklch(0.75_0.12_220)]/12 text-xs font-bold uppercase tracking-wider text-[oklch(0.86_0.1_220)] transition-colors hover:bg-[oklch(0.75_0.12_220)]/20 disabled:cursor-not-allowed disabled:opacity-40"
          >
            <Check className="size-3.5" />
            Confirm
          </button>
        </div>
      </div>
    );
  }

  // ── List view (empty state + saved groups + create button) ──
  return (
    <div className="flex min-h-0 flex-1 flex-col bg-transparent">
      <div className="flex items-center justify-between border-b border-[var(--gm-border)] p-4">
        <h2 className="globe-section-title">Constellation Group</h2>
        <span className="rounded-full border border-emerald-400/20 bg-emerald-400/10 px-2.5 py-1 text-xs font-bold text-emerald-300">
          {groups.length} GROUP{groups.length === 1 ? "" : "S"}
        </span>
      </div>

      <div className="min-h-0 flex-1 overflow-y-auto p-3">
        {groups.length === 0 ? (
          <div className="flex h-full flex-col items-center justify-center gap-1 px-4 text-center">
            <span className="text-sm font-medium text-[oklch(0.6_0.01_260)]">
              No constellation groups yet
            </span>
            <span className="text-xs text-[oklch(0.45_0.02_250)]">
              Create one to select satellites for this mission.
            </span>
          </div>
        ) : (
          <div className="space-y-2">
            {groups.map((group) => {
              const isOpenConfig = openConfigGroupId === group.id;
              const status = groupConfigStatus?.[group.id];
              const visibleSatelliteIds = availableGroupIds(group.satelliteIds);
              return (
               <div
  key={group.id}
  className={cn(
    "rounded-lg border p-2.5 transition-colors",
    isOpenConfig
      ? "border-[oklch(0.75_0.12_220)]/45 bg-[oklch(0.75_0.12_220)]/10"
      : "border-white/5 bg-white/[0.02] hover:border-[oklch(0.75_0.12_220)]/30 hover:bg-[oklch(0.75_0.12_220)]/5",
  )}
>
                  <button
  type="button"
  onClick={() => applyGroup(group)}
  className="flex w-full items-center gap-2 text-left outline-none focus:outline-none focus-visible:ring-1 focus-visible:ring-[oklch(0.75_0.12_220)]/50"
>
                    <span className="flex-1 truncate text-sm font-semibold text-[oklch(0.95_0_0)]">
                      {group.name}
                    </span>

                    <span className="flex items-center gap-1">
                      {isOpenConfig && (
                        <span className="rounded-full bg-[oklch(0.75_0.12_220)]/20 px-1.5 py-0.5 text-[9px] font-bold text-[oklch(0.85_0.1_220)]">
                          ACTIVE
                        </span>
                      )}
                      {status === "completed" ? (
                        <span className="rounded-full bg-emerald-400/20 px-1.5 py-0.5 text-[9px] font-bold text-emerald-300">
                          COMPLETED
                        </span>
                      ) : status === "in-progress" ? (
                        <span className="rounded-full bg-amber-400/20 px-1.5 py-0.5 text-[9px] font-bold text-amber-300">
                          IN PROGRESS
                        </span>
                      ) : null}
                    </span>

                    <span className="text-[10px] text-[oklch(0.5_0.02_250)]">
                      {visibleSatelliteIds.length} sat
                      {visibleSatelliteIds.length === 1 ? "" : "s"}
                    </span>
                  </button>

                  <div className="mt-2 flex flex-wrap gap-1.5">
                    {visibleSatelliteIds.map((id) => {
                      const sat = satelliteById.get(id);
                      return (
                        <span
                          key={id}
                          className="flex items-center gap-1 rounded bg-white/[0.03] px-1.5 py-0.5 text-[10px] text-[oklch(0.8_0_0)]"
                        >
                          <span
                            className="size-1.5 rounded-full"
                            style={{ background: sat?.color ?? "#7dd3fc" }}
                          />
                          {sat?.name ?? id}
                        </span>
                      );
                    })}
                  </div>

                  <div className="mt-2 flex items-center justify-end gap-1 border-t border-white/5 pt-2">
                    <button
                      type="button"
                      onClick={() => openEdit(group)}
                      title="Edit group"
                      className="flex items-center gap-1 rounded px-2 py-1 text-[10px] font-semibold text-[oklch(0.65_0.02_250)] hover:bg-white/5 hover:text-[oklch(0.9_0_0)] focus:outline-none focus-visible:ring-1 focus-visible:ring-[oklch(0.75_0.12_220)]/50"
                    >
                      <Pencil className="size-3" />
                      Edit
                    </button>
                    <button
                      type="button"
                      onClick={() => deleteGroup(group)}
                      title="Delete group"
                      className="flex items-center gap-1 rounded px-2 py-1 text-[10px] font-semibold text-[oklch(0.65_0.02_250)] hover:bg-red-500/10 hover:text-red-400"
                    >
                      <Trash2 className="size-3" />
                      Delete
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      <div className="shrink-0 border-t border-[var(--gm-border)] p-3">
        <button
          type="button"
          onClick={openCreate}
          className="flex h-10 w-full items-center justify-center gap-2 rounded-lg border border-dashed border-white/15 bg-white/[0.02] text-xs font-semibold text-[oklch(0.72_0.02_250)] transition-colors hover:border-[oklch(0.75_0.12_220)]/40 hover:bg-[oklch(0.75_0.12_220)]/5 hover:text-[oklch(0.92_0_0)]"
        >
          <Plus className="size-4" />
          Create Constellation Group
        </button>
      </div>
    </div>
  );
}