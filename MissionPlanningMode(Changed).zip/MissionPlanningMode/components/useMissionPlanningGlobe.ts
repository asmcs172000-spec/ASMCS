import { useCallback, useEffect, useRef, useState } from "react";
import * as Cesium from "cesium";
import "cesium/Build/Cesium/Widgets/widgets.css";

// ─── Constants ──────────────────────────────────────────────────────────

const OFFLINE_MIN_ZOOM_METERS = 100;
const ONLINE_MIN_ZOOM_METERS = 100;
const ZOOM_STEP_FACTOR = 0.6;
const COUNTRY_BORDER_COLOR = "#5fd4ff";
const COUNTRY_BORDER_WIDTH = 1.3;

// ─── Helpers ────────────────────────────────────────────────────────────

async function checkOnline(): Promise<boolean> {
  return navigator.onLine;
}

async function loadCountryBorders(viewer: Cesium.Viewer) {
  try {
    const dataSource = await Cesium.GeoJsonDataSource.load("/countries.geojson", {
      stroke: Cesium.Color.fromCssColorString(COUNTRY_BORDER_COLOR).withAlpha(0.85),
      strokeWidth: COUNTRY_BORDER_WIDTH,
      fill: Cesium.Color.TRANSPARENT,
      clampToGround: false,
    });
    viewer.dataSources.add(dataSource);

    for (const entity of dataSource.entities.values) {
      if (!entity.polygon) continue;
      entity.polygon.fill = new Cesium.ConstantProperty(false);
      entity.polygon.outline = new Cesium.ConstantProperty(true);
      entity.polygon.outlineColor = new Cesium.ConstantProperty(
        Cesium.Color.fromCssColorString(COUNTRY_BORDER_COLOR).withAlpha(0.85)
      );
      entity.polygon.outlineWidth = new Cesium.ConstantProperty(COUNTRY_BORDER_WIDTH);
      entity.polygon.height = new Cesium.ConstantProperty(0);
      entity.polygon.classificationType = new Cesium.ConstantProperty(
        Cesium.ClassificationType.TERRAIN
      );
    }

    viewer.scene.requestRender();
    console.log("Country borders loaded (mission planning globe)");
  } catch (err) {
    console.error("Failed to load country borders", err);
  }
}

const CESIUM_OVERRIDES = `
  .cesium-viewer-bottom,
  .cesium-viewer-animationContainer,
  .cesium-viewer-timelineContainer,
  .cesium-viewer-toolbar {
    display: none !important;
  }
  .cesium-widget,
  .cesium-widget canvas {
    width: 100% !important;
    height: 100% !important;
  }
`;

function injectStyles() {
  if (document.getElementById("cesium-overrides")) return;
  const el = document.createElement("style");
  el.id = "cesium-overrides";
  el.textContent = CESIUM_OVERRIDES;
  document.head.appendChild(el);
}

// ─── Hook ───────────────────────────────────────────────────────────────

/**
 * Standalone globe logic for Mission Planning Mode.
 * Extracted from GlobeView.tsx but stripped of satellites, ground stations,
 * ground tracks, and pass prediction — just the base Cesium globe:
 * skybox, imagery layers, country borders, camera setup, and zoom controls.
 *
 * This is intentionally NOT shared with GlobeMode — it's a separate copy
 * scoped to this mode only, so changes here never affect Globe Mode.
 */
export function useMissionPlanningGlobe() {
  const ref = useRef<HTMLDivElement>(null);
  const viewerRef = useRef<Cesium.Viewer | null>(null);
  const [viewerReady, setViewerReady] = useState(false);
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [statusMsg, setStatusMsg] = useState("");

  useEffect(() => {
    injectStyles();
  }, []);

  // ── Online/offline polling ──────────────────────────────────────────
  useEffect(() => {
    let cancelled = false;
    const poll = async () => {
      const online = await checkOnline();
      if (!cancelled) setIsOnline(online);
    };
    poll();
    const id = setInterval(poll, 10_000);
    const goOnline = () => poll();
    const goOffline = () => {
      if (!cancelled) setIsOnline(false);
    };
    window.addEventListener("online", goOnline);
    window.addEventListener("offline", goOffline);
    return () => {
      cancelled = true;
      clearInterval(id);
      window.removeEventListener("online", goOnline);
      window.removeEventListener("offline", goOffline);
    };
  }, []);

  useEffect(() => {
    if (!viewerRef.current || viewerRef.current.isDestroyed()) return;
    const cam = viewerRef.current.scene.screenSpaceCameraController;
    cam.minimumZoomDistance = !isOnline ? 500_000 : 100;
    setStatusMsg(isOnline ? "🟢 Online — Enhanced View Available" : "🔴 Offline — Limited Detail Mode");
    const t = setTimeout(() => setStatusMsg(""), 3000);
    return () => clearTimeout(t);
  }, [isOnline]);

  // ── Cesium init (mount-once) ────────────────────────────────────────
  useEffect(() => {
    if (!ref.current) return;
    if (viewerRef.current && !viewerRef.current.isDestroyed()) return;
    let isMounted = true;

    (async () => {
      if (!ref.current || !isMounted) return;
      const online = await checkOnline();
      if (!isMounted || !ref.current) return;

      viewerRef.current = new Cesium.Viewer(ref.current, {
        terrainProvider: new Cesium.EllipsoidTerrainProvider(),
        animation: false,
        timeline: false,
        baseLayerPicker: false,
        navigationHelpButton: false,
        sceneModePicker: false,
        fullscreenButton: false,
        geocoder: false,
        homeButton: false,
        infoBox: false,
        selectionIndicator: false,
        requestRenderMode: true,
        maximumRenderTimeChange: Infinity,
        shadows: false,
        skyAtmosphere: new Cesium.SkyAtmosphere(),
        skyBox: new Cesium.SkyBox({
          sources: {
            positiveX: "/skybox/skybox_px.png",
            negativeX: "/skybox/skybox_nx.png",
            positiveY: "/skybox/skybox_py.png",
            negativeY: "/skybox/skybox_ny.png",
            positiveZ: "/skybox/skybox_pz.png",
            negativeZ: "/skybox/skybox_nz.png",
          },
        }),
      });

      const scene = viewerRef.current.scene;
      scene.fog.enabled = false;
      scene.globe.showGroundAtmosphere = false;
      scene.globe.maximumScreenSpaceError = 6;
      scene.globe.tileCacheSize = 1000;
      scene.globe.preloadAncestors = true;
      scene.globe.depthTestAgainstTerrain = false;
      scene.globe.preloadSiblings = true;
      scene.globe.depthTestAgainstTerrain = false;
      scene.postProcessStages.fxaa.enabled = false;
      scene.globe.enableLighting = false;
      if (scene.skyAtmosphere) scene.skyAtmosphere.show = false;
      scene.globe.baseColor = Cesium.Color.fromCssColorString("#1a3a5c");
      scene.backgroundColor = Cesium.Color.fromCssColorString("#06111f");

      viewerRef.current.useBrowserRecommendedResolution = true;

      let resolutionTimer: ReturnType<typeof setTimeout> | null = null;
      const dynamicResolution = () => {
        if (!viewerRef.current || viewerRef.current.isDestroyed()) return;
        viewerRef.current.resolutionScale = 0.6;
        scene.requestRender();
        if (resolutionTimer) clearTimeout(resolutionTimer);
        resolutionTimer = setTimeout(() => {
          if (!viewerRef.current || viewerRef.current.isDestroyed()) return;
          viewerRef.current.resolutionScale = 1.0;
          scene.requestRender();
        }, 300);
      };
      scene.globe.tileLoadProgressEvent.addEventListener(() => scene.requestRender());
      viewerRef.current.camera.changed.addEventListener(() => {
        scene.requestRender();
        dynamicResolution();
      });
      viewerRef.current.camera.percentageChanged = 0.05;

      if (!isMounted || !viewerRef.current) return;

      const cam = viewerRef.current.scene.screenSpaceCameraController;
      cam.enableInputs = true;
      cam.enableZoom = true;
      cam.minimumZoomDistance = !online ? 500_000 : 100;
      cam.maximumZoomDistance = 3e7;
      cam.zoomEventTypes = [Cesium.CameraEventType.PINCH, Cesium.CameraEventType.RIGHT_DRAG];
      cam.inertiaSpin = 0.5;
      cam.inertiaTranslate = 0.5;
      cam.inertiaZoom = 0.35;

      // ── Imagery layers (same stack as Globe Mode) ─────────────────
      viewerRef.current.imageryLayers.removeAll();

      try {
        const naturalEarth = await Cesium.TileMapServiceImageryProvider.fromUrl(
          Cesium.buildModuleUrl("Assets/Textures/NaturalEarthII"),
          { fileExtension: "jpg", maximumLevel: 5 }
        );
        if (isMounted && viewerRef.current && !viewerRef.current.isDestroyed()) {
          const neLayer = viewerRef.current.imageryLayers.addImageryProvider(naturalEarth);
          neLayer.brightness = 1.0;
          neLayer.contrast = 1.05;
          neLayer.saturation = 1.1;
          neLayer.gamma = 1.0;
        }
      } catch (e) {
        console.warn("NaturalEarthII failed:", e);
      }

      try {
        const blueMarble = new Cesium.SingleTileImageryProvider({
          url: "/earth/earth_blue_marble.jpg",
        });
        if (isMounted && viewerRef.current && !viewerRef.current.isDestroyed()) {
          const bmLayer = viewerRef.current.imageryLayers.addImageryProvider(blueMarble);
          bmLayer.brightness = 1.05;
          bmLayer.contrast = 1.0;
          bmLayer.saturation = 1.0;
          bmLayer.gamma = 1.0;
        }
      } catch (e) {
        console.warn("Blue Marble not found — using NaturalEarthII:", e);
      }

      if (online && isMounted && viewerRef.current && !viewerRef.current.isDestroyed()) {
        try {
          const googleSat = new Cesium.UrlTemplateImageryProvider({
            url: "https://mt1.google.com/vt/lyrs=s&x={x}&y={y}&z={z}",
            credit: "Google Maps",
          });
          const satLayer = viewerRef.current.imageryLayers.addImageryProvider(googleSat);
          satLayer.alpha = 1.0;
          satLayer.brightness = 1.05;
          satLayer.contrast = 1.05;
          satLayer.saturation = 0.9;
          satLayer.gamma = 1.1;
        } catch (e) {
          console.warn("Google satellite layer failed:", e);
        }

        try {
          const labels = new Cesium.UrlTemplateImageryProvider({
            url: "https://{s}.basemaps.cartocdn.com/light_only_labels/{z}/{x}/{y}.png",
            subdomains: ["a", "b", "c", "d"],
            credit: "© CartoDB",
            minimumLevel: 1,
            maximumLevel: 16,
          });
          viewerRef.current.imageryLayers.addImageryProvider(labels);
        } catch (e) {
          console.warn("Label layer failed:", e);
        }
      }

      if (!ref.current || !isMounted || !viewerRef.current) return;

      await loadCountryBorders(viewerRef.current);

      viewerRef.current.camera.setView({
        destination: Cesium.Cartesian3.fromDegrees(0, 20, 30_000_000),
      });

      if (isMounted) setViewerReady(true);
    })();

    return () => {
      isMounted = false;
    };
    // Mount-once, deliberately empty deps — same rationale as GlobeView.tsx
     
  }, []);

  // ── Wheel / trackpad zoom ────────────────────────────────────────────
  useEffect(() => {
    const viewer = viewerRef.current;
    if (!viewerReady || !viewer || viewer.isDestroyed()) return;
    const canvas = viewer.scene.canvas;
    canvas.style.touchAction = "none";

    const onWheelZoom = (e: WheelEvent) => {
      if (!viewerRef.current || viewerRef.current.isDestroyed()) return;
      e.preventDefault();
      e.stopPropagation();

      const camera = viewerRef.current.camera;
      const height = camera.positionCartographic.height;
      const minZoom = isOnline ? ONLINE_MIN_ZOOM_METERS : OFFLINE_MIN_ZOOM_METERS;
      const intensity = e.ctrlKey ? 0.0022 : 0.0014;
      const factor = Math.exp(e.deltaY * intensity);
      const nextHeight = Math.min(3e7, Math.max(minZoom, height * factor));
      if (nextHeight < height) camera.zoomIn(height - nextHeight);
      else if (nextHeight > height) camera.zoomOut(nextHeight - height);
      viewerRef.current.scene.requestRender();
    };

    canvas.addEventListener("wheel", onWheelZoom, { passive: false });
    return () => canvas.removeEventListener("wheel", onWheelZoom);
  }, [viewerReady, isOnline]);

  // ── Destroy only on unmount ──────────────────────────────────────────
  useEffect(() => {
    return () => {
      if (viewerRef.current && !viewerRef.current.isDestroyed()) {
        viewerRef.current.destroy();
        viewerRef.current = null;
      }
    };
  }, []);

  const handleZoomIn = useCallback(() => {
    const v = viewerRef.current;
    if (!v || v.isDestroyed()) return;
    const cam = v.camera;
    const minZoom = isOnline ? ONLINE_MIN_ZOOM_METERS : OFFLINE_MIN_ZOOM_METERS;
    const currentHeight = cam.positionCartographic.height;
    const targetHeight = Math.max(minZoom, currentHeight * ZOOM_STEP_FACTOR);
    cam.zoomIn(currentHeight - targetHeight);
    v.scene.requestRender();
  }, [isOnline]);

  const handleZoomOut = useCallback(() => {
    const v = viewerRef.current;
    if (!v || v.isDestroyed()) return;
    const cam = v.camera;
    const currentHeight = cam.positionCartographic.height;
    cam.zoomOut(currentHeight * (1 / ZOOM_STEP_FACTOR - 1));
    v.scene.requestRender();
  }, []);

  return {
    ref,
    viewerRef,
    viewerReady,
    isOnline,
    statusMsg,
    handleZoomIn,
    handleZoomOut,
  };
}