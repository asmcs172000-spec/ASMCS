// vizPlayback.ts
//
// Shared play / pause / stop state for the frequency visualizations (Spot,
// Strip sweep, Strip capture plan, Orbit reference). Only one runs at a time.
//   - Animations call vizStarted(kind) when they start and vizStopped(kind)
//     from their clear function (a no-op unless that kind is the active one).
//   - setVizPaused() freezes the Cesium clock (clock-driven animations) and
//     sets a flag the requestAnimationFrame-driven ones check each frame.
//   - useVizPlayback() lets the control bar follow the state, including when
//     the animation is closed from the globe's own "Back to Globe" button.

import { useSyncExternalStore } from "react";
import type * as Cesium from "cesium";

export type VizKind = "spot" | "strip-frequency" | "strip-plan" | "orbit";
export type VizPlaybackState = { active: VizKind | null; paused: boolean };

let state: VizPlaybackState = { active: null, paused: false };
const listeners = new Set<() => void>();

function set(next: VizPlaybackState) {
  if (next.active === state.active && next.paused === state.paused) return;
  state = next;
  listeners.forEach((l) => l());
}

export function vizStarted(kind: VizKind) {
  set({ active: kind, paused: false });
}

export function vizStopped(kind: VizKind) {
  if (state.active === kind) set({ active: null, paused: false });
}

export function isVizPaused() {
  return state.paused;
}

export function setVizPaused(viewer: Cesium.Viewer | null | undefined, paused: boolean) {
  if (!state.active) return;
  if (viewer && !viewer.isDestroyed()) {
    viewer.clock.shouldAnimate = !paused;
    viewer.scene.requestRender();
  }
  set({ ...state, paused });
}

export function useVizPlayback(): VizPlaybackState {
  return useSyncExternalStore(
    (l) => {
      listeners.add(l);
      return () => listeners.delete(l);
    },
    () => state,
  );
}
