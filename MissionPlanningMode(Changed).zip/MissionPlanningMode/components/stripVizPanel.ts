// stripVizPanel.ts
//
// Shared pieces of the two strip animations ("Visualize capture plan" and
// "Visualize on map"):
//   - mountStatusPanel(): ONE tidy readout UNDER the globe
//       header  : what is playing + status chip
//       numbers : area captured · time (UTC) · capture time
//       bar     : orbits / frequency segments with playhead
//       times   : AOS · mission start · coverage complete · mission end · LOS
//   - addBeamFrustum(): a volumetric sensor beam (satellite -> live footprint):
//       soft outer glow, body and bright core + energy pulses travelling down.
//       No dashed or solid edge lines.

import * as Cesium from "cesium";
import { FREQUENCY_PRESETS, type FrequencySegment } from "./FrequencyAndTime";

/** Element (under the globe) that hosts the animation readout and legends. */
export const STRIP_VIZ_PANEL_ID = "mp-viz-panel";

const FONT = `"Roboto", "Segoe UI", system-ui, sans-serif`;
const MONO = `"Roboto Mono", ui-monospace, Consolas, monospace`;

export const fmtClock = (sec: number) => {
  const s = Math.max(0, Math.round(sec));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
};
export const fmtUtc = (d: Date) => d.toISOString().slice(11, 19);

// ─── Status panel ─────────────────────────────────────────────────────

export type BarSegment = {
  id: string;
  title: string;
  subtitle: string;
  color: string;
  /** Width in % of the bar. */
  widthPct: number;
};

export type BarMarker = { leftPct: number; label: string };

/** Pass times shown in the bottom row (one set per orbit). */
export type PassTimes = {
  aos: Date;
  missionStart: Date;
  coverageDone: Date;
  missionEnd: Date;
  los: Date;
  losBeforeEnd: boolean;
};

export type StatusUpdate = {
  /** Header, e.g. "Orbit 2 · C104-B". */
  title: string;
  fraction: string;
  /** Simulated real time. */
  utc: Date;
  /** Seconds since mission start, and the time needed to cover the AOI. */
  captureSec: number;
  captureTotalSec: number;
  activeSegmentId: string | null;
  playheadPct: number;
  status: string;
  tone: "live" | "done" | "warn";
  times: PassTimes;
};

export type StatusPanel = { update: (u: StatusUpdate) => void };

export function mountStatusPanel(
  viewer: Cesium.Viewer,
  opts: { overlayClass: string; segments: BarSegment[]; markers: BarMarker[] },
): StatusPanel {
  const host = document.getElementById(STRIP_VIZ_PANEL_ID);
  const root = document.createElement("div");
  root.className = opts.overlayClass;
  root.style.cssText =
    (host ? "margin-bottom:10px;" : "position:absolute;left:12px;right:12px;bottom:12px;z-index:20;") +
    "padding:14px 16px;border:1px solid rgba(255,255,255,.08);border-radius:12px;" +
    "background:linear-gradient(180deg,rgba(24,28,36,.9),rgba(12,14,18,.94));" +
    `color:#e8ecf0;font:13px/1.45 ${FONT};box-shadow:0 10px 30px rgba(0,0,0,.35);`;

  const big = (key: string, label: string, accent = false) =>
    `<div style="display:flex;flex-direction:column;gap:2px;min-width:0">
<span data-k="${key}" style="font:${accent ? "700 28px" : "600 20px"} ${MONO};color:${accent ? "#7fe3ff" : "#f1f5f8"};line-height:1.1;white-space:nowrap">—</span>
<span style="font-size:11px;color:#8a96a3">${label}</span></div>`;

  root.innerHTML = `
<div style="display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:12px">
<span data-k="title" style="font-weight:600;font-size:14px;color:#f1f5f8"></span>
<span data-k="status" style="font-size:11.5px;font-weight:600;padding:3px 9px;border-radius:999px;white-space:nowrap"></span></div>
<div style="display:grid;grid-template-columns:1.1fr 1fr 1fr;gap:12px;align-items:end;margin-bottom:12px">
${big("pct", "Area captured", true)}
${big("utc", "Time (UTC)")}
${big("capture", "Capture time")}
</div>
<div data-k="bar" style="position:relative;display:flex;height:38px;border-radius:7px;overflow:hidden;border:1px solid rgba(255,255,255,.12)"></div>
<div data-k="scale" style="position:relative;height:16px;margin-top:3px;font:10.5px ${MONO};color:#6ee7b7"></div>
<div data-k="times" style="display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:6px;margin-top:8px;padding-top:10px;border-top:1px solid rgba(255,255,255,.08)"></div>`;

  const q = (k: string) => root.querySelector(`[data-k="${k}"]`) as HTMLElement;
  const bar = q("bar");
  const segEls = new Map<string, HTMLDivElement>();
  for (const s of opts.segments) {
    const el = document.createElement("div");
    el.title = `${s.title} · ${s.subtitle}`;
    el.style.cssText =
      `flex:0 0 ${s.widthPct}%;display:flex;flex-direction:column;align-items:center;justify-content:center;` +
      `background:${s.color};filter:brightness(.5) saturate(.85);border-right:1px solid rgba(0,0,0,.35);` +
      "overflow:hidden;white-space:nowrap;transition:filter .2s linear;min-width:0;padding:0 4px;";
    el.innerHTML =
      `<span style="font:600 11px ${FONT};color:#fff;overflow:hidden;text-overflow:ellipsis;max-width:100%">${s.title}</span>` +
      `<span style="font:10px ${MONO};color:rgba(255,255,255,.85);overflow:hidden;text-overflow:ellipsis;max-width:100%">${s.subtitle}</span>`;
    bar.appendChild(el);
    segEls.set(s.id, el);
  }
  for (const m of opts.markers) {
    if (!(m.leftPct >= 0 && m.leftPct <= 100)) continue;
    const mk = document.createElement("div");
    mk.title = m.label;
    mk.style.cssText = `position:absolute;top:0;bottom:0;left:${m.leftPct}%;border-left:2px dashed #6ee7b7;pointer-events:none;`;
    bar.appendChild(mk);
    const tag = document.createElement("span");
    tag.textContent = m.label;
    tag.style.cssText = `position:absolute;top:0;left:${m.leftPct}%;transform:translateX(-50%);white-space:nowrap;`;
    q("scale").appendChild(tag);
  }
  const head = document.createElement("div");
  head.style.cssText =
    "position:absolute;top:0;bottom:0;width:2px;left:0%;background:#fff;box-shadow:0 0 8px #fff;pointer-events:none;";
  bar.appendChild(head);

  if (host) host.insertBefore(root, host.firstChild);
  else viewer.container.appendChild(root);

  const chip = {
    live: "color:#7fe3ff;background:rgba(79,179,232,.14);border:1px solid rgba(79,179,232,.35)",
    done: "color:#6ee7b7;background:rgba(52,211,153,.12);border:1px solid rgba(52,211,153,.35)",
    warn: "color:#f3c46e;background:rgba(240,180,76,.12);border:1px solid rgba(240,180,76,.35)",
  } as const;
  const timeCell = (label: string, value: string, color = "#e8ecf0") =>
    `<div style="display:flex;flex-direction:column;min-width:0"><span style="font-size:10.5px;color:#8a96a3;white-space:nowrap">${label}</span>` +
    `<span style="font:500 12.5px ${MONO};color:${color}">${value}</span></div>`;

  let lastActive: string | null = null;
  let lastTimesKey = "";
  let lastTone = "";

  return {
    update(u) {
      q("title").textContent = u.title;
      q("pct").textContent = u.fraction;
      q("utc").textContent = fmtUtc(u.utc);
      q("capture").textContent = `${fmtClock(Math.min(u.captureSec, u.captureTotalSec))} / ${fmtClock(u.captureTotalSec)}`;
      const st = q("status");
      st.textContent = u.status;
      if (u.tone !== lastTone) {
        st.style.cssText += `;${chip[u.tone]}`;
        lastTone = u.tone;
      }
      head.style.left = `${Math.min(100, Math.max(0, u.playheadPct))}%`;
      if (u.activeSegmentId !== lastActive) {
        segEls.forEach((el, id) => {
          el.style.filter = id === u.activeSegmentId ? "brightness(1.1) saturate(1.1)" : "brightness(.5) saturate(.85)";
        });
        lastActive = u.activeSegmentId;
      }
      const t = u.times;
      const key = `${t.aos.getTime()}|${t.coverageDone.getTime()}`;
      if (key !== lastTimesKey) {
        q("times").innerHTML =
          timeCell("AOS", fmtUtc(t.aos)) +
          timeCell("Mission start", fmtUtc(t.missionStart)) +
          timeCell("Coverage done", fmtUtc(t.coverageDone), "#6ee7b7") +
          timeCell("Mission end", fmtUtc(t.missionEnd)) +
          timeCell(t.losBeforeEnd ? "LOS ⚠" : "LOS", fmtUtc(t.los), t.losBeforeEnd ? "#f3c46e" : "#e8ecf0");
        lastTimesKey = key;
      }
    },
  };
}

// ─── Frequency panel (Spot + Orbit reference) ─────────────────────────
//
// Same look as the strip readout, mounted under the globe:
//   header  : title + status chip
//   numbers : active frequency · time (UTC) · mission time
//   bar     : frequency segments with playhead
//   legend  : frequencies used · satellites · ground track

export type FrequencyPanelUpdate = {
  activeIndex: number;
  playheadPct: number;
  utc: Date | null;
  elapsedSec: number;
  totalSec: number;
  paused: boolean;
};

export type FrequencyPanel = { update: (u: FrequencyPanelUpdate) => void };

export function mountFrequencyPanel(
  viewer: Cesium.Viewer,
  opts: {
    overlayClass: string;
    title: string;
    segments: FrequencySegment[];
    satellites: { name: string; color: string }[];
    /** Amber alert line, e.g. LOS before mission end. */
    warning?: string | null;
  },
): FrequencyPanel {
  const host = document.getElementById(STRIP_VIZ_PANEL_ID);
  const root = document.createElement("div");
  root.className = opts.overlayClass;
  root.style.cssText =
    (host ? "margin-bottom:10px;" : "position:absolute;left:12px;right:12px;bottom:12px;z-index:20;") +
    "padding:14px 16px;border:1px solid rgba(255,255,255,.08);border-radius:12px;" +
    "background:linear-gradient(180deg,rgba(24,28,36,.9),rgba(12,14,18,.94));" +
    `color:#e8ecf0;font:13px/1.45 ${FONT};box-shadow:0 10px 30px rgba(0,0,0,.35);`;

  const total = opts.segments.reduce((sum, s) => sum + s.durationSeconds, 0) || 1;
  const big = (key: string, label: string, accent = false) =>
    `<div style="display:flex;flex-direction:column;gap:2px;min-width:0">
<span data-k="${key}" style="font:${accent ? "700 20px" : "600 17px"} ${MONO};color:${accent ? "#7fe3ff" : "#f1f5f8"};line-height:1.15;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">—</span>
<span style="font-size:11px;color:#8a96a3">${label}</span></div>`;
  const usedPresets = [...new Set(opts.segments.map((s) => s.presetId))];

  root.innerHTML = `
<div style="display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:12px">
<span style="font-weight:600;font-size:14px;color:#f1f5f8">${opts.title}</span>
<span data-k="status" style="font-size:11.5px;font-weight:600;padding:3px 9px;border-radius:999px;white-space:nowrap"></span></div>
<div style="display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px;align-items:end;margin-bottom:12px">
${big("freq", "Active frequency", true)}
${big("utc", "Time (UTC)")}
${big("clock", "Mission time")}
</div>
<div data-k="bar" style="position:relative;display:flex;height:38px;border-radius:7px;overflow:hidden;border:1px solid rgba(255,255,255,.12)"></div>
<div style="display:flex;flex-direction:column;gap:8px;margin-top:12px;padding-top:10px;border-top:1px solid rgba(255,255,255,.08)">
<div style="display:flex;flex-wrap:wrap;gap:6px 14px">
${usedPresets
  .map((id) => {
    const p = FREQUENCY_PRESETS[id];
    return `<span data-preset="${id}" style="display:flex;align-items:center;gap:7px;font-size:12.5px;padding:2px 6px;border-radius:5px;transition:background .2s linear,opacity .2s linear">
<span style="width:12px;height:12px;border-radius:3px;background:${p.color}"></span>${p.label} <span style="color:#8a96a3">${p.swathKm} km swath</span></span>`;
  })
  .join("")}
</div>
<div style="display:flex;flex-wrap:wrap;gap:6px 14px;font-size:12.5px">
${opts.satellites
  .map(
    (s) =>
      `<span style="display:flex;align-items:center;gap:7px"><span style="width:8px;height:8px;border-radius:50%;background:${s.color}"></span>${s.name}</span>`,
  )
  .join("")}
<span style="display:flex;align-items:center;gap:7px;color:#aab4bd"><span style="width:16px;border-top:2px solid #fff"></span>Ground track</span>
</div>
${opts.warning ? `<div style="font-size:11.5px;color:#f3c46e">⚠ ${opts.warning}</div>` : ""}
</div>`;

  const q = (k: string) => root.querySelector(`[data-k="${k}"]`) as HTMLElement;
  const bar = q("bar");
  const segEls = opts.segments.map((s) => {
    const p = FREQUENCY_PRESETS[s.presetId];
    const el = document.createElement("div");
    el.title = `${p.label} · ${fmtClock(s.durationSeconds)}`;
    el.style.cssText =
      `flex:0 0 ${(s.durationSeconds / total) * 100}%;display:flex;flex-direction:column;align-items:center;justify-content:center;` +
      `background:${p.color};filter:brightness(.5) saturate(.85);border-right:1px solid rgba(0,0,0,.35);` +
      "overflow:hidden;white-space:nowrap;transition:filter .2s linear;min-width:0;padding:0 4px;";
    el.innerHTML =
      `<span style="font:600 11px ${FONT};color:#fff;overflow:hidden;text-overflow:ellipsis;max-width:100%">${p.label}</span>` +
      `<span style="font:10px ${MONO};color:rgba(255,255,255,.85);overflow:hidden;text-overflow:ellipsis;max-width:100%">${p.swathKm} km</span>`;
    bar.appendChild(el);
    return el;
  });
  const head = document.createElement("div");
  head.style.cssText =
    "position:absolute;top:0;bottom:0;width:2px;left:0%;background:#fff;box-shadow:0 0 8px #fff;pointer-events:none;";
  bar.appendChild(head);

  if (host) host.insertBefore(root, host.firstChild);
  else viewer.container.appendChild(root);

  const chip = {
    live: "color:#7fe3ff;background:rgba(79,179,232,.14);border:1px solid rgba(79,179,232,.35)",
    warn: "color:#f3c46e;background:rgba(240,180,76,.12);border:1px solid rgba(240,180,76,.35)",
  } as const;
  let lastActive = -2;
  let lastPaused: boolean | null = null;

  return {
    update(u) {
      const seg = opts.segments[u.activeIndex];
      q("freq").textContent = seg ? FREQUENCY_PRESETS[seg.presetId].label : "—";
      q("utc").textContent = u.utc ? fmtUtc(u.utc) : "—";
      q("clock").textContent = `${fmtClock(u.elapsedSec)} / ${fmtClock(u.totalSec)}`;
      head.style.left = `${Math.min(100, Math.max(0, u.playheadPct))}%`;
      if (u.paused !== lastPaused) {
        const st = q("status");
        st.textContent = u.paused ? "Paused" : "Playing";
        st.style.cssText += `;${u.paused ? chip.warn : chip.live}`;
        lastPaused = u.paused;
      }
      if (u.activeIndex !== lastActive) {
        segEls.forEach((el, i) => {
          el.style.filter = i === u.activeIndex ? "brightness(1.1) saturate(1.1)" : "brightness(.5) saturate(.85)";
        });
        root.querySelectorAll<HTMLElement>("[data-preset]").forEach((el) => {
          const on = !!seg && el.dataset["preset"] === seg.presetId;
          el.style.background = on ? "rgba(95,212,255,.14)" : "transparent";
          el.style.opacity = on || !seg ? "1" : "0.6";
        });
        lastActive = u.activeIndex;
      }
    },
  };
}

/** "← Back to Globe" button, top-left on the globe (same look as the strip animations). */
export function mountBackToGlobeButton(viewer: Cesium.Viewer, overlayClass: string, onClick: () => void) {
  const btn = document.createElement("button");
  btn.type = "button";
  btn.className = overlayClass;
  btn.textContent = "← Back to Globe";
  btn.style.cssText =
    "position:absolute;left:12px;top:12px;z-index:22;padding:7px 13px;" +
    "border:1px solid rgba(255,255,255,.14);border-radius:8px;background:rgba(14,16,21,.9);" +
    `color:#eaf6ff;font:500 12px ${FONT};cursor:pointer;box-shadow:0 4px 16px rgba(0,0,0,.5)`;
  btn.addEventListener("click", onClick);
  viewer.container.appendChild(btn);
  return btn;
}

// ─── Volumetric sensor beam ────────────────────────────────────────────

export type BeamFrame = {
  apex: Cesium.Cartesian3;
  /** Footprint corners on the ground (4, in ring order). */
  base: Cesium.Cartesian3[];
  color: Cesium.Color;
};

const PULSE_COUNT = 3;
const PULSE_PERIOD_MS = 1400;

/** Corners scaled about their centre (s < 1 shrinks, s > 1 grows). */
function scaleRing(ring: Cesium.Cartesian3[], s: number): Cesium.Cartesian3[] {
  const c = new Cesium.Cartesian3();
  ring.forEach((p) => Cesium.Cartesian3.add(c, p, c));
  Cesium.Cartesian3.divideByScalar(c, ring.length, c);
  return ring.map((p) => Cesium.Cartesian3.lerp(c, p, s, new Cesium.Cartesian3()));
}

/**
 * Sensor beam = glowing volume from the satellite to its live footprint:
 *   outer glow (wider, faint) + body + bright core, all translucent faces,
 *   with energy pulses (thin slabs) travelling from the satellite to the ground.
 */
export function addBeamFrustum(
  viewer: Cesium.Viewer,
  idPrefix: string,
  frameAt: (time: Cesium.JulianDate) => BeamFrame | null,
  opts: { strength?: number } = {},
) {
  const k = opts.strength ?? 1;
  const now = () => viewer.clock.currentTime;
  const empty = new Cesium.PolygonHierarchy([]);
  const read = (time: unknown) => frameAt((time as Cesium.JulianDate) ?? now());

  // Layers: [base scale, alpha, lighten]
  const layers: [number, number, number][] = [
    [1.35, 0.06 * k, 0],
    [1.0, 0.12 * k, 0.1],
    [0.4, 0.22 * k, 0.45],
  ];
  layers.forEach(([scale, alpha, lighten], li) => {
    for (let i = 0; i < 4; i++) {
      viewer.entities.add({
        id: `${idPrefix}beam-l${li}-f${i}`,
        polygon: {
          hierarchy: new Cesium.CallbackProperty((time) => {
            const f = read(time);
            if (!f || f.base.length < 4) return empty;
            const b = scale === 1 ? f.base : scaleRing(f.base, scale);
            return new Cesium.PolygonHierarchy([f.apex, b[i], b[(i + 1) % 4]]);
          }, false),
          material: new Cesium.ColorMaterialProperty(
            new Cesium.CallbackProperty((time) => {
              const f = read(time);
              if (!f) return Cesium.Color.TRANSPARENT;
              const c = Cesium.Color.lerp(f.color, Cesium.Color.WHITE, lighten, new Cesium.Color());
              return c.withAlpha(alpha);
            }, false),
          ),
          perPositionHeight: true,
        },
      });
    }
  });

  // Energy pulses travelling down the beam.
  for (let p = 0; p < PULSE_COUNT; p++) {
    const phaseAt = () => ((performance.now() / PULSE_PERIOD_MS + p / PULSE_COUNT) % 1);
    viewer.entities.add({
      id: `${idPrefix}beam-pulse-${p}`,
      polygon: {
        hierarchy: new Cesium.CallbackProperty((time) => {
          const f = read(time);
          if (!f || f.base.length < 4) return empty;
          const t = 0.08 + 0.92 * phaseAt();
          return new Cesium.PolygonHierarchy(
            f.base.map((b) => Cesium.Cartesian3.lerp(f.apex, b, t, new Cesium.Cartesian3())),
          );
        }, false),
        material: new Cesium.ColorMaterialProperty(
          new Cesium.CallbackProperty((time) => {
            const f = read(time);
            if (!f) return Cesium.Color.TRANSPARENT;
            const t = phaseAt();
            const c = Cesium.Color.lerp(f.color, Cesium.Color.WHITE, 0.35, new Cesium.Color());
            return c.withAlpha(0.32 * k * Math.sin(Math.PI * t));
          }, false),
        ),
        perPositionHeight: true,
      },
    });
  }
}
