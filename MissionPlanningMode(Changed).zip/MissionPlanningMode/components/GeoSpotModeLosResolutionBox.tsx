import { useState } from "react";
import { AlertTriangle, X } from "lucide-react";
import { FrequencyPlanTable, type FrequencySegment } from "./FrequencyAndTime";
import type { MissionPlan, SpotOrbit } from "./SpotModeRange";

// Spot mode: a selected pass whose LOS comes before the mission end. The
// operator chooses how to complete the mission for THIS pass:
//   A. "multi" — keep the plan, finish it on the following passes
//                (the multi-pass plan is shown here only).
//   B. "edit"  — re-enter the frequency plan (start / duration) so the
//                whole mission ends before LOS.

export type LosChoice = "multi" | "edit";

type Props = {
  satelliteName: string;
  orbit: SpotOrbit;
  /** Multi-pass plan starting at this orbit. */
  plan: MissionPlan;
  segments: FrequencySegment[];
  /** Previously chosen option for this pass, if any. */
  initialChoice?: LosChoice | null;
  onClose: () => void;
  onChooseMulti: () => void;
  onApplyPlan: (segments: FrequencySegment[]) => void;
};

const hms = (d: Date) => d.toISOString().slice(11, 19);
function mmss(sec: number) {
  const s = Math.max(0, Math.round(sec));
  return `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;
}

export default function GeoSpotModeLosResolutionBox({
  satelliteName,
  orbit,
  plan,
  segments,
  initialChoice,
  onClose,
  onChooseMulti,
  onApplyPlan,
}: Props) {
  const [choice, setChoice] = useState<LosChoice>(initialChoice ?? "multi");
  const [draft, setDraft] = useState<FrequencySegment[]>(segments);

  const available = Math.floor(orbit.availableSeconds);
  const missing = orbit.missionDurationSeconds - orbit.availableSeconds;
  const draftTotal = draft.reduce((s, x) => s + x.durationSeconds, 0);
  const draftFits = draft.length > 0 && draftTotal > 0 && draftTotal <= available;
  const canApply = choice === "multi" ? plan.allocations.length > 0 : draftFits;

  // Timeline: mission start → LOS (green) → planned end (amber, lost).
  const availPct = (orbit.availableSeconds / orbit.missionDurationSeconds) * 100;

  return (
    <div
      className="fixed inset-0 z-[60] flex items-center justify-center bg-black/35 p-4 backdrop-blur-[2px]"
      onMouseDown={(e) => e.target === e.currentTarget && onClose()}
      role="dialog"
      aria-modal="true"
      aria-label="LOS before mission end"
    >
      <div
        className="flex max-h-[90vh] w-[min(920px,100%)] flex-col overflow-hidden rounded-[var(--mp-radius-card)] border border-[var(--mp-border)] shadow-[0_20px_60px_rgba(0,0,0,.55)] backdrop-blur-md"
        style={{ background: "rgba(18,22,27,.86)" }}
      >
        <div className="mp-card-head !bg-[rgba(22,27,33,.7)]">
          <span className="flex min-w-0 items-center gap-2 font-semibold">
            <AlertTriangle className="size-4 shrink-0 text-[var(--mp-warn)]" />
            <span className="truncate">
              LOS before mission end · {satelliteName} · {orbit.missionStart.toISOString().slice(0, 10)} {hms(orbit.missionStart)} UTC
            </span>
          </span>
          <button type="button" onClick={onClose} title="Close" className="text-[var(--mp-text-3)] hover:text-[var(--mp-text)]">
            <X className="size-4" />
          </button>
        </div>

        <div className="flex min-h-0 flex-col gap-4 overflow-y-auto px-4 py-4">
          {/* This pass at a glance */}
          <div className="flex flex-col gap-2">
            <div className="grid grid-cols-4 gap-2">
              <Fact label="Mission start" value={hms(orbit.missionStart)} />
              <Fact label="LOS" value={hms(orbit.los)} tone="warn" />
              <Fact label="Planned end" value={hms(orbit.missionEnd)} />
              <Fact label="Missing" value={mmss(missing)} tone="warn" />
            </div>
            <div className="flex h-3 overflow-hidden rounded-full border border-[var(--mp-border)]">
              <div className="h-full bg-[var(--mp-ok)]/70" style={{ width: `${availPct}%` }} title={`Fits before LOS · ${mmss(available)}`} />
              <div className="h-full flex-1 bg-[var(--mp-warn)]/60" title={`After LOS · ${mmss(missing)}`} />
            </div>
            <div className="mp-mono flex justify-between text-[11px] text-[var(--mp-text-3)]">
              <span>fits before LOS {mmss(available)}</span>
              <span>plan {mmss(orbit.missionDurationSeconds)}</span>
            </div>
          </div>

          {/* Option A */}
          <Choice
            on={choice === "multi"}
            onSelect={() => setChoice("multi")}
            title="Complete the mission on upcoming passes"
            note="Keep the frequency plan. The rest is captured on the next passes of this satellite."
          >
            <div className="flex flex-col gap-1">
              <span className="mb-1 text-[10px] font-semibold uppercase tracking-wider text-[var(--mp-text-3)]">
                Multi-pass plan
              </span>
              {plan.allocations.map((a, k) => (
                <div key={a.orbitIndex} className="mp-mono grid grid-cols-[auto_1fr_auto] gap-3 text-[12.5px]">
                  <span className="text-[var(--mp-text-3)]">Pass {k + 1}</span>
                  <span>
                    {a.start.toISOString().slice(0, 10)} {hms(a.start)}
                  </span>
                  <span className="text-[var(--mp-text-2)]">
                    {mmss(a.planOffsetSeconds)} → {mmss(a.planOffsetSeconds + a.durationSeconds)}
                  </span>
                </div>
              ))}
              <span className={`mt-1 text-xs ${plan.completed ? "text-[var(--mp-ok)]" : "text-[var(--mp-warn)]"}`}>
                {plan.completed
                  ? `Mission completes in ${plan.allocations.length} passes.`
                  : `${mmss(plan.remainingSeconds)} still uncovered in the scan window.`}
              </span>
            </div>
          </Choice>

          {/* Option B */}
          <Choice
            on={choice === "edit"}
            onSelect={() => setChoice("edit")}
            title="Re-enter the frequency plan to fit this pass"
            note={`Set each segment's start and duration so the mission ends before LOS (≤ ${mmss(available)}).`}
          >
            <div className="flex flex-col gap-2.5">
              <FrequencyPlanTable segments={draft} onSegmentsChange={setDraft} />
              <div
                className="flex flex-wrap items-center justify-between gap-2 rounded-md border px-3 py-2 text-xs"
                style={{
                  borderColor: draftFits ? "rgba(52,196,138,.4)" : "rgba(226,176,74,.4)",
                  background: draftFits ? "rgba(52,196,138,.08)" : "rgba(226,176,74,.08)",
                  color: draftFits ? "var(--mp-ok)" : "var(--mp-warn)",
                }}
              >
                <span>
                  Mission time <span className="mp-mono font-semibold">{mmss(draftTotal)}</span> · must be ≤{" "}
                  <span className="mp-mono font-semibold">{mmss(available)}</span> (LOS)
                </span>
                <span className="font-semibold">
                  {draft.length === 0
                    ? "Add at least one segment"
                    : draftFits
                      ? "Fits within LOS"
                      : `${mmss(draftTotal - available)} over LOS`}
                </span>
              </div>
            </div>
          </Choice>
        </div>

        <div className="flex items-center justify-end gap-2 border-t border-[var(--mp-border)] px-4 py-3">
          <button
            type="button"
            onClick={onClose}
            className="rounded-md border border-[#33404b] px-4 py-[9px] hover:bg-white/[0.04]"
          >
            Cancel
          </button>
          <button
            type="button"
            disabled={!canApply}
            onClick={() => (choice === "multi" ? onChooseMulti() : onApplyPlan(draft))}
            className="mp-btn-primary"
          >
            {choice === "multi" ? "Use upcoming passes" : "Apply new frequency plan"}
          </button>
        </div>
      </div>
    </div>
  );
}

function Fact({ label, value, tone }: { label: string; value: string; tone?: "warn" }) {
  return (
    <div className="rounded-md border border-[var(--mp-border)] px-2.5 py-2">
      <div className="text-[10px] font-medium uppercase tracking-wider text-[var(--mp-text-3)]">{label}</div>
      <div className={`mp-mono mt-0.5 text-sm font-semibold ${tone === "warn" ? "text-[var(--mp-warn)]" : ""}`}>{value}</div>
    </div>
  );
}

function Choice({
  on,
  onSelect,
  title,
  note,
  children,
}: {
  on: boolean;
  onSelect: () => void;
  title: string;
  note: string;
  children: React.ReactNode;
}) {
  return (
    <div
      className="overflow-hidden rounded-lg border transition-colors"
      style={{
        borderColor: on ? "var(--mp-selected-border)" : "var(--mp-border)",
        background: on ? "rgba(77,163,255,.06)" : "transparent",
      }}
    >
      <button type="button" onClick={onSelect} className="flex w-full items-start gap-2.5 px-3.5 py-3 text-left">
        <span
          className="mt-0.5 size-3.5 shrink-0 rounded-full border-[1.5px] shadow-[inset_0_0_0_3px_#10161c]"
          style={{ borderColor: on ? "var(--mp-accent)" : "#4a5866", background: on ? "var(--mp-accent)" : "transparent" }}
        />
        <span className="flex flex-col gap-0.5">
          <span className="font-semibold">{title}</span>
          <span className="text-xs text-[var(--mp-text-3)]">{note}</span>
        </span>
      </button>
      {on && <div className="border-t border-[var(--mp-border-row)] px-3.5 py-3">{children}</div>}
    </div>
  );
}
