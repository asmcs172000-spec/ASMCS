import * as Cesium from "cesium";
import * as satellite from "satellite.js";
import { FREQUENCY_PRESETS, type FrequencyPresetId, type FrequencySegment } from "./FrequencyAndTime";
import {
  fallbackColorForName,
  OTHER_SAT_FALLBACK_COLORS,
  type TleEntry,
} from "./satelliteRangeUtils";
import { mountBackToGlobeButton, mountFrequencyPanel } from "./stripVizPanel";
import { isVizPaused, vizStarted, vizStopped } from "./vizPlayback";

// ─── Constants ──────────────────────────────────────────────────────────

const ENTITY_PREFIX = "freq-viz-";
const OVERLAY_CLASS = "freq-viz-overlay";
const SATELLITE_ICON_URL = "/satellite.png";
const CLOCK_MULTIPLIER = 13;

/**
 * CONSTANT along-track look-ahead (in mission seconds) between a satellite's
 * ACTUAL current position and the ground point its beam is illuminating. Each
 * satellite always sits at its real, TLE-propagated position for the current
 * mission clock time — this constant only decides how far ahead (in time,
 * along its real orbit) the beam target sits, so every beam is always slanted
 * forward and never collapses onto nadir.
 */
const BEAM_LEAD_SECONDS = 200;

/**
 * Lead-in (pre-roll) before the FIRST swath starts. The clock now begins
 * BEAM_LEAD_SECONDS + MISSION_PRE_ROLL_SECONDS before the first band, so the
 * satellite flies in already slanted and its beam crosses the very START of
 * the first swath instead of appearing part-way through it.
 */
const MISSION_PRE_ROLL_SECONDS = 60;

/** Cross-track spread of the beam cone at the satellite itself (meters). */
const BEAM_APEX_HALF_WIDTH_METERS = 60_000;

/** Along-track half-length of the bright footprint slice (seconds). */
const FOOTPRINT_HALF_WINDOW_SECONDS = 4;

/** How long satellites keep animating after the last swath is scanned. */
const TAIL_OUT_SECONDS = 30;

/** Extra ground-track drawn BEFORE and AFTER the animated window (seconds).
 *  Symmetric on purpose: the animation then plays in the MIDDLE of each
 *  satellite's overall ground track. */
const TRACK_MARGIN_SECONDS = 3000;

/** Sample spacing (seconds) used when building curved swath/track polygons. */
const SWATH_SAMPLE_STEP_SECONDS = 5;

/** Sample spacing (seconds) for secondary satellites' swath/track polygons —
 *  coarser than the primary's so a large constellation stays performant. */
const OTHER_SWATH_SAMPLE_STEP_SECONDS = 10;
const OTHER_TRACK_SAMPLE_STEP_SECONDS = 20;

/** Time delta (seconds) used to estimate local ground-track heading. */
const HEADING_SAMPLE_DELTA_SECONDS = 1;

/** Per-satellite scan-phase stagger (seconds) so the beams of the whole
 *  constellation don't sweep their frequency plan in perfect lockstep. */
const SCAN_STAGGER_SECONDS = 12;

/** Opacity scaling applied to secondary satellites so the primary stays the
 *  visual focus while the rest of the constellation is still clearly there. */
const SECONDARY_ALPHA_SCALE = 0.55;

let clockTickListener: Cesium.Event.RemoveCallback | null = null;

/** Entities that existed in mission-planning mode (satellite icons, labels,
 *  orbits, ground tracks, ...) are hidden while the animation runs and
 *  restored on cleanup. IDs (not entity object references) are stored: if
 *  Mission Planning's own effects replace these entities while the
 *  animation is running (e.g. selectedSatIds or TLE data changes), a saved
 *  object reference goes stale and restoring it does nothing to the real,
 *  currently-visible entity — that staleness was why "Back" sometimes
 *  didn't bring the ground track back. Looking each one up by ID at
 *  restore time, and always setting it to visible (rather than trusting a
 *  captured show-state), is reliable regardless of what happened to the
 *  entities in between. */
let hiddenPlanningEntityIds: string[] = [];

function hidePlanningEntities(viewer: Cesium.Viewer) {
  hiddenPlanningEntityIds = [];
  viewer.entities.values.forEach((e) => {
    const id = typeof e.id === "string" ? e.id : "";
    if (id.startsWith(ENTITY_PREFIX)) return;
    const isMarker = !!(e.billboard || e.point || e.label || e.model || e.path || e.polyline);
    if (!isMarker) return;
    hiddenPlanningEntityIds.push(id);
    e.show = false;
  });
}

function restorePlanningEntities(viewer?: Cesium.Viewer) {
  if (viewer && !viewer.isDestroyed()) {
    hiddenPlanningEntityIds.forEach((id) => {
      const entity = viewer.entities.getById(id);
      if (entity) entity.show = true;
    });
    viewer.scene.requestRender();
  }
  hiddenPlanningEntityIds = [];
}

// ─── Public types ───────────────────────────────────────────────────────

export type FrequencyVisualizationCallbacks = {
  onBack?: () => void;
  onNext?: () => void;
};

export type FrequencyVisualizationOptions = {
  /** The satellite the frequency plan / beam animation is centred on: it gets
   *  the icon, band labels, progressive coverage fill and the camera framing. */
  primaryTle: TleEntry;
  /** The real-world moment mission time t = 0 corresponds to (the selected
   *  capture time from OrbitReference). All satellite positions are computed
   *  by propagating each TLE from this moment forward. */
  captureTime: Date;
  /** Every other satellite in the constellation group (TleEntry.color is used
   *  when present, matching the app's Constellation Group list — the same
   *  fallback palette/hash used elsewhere kicks in otherwise). Each one now
   *  gets the FULL visualization: real ground track, moving marker, slanted
   *  forward-looking beam cone, pulsing footprint slice and the frequency
   *  swath bands of the same plan (time-staggered), so panning the globe away
   *  from the primary reveals the whole constellation scanning. */
  otherSatellites?: TleEntry[];
  /** Optional per-satellite frequency plans, keyed by TleEntry.name. Any
   *  satellite without an entry uses the shared `segments` plan. */
  segmentsBySatelliteName?: Record<string, FrequencySegment[]>;
};

// ─── Cleanup ────────────────────────────────────────────────────────────

export function clearFrequencyVisualization(viewer: Cesium.Viewer) {
  vizStopped("orbit");
  document.querySelectorAll(`.${OVERLAY_CLASS}`).forEach((el) => el.remove());
  if (viewer.isDestroyed()) {
    restorePlanningEntities();
    return;
  }

  const toRemove: Cesium.Entity[] = [];
  viewer.entities.values.forEach((e) => {
    if (e.id?.toString().startsWith(ENTITY_PREFIX)) toRemove.push(e);
  });
  toRemove.forEach((e) => viewer.entities.remove(e));

  if (clockTickListener) {
    clockTickListener();
    clockTickListener = null;
  }

  restorePlanningEntities(viewer);

  viewer.container.querySelectorAll(`.${OVERLAY_CLASS}`).forEach((el) => el.remove());
}

// ─── TLE propagation helpers ────────────────────────────────────────────

type Subpoint = { lonDeg: number; latDeg: number; heightM: number };

/** satrec cache: twoline2satrec is the expensive part of propagation and the
 *  per-frame callbacks below hit it for every satellite, several times each. */
const satrecCache = new Map<string, satellite.SatRec>();

function satrecFor(tle: TleEntry): satellite.SatRec {
  const key = `${tle.tle1}|${tle.tle2}`;
  let rec = satrecCache.get(key);
  if (!rec) {
    rec = satellite.twoline2satrec(tle.tle1, tle.tle2);
    satrecCache.set(key, rec);
  }
  return rec;
}

/** Real subsatellite point (and altitude) for a TLE at an absolute time. */
function subpointAt(tle: TleEntry, date: Date): Subpoint | null {
  const pv = satellite.propagate(satrecFor(tle), date);
  if (!pv) return null;
  const pos = pv.position;
  if (!pos || typeof pos === "boolean") return null;
  const gmst = satellite.gstime(date);
  const geo = satellite.eciToGeodetic(pos, gmst);
  return {
    lonDeg: satellite.degreesLong(geo.longitude),
    latDeg: satellite.degreesLat(geo.latitude),
    heightM: geo.height * 1000,
  };
}

function subpointCartesian(sp: Subpoint, heightM = 0): Cesium.Cartesian3 {
  return Cesium.Cartesian3.fromDegrees(sp.lonDeg, sp.latDeg, heightM);
}

/** Local ground-track heading (radians, clockwise from north) at a given
 *  time, estimated from two nearby real positions via an ENU frame. */
function headingRadAt(tle: TleEntry, date: Date): number {
  const before = subpointAt(tle, new Date(date.getTime() - HEADING_SAMPLE_DELTA_SECONDS * 1000));
  const after = subpointAt(tle, new Date(date.getTime() + HEADING_SAMPLE_DELTA_SECONDS * 1000));
  if (!before || !after) return 0;
  const origin = subpointCartesian(before);
  const target = subpointCartesian(after);
  const enu = Cesium.Transforms.eastNorthUpToFixedFrame(origin);
  const inverse = Cesium.Matrix4.inverseTransformation(enu, new Cesium.Matrix4());
  const local = Cesium.Matrix4.multiplyByPoint(inverse, target, new Cesium.Cartesian3());
  return Math.atan2(local.x, local.y); // atan2(east, north)
}

/** Offsets a world point by `distanceMeters` along `headingRad` (flat-plane
 *  ENU approximation — fine for swath widths of tens to hundreds of km). */
function offsetPointMeters(
  point: Cesium.Cartesian3,
  headingRad: number,
  distanceMeters: number,
): Cesium.Cartesian3 {
  const enu = Cesium.Transforms.eastNorthUpToFixedFrame(point);
  const localOffset = new Cesium.Cartesian3(
    Math.sin(headingRad) * distanceMeters,
    Math.cos(headingRad) * distanceMeters,
    0,
  );
  const worldOffset = Cesium.Matrix4.multiplyByPointAsVector(
    enu,
    localOffset,
    new Cesium.Cartesian3(),
  );
  return Cesium.Cartesian3.add(point, worldOffset, new Cesium.Cartesian3());
}

/** Samples a satellite's real ground track between two mission-seconds. */
function sampleTrackPositions(
  tle: TleEntry,
  captureTime: Date,
  fromSec: number,
  toSec: number,
  stepSec: number,
): Cesium.Cartesian3[] {
  const pts: Cesium.Cartesian3[] = [];
  for (let t = fromSec; t <= toSec + 1e-6; t += stepSec) {
    const sp = subpointAt(tle, new Date(captureTime.getTime() + t * 1000));
    if (sp) pts.push(subpointCartesian(sp, 0));
  }
  return pts;
}

/** Builds a curved swath polygon ring (left edge forward + right edge
 *  reversed) following the satellite's ACTUAL ground track between two
 *  mission-seconds, with a possibly time-varying half-width. */
function buildSwathRing(
  tle: TleEntry,
  captureTime: Date,
  fromSec: number,
  toSec: number,
  halfMetersAt: (atSeconds: number) => number,
  stepSec = SWATH_SAMPLE_STEP_SECONDS,
): Cesium.Cartesian3[] {
  const start = Math.min(fromSec, toSec);
  const end = Math.max(fromSec, toSec);
  if (end - start < 1e-6) return [];

  const left: Cesium.Cartesian3[] = [];
  const right: Cesium.Cartesian3[] = [];

  for (let t = start; t <= end + 1e-6; t += stepSec) {
    const clamped = Math.min(t, end);
    const date = new Date(captureTime.getTime() + clamped * 1000);
    const sp = subpointAt(tle, date);
    if (!sp) continue;
    const point = subpointCartesian(sp, 1);
    const heading = headingRadAt(tle, date);
    const half = halfMetersAt(clamped);
    left.push(offsetPointMeters(point, heading - Math.PI / 2, half));
    right.push(offsetPointMeters(point, heading + Math.PI / 2, half));
  }
  if (left.length === 0) return [];
  return [...left, ...right.reverse()];
}

// ─── Frequency-segment helpers (unchanged logic) ────────────────────────

function smoothstep(t: number) {
  const c = Math.min(1, Math.max(0, t));
  return c * c * (3 - 2 * c);
}

function getActiveIndex(segments: FrequencySegment[], atSeconds: number): number {
  if (atSeconds <= segments[0].startSeconds) return 0;
  for (let i = 0; i < segments.length; i++) {
    const s = segments[i];
    if (atSeconds >= s.startSeconds && atSeconds < s.startSeconds + s.durationSeconds) return i;
  }
  return segments.length - 1;
}

/** HALF-width in meters at a given mission time, smoothly blended across
 *  band boundaries (used only for the moving beam/footprint, not the
 *  static bands which keep each segment's own fixed width). */
function swathHalfMetersAt(segments: FrequencySegment[], atSeconds: number): number {
  const pts: { t: number; w: number }[] = [];
  segments.forEach((s) => {
    const halfM = (FREQUENCY_PRESETS[s.presetId].swathKm * 1000) / 2;
    pts.push({ t: s.startSeconds, w: halfM });
    pts.push({ t: s.startSeconds + s.durationSeconds, w: halfM });
  });

  if (atSeconds <= pts[0].t) return pts[0].w;
  for (let i = 0; i < pts.length - 1; i++) {
    const a = pts[i];
    const c = pts[i + 1];
    if (atSeconds >= a.t && atSeconds <= c.t) {
      if (c.t - a.t < 1e-6) return c.w;
      return a.w + (c.w - a.w) * smoothstep((atSeconds - a.t) / (c.t - a.t));
    }
  }
  return pts[pts.length - 1].w;
}

// ─── Per-satellite visualization ────────────────────────────────────────

type SatelliteVizConfig = {
  tle: TleEntry;
  /** Frequency plan for THIS satellite, already sorted by startSeconds. */
  segments: FrequencySegment[];
  captureTime: Date;
  /** Unique entity-id namespace for this satellite. */
  idKey: string;
  /** Mission-time offset applied to the scan progress so constellation
   *  members don't sweep their plan in perfect lockstep. */
  scanOffsetSeconds: number;
  /** Constellation colour used for the marker, label and ground track. */
  accentColor: string;
  isPrimary: boolean;
  elapsedAt: (time: Cesium.JulianDate) => number;
  missionStartSeconds: number;
  missionEndSeconds: number;
};

/**
 * Adds the full swath / frequency / beam visualization for ONE satellite.
 * The primary and every constellation member go through this same function,
 * so all of them animate identically; only cosmetic extras (icon vs. dot,
 * band labels, progressive coverage fill, nadir line) are primary-only, and
 * secondary satellites are drawn at reduced opacity with coarser sampling.
 */
function addSatelliteVisualization(viewer: Cesium.Viewer, cfg: SatelliteVizConfig) {
  const {
    tle,
    segments,
    captureTime,
    idKey,
    scanOffsetSeconds,
    accentColor,
    isPrimary,
    elapsedAt,
    missionStartSeconds,
    missionEndSeconds,
  } = cfg;

  const prefix = `${ENTITY_PREFIX}${idKey}-`;
  const alpha = (a: number) => (isPrimary ? a : a * SECONDARY_ALPHA_SCALE);
  const swathStep = isPrimary ? SWATH_SAMPLE_STEP_SECONDS : OTHER_SWATH_SAMPLE_STEP_SECONDS;

  /** Scan position within THIS satellite's plan, wrapped into the plan window
   *  so a stagger never pushes a beam outside its own frequency schedule. */
  const scanSecondsAt = (elapsed: number) => {
    // The beam target is ALWAYS the point of this satellite's own real ground
    // track BEAM_LEAD_SECONDS ahead of where the satellite currently is. That
    // keeps the beam slanted forward AND makes the scan progress line up 1:1
    // with the swath bands: at the moment the target reaches
    // `missionStartSeconds` the beam is exactly on the START of band 0.
    return elapsed + BEAM_LEAD_SECONDS + scanOffsetSeconds;
  };

  // ── Real position at the current mission clock time ──
  const position = new Cesium.CallbackPositionProperty(
    (time) => {
      const elapsed = elapsedAt(time as Cesium.JulianDate);
      const sp = subpointAt(tle, new Date(captureTime.getTime() + elapsed * 1000));
      return sp ? subpointCartesian(sp, sp.heightM) : undefined;
    },
    false,
    Cesium.ReferenceFrame.FIXED,
  );

 viewer.entities.add({
    id: `${prefix}sat-body`,
    position,
    billboard: {
      image: SATELLITE_ICON_URL,
      width: 130,
      height: 130,
      verticalOrigin: Cesium.VerticalOrigin.CENTER,
      horizontalOrigin: Cesium.HorizontalOrigin.CENTER,
      disableDepthTestDistance: 0,
    },
    
    label: {
      text: tle.name,
      font: isPrimary ? "12px monospace" : "11px monospace",
      fillColor: isPrimary ? Cesium.Color.WHITE : Cesium.Color.fromCssColorString(accentColor),
      pixelOffset: new Cesium.Cartesian2(0, isPrimary ? -60 : -34),
      showBackground: true,
      backgroundColor: Cesium.Color.fromCssColorString("#0b1622").withAlpha(0.6),
      disableDepthTestDistance: 0,
    },
  });

  // ── Nadir reference line (primary only — the beam never points here) ──
  if (isPrimary) {
    viewer.entities.add({
      id: `${prefix}nadir-line`,
      polyline: {
        positions: new Cesium.CallbackProperty((time) => {
          const sat = position.getValue(time as Cesium.JulianDate);
          if (!sat) return [];
          const carto = Cesium.Cartographic.fromCartesian(sat);
          return [sat, Cesium.Cartesian3.fromRadians(carto.longitude, carto.latitude, 0)];
        }, false),
        width: 2,
        material: new Cesium.PolylineDashMaterialProperty({
          color: Cesium.Color.fromCssColorString("#c8e1ff").withAlpha(0.35),
          dashLength: 8,
        }),
      },
    });
  }

   // ── Beam frame: real position + real forward-looking target ──
  // Cached per mission-elapsed-second value: beamFrame is read by SIX
  // separate CallbackProperty callbacks every frame (beam-cone hierarchy +
  // material, both beam edges, footprint hierarchy + material). Without
  // caching, each of those six recomputed the full beam geometry from
  // scratch — six TLE propagations' worth of work, six times over, every
  // frame, for every satellite. That redundant work was the actual cause
  // of the stutter/flicker — caching the result for the current frame's
  // elapsed time means it's computed once and reused by all six.
  let cachedBeamElapsed: number | null = null;
  let cachedBeamFrame: {
    apexLeft: Cesium.Cartesian3;
    apexRight: Cesium.Cartesian3;
    left: Cesium.Cartesian3;
    right: Cesium.Cartesian3;
    preset: (typeof FREQUENCY_PRESETS)[FrequencyPresetId];
    index: number;
    targetSeconds: number;
  } | null = null;

  const beamFrame = (time: Cesium.JulianDate) => {
    const elapsed = elapsedAt(time);
    if (cachedBeamElapsed === elapsed) return cachedBeamFrame;

    const targetSeconds = scanSecondsAt(elapsed);
    // Target sits on the satellite's REAL propagated track, BEAM_LEAD_SECONDS
    // ahead of its current position — identical geometry to the ground track
    // and the swath bands, so nothing drifts apart.
    const targetDate = new Date(captureTime.getTime() + targetSeconds * 1000);
    const satDate = new Date(captureTime.getTime() + elapsed * 1000);

    const satSub = subpointAt(tle, satDate);
    const targetSub = subpointAt(tle, targetDate);
    if (!satSub || !targetSub) {
      cachedBeamElapsed = elapsed;
      cachedBeamFrame = null;
      return null;
    }

    const satPoint = subpointCartesian(satSub, satSub.heightM);
    const satHeading = headingRadAt(tle, satDate);
    const apexLeft = offsetPointMeters(
      satPoint,
      satHeading - Math.PI / 2,
      BEAM_APEX_HALF_WIDTH_METERS,
    );
    const apexRight = offsetPointMeters(
      satPoint,
      satHeading + Math.PI / 2,
      BEAM_APEX_HALF_WIDTH_METERS,
    );

    const targetPoint = subpointCartesian(targetSub, 0);
    const targetHeading = headingRadAt(tle, targetDate);
    const index = getActiveIndex(segments, targetSeconds);
    const preset = FREQUENCY_PRESETS[segments[index].presetId];
    const half = swathHalfMetersAt(segments, targetSeconds);
    const left = offsetPointMeters(targetPoint, targetHeading - Math.PI / 2, half);
    const right = offsetPointMeters(targetPoint, targetHeading + Math.PI / 2, half);

    cachedBeamElapsed = elapsed;
    cachedBeamFrame = { apexLeft, apexRight, left, right, preset, index, targetSeconds };
    return cachedBeamFrame;
  };

  viewer.entities.add({
    id: `${prefix}beam-cone`,
    polygon: {
      hierarchy: new Cesium.CallbackProperty((time) => {
        const f = beamFrame(time as Cesium.JulianDate);
        if (!f) return new Cesium.PolygonHierarchy([]);
        return new Cesium.PolygonHierarchy([f.apexLeft, f.left, f.right, f.apexRight]);
      }, false),
      material: new Cesium.ColorMaterialProperty(
        new Cesium.CallbackProperty((time) => {
          const f = beamFrame(time as Cesium.JulianDate);
          if (!f) return Cesium.Color.WHITE.withAlpha(0);
          return Cesium.Color.fromCssColorString(f.preset.color).withAlpha(alpha(0.3));
        }, false),
      ),
      perPositionHeight: true,
      outline: false,
    },
  });

  (["left", "right"] as const).forEach((side) => {
    viewer.entities.add({
      id: `${prefix}beam-edge-${side}`,
      polyline: {
        positions: new Cesium.CallbackProperty((time) => {
          const f = beamFrame(time as Cesium.JulianDate);
          if (!f) return [];
          return side === "left" ? [f.apexLeft, f.left] : [f.apexRight, f.right];
        }, false),
        width: 2,
        material: new Cesium.PolylineDashMaterialProperty({
          color: Cesium.Color.fromCssColorString(isPrimary ? "#5fd4ff" : accentColor).withAlpha(
            alpha(0.7),
          ),
          dashLength: 8,
        }),
      },
    });
  });

  // ── Bright pulsing footprint slice, following the REAL curved track ──
  viewer.entities.add({
    id: `${prefix}footprint`,
    polygon: {
      hierarchy: new Cesium.CallbackProperty((time) => {
        const f = beamFrame(time as Cesium.JulianDate);
        if (!f) return new Cesium.PolygonHierarchy([]);
        const centerReal = f.targetSeconds;
        const ring = buildSwathRing(
          tle,
          captureTime,
          centerReal - FOOTPRINT_HALF_WINDOW_SECONDS,
          centerReal + FOOTPRINT_HALF_WINDOW_SECONDS,
          () => swathHalfMetersAt(segments, f.targetSeconds),
          isPrimary ? 2 : 4,
        );
        return new Cesium.PolygonHierarchy(ring);
      }, false),
      material: new Cesium.ColorMaterialProperty(
        new Cesium.CallbackProperty((time) => {
          const f = beamFrame(time as Cesium.JulianDate);
          if (!f) return Cesium.Color.WHITE.withAlpha(0);
          const secs = elapsedAt(time as Cesium.JulianDate);
          const pulse = 0.82 + 0.18 * Math.sin(secs / 1.2);
          return Cesium.Color.fromCssColorString(f.preset.color).withAlpha(alpha(0.55 * pulse));
        }, false),
      ),
      outline: true,
      outlineColor: Cesium.Color.WHITE.withAlpha(alpha(0.7)),
      perPositionHeight: true,
    },
  });

  // ── Dashed full ground track (real orbit) ──
  // The drawn track is padded by the SAME margin before and after the animated
  // window, so the scanned section always sits in the MIDDLE of the visible
  // ground track. Sampling uses exactly the same TLE propagation as the
  // satellite marker and the swath bands.
  const trackPadSeconds = TRACK_MARGIN_SECONDS;
  const trackPositions = sampleTrackPositions(
    tle,
    captureTime,
    missionStartSeconds - trackPadSeconds,
    missionEndSeconds + trackPadSeconds,
    isPrimary ? SWATH_SAMPLE_STEP_SECONDS : OTHER_TRACK_SAMPLE_STEP_SECONDS,
  );
  /** Track limited to the mission window — used for camera framing so the
   *  initial zoom/angle matches the previous behaviour. */
  const missionTrackPositions = sampleTrackPositions(
    tle,
    captureTime,
    missionStartSeconds,
    missionEndSeconds,
    isPrimary ? SWATH_SAMPLE_STEP_SECONDS : OTHER_TRACK_SAMPLE_STEP_SECONDS,
  );

  viewer.entities.add({
    id: `${prefix}ground-track`,
    polyline: {
      positions: trackPositions,
      width: isPrimary ? 3 : 2.5,
      material: new Cesium.PolylineGlowMaterialProperty({
        glowPower: 0.25,
        color: Cesium.Color.fromCssColorString(accentColor).withAlpha(
          isPrimary ? 1.0 : 0.75,
        ),
      }),
      clampToGround: true,
    },
  });

  // ── Static frequency bands (fixed width, real curved ground track) ──
  segments.forEach((seg, i) => {
    const preset = FREQUENCY_PRESETS[seg.presetId];
    const halfM = (preset.swathKm * 1000) / 2;
    const segStart = seg.startSeconds;
    const segEnd = seg.startSeconds + seg.durationSeconds;

    const baseColor = Cesium.Color.fromCssColorString(preset.color);
    const darkFill = Cesium.Color.multiplyByScalar(baseColor, 0.55, new Cesium.Color()).withAlpha(
      alpha(0.75),
    );
    const glowOutline = Cesium.Color.multiplyByScalar(baseColor, 1.3, new Cesium.Color()).withAlpha(
      alpha(1),
    );
    const coveredFill = Cesium.Color.multiplyByScalar(baseColor, 1.15, new Cesium.Color()).withAlpha(
      alpha(0.6),
    );

    const fullRing = buildSwathRing(tle, captureTime, segStart, segEnd, () => halfM, swathStep);

    viewer.entities.add({
      id: `${prefix}band-glow-${i}`,
      polygon: {
        hierarchy: new Cesium.PolygonHierarchy(fullRing),
        material: baseColor.withAlpha(alpha(0.18)),
        height: 0,
      },
    });

    viewer.entities.add({
      id: `${prefix}band-${i}`,
      polygon: {
        hierarchy: new Cesium.PolygonHierarchy(fullRing),
        material: darkFill,
        outline: true,
        outlineColor: glowOutline,
        outlineWidth: isPrimary ? 4 : 2,
        height: 0,
      },
    });

    // Progressive coverage fill is per-frame polygon rebuilding, so it stays
    // on the primary only — a whole constellation of these would tank FPS.
       if (isPrimary) {
      viewer.entities.add({
        id: `${prefix}band-covered-${i}`,
        polygon: {
          hierarchy: new Cesium.CallbackProperty((time) => {
            const target = scanSecondsAt(elapsedAt(time as Cesium.JulianDate));
            const coveredEnd = Math.min(Math.max(target, segStart), segEnd);
            if (coveredEnd <= segStart) return new Cesium.PolygonHierarchy([]);
            const ring = buildSwathRing(
              tle,
              captureTime,
              segStart,
              coveredEnd,
              () => halfM,
              swathStep,
            );
            return new Cesium.PolygonHierarchy(ring);
          }, false),
          material: coveredFill,
          perPositionHeight: true,
        },
      });
    }
  });

  return { scanSecondsAt, trackPositions, missionTrackPositions };
}

// ─── Main entry point ───────────────────────────────────────────────────

export function visualizeFrequencyPlan(
  viewer: Cesium.Viewer,
  segments: FrequencySegment[],
  options: FrequencyVisualizationOptions,
  callbacks?: FrequencyVisualizationCallbacks,
) {
  if (viewer.isDestroyed() || segments.length === 0) return;

  clearFrequencyVisualization(viewer);
  // Only the animation's own satellite icons should be visible.
  hidePlanningEntities(viewer);

  const {
    primaryTle,
    captureTime,
    otherSatellites = [],
    segmentsBySatelliteName = {},
  } = options;

  const sortPlan = (plan: FrequencySegment[]) =>
    [...plan].sort((a, b) => a.startSeconds - b.startSeconds);

  const ordered = sortPlan(segments);
  const planFor = (tle: TleEntry) => {
    const custom = segmentsBySatelliteName[tle.name];
    return custom && custom.length > 0 ? sortPlan(custom) : ordered;
  };

  const missionStartSeconds = ordered[0].startSeconds;
  const missionEndSeconds = ordered.reduce(
    (max, s) => Math.max(max, s.startSeconds + s.durationSeconds),
    0,
  );
  if (missionEndSeconds <= missionStartSeconds) return;

  // ── Clock: real UTC time, anchored to the SELECTED capture time ──
  const captureJulian = Cesium.JulianDate.fromDate(captureTime);
  const elapsedAt = (time: Cesium.JulianDate) =>
    Cesium.JulianDate.secondsDifference(time, captureJulian);

  // Satellite-time window. The satellite enters BEAM_LEAD_SECONDS + pre-roll
  // BEFORE the first band so that, when scanning begins, its beam is already
  // inclined and lands on the very start of the first swath.
  const clockStartTime = Cesium.JulianDate.addSeconds(
    captureJulian,
    missionStartSeconds - BEAM_LEAD_SECONDS - MISSION_PRE_ROLL_SECONDS,
    new Cesium.JulianDate(),
  );
  const stopTime = Cesium.JulianDate.addSeconds(
    captureJulian,
    missionEndSeconds - BEAM_LEAD_SECONDS + TAIL_OUT_SECONDS,
    new Cesium.JulianDate(),
  );

  viewer.clock.startTime = clockStartTime.clone();
  viewer.clock.stopTime = stopTime.clone();
  viewer.clock.currentTime = clockStartTime.clone();
  viewer.clock.clockRange = Cesium.ClockRange.LOOP_STOP;
  viewer.clock.multiplier = CLOCK_MULTIPLIER;
  viewer.clock.shouldAnimate = true;

  // ── Primary satellite: full visualization + labels + coverage fill ──
  const primary = addSatelliteVisualization(viewer, {
    tle: primaryTle,
    segments: ordered,
    captureTime,
    idKey: "primary",
    scanOffsetSeconds: 0,
    accentColor: primaryTle.color ?? "#ffffff",
    isPrimary: true,
    elapsedAt,
    missionStartSeconds,
    missionEndSeconds,
  });

  // ── The rest of the constellation: SAME swath/frequency/beam animation ──
  otherSatellites
    .filter((tle) => tle.name !== primaryTle.name)
    .forEach((tle, i) => {
      addSatelliteVisualization(viewer, {
        tle,
        segments: planFor(tle),
        captureTime,
        idKey: `other-${i}`,
        scanOffsetSeconds: (i + 1) * SCAN_STAGGER_SECONDS,
        accentColor: tle.color ?? fallbackColorForName(tle.name, OTHER_SAT_FALLBACK_COLORS),
        isPrimary: false,
        elapsedAt,
        missionStartSeconds,
        missionEndSeconds,
      });
    });

  // ── Readout + legend UNDER the globe; panel and beam read the SAME target ──
  const span = missionEndSeconds - missionStartSeconds;
  const panel = mountFrequencyPanel(viewer, {
    overlayClass: OVERLAY_CLASS,
    title: `Orbit reference · ${primaryTle.name} · from ${captureTime.toISOString().slice(11, 19)} UTC`,
    segments: ordered,
    satellites: [primaryTle, ...otherSatellites.filter((t) => t.name !== primaryTle.name)].map((t) => ({
      name: t.name,
      color: t.color ?? fallbackColorForName(t.name, OTHER_SAT_FALLBACK_COLORS),
    })),
  });
  mountBackToGlobeButton(viewer, OVERLAY_CLASS, () => {
    clearFrequencyVisualization(viewer);
    callbacks?.onBack?.();
  });

  const syncPanel = () => {
    const target = primary.scanSecondsAt(elapsedAt(viewer.clock.currentTime));
    panel.update({
      activeIndex: getActiveIndex(ordered, target),
      playheadPct: ((target - missionStartSeconds) / span) * 100,
      utc: Cesium.JulianDate.toDate(viewer.clock.currentTime),
      elapsedSec: Math.min(span, Math.max(0, target - missionStartSeconds)),
      totalSec: span,
      paused: isVizPaused(),
    });
  };
  clockTickListener = viewer.clock.onTick.addEventListener(() => {
    viewer.scene.requestRender();
    syncPanel();
  });
  syncPanel();
  vizStarted("orbit");

  // ── Camera: framed on the PRIMARY satellite's track + swath only.
  //    Every other satellite is fully rendered (beam, footprint, bands) and
  //    becomes visible as soon as the user pans/rotates the globe away. ──
  const swathCorners = ordered.flatMap((seg) => {
    const halfM = (FREQUENCY_PRESETS[seg.presetId].swathKm * 1000) / 2;
    return buildSwathRing(
      primaryTle,
      captureTime,
      seg.startSeconds,
      seg.startSeconds + seg.durationSeconds,
      () => halfM,
    );
  });

  const boundingSphere = Cesium.BoundingSphere.fromPoints([
    ...primary.missionTrackPositions,
    ...swathCorners,
  ]);

  viewer.camera.flyToBoundingSphere(boundingSphere, {
    offset: new Cesium.HeadingPitchRange(
      Cesium.Math.toRadians(-22),
      Cesium.Math.toRadians(-38),
      boundingSphere.radius * 2.4,
    ),
    duration: 2.2,
    complete: () => viewer.scene.requestRender(),
  });
}
