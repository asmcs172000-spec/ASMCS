// Uplink TDOA Geolocation Accuracy Estimator 

import * as satellite from "satellite.js";
import type { RectangleBounds } from "./useTargetPicker";
import type { TleEntry } from "./SpotModeRange";

// ─────────────────────────────────────────────────────────────────────────────
// Public types
// ─────────────────────────────────────────────────────────────────────────────

export type AccuracySample = {
  lat: number;
  lon: number;
  south: number;
  north: number;
  west: number;
  east: number;
  accuracyMeters: number | null;
  visibleSatellites: number;
  computed: boolean;
  satelliteGeometry?: CellSatelliteGeometry[];
  passIndex: number;
  passLabel: string;
};

export type CellSatelliteGeometry = {
  satelliteName: string;
  slantRangeKm: number | null;
  elevationDeg: number | null;
  /** Per-satellite range uncertainty in metres (used in the TDOA normal matrix). */
  uncertaintyMps: number | null;
  tdoaPairsUsed: number;
  usedInSolution: boolean;
  exclusionReason: string | null;
};

// ─────────────────────────────────────────────────────────────────────────────
// Configuration constants
// ─────────────────────────────────────────────────────────────────────────────

export const ACCURACY_STEP_MIN_KM = 5;
export const ACCURACY_STEP_MAX_KM = 100;
export const ACCURACY_STEP_DEFAULT_KM = 25;

// Minimum elevation for a satellite to be included in the solution.
export const MIN_ELEVATION_DEG = 5;

// Maximum slant range for a satellite to be included.
export const MAX_SLANT_RANGE_KM = 1800;

// Per-satellite range-equivalent measurement precision, expressed in metres.
// It encodes the combined effect of timing jitter, clock stability, and SNR.
//
//   1 metre of range error  ←→  ~3.34 ns of timing error  (c ≈ 3e8 m/s)
//
// The default of 30 m corresponds to ~100 ns of timing precision, which is
// representative of a moderate-SNR uplink with a stable oscillator.
export const SIGMA_RANGE_M = 30;

// Grid sample cap, to keep the computation interactive.
const MAX_SAMPLES = 4096;

// Earth constants
const EARTH_RADIUS_KM = 6371.0088;
const EARTH_ROTATION_RAD_PER_SEC = 7.2921159e-5;

// Set true to log per-pass diagnostic info to the browser console.
export const ACCURACY_DEBUG = true;

// ─────────────────────────────────────────────────────────────────────────────
// Internal types and vector helpers
// ─────────────────────────────────────────────────────────────────────────────

type Ecf = { x: number; y: number; z: number };

type SatelliteState = {
  name: string;
  pos: Ecf; // ECF position (km)
};

/**
 * Pre-parsed satellite record. Created once per TLE set and reused for every
 * animation frame — `twoline2satrec` is the expensive part of propagation and
 * must not be called per frame.
 */
type PreparedSatellite = {
  name: string;
  satrec: satellite.SatRec;
};

type OrbitWindow = { aos: Date; los: Date; label?: string };

const dot = (a: Ecf, b: Ecf) => a.x * b.x + a.y * b.y + a.z * b.z;
const sub = (a: Ecf, b: Ecf): Ecf => ({ x: a.x - b.x, y: a.y - b.y, z: a.z - b.z });
const scale = (a: Ecf, s: number): Ecf => ({ x: a.x * s, y: a.y * s, z: a.z * s });
const norm = (a: Ecf) => Math.sqrt(dot(a, a));

// ─────────────────────────────────────────────────────────────────────────────
// 2×2 linear algebra (the TDOA + surface solver is 2-dimensional)
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Invert a 2×2 matrix with a **relative** singularity check.
 */
function invert2x2(m: number[][]): number[][] | null {
  const a = m[0][0];
  const b = m[0][1];
  const c = m[1][0];
  const d = m[1][1];
  const det = a * d - b * c;
  if (!Number.isFinite(det)) return null;

  const maxAbs = Math.max(
    Math.abs(a), Math.abs(b), Math.abs(c), Math.abs(d),
    1e-30,
  );
  if (Math.abs(det) < 1e-12 * maxAbs * maxAbs) return null;

  return [
    [ d / det, -b / det],
    [-c / det,  a / det],
  ];
}

// ─────────────────────────────────────────────────────────────────────────────
// Coordinate frame helpers
// ─────────────────────────────────────────────────────────────────────────────

/** Geodetic (lat, lon, 0) → ECF position in km. */
function targetEcf(latDeg: number, lonDeg: number): Ecf {
  const lat = satellite.degreesToRadians(latDeg);
  const lon = satellite.degreesToRadians(lonDeg);
  const ecf = satellite.geodeticToEcf({ latitude: lat, longitude: lon, height: 0 });
  return { x: ecf.x, y: ecf.y, z: ecf.z };
}

/**
 * Local East-North-Up unit basis at a target point, expressed in ECF.
 */
function enuBasis(latDeg: number, lonDeg: number) {
  const lat = satellite.degreesToRadians(latDeg);
  const lon = satellite.degreesToRadians(lonDeg);
  return {
    east:  { x: -Math.sin(lon), y: Math.cos(lon), z: 0 },
    north: {
      x: -Math.sin(lat) * Math.cos(lon),
      y: -Math.sin(lat) * Math.sin(lon),
      z: Math.cos(lat),
    },
    up: {
      x: Math.cos(lat) * Math.cos(lon),
      y: Math.cos(lat) * Math.sin(lon),
      z: Math.sin(lat),
    },
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// TLE preparation — called ONCE per TLE set
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Parse every TLE into a satrec exactly once. The returned array is reused
 * for every propagation call (per animation frame, per grid scan, etc).
 */
export function prepareTles(tles: TleEntry[]): PreparedSatellite[] {
  const prepared: PreparedSatellite[] = [];
  for (const tle of tles) {
    try {
      const satrec = satellite.twoline2satrec(tle.tle1, tle.tle2);
      prepared.push({ name: tle.name, satrec });
    } catch (error) {
      if (ACCURACY_DEBUG) {
        console.warn(`[uplink] failed to parse TLE for ${tle.name}`, error);
      }
    }
  }
  return prepared;
}

// ─────────────────────────────────────────────────────────────────────────────
// SGP4 propagation → ECF position
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Propagate every prepared satellite to `time` and return ECF position (km).
 */
function propagatePrepared(
  prepared: PreparedSatellite[],
  time: Date,
  diagnosticLabel = "propagation",
): SatelliteState[] {
  const gmst = satellite.gstime(time);
  const states: SatelliteState[] = [];

  for (const entry of prepared) {
    const p = satellite.propagate(entry.satrec, time);

    if (!p?.position || typeof p.position === "boolean") {
      if (ACCURACY_DEBUG) {
        console.warn(`[uplink] ${entry.name}: SGP4 returned no position`);
      }
      continue;
    }
  
    const posEcfRaw = satellite.eciToEcf(p.position, gmst);
    const posEcfVec: Ecf = { x: posEcfRaw.x, y: posEcfRaw.y, z: posEcfRaw.z };

    states.push({ name: entry.name, pos: posEcfVec});
  }

  if (ACCURACY_DEBUG) {
    console.debug(
      `[uplink] ${diagnosticLabel}: ${states.length}/${prepared.length} propagated at ${time.toISOString()}`,
    );
  }
  return states;
}

// ─────────────────────────────────────────────────────────────────────────────
// Per-satellite TDOA geometry
// ─────────────────────────────────────────────────────────────────────────────

type SatTdoaGeom = {
  /** Horizontal (E, N) Jacobian row of range w.r.t. the emitter's ECF position. */
  enuHoriz: [number, number];
  /** Full 3D unit vector from satellite to emitter — kept for diagnostics. */
  enu: [number, number, number];
  rangeKm: number;
  elevationDeg: number;
  exclusionReason: string | null;
};

/**
 * Compute the TDOA geometry vector for one satellite relative to one target
 * point, projected into the local ENU frame.
 *
 * Physics:
 *   ρ = |r_emitter − r_sat|                         [slant range]
 *   ∂ρ/∂r_emitter = (r_emitter − r_sat) / ρ = û    [unit vector, sat → emitter]
 *
 * The Jacobian of a TDOA observable Δρ_ij = ρ_i − ρ_j w.r.t. the emitter
 * position is (û_i − û_j). Projected into the local ENU frame, and then
 * restricted to the horizontal (E, N) plane by the Earth-surface constraint,
 * each satellite contributes a 2-vector (û_E, û_N).
 *
 * The vertical component û_U is discarded — the surface constraint absorbs it.
 * This is the standard "constrained TDOA" formulation for ground emitters.
 *
 * Sign is arbitrary — the normal matrix uses (gᵢ − ḡ)(gᵢ − ḡ)ᵀ.
 */
function satelliteTdoaGeometry(
  state: SatelliteState,
  targetPos: Ecf,
  basis: ReturnType<typeof enuBasis>,
): SatTdoaGeom {
  const delta = sub(state.pos, targetPos);
  const rangeKm = norm(delta);

  if (!Number.isFinite(rangeKm) || rangeKm <= 1e-9) {
    return {
      enuHoriz: [0, 0],
      enu: [0, 0, 0],
      rangeKm: 0,
      elevationDeg: 0,
      exclusionReason: "Invalid slant range",
    };
  }

  const invRange = 1 / rangeKm;
  const u: Ecf = scale(delta, invRange);

  // Elevation above local horizon
  const sinElev = dot(u, basis.up);
  const elevationDeg = satellite.radiansToDegrees(
    Math.asin(Math.max(-1, Math.min(1, sinElev))),
  );

  // Visibility filters
  if (rangeKm > MAX_SLANT_RANGE_KM) {
    return {
      enuHoriz: [0, 0],
      enu: [0, 0, 0],
      rangeKm,
      elevationDeg,
      exclusionReason: `Slant range exceeds ${MAX_SLANT_RANGE_KM} km limit`,
    };
  }
  if (elevationDeg < MIN_ELEVATION_DEG) {
    return {
      enuHoriz: [0, 0],
      enu: [0, 0, 0],
      rangeKm,
      elevationDeg,
      exclusionReason: `Elevation below ${MIN_ELEVATION_DEG}° minimum`,
    };
  }

  // Unit vector from satellite to emitter, expressed in ECF. 
  const enuFull: [number, number, number] = [
    dot(u, basis.east),
    dot(u, basis.north),
    dot(u, basis.up),
  ];

  // Horizontal component only — the surface constraint has eliminated U.
  const enuHoriz: [number, number] = [enuFull[0], enuFull[1]];

  return {
    enuHoriz,
    enu: enuFull,
    rangeKm,
    elevationDeg,
    exclusionReason: null,
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// Rigorous TDOA normal matrix (2×2, horizontal)
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Build the exact 2×2 GLS normal matrix for the TDOA measurement set formed
 * by referencing satellite 1, with the Earth-surface constraint applied.
 */
function buildTdoaNormalMatrix2D(
  geometryVectorsEnuHoriz: [number, number][],
): number[][] {
  const n = geometryVectorsEnuHoriz.length;
  if (n < 3) {
    return [[0, 0], [0, 0]];
  }

  // Mean horizontal geometry vector h̄
  let mx = 0;
  let my = 0;
  for (const h of geometryVectorsEnuHoriz) {
    mx += h[0];
    my += h[1];
  }
  mx /= n;
  my /= n;

  // N = (1/σ²) Σᵢ (hᵢ − h̄)(hᵢ − h̄)ᵀ
  const invVar = 1 / (SIGMA_RANGE_M * SIGMA_RANGE_M);
  const N = [[0, 0], [0, 0]];
  for (const h of geometryVectorsEnuHoriz) {
    const cx = h[0] - mx;
    const cy = h[1] - my;
    N[0][0] += cx * cx * invVar;
    N[0][1] += cx * cy * invVar;
    N[1][1] += cy * cy * invVar;
  }
  // Symmetric off-diagonal
  N[1][0] = N[0][1];

  return N;
}

// ─────────────────────────────────────────────────────────────────────────────
// Core estimator: accuracy at one point
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Estimate horizontal geolocation accuracy at a single target point given a
 * set of propagated satellite states.
 *
 * Pipeline:
 *   1. Build the target's ECF position, and ENU basis.
 *   2. For each satellite, compute its horizontal ENU TDOA geometry vector
 *      and apply visibility filters (elevation, slant range).
 *   3. If ≥ 3 satellites survive, build the rigorous 2×2 TDOA normal matrix
 *      and invert it.
 *   4. Extract DRMS = √(C_ee + C_nn) from the 2×2 covariance.
 *
 * When the solve is singular (all horizontal geometry vectors collinear),
 * we return a large sentinel accuracy AND mark every accepted satellite as
 * unused, so the UI does not show a "used" satellite for a failed solve.
 */
function estimateAtPointUplink(
  latDeg: number,
  lonDeg: number,
  states: SatelliteState[],
): {
  accuracyMeters: number | null;
  visibleSatellites: number;
  satelliteGeometry: CellSatelliteGeometry[];
} {
  const targetPos = targetEcf(latDeg, lonDeg);
  const basis = enuBasis(latDeg, lonDeg);

  const acceptedHoriz: [number, number][] = [];
  const diagnostics: CellSatelliteGeometry[] = [];

  // ── Per-satellite evaluation ──
  for (const state of states) {
    const geom = satelliteTdoaGeometry(state, targetPos, basis);

    if (geom.exclusionReason) {
      diagnostics.push({
        satelliteName: state.name,
        slantRangeKm: geom.rangeKm,
        elevationDeg: geom.elevationDeg,
        uncertaintyMps: null,
        tdoaPairsUsed: 0,
        usedInSolution: false,
        exclusionReason: geom.exclusionReason,
      });
      continue;
    }

    acceptedHoriz.push(geom.enuHoriz);
    diagnostics.push({
      satelliteName: state.name,
      slantRangeKm: geom.rangeKm,
      elevationDeg: geom.elevationDeg,
      uncertaintyMps: SIGMA_RANGE_M,
      tdoaPairsUsed: 0, // filled in after we know the count
      usedInSolution: true,
      exclusionReason: null,
    });
  }

  const visibleSatellites = acceptedHoriz.length;

  // ── Solvability check ──
  // With the Earth-surface constraint, the unknowns are (lat, lon) = 2D, and
  // N satellites give N − 1 independent TDOA equations. N = 3 gives exactly
  // 2 equations for 2 unknowns: solvable when the horizontal geometry is
  // non-degenerate. N ≥ 4 gives an over-determined system (preferred).
  if (visibleSatellites < 3) {
    return { accuracyMeters: null, visibleSatellites, satelliteGeometry: diagnostics };
  }

  // ── Build the rigorous 2×2 TDOA normal matrix ──
  const N = buildTdoaNormalMatrix2D(acceptedHoriz);

  // ── Invert and extract DRMS ──
  const covariance = invert2x2(N);
  if (!covariance) {
    // Singular horizontal geometry (all geometry vectors collinear, e.g.
    // all satellites on the same orbital ground track through the target).
    // Mark accepted satellites as unused so the UI reflects the failure.
    for (const d of diagnostics) {
      if (d.usedInSolution) {
        d.usedInSolution = false;
        d.exclusionReason = "Singular horizontal TDOA geometry";
      }
    }
    return {
      accuracyMeters: 999_999,
      visibleSatellites,
      satelliteGeometry: diagnostics,
    };
  }

  // Annotate diagnostics: each accepted satellite participates in N−1 pairs.
  for (const d of diagnostics) {
    if (d.usedInSolution) {
      d.tdoaPairsUsed = visibleSatellites - 1;
    }
  }

  // DRMS is the trace of the 2×2 horizontal covariance.
  const horizontalVariance =
    Math.max(0, covariance[0][0]) + Math.max(0, covariance[1][1]);
  const accuracyMeters = Math.min(Math.sqrt(horizontalVariance), 999_999);

  if (!Number.isFinite(accuracyMeters)) {
    return { accuracyMeters: null, visibleSatellites, satelliteGeometry: diagnostics };
  }
  return { accuracyMeters, visibleSatellites, satelliteGeometry: diagnostics };
}

// ─────────────────────────────────────────────────────────────────────────────
// Grid generation
// ─────────────────────────────────────────────────────────────────────────────

/** Subdivide the rectangle into cells sized to the requested step. */
export function createAccuracyGrid(
  bounds: RectangleBounds,
  stepKm: number,
): AccuracySample[] {
  const southBound = Math.max(-90, Math.min(bounds.south, bounds.north));
  const northBound = Math.min(90, Math.max(bounds.south, bounds.north));
  const westBound = Math.max(-180, Math.min(bounds.west, bounds.east));
  const eastBound = Math.min(180, Math.max(bounds.west, bounds.east));
  const midLat = (southBound + northBound) / 2;
  const gridStepKm = effectiveAccuracyStepKm(bounds, stepKm);
  const latStep = gridStepKm / 111.32;
  const lonStep =
    gridStepKm / (111.32 * Math.max(Math.cos((midLat * Math.PI) / 180), 0.05));
  const rowCount = Math.max(1, Math.ceil((northBound - southBound) / latStep));
  const columnCount = Math.max(1, Math.ceil((eastBound - westBound) / lonStep));
  const samples: AccuracySample[] = [];

  for (let row = 0; row < rowCount; row++) {
    const south = southBound + row * latStep;
    const north = Math.min(northBound, south + latStep);
    const centerLat = (south + north) / 2;
    for (let column = 0; column < columnCount; column++) {
      const west = westBound + column * lonStep;
      const east = Math.min(eastBound, west + lonStep);
      const centerLon = (west + east) / 2;
      samples.push({
        lat: centerLat,
        lon: centerLon,
        south,
        north,
        west,
        east,
        accuracyMeters: null,
        visibleSatellites: 0,
        computed: false,
        passIndex: -1,
        passLabel: "",
      });
    }
  }
  return samples;
}

/** Square, target-centred footprint used by point-mode swath estimates. */
export function accuracySwathBounds(
  lat: number,
  lon: number,
  swathKm: number,
): RectangleBounds {
  const halfLat = swathKm / (2 * 111.32);
  const halfLon = swathKm / (2 * 111.32 * Math.max(Math.cos((lat * Math.PI) / 180), 0.05));
  return {
    south: Math.max(-90, lat - halfLat),
    north: Math.min(90, lat + halfLat),
    west: Math.max(-180, lon - halfLon),
    east: Math.min(180, lon + halfLon),
  };
}

/** Create one sample at the exact target coordinate for point-target estimates. */
export function createAccuracyPointGrid(
  lat: number,
  lon: number,
): AccuracySample[] {
  const halfLat = 0.5 / 111.32;
  const halfLon = 0.5 / (111.32 * Math.max(Math.cos((lat * Math.PI) / 180), 0.05));
  return [{
    lat,
    lon,
    south: Math.max(-90, lat - halfLat),
    north: Math.min(90, lat + halfLat),
    west: Math.max(-180, lon - halfLon),
    east: Math.min(180, lon + halfLon),
    accuracyMeters: null,
    visibleSatellites: 0,
    computed: false,
    passIndex: -1,
    passLabel: "",
  }];
}

/**
 * Coarsen the grid spacing if the raw step would exceed MAX_SAMPLES cells,
 * so the computation stays interactive without truncating the rectangle.
 */
export function effectiveAccuracyStepKm(
  bounds: RectangleBounds,
  stepKm: number,
): number {
  const southBound = Math.max(-90, Math.min(bounds.south, bounds.north));
  const northBound = Math.min(90, Math.max(bounds.south, bounds.north));
  const westBound = Math.max(-180, Math.min(bounds.west, bounds.east));
  const eastBound = Math.min(180, Math.max(bounds.west, bounds.east));
  const midLat = (southBound + northBound) / 2;
  const cosLat = Math.max(Math.cos((midLat * Math.PI) / 180), 0.05);
  let effectiveStepKm = Math.max(
    ACCURACY_STEP_MIN_KM,
    Math.min(stepKm, ACCURACY_STEP_MAX_KM),
  );

  for (let attempt = 0; attempt < 8; attempt++) {
    const rows = Math.max(
      1,
      Math.ceil(((northBound - southBound) * 111.32) / effectiveStepKm),
    );
    const columns = Math.max(
      1,
      Math.ceil(((eastBound - westBound) * 111.32 * cosLat) / effectiveStepKm),
    );
    const sampleCount = rows * columns;
    if (sampleCount <= MAX_SAMPLES) break;
    effectiveStepKm *= Math.sqrt(sampleCount / MAX_SAMPLES) * 1.01;
  }
  return effectiveStepKm;
}

// ─────────────────────────────────────────────────────────────────────────────
// Visualization helpers
// ─────────────────────────────────────────────────────────────────────────────

export const ACCURACY_COLOR_LEGEND = [
  { color: "#22c55e", label: "≤ 10 km", maxRoundedKm: 10 },
  { color: "#eab308", label: "11–30 km", maxRoundedKm: 30 },
  { color: "#f97316", label: "31–70 km", maxRoundedKm: 70 },
  { color: "#ef4444", label: "> 71 km", maxRoundedKm: Infinity },
  { color: "#64748b", label: "No solution", maxRoundedKm: null },
] as const;

export function accuracyColor(accuracyMeters: number | null): string {
  if (
    accuracyMeters === null ||
    !Number.isFinite(accuracyMeters) ||
    accuracyMeters >= 999_999
  ) {
    return ACCURACY_COLOR_LEGEND[4].color;
  }
  const accuracyKm = Math.round(accuracyMeters / 1000);
  return (
    ACCURACY_COLOR_LEGEND.find(
      (band) => band.maxRoundedKm !== null && accuracyKm <= band.maxRoundedKm,
    )?.color ?? ACCURACY_COLOR_LEGEND[3].color
  );
}

export function formatAccuracy(accuracyMeters: number | null): string {
  if (accuracyMeters === null) return "No TDOA solution";
  if (accuracyMeters >= 1000)
    return `${(accuracyMeters / 1000).toFixed(1)} km`;
  return `${Math.round(accuracyMeters)} m`;
}

// export function coverageAreaKm2(bounds: RectangleBounds): number {
//   const latHeight =
//     Math.abs(bounds.north - bounds.south) * (Math.PI / 180) * EARTH_RADIUS_KM;
//   const lonWidth =
//     Math.abs(bounds.east - bounds.west) *
//     (Math.PI / 180) *
//     EARTH_RADIUS_KM *
//     Math.cos(((bounds.north + bounds.south) / 2) * (Math.PI / 180));
//   return Math.abs(latHeight * lonWidth);
// }

// ─────────────────────────────────────────────────────────────────────────────
// Public API — single-instant synchronous estimator (one-shot)
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Estimate TDOA geolocation accuracy for every cell in `bounds`, at a single
 * instant in time.
 *
 * @param bounds  Rectangle over which to compute accuracy
 * @param tles    Satellite TLEs (will be parsed once)
 * @param pass    Pass window — only `pass.aos` is used as the evaluation time
 * @param stepKm  Desired grid spacing in km
 */
// export function estimateGeolocationAccuracy(
//   bounds: RectangleBounds,
//   tles: TleEntry[],
//   pass: OrbitWindow,
//   stepKm: number,
// ): AccuracySample[] {
//   const clampedStep = Math.max(
//     ACCURACY_STEP_MIN_KM,
//     Math.min(stepKm, ACCURACY_STEP_MAX_KM),
//   );
//   const cells = createAccuracyGrid(bounds, clampedStep);

//   if (tles.length === 0) {
//     return cells.map((cell) => ({ ...cell, computed: true }));
//   }

//   const prepared = prepareTles(tles);
//   const time = pass.aos;
//   const states = propagatePrepared(
//     prepared,
//     time,
//     pass.label ?? "selected pass",
//   );
//   const passLabel = pass.label ?? "Selected pass";

//   return cells.map((cell) => {
//     const estimate = estimateAtPointUplink(cell.lat, cell.lon, states);
//     return {
//       ...cell,
//       accuracyMeters: estimate.accuracyMeters,
//       visibleSatellites: estimate.visibleSatellites,
//       computed: true,
//       satelliteGeometry: estimate.satelliteGeometry,
//       passIndex: 0,
//       passLabel,
//     };
//   });
// }

// ─────────────────────────────────────────────────────────────────────────────
// Public API — animation-frame async estimator
// ─────────────────────────────────────────────────────────────────────────────

export type AnimatedAccuracyOptions = {
  bounds: RectangleBounds;
  prepared: PreparedSatellite[];
  time: Date;
  stepKm: number;
  onSamples?: (samples: AccuracySample[]) => void;
  onProgress?: (completed: number, total: number) => void;
  shouldAbort?: () => boolean;
  grid?: AccuracySample[];
};

/**
 * Evaluate the accuracy grid at one exact simulation instant, in a
 * cooperative (chunked) manner so the animation loop stays responsive.
 *
 * With the Earth-surface constraint and TDOA, N = 3 satellites are
 * sufficient. N ≥ 4 is preferred for redundancy.
 */
export async function estimateGeolocationAccuracyAtTimeAsync(
  options: AnimatedAccuracyOptions,
): Promise<AccuracySample[]> {
  const {
    bounds,
    prepared,
    time,
    stepKm,
    onSamples,
    onProgress,
    shouldAbort,
    grid,
  } = options;

  const clampedStep = Math.max(
    ACCURACY_STEP_MIN_KM,
    Math.min(stepKm, ACCURACY_STEP_MAX_KM),
  );

  const cells = grid ?? createAccuracyGrid(bounds, clampedStep);
  const passLabel = `Animated · ${time.toISOString().slice(11, 19)} UTC`;

  onProgress?.(0, cells.length);

  const states = propagatePrepared(prepared, time, "animated");

  const results: AccuracySample[] = [];
  const chunkSize = 64;

  for (let start = 0; start < cells.length; start += chunkSize) {
    if (shouldAbort?.()) {
      return results;
    }

    const end = Math.min(start + chunkSize, cells.length);
    for (let index = start; index < end; index++) {
      const cell = cells[index];
      const estimate = estimateAtPointUplink(cell.lat, cell.lon, states);
      results.push({
        ...cell,
        accuracyMeters: estimate.accuracyMeters,
        visibleSatellites: estimate.visibleSatellites,
        computed: true,
        satelliteGeometry: estimate.satelliteGeometry,
        passIndex: 0,
        passLabel,
      });
    }

    onProgress?.(end, cells.length);
    onSamples?.(results.slice());
    await new Promise<void>((resolve) => window.setTimeout(resolve, 0));
  }

  return results;
}

// ─────────────────────────────────────────────────────────────────────────────
// Public API — single-pass async chunked estimator (offline study)
// ─────────────────────────────────────────────────────────────────────────────

export async function estimateGeolocationAccuracyAsync(
  bounds: RectangleBounds,
  tles: TleEntry[],
  pass: OrbitWindow,
  stepKm: number,
  onProgress?: (completed: number, total: number) => void,
  onBatch?: (startIndex: number, samples: AccuracySample[]) => void,
  grid?: AccuracySample[],
): Promise<AccuracySample[]> {
  const clampedStep = Math.max(
    ACCURACY_STEP_MIN_KM,
    Math.min(stepKm, ACCURACY_STEP_MAX_KM),
  );
  const cells = grid ?? createAccuracyGrid(bounds, clampedStep);

  onProgress?.(0, cells.length);

  if (tles.length === 0) {
    onProgress?.(cells.length, cells.length);
    return cells.map((cell) => ({ ...cell, computed: true }));
  }

  const prepared = prepareTles(tles);
  const time = pass.aos;
  const states = propagatePrepared(prepared, time, pass.label ?? "selected pass");
  const passLabel = pass.label ?? "Selected pass";

  const results: AccuracySample[] = [];
  const chunkSize = 32;
  for (let start = 0; start < cells.length; start += chunkSize) {
    const end = Math.min(start + chunkSize, cells.length);
    const batch: AccuracySample[] = [];

    for (let index = start; index < end; index++) {
      const cell = cells[index];
      const estimate = estimateAtPointUplink(cell.lat, cell.lon, states);
      const sample: AccuracySample = {
        ...cell,
        accuracyMeters: estimate.accuracyMeters,
        visibleSatellites: estimate.visibleSatellites,
        computed: true,
        satelliteGeometry: estimate.satelliteGeometry,
        passIndex: 0,
        passLabel,
      };
      results.push(sample);
      batch.push(sample);
    }

    onBatch?.(start, batch);
    onProgress?.(end, cells.length);
    await new Promise<void>((resolve) => window.setTimeout(resolve, 0));
  }

  return results;
}