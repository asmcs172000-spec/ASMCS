import { useMemo, useEffect, useLayoutEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { Map as MapIcon, ChevronDown, ArrowRight, Check, Play, Pause, Square } from "lucide-react";
import { useVizPlayback } from "./vizPlayback";

// ─── Types ────────────────────────────────────────────────────────────────

export type FrequencyPresetId = "20" | "50" | "120" | "80";

export type FrequencySegment = {
  id: string;
  presetId: FrequencyPresetId;
  startSeconds: number;
  durationSeconds: number;
};

type Props = {
  segments: FrequencySegment[];
  onSegmentsChange: (segments: FrequencySegment[]) => void;
  onVisualize?: (segments: FrequencySegment[]) => void;
  onBack?: () => void;
  onNext?: () => void;
};

type TableProps = {
  segments: FrequencySegment[];
  onSegmentsChange: (segments: FrequencySegment[]) => void;
  /** When true, the table is read-only and no mutation handler will fire.
   *  Only meaningful when a caller also passes onConfirm (see below) —
   *  Strip mode uses this; Spot mode's default export never sets it. */
  locked?: boolean;
  /** Presence of this prop is what turns the Confirm/Edit row on at all.
   *  Strip mode passes it. The default `FrequencyAndTime` export below
   *  (used by Spot mode) never passes it, so Spot mode never shows the
   *  row and behaves exactly as before. */
  onConfirm?: () => void;
  onEdit?: () => void;
};

type NavProps = {
  segments: FrequencySegment[];
  onVisualize?: (segments: FrequencySegment[]) => void;
  /** Stop: clear the animation and return the globe to its normal state. */
  onBack?: () => void;
  onNext?: () => void;
  onPauseChange?: (paused: boolean) => void;
  /** When set, Visualize is disabled and this is shown instead. */
  disabledReason?: string | null;
  title?: string;
};

type PresetInfo = {
  label: string;
  bandwidthLabel: string;
  swathKm: number;
  color: string;
};

export const FREQUENCY_PRESETS: Record<FrequencyPresetId, PresetInfo> = {
  "20": { label: "20 MHz", bandwidthLabel: "20 - 40 MHz", swathKm: 340, color: "#b5730a" },
  "50": { label: "50 MHz", bandwidthLabel: "50 - 90 MHz", swathKm: 260, color: "#0e7f95" },
  "120": { label: "120 MHz", bandwidthLabel: "120 MHz (Fixed)", swathKm: 140, color: "#6d3fc4" },
  "80": { label: "80 MHz", bandwidthLabel: "80 MHz (Fixed)", swathKm: 200, color: "#1f9d52" },
};

const LOWEST_FREQUENCY_PRESET_ID = (Object.keys(FREQUENCY_PRESETS) as FrequencyPresetId[])
  .reduce((lowest, id) => Number(id) < Number(lowest) ? id : lowest);
export const MIN_FREQUENCY_SWATH_KM = FREQUENCY_PRESETS[LOWEST_FREQUENCY_PRESET_ID].swathKm;

const PRESET_ORDER: FrequencyPresetId[] = ["20", "50", "120", "80"];

// ─── Hardcoded mission time: 10 minutes ────────────────────────────────────
const MISSION_DURATION_SECONDS = 10 * 60;
const DEFAULT_SEGMENT_SECONDS = 60;

// ─── Helpers ──────────────────────────────────────────────────────────────

function formatMmSs(totalSeconds: number) {
  const sign = totalSeconds < 0 ? "-" : "";
  const s = Math.abs(Math.round(totalSeconds));
  const m = Math.floor(s / 60);
  const sec = s % 60;
  return `${sign}${m.toString().padStart(2, "0")}:${sec.toString().padStart(2, "0")}`;
}

function makeId() {
  return Math.random().toString(36).slice(2, 10);
}

// ─── Component ────────────────────────────────────────────────────────────

export function FrequencyPlanTable({
  segments,
  onSegmentsChange,
  locked = false,
  onConfirm,
  onEdit,
}: TableProps) {
  const totalAllocated = useMemo(
    () => segments.reduce((sum, s) => sum + s.durationSeconds, 0),
    [segments],
  );

  const remaining = MISSION_DURATION_SECONDS - totalAllocated;
  const isAtLimit = remaining <= 0;

  const updateSegment = (id: string, patch: Partial<FrequencySegment>) => {
    if (locked) return;
    onSegmentsChange(
      segments.map((s) => {
        if (s.id !== id) return s;
        const next = { ...s, ...patch };

        // Clamp so no single segment can push the total past the 10-minute cap.
        const othersTotal = segments.reduce(
          (sum, other) => (other.id === id ? sum : sum + other.durationSeconds),
          0,
        );
        const maxDurationForThis = Math.max(0, MISSION_DURATION_SECONDS - othersTotal);
        if (next.durationSeconds > maxDurationForThis) {
          next.durationSeconds = maxDurationForThis;
        }

        return next;
      }),
    );
  };

  const removeSegment = (id: string) => {
    if (locked) return;
    onSegmentsChange(segments.filter((s) => s.id !== id));
  };

  // Each preset chip appends a segment right after the last one, sized to
  // whatever mission time is still free (up to 1:00).
  const addSegment = (presetId: FrequencyPresetId) => {
    if (locked || isAtLimit) return;
    const lastEnd = segments.reduce((end, s) => Math.max(end, s.startSeconds + s.durationSeconds), 0);
    onSegmentsChange([
      ...segments,
      {
        id: makeId(),
        presetId,
        startSeconds: lastEnd,
        durationSeconds: Math.max(0, Math.min(DEFAULT_SEGMENT_SECONDS, remaining)),
      },
    ]);
  };

  const canConfirm = segments.length > 0 && segments.every((s) => s.durationSeconds > 0);
  // Start / Duration get a fixed minimum so the mm:ss boxes are never clipped.
  const COLS =
    "grid-cols-[36px_minmax(124px,1.2fr)_minmax(120px,1.1fr)_minmax(150px,1fr)_minmax(150px,1fr)_minmax(72px,.7fr)_28px] gap-x-2";

  return (
    <div className="mp-card">
      <div className="mp-card-head flex-wrap">
        <span className="font-semibold">Frequency scheduling</span>
        <div className="flex flex-wrap gap-1.5">
          {PRESET_ORDER.map((id) => {
            const preset = FREQUENCY_PRESETS[id];
            return (
              <button
                key={id}
                type="button"
                onClick={() => addSegment(id)}
                disabled={isAtLimit || locked}
                title={locked ? "Edit the plan to change segments" : isAtLimit ? "10-minute mission time fully allocated" : `Add a ${preset.label} segment`}
                className="mp-mono flex items-center gap-1.5 whitespace-nowrap rounded-[5px] border border-[var(--mp-border-input)] px-2.5 py-[5px] text-xs font-medium hover:bg-white/[0.05] disabled:cursor-not-allowed disabled:opacity-40"
              >
                <span className="size-2 rounded-[2px]" style={{ background: preset.color }} />+ {preset.label}
              </button>
            );
          })}
        </div>
      </div>

      <div className="overflow-x-auto">
        <div className="min-w-[820px]">
          <div className={`mp-mono grid ${COLS} border-b border-[var(--mp-border-row)] px-4 py-[9px] text-[10.5px] font-semibold tracking-[0.06em] text-[var(--mp-text-3)]`}>
            <span>#</span>
            <span>PRESET</span>
            <span>BANDWIDTH</span>
            <span>START</span>
            <span>DURATION</span>
            <span>SWATH</span>
            <span />
          </div>
          {segments.length === 0 ? (
            <div className="px-4 py-6 text-center text-xs text-[var(--mp-text-3)]">
              No frequency segments yet. Add one with the preset buttons above.
            </div>
          ) : (
            segments.map((seg, i) => {
              const preset = FREQUENCY_PRESETS[seg.presetId];
              return (
                <div
                  key={seg.id}
                  className={`mp-mono grid ${COLS} items-center border-b border-[var(--mp-border-row)] px-4 py-[7px] text-[12.5px]`}
                >
                  <span className="text-[var(--mp-text-3)]">{String(i + 1).padStart(2, "0")}</span>
                  <span>
                    <PresetDropdown
                      value={seg.presetId}
                      onChange={(id) => updateSegment(seg.id, { presetId: id })}
                      disabled={locked}
                    />
                  </span>
                  <span className="text-[var(--mp-text-2)]">{preset.bandwidthLabel}</span>
                  <TimeInput
                    minutes={Math.floor(seg.startSeconds / 60)}
                    seconds={seg.startSeconds % 60}
                    onChange={(m, s) => updateSegment(seg.id, { startSeconds: m * 60 + s })}
                    disabled={locked}
                  />
                  <TimeInput
                    minutes={Math.floor(seg.durationSeconds / 60)}
                    seconds={seg.durationSeconds % 60}
                    onChange={(m, s) => updateSegment(seg.id, { durationSeconds: m * 60 + s })}
                    disabled={locked}
                  />
                  <span>{preset.swathKm} km</span>
                  <button
                    type="button"
                    title="Remove segment"
                    onClick={() => removeSegment(seg.id)}
                    disabled={locked}
                    className="text-center text-[var(--mp-text-3)] hover:text-[var(--mp-err-text)] disabled:cursor-not-allowed disabled:opacity-30"
                  >
                    ×
                  </button>
                </div>
              );
            })
          )}
        </div>
      </div>

      <div className="flex flex-col gap-2 px-4 py-3">
        <div className="flex justify-between text-xs">
          <span className="text-[var(--mp-text-2)]">Mission time used</span>
          <span className="mp-mono">
            {formatMmSs(totalAllocated)} / {formatMmSs(MISSION_DURATION_SECONDS)}
          </span>
        </div>
        <div className="relative h-[22px] overflow-hidden rounded border border-[var(--mp-border)] bg-[rgba(5,9,13,.5)]">
          {segments.map((seg) => (
            <div
              key={seg.id}
              className="absolute inset-y-0 border-r border-[#0d1115] opacity-85"
              style={{
                left: `${(Math.min(seg.startSeconds, MISSION_DURATION_SECONDS) / MISSION_DURATION_SECONDS) * 100}%`,
                width: `${(Math.min(seg.durationSeconds, MISSION_DURATION_SECONDS) / MISSION_DURATION_SECONDS) * 100}%`,
                background: FREQUENCY_PRESETS[seg.presetId].color,
              }}
            />
          ))}
        </div>
        <div className="mp-mono flex justify-between text-[10.5px] text-[var(--mp-text-3)]">
          <span>00:00</span>
          <span>05:00</span>
          <span>10:00</span>
        </div>
        {isAtLimit && !locked && (
          <div className="text-[11.5px] text-[var(--mp-warn)]">
            10-minute mission time is fully allocated. Remove or shorten a segment to add another.
          </div>
        )}
        {onConfirm && (
          <div className="text-[11.5px] text-[var(--mp-text-3)]">
            {locked
              ? "Plan confirmed. Edit it to make changes."
              : "Confirm the plan once you're done to search for capture orbits."}
          </div>
        )}
      </div>

      {/* ── Confirm / Edit row ──
          Only rendered when a caller passes onConfirm. Strip mode passes
          it (see GeoReferenceStripMode.tsx); the default FrequencyAndTime
          export below (Spot mode) never does, so this never shows there. ── */}
      {onConfirm && (
        <div className="flex items-center justify-center gap-2 border-t border-[var(--mp-border-row)] px-4 py-3">
          {!locked ? (
            <button
              type="button"
              disabled={!canConfirm}
              onClick={onConfirm}
              title={!canConfirm ? "Every segment needs a duration above 0" : undefined}
              className="flex h-9 items-center gap-2 rounded-lg border border-emerald-500/40 bg-emerald-500/10 px-5 text-xs font-bold uppercase tracking-wider text-emerald-300 transition-colors hover:bg-emerald-500/20 disabled:cursor-not-allowed disabled:opacity-40"
            >
              <Check className="size-3.5" />
              Confirm Frequency Plan
            </button>
          ) : (
            <button
              type="button"
              onClick={onEdit}
              className="flex h-9 items-center gap-2 rounded-lg border border-white/10 bg-white/[0.02] px-5 text-xs font-bold uppercase tracking-wider text-[oklch(0.72_0.02_250)] transition-colors hover:border-white/20 hover:bg-white/[0.05]"
            >
              Edit Frequency Plan
            </button>
          )}
        </div>
      )}
    </div>
  );
}

// ─── Visualization controls: Visualize · Pause / Resume · Stop ─────────
// Split out so callers can render the segment TABLE in the reference step
// while the controls sit with the orbits in the visualization step. The
// play state comes from vizPlayback, so it also follows the globe's own
// "Back to Globe" button.
export function FrequencyVisualizeNav({
  segments,
  onVisualize,
  onBack,
  onNext,
  onPauseChange,
  disabledReason,
  title = "Visualization",
}: NavProps) {
  const playback = useVizPlayback();
  const active = playback.active !== null;
  const noPlan = segments.length === 0;
  const blocked = noPlan ? "Add a frequency segment first" : disabledReason ?? null;

  return (
    <div className="mp-card">
      <div className="mp-card-head">
        <span className="font-semibold">{title}</span>
        <span
          className="mp-mono whitespace-nowrap rounded border px-[7px] py-[3px] text-[10.5px] font-semibold"
          style={{
            color: !active ? "var(--mp-text-3)" : playback.paused ? "var(--mp-warn)" : "var(--mp-ok)",
            borderColor: !active ? "var(--mp-border-input)" : playback.paused ? "var(--mp-warn)" : "var(--mp-ok)",
          }}
        >
          {!active ? "STOPPED" : playback.paused ? "PAUSED" : "PLAYING"}
        </span>
      </div>
      <div className="flex flex-wrap items-center gap-2 px-4 py-3">
        <button
          type="button"
          disabled={!!blocked}
          title={blocked ?? undefined}
          onClick={() => onVisualize?.(segments)}
          className="mp-btn-primary flex items-center gap-2"
        >
          <MapIcon className="size-4" />
          {active ? "Restart visualization" : "Visualize on map"}
        </button>
        <button
          type="button"
          disabled={!active}
          onClick={() => onPauseChange?.(!playback.paused)}
          className="flex items-center gap-2 whitespace-nowrap rounded-md border border-[var(--mp-border-input)] px-4 py-[9px] font-semibold hover:bg-white/[0.04] disabled:cursor-not-allowed disabled:opacity-40"
        >
          {playback.paused ? <Play className="size-4" /> : <Pause className="size-4" />}
          {playback.paused ? "Resume" : "Pause"}
        </button>
        <button
          type="button"
          disabled={!active}
          onClick={onBack}
          className="flex items-center gap-2 whitespace-nowrap rounded-md border border-[var(--mp-border-input)] px-4 py-[9px] font-semibold hover:bg-white/[0.04] disabled:cursor-not-allowed disabled:opacity-40"
        >
          <Square className="size-3.5" />
          Stop
        </button>
        {onNext && (
          <button
            type="button"
            disabled={noPlan}
            onClick={onNext}
            className="ml-auto flex items-center gap-2 whitespace-nowrap rounded-md border border-[var(--mp-border-input)] px-4 py-[9px] font-semibold hover:bg-white/[0.04] disabled:cursor-not-allowed disabled:opacity-40"
          >
            Next
            <ArrowRight className="size-3.5" />
          </button>
        )}
        {blocked && <span className="text-xs text-[var(--mp-text-3)]">{blocked}</span>}
      </div>
    </div>
  );
}

// ─── Default export: table + nav together — unchanged for Spot mode,
//     which still renders both as one block. Never passes locked/onConfirm/
//     onEdit, so Spot mode's table is never locked and never shows the
//     Confirm/Edit row. ──────────────────────────
export default function FrequencyAndTime({
  segments,
  onSegmentsChange,
  onVisualize,
  onBack,
  onNext,
}: Props) {
  return (
    <div className="space-y-6">
      <FrequencyPlanTable segments={segments} onSegmentsChange={onSegmentsChange} />
      <FrequencyVisualizeNav segments={segments} onVisualize={onVisualize} onBack={onBack} onNext={onNext} />
    </div>
  );
}

// ─── Small mm:ss number-pair input ─────────────────────────────────────────

function TimeInput({
  minutes,
  seconds,
  onChange,
  disabled = false,
}: {
  minutes: number;
  seconds: number;
  onChange: (minutes: number, seconds: number) => void;
  disabled?: boolean;
}) {
  // ▲ / ▼ step the value; seconds carry over into minutes (0:59 ▲ → 1:00).
  const stepBy = (deltaSeconds: number) => {
    const total = Math.max(0, minutes * 60 + seconds + deltaSeconds);
    onChange(Math.floor(total / 60), total % 60);
  };
  return (
    <div className="flex items-center gap-1">
      <StepField
        value={minutes}
        disabled={disabled}
        onType={(v) => onChange(Math.max(0, v), seconds)}
        onStep={(dir) => stepBy(dir * 60)}
        label="minutes"
      />
      <span className="text-[oklch(0.5_0.02_250)]">:</span>
      <StepField
        value={seconds}
        disabled={disabled}
        onType={(v) => onChange(minutes, Math.min(59, Math.max(0, v)))}
        onStep={(dir) => stepBy(dir)}
        label="seconds"
        pad
      />
    </div>
  );
}

function StepField({
  value,
  disabled,
  onType,
  onStep,
  label,
  pad = false,
}: {
  value: number;
  disabled: boolean;
  onType: (v: number) => void;
  onStep: (dir: 1 | -1) => void;
  label: string;
  pad?: boolean;
}) {
  const btn =
    "flex h-1/2 w-4 items-center justify-center text-[oklch(0.6_0.02_250)] hover:bg-white/[0.06] hover:text-[oklch(0.9_0_0)] disabled:cursor-not-allowed disabled:opacity-40";
  return (
    <div className="flex h-[30px] overflow-hidden rounded-[5px] border border-[var(--mp-border-input)] bg-[var(--mp-input)] focus-within:border-[oklch(0.75_0.12_220)]/50">
      <input
        type="text"
        inputMode="numeric"
        aria-label={label}
        value={pad ? String(value).padStart(2, "0") : String(value)}
        disabled={disabled}
        onChange={(e) => onType(Number(e.target.value.replace(/\D/g, "")) || 0)}
        onKeyDown={(e) => {
          if (e.key === "ArrowUp") {
            e.preventDefault();
            onStep(1);
          } else if (e.key === "ArrowDown") {
            e.preventDefault();
            onStep(-1);
          }
        }}
        className="w-9 bg-transparent px-1 text-center text-[oklch(0.9_0_0)] outline-none disabled:cursor-not-allowed disabled:opacity-40"
      />
      <div className="flex flex-col border-l border-[var(--mp-border-input)]">
        <button type="button" tabIndex={-1} disabled={disabled} onClick={() => onStep(1)} className={btn} aria-label={`Increase ${label}`}>
          <ChevronDown className="size-3 rotate-180" />
        </button>
        <button type="button" tabIndex={-1} disabled={disabled} onClick={() => onStep(-1)} className={btn} aria-label={`Decrease ${label}`}>
          <ChevronDown className="size-3" />
        </button>
      </div>
    </div>
  );
}

// ─── Custom-styled preset dropdown (replaces native <select>) ─────────────
// Rendered via a portal into document.body so it can't be clipped by the
// table's overflow-x-auto wrapper.

function PresetDropdown({
  value,
  onChange,
  disabled = false,
}: {
  value: FrequencyPresetId;
  onChange: (id: FrequencyPresetId) => void;
  disabled?: boolean;
}) {
  const [open, setOpen] = useState(false);
  const [coords, setCoords] = useState<{ top: number; left: number; width: number } | null>(null);
  const buttonRef = useRef<HTMLButtonElement>(null);
  const menuRef = useRef<HTMLDivElement>(null);
  const selected = FREQUENCY_PRESETS[value];

  const updateCoords = () => {
    const rect = buttonRef.current?.getBoundingClientRect();
    if (!rect) return;
    setCoords({
      top: rect.bottom + 4,
      left: rect.left,
      width: Math.max(rect.width, 130),
    });
  };

  useLayoutEffect(() => {
    if (open) updateCoords();
  }, [open]);

  useEffect(() => {
    if (!open) return;

    const handleClickOutside = (e: MouseEvent) => {
      if (
        buttonRef.current &&
        !buttonRef.current.contains(e.target as Node) &&
        menuRef.current &&
        !menuRef.current.contains(e.target as Node)
      ) {
        setOpen(false);
      }
    };
    const handleReposition = () => updateCoords();

    document.addEventListener("mousedown", handleClickOutside);
    window.addEventListener("scroll", handleReposition, true);
    window.addEventListener("resize", handleReposition);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
      window.removeEventListener("scroll", handleReposition, true);
      window.removeEventListener("resize", handleReposition);
    };
  }, [open]);

  return (
    <div className="relative w-[110px]">
      <button
        ref={buttonRef}
        type="button"
        disabled={disabled}
        onClick={() => setOpen((v) => !v)}
        className={`flex w-full items-center justify-between gap-1.5 rounded-md border px-2.5 py-1.5 text-left text-xs font-semibold transition-colors disabled:cursor-not-allowed disabled:opacity-40 ${
          open
            ? "border-[oklch(0.75_0.12_220)]/50 bg-[oklch(0.75_0.12_220)]/10 text-[oklch(0.92_0_0)]"
            : "border-white/10 bg-white/[0.03] text-[oklch(0.9_0_0)] hover:border-white/20"
        }`}
      >
        <span className="flex min-w-0 items-center gap-1.5 truncate">
          <span
            className="inline-block size-2 shrink-0 rounded-full"
            style={{ background: selected.color }}
          />
          <span className="truncate">{selected.label}</span>
        </span>
        <ChevronDown
          className={`size-3.5 shrink-0 text-[oklch(0.5_0.02_250)] transition-transform ${open ? "rotate-180" : ""}`}
        />
      </button>

      {open && coords &&
        createPortal(
          <div
            ref={menuRef}
            style={{
              position: "fixed",
              top: coords.top,
              left: coords.left,
              width: coords.width,
              zIndex: 9999,
            }}
            className="overflow-hidden rounded-lg border border-white/10 bg-[oklch(0.14_0.02_255)] shadow-xl shadow-black/50"
          >
            {PRESET_ORDER.map((id) => {
              const preset = FREQUENCY_PRESETS[id];
              const active = id === value;
              return (
                <button
                  key={id}
                  type="button"
                  onClick={() => {
                    onChange(id);
                    setOpen(false);
                  }}
                  className={`flex w-full items-center gap-2 px-3 py-2 text-left text-xs transition-colors ${
                    active
                      ? "bg-[oklch(0.75_0.12_220)]/12 font-semibold text-[oklch(0.92_0_0)]"
                      : "text-[oklch(0.8_0_0)] hover:bg-white/[0.05]"
                  }`}
                >
                  <span
                    className="inline-block size-2 shrink-0 rounded-full"
                    style={{ background: preset.color }}
                  />
                  <span className="flex-1 truncate">{preset.label}</span>
                  {active && <Check className="size-3 shrink-0 text-[oklch(0.78_0.1_150)]" />}
                </button>
              );
            })}
          </div>,
          document.body,
        )}
    </div>
  );
}