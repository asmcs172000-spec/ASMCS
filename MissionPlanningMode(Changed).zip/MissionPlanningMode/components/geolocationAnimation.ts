import * as Cesium from "cesium";
import * as satellite from "satellite.js";
import type { AccuracySample } from "./geolocationAccuracy";
import {
  ACCURACY_DEBUG,
  createAccuracyGrid,
  estimateGeolocationAccuracyAtTimeAsync,
  MAX_SLANT_RANGE_KM,
  prepareTles,
} from "./geolocationAccuracy";
import type { RectangleBounds } from "./useTargetPicker";
import type { TleEntry } from "./SpotModeRange";

const PREFIX = "geo-animation__";
const EARTH_RADIUS_KM = 6378.137;
const ORBIT_SAMPLE_SECONDS = 10;
const MAX_ORBIT_SAMPLES = 180;
const SAMPLE_HOLD_MS = 180;
const COLORS = ["#38bdf8", "#fbbf24", "#f472b6", "#4ade80", "#c084fc", "#fb7185"];

type AnimationSatellite = {
  tle: TleEntry;
  satrec: satellite.SatRec;
  color: Cesium.Color;
  position: Cesium.Cartesian3;
};

type Options = {
  viewer: Cesium.Viewer;
  bounds: RectangleBounds;
  point?: { lat: number; lon: number };
  grid?: AccuracySample[];
  satellites: TleEntry[];
  startTime: Date;
  endTime: Date;
  stepKm: number;
  onSamples: (samples: AccuracySample[]) => void;
  onTimeChange: (time: Date) => void;
};

function wrapLongitude(longitude: number) {
  return Cesium.Math.negativePiToPi(longitude);
}

function propagatePosition(satrec: satellite.SatRec, time: Date) {
  const pv = satellite.propagate(satrec, time);
  if (!pv?.position || typeof pv.position === "boolean") return null;
  const geodetic = satellite.eciToGeodetic(pv.position, satellite.gstime(time));
  return {
    lon: wrapLongitude(geodetic.longitude),
    lat: geodetic.latitude,
    heightKm: geodetic.height,
    ecf: satellite.eciToEcf(pv.position, satellite.gstime(time)),
  };
}

function hasLineOfSight(
  satelliteEcf: { x: number; y: number; z: number },
  latitude: number,
  longitude: number,
) {
  const cosLat = Math.cos(latitude);
  const ground = {
    x: EARTH_RADIUS_KM * cosLat * Math.cos(longitude),
    y: EARTH_RADIUS_KM * cosLat * Math.sin(longitude),
    z: EARTH_RADIUS_KM * Math.sin(latitude),
  };
  const delta = {
    x: satelliteEcf.x - ground.x,
    y: satelliteEcf.y - ground.y,
    z: satelliteEcf.z - ground.z,
  };
  const range = Math.hypot(delta.x, delta.y, delta.z);
  if (range > MAX_SLANT_RANGE_KM || range <= 0) return false;
  const up = {
    x: cosLat * Math.cos(longitude),
    y: cosLat * Math.sin(longitude),
    z: Math.sin(latitude),
  };
  const sinElevation = (delta.x * up.x + delta.y * up.y + delta.z * up.z) / range;
  return sinElevation > 0;
}

/** Walk the selected AOS→LOS pass in discrete simulation-time intervals.
 * The satellite records and target grid are prepared once and reused. At
 * each interval, satellite positions/LOS are locked to the frame timestamp,
 * then the complete accuracy grid for that same time is published atomically
 * before playback advances. */
export function startGeolocationAnimation(options: Options): () => void {
  const { viewer, bounds, point, grid, satellites, startTime, endTime, stepKm, onSamples, onTimeChange } = options;
  if (viewer.isDestroyed() || satellites.length === 0) return () => undefined;

  const spanMs = Math.max(1000, endTime.getTime() - startTime.getTime());
  const corners = [
    { lat: bounds.north, lon: bounds.west },
    { lat: bounds.north, lon: bounds.east },
    { lat: bounds.south, lon: bounds.east },
    { lat: bounds.south, lon: bounds.west },
  ];
  const center = {
    lat: point?.lat ?? (bounds.north + bounds.south) / 2,
    lon: point?.lon ?? (bounds.west + bounds.east) / 2,
  };
  const centerPosition = Cesium.Cartesian3.fromDegrees(center.lon, center.lat, 0);
  // The accuracy solver accepts pre-parsed satrecs and a reusable grid. Build
  // both once here rather than repeating TLE parsing and grid generation for
  // every pass interval.
  const preparedSatellites = prepareTles(satellites);
  const preparedByName = new Map(preparedSatellites.map((entry) => [entry.name, entry]));
  const accuracyGrid = grid ?? createAccuracyGrid(bounds, stepKm);
  const satPlans: AnimationSatellite[] = satellites.flatMap((tle, index) => {
    const prepared = preparedByName.get(tle.name);
    if (!prepared) return [];
    return [{
      tle,
      satrec: prepared.satrec,
      color: Cesium.Color.fromCssColorString(tle.color ?? COLORS[index % COLORS.length]),
      position: Cesium.Cartesian3.ZERO,
    }];
  });
  let disposed = false;
  let intervalTimer = 0;
  let sampleIndex = 0;
  let activeFrame = 0;
  const beamVisibility = new Map<string, boolean>();
  const intervalCount = Math.min(
    MAX_ORBIT_SAMPLES,
    Math.max(1, Math.ceil(spanMs / (ORBIT_SAMPLE_SECONDS * 1000))),
  );

  // Target rectangle remains separate from the picker geometry, so stopping
  // playback never disturbs the operator's editable target shape.
  if (point) {
    viewer.entities.add({
      id: `${PREFIX}target-swath`,
      rectangle: {
        coordinates: Cesium.Rectangle.fromDegrees(bounds.west, bounds.south, bounds.east, bounds.north),
        material: Cesium.Color.TRANSPARENT,
        outline: true,
        outlineColor: Cesium.Color.fromCssColorString("#7dd3fc").withAlpha(0.9),
        outlineWidth: 2,
        height: 60,
      },
    });
  } else {
    viewer.entities.add({
      id: `${PREFIX}target`,
      rectangle: {
        coordinates: Cesium.Rectangle.fromDegrees(bounds.west, bounds.south, bounds.east, bounds.north),
        material: Cesium.Color.fromCssColorString("#38bdf8").withAlpha(0.16),
        outline: true,
        outlineColor: Cesium.Color.fromCssColorString("#7dd3fc").withAlpha(0.95),
        outlineWidth: 2,
        // Keep the target footprint visible and fixed for the entire pass; LOS
        // only gates the satellite-to-area cone edges, never the target shape.
        show: true,
        height: 80,
      },
    });
  }

  satPlans.forEach((plan, satIndex) => {
    const id = `${PREFIX}${satIndex}`;
    const positionProperty = new Cesium.CallbackPositionProperty(
      () => plan.position,
      false,
      Cesium.ReferenceFrame.FIXED,
    );
    viewer.entities.add({
      id: `${id}__satellite`,
      name: `${plan.tle.name} · selected-orbit playback`,
      position: positionProperty,
      billboard: {
        image: "/satellite.png",
        width: 52,
        height: 52,
        color: plan.color,
        disableDepthTestDistance: Number.POSITIVE_INFINITY,
        verticalOrigin: Cesium.VerticalOrigin.CENTER,
        horizontalOrigin: Cesium.HorizontalOrigin.CENTER,
      },
      label: {
        text: plan.tle.name,
        font: "12px sans-serif",
        style: Cesium.LabelStyle.FILL_AND_OUTLINE,
        fillColor: plan.color,
        outlineColor: Cesium.Color.BLACK,
        outlineWidth: 3,
        pixelOffset: new Cesium.Cartesian2(0, -24),
        disableDepthTestDistance: Number.POSITIVE_INFINITY,
      },
    });

    // Show a real propagated ground track for the selected orbit window.
    const track: Cesium.Cartesian3[] = [];
    for (let sample = 0; sample <= 48; sample++) {
      const time = new Date(startTime.getTime() + (spanMs * sample) / 48);
      const point = propagatePosition(plan.satrec, time);
      if (point) track.push(Cesium.Cartesian3.fromRadians(point.lon, point.lat, 0));
    }
    viewer.entities.add({
      id: `${id}__track`,
      polyline: {
        positions: track,
        width: 2,
        material: new Cesium.PolylineGlowMaterialProperty({ color: plan.color.withAlpha(0.72), glowPower: 0.18 }),
        clampToGround: true,
      },
    });

    // Four satellite-to-area-corner rays form a wireframe swath cone. Each
    // edge activates independently on physical LOS to that corner.
    corners.forEach((corner, cornerIndex) => {
      const beamId = `${id}__beam-${cornerIndex}`;
      beamVisibility.set(beamId, false);
      const cornerPosition = Cesium.Cartesian3.fromDegrees(corner.lon, corner.lat, 0);
      viewer.entities.add({
        id: beamId,
        name: `${plan.tle.name} LOS swath edge`,
        polyline: {
          positions: new Cesium.CallbackProperty(() => [plan.position, cornerPosition], false),
          show: new Cesium.CallbackProperty(() => beamVisibility.get(beamId) ?? false, false),
          width: 2,
          arcType: Cesium.ArcType.NONE,
          material: new Cesium.PolylineDashMaterialProperty({ color: plan.color.withAlpha(0.9), dashLength: 12 }),
        },
      });
    });

    const centerBeamId = `${id}__beam-center`;
    beamVisibility.set(centerBeamId, false);
    viewer.entities.add({
      id: centerBeamId,
      name: `${plan.tle.name} LOS to target area`,
      polyline: {
        positions: new Cesium.CallbackProperty(() => [plan.position, centerPosition], false),
        show: new Cesium.CallbackProperty(() => beamVisibility.get(centerBeamId) ?? false, false),
        width: 3,
        arcType: Cesium.ArcType.NONE,
        material: new Cesium.PolylineGlowMaterialProperty({ color: plan.color, glowPower: 0.22 }),
      },
    });
  });

  const updateSatelliteGeometry = (time: Date) => {
    satPlans.forEach((plan, satIndex) => {
      const point = propagatePosition(plan.satrec, time);
      if (!point) return;
      plan.position = Cesium.Cartesian3.fromRadians(point.lon, point.lat, point.heightKm * 1000);
      corners.forEach((corner, cornerIndex) => {
        const lineVisible = hasLineOfSight(
          point.ecf,
          corner.lat * Math.PI / 180,
          corner.lon * Math.PI / 180,
        );
        beamVisibility.set(`${PREFIX}${satIndex}__beam-${cornerIndex}`, lineVisible);
      });
      const centerVisible = hasLineOfSight(point.ecf, center.lat * Math.PI / 180, center.lon * Math.PI / 180);
      beamVisibility.set(`${PREFIX}${satIndex}__beam-center`, centerVisible);
    });
    viewer.scene.requestRender();
  };

  const playNextSample = async () => {
    if (disposed || viewer.isDestroyed()) return;
    const time = new Date(startTime.getTime() + (spanMs * sampleIndex) / intervalCount);
    const frameId = ++activeFrame;

    // Move all satellites and their LOS beams first. The target area remains
    // fixed; both the geometry and accuracy samples for this interval refer
    // to the same `time` value shown in the playback clock.
    updateSatelliteGeometry(time);
    onTimeChange(time);

    try {
      const samples = await estimateGeolocationAccuracyAtTimeAsync({
        bounds,
        prepared: preparedSatellites,
        time,
        stepKm,
        grid: accuracyGrid,
        // Collect a complete, consistent grid before replacing the visible
        // heatmap. Georeference rebuilds its Cesium primitive on each state
        // update, so publishing every chunk makes the overlay flicker and
        // repeatedly tears down its picking handler.
        shouldAbort: () => disposed || frameId !== activeFrame,
      });
      if (disposed || viewer.isDestroyed() || frameId !== activeFrame) return;
      if (ACCURACY_DEBUG) {
        console.groupCollapsed(`[accuracy animation] ${time.toISOString()} · ${samples.length} cells`);
        console.table(samples.map((sample, index) => ({
          cell: index + 1,
          sourceCellLat: Number(((sample.south + sample.north) / 2).toFixed(6)),
          sourceCellLon: Number(((sample.west + sample.east) / 2).toFixed(6)),
          estimatorLat: Number(sample.lat.toFixed(6)),
          estimatorLon: Number(sample.lon.toFixed(6)),
          accuracy: sample.accuracyMeters === null
            ? "No 3-satellite solution"
            : `${sample.accuracyMeters.toFixed(2)} m`,
          visibleSatellites: sample.visibleSatellites,
          pass: sample.passLabel || "No pass assigned",
        })));
        console.groupEnd();
      }
      onSamples(samples);
    } catch (error) {
      console.error("Animated geolocation accuracy update failed", error);
    }

    if (disposed || viewer.isDestroyed() || frameId !== activeFrame) return;
    sampleIndex = (sampleIndex + 1) % (intervalCount + 1);
    intervalTimer = window.setTimeout(playNextSample, SAMPLE_HOLD_MS);
  };

  // Put the constellation at AOS immediately; the first accuracy grid is
  // evaluated at this same instant and progressively replaces prior cells.
  updateSatelliteGeometry(startTime);
  onSamples([]);
  void playNextSample();

  return () => {
    if (disposed) return;
    disposed = true;
    activeFrame += 1;
    window.clearTimeout(intervalTimer);
    if (!viewer.isDestroyed()) {
      viewer.entities.values
        .filter((entity) => typeof entity.id === "string" && entity.id.startsWith(PREFIX))
        .forEach((entity) => viewer.entities.remove(entity));
      viewer.scene.requestRender();
    }
  };
}
