// GeoReferenceStripOrbitPlanAnimation.ts
//
// "Visualize Capture Plan": the LEADING satellite tours EVERY orbit of the plan.
//
// SOURCE OF TRUTH (GeoReferenceStripModeRange.ts):
//   orbit.passes[].segmentBreakdown[].footprints[] -> swept rectangles (lat/lon corners,
//                                                     tStartSec / tEndSec after THAT pass's start)
//   pass.newCoverageCurve                         -> NEW AOI fraction vs. seconds after mission start
//   orbit.newlyCoveredFraction                    -> what the orbit ADDS beyond earlier orbits
//
// Each orbit is drawn in ONE colour (no frequency colours). Its bands include the
// area of every satellite of that orbit, so the % matches the plan list; only the
// leader is flown.
//
// SWEEP RULES
//   * The sensor boresight follows the planner rectangle's line, EXTRAPOLATED
//     before / after it, so it never freezes at the AOI edge or swings backward.
//   * The sensor runs until mission end (it is not stopped by LOS; LOS before
//     mission end is listed as an alert in the legend).
//   * Dead time is skipped: each orbit is animated from its first capture to a
//     short run-out after its last capture.
//
// GROUND TRACKS: one FULL orbit (whole globe) per orbit, solid white; the one being
// captured is drawn in its orbit colour.
//
// Planner corner order for each footprint:
//   [0] alongMin/crossMin  [1] alongMin/crossMax
//   [2] alongMax/crossMax  [3] alongMax/crossMin

import * as Cesium from "cesium";
import * as satellite from "satellite.js";
import type { TleEntry } from "./satelliteRangeUtils";
import {
  formatCoveragePercent,
  type StripCapturePlanResult,
  type StripOrbit,
  type StripPass,
} from "./GeoReferenceStripModeRange";
import { rectangleAreaKm2 } from "./areaFromBounds";
import { STRIP_VIZ_PANEL_ID, addBeamFrustum, fmtClock, mountStatusPanel, type StatusPanel } from "./stripVizPanel";

import { vizStarted, vizStopped } from "./vizPlayback";

export { STRIP_VIZ_PANEL_ID };

const ENTITY_PREFIX = "strip-viz-";
const OVERLAY_CLASS = "strip-viz-overlay";
const SATELLITE_ICON_URL = "/satellite.png";
const FONT = `"Roboto", "Segoe UI", system-ui, sans-serif`;
const MONO = `"Roboto Mono", ui-monospace, Consolas, monospace`;

/** Virtual seconds of animation per real second. */
const CLOCK_MULTIPLIER = 13;
const MISSION_PRE_ROLL_SECONDS = 10;
const TAIL_OUT_SECONDS = 15;
/** Pause between orbits, in animation seconds (real orbit gaps are hours). */
const PASS_TRANSITION_SECONDS = 3;

/** Half along-track length of the live footprint (= beam base), km. */
const FOOTPRINT_HALF_LENGTH_KM = 14;
const BAND_BASE_HEIGHT_METERS = 5;
const BAND_HEIGHT_STEP_METERS = 3;
const LIVE_BOX_HEIGHT_METERS = 220;
const TRACK_POINTS_PER_ORBIT = 400;

/** One colour per orbit. */
const ORBIT_PALETTE = ["#4fb3e8", "#f59e0b", "#34d399", "#c084fc", "#f472b6", "#facc15", "#60a5fa", "#fb7185"];
export const orbitColor = (orbitIndex: number) => ORBIT_PALETTE[orbitIndex % ORBIT_PALETTE.length];

type LatLon = { lat: number; lon: number };
type Subpoint = LatLon & { heightM: number };

let clockTickListener: Cesium.Event.RemoveCallback | null = null;
let hiddenPlanningEntityIds: string[] = [];
const satrecCache = new Map<string, satellite.SatRec>();

const toRad = (d: number) => (d * Math.PI) / 180;
const clamp01 = (x: number) => Math.min(1, Math.max(0, x));

// ─── hide / restore planning entities ──────────────────────────────────

function hidePlanningEntities(viewer: Cesium.Viewer) {
  hiddenPlanningEntityIds = [];
  for (const e of viewer.entities.values) {
    const id = typeof e.id === "string" ? e.id : "";
    if (id.startsWith(ENTITY_PREFIX)) continue;
    if (!(e.billboard || e.point || e.label || e.model || e.path || e.polyline || e.polygon)) continue;
    hiddenPlanningEntityIds.push(id);
    e.show = false;
  }
}

function restorePlanningEntities(viewer?: Cesium.Viewer) {
  if (viewer && !viewer.isDestroyed()) {
    for (const id of hiddenPlanningEntityIds) {
      const e = viewer.entities.getById(id);
      if (e) e.show = true;
    }
    viewer.scene.requestRender();
  }
  hiddenPlanningEntityIds = [];
}

export type StripVisualizationCallbacks = { onBack?: () => void };

export function clearStripVisualization(viewer: Cesium.Viewer) {
  vizStopped("strip-plan");
  document.querySelectorAll(`.${OVERLAY_CLASS}`).forEach((el) => el.remove());
  if (clockTickListener) {
    clockTickListener();
    clockTickListener = null;
  }
  if (viewer.isDestroyed()) {
    restorePlanningEntities();
    return;
  }
  for (const e of [...viewer.entities.values]) {
    if (e.id?.toString().startsWith(ENTITY_PREFIX)) viewer.entities.remove(e);
  }
  restorePlanningEntities(viewer);
}

// ─── TLE helpers ───────────────────────────────────────────────────────

function satrecFor(tle: TleEntry): satellite.SatRec {
  const key = `${tle.tle1}|${tle.tle2}`;
  let rec = satrecCache.get(key);
  if (!rec) {
    rec = satellite.twoline2satrec(tle.tle1, tle.tle2);
    satrecCache.set(key, rec);
  }
  return rec;
}

function subpointAt(tle: TleEntry, date: Date): Subpoint | null {
  const pv = satellite.propagate(satrecFor(tle), date);
  if (!pv?.position || typeof pv.position === "boolean") return null;
  const geo = satellite.eciToGeodetic(pv.position, satellite.gstime(date));
  return {
    lon: satellite.degreesLong(geo.longitude),
    lat: satellite.degreesLat(geo.latitude),
    heightM: geo.height * 1000,
  };
}

function cartesian(p: LatLon, heightM = 0): Cesium.Cartesian3 {
  return Cesium.Cartesian3.fromDegrees(p.lon, p.lat, heightM);
}

/** One COMPLETE orbit (full revolution around the globe) centred on `center`. */
function fullOrbitTrack(tle: TleEntry, center: Date): Cesium.Cartesian3[] {
  const rec = satrecFor(tle);
  const noRadPerMin = rec.no;
  const periodSec = Number.isFinite(noRadPerMin) && noRadPerMin > 0 ? ((2 * Math.PI) / noRadPerMin) * 60 : 95 * 60;
  const pts: Cesium.Cartesian3[] = [];
  const startMs = center.getTime() - (periodSec * 1000) / 2;
  for (let i = 0; i <= TRACK_POINTS_PER_ORBIT; i++) {
    const sp = subpointAt(tle, new Date(startMs + (periodSec * 1000 * i) / TRACK_POINTS_PER_ORBIT));
    if (sp) pts.push(cartesian(sp, 0));
  }
  return pts;
}

function rectangleRing(bounds: StripCapturePlanResult["bounds"]): Cesium.Cartesian3[] {
  return [
    cartesian({ lon: bounds.west, lat: bounds.north }),
    cartesian({ lon: bounds.east, lat: bounds.north }),
    cartesian({ lon: bounds.east, lat: bounds.south }),
    cartesian({ lon: bounds.west, lat: bounds.south }),
  ];
}

// ─── Planner rectangles ────────────────────────────────────────────────

type PlannerRect = {
  satelliteName: string;
  /** Orbit-local seconds (leader mission start = 0). */
  startSec: number;
  endSec: number;
  corners: LatLon[];
};

const lerpLL = (a: LatLon, b: LatLon, f: number): LatLon => ({
  lat: a.lat + (b.lat - a.lat) * f,
  lon: a.lon + (b.lon - a.lon) * f,
});

/** Clamped 0..1 progress (for fills). */
const progressOf = (r: PlannerRect, t: number) => clamp01(rawProgressOf(r, t));
/** UNclamped progress: < 0 before, > 1 after the rectangle, so the beam keeps moving. */
const rawProgressOf = (r: PlannerRect, t: number) => (t - r.startSec) / Math.max(0.001, r.endSec - r.startSec);

/** Edge line at fraction f. f is NOT clamped, so it extrapolates. */
function edgeAt(r: PlannerRect, f: number) {
  const c = r.corners;
  return { left: lerpLL(c[0], c[3], f), right: lerpLL(c[1], c[2], f) };
}

function ringBetween(r: PlannerRect, f0: number, f1: number, heightM: number): Cesium.Cartesian3[] {
  const a = clamp01(Math.min(f0, f1));
  const b = clamp01(Math.max(f0, f1));
  if (b - a < 1e-6) return [];
  return ringRaw(r, a, b, heightM);
}

function ringRaw(r: PlannerRect, a: number, b: number, heightM: number): Cesium.Cartesian3[] {
  const s = edgeAt(r, a);
  const t = edgeAt(r, b);
  return [cartesian(s.left, heightM), cartesian(s.right, heightM), cartesian(t.right, heightM), cartesian(t.left, heightM)];
}

/** Along-track length of a rectangle (km). */
function rectAlongKm(r: PlannerRect): number {
  const a = r.corners[0];
  const b = r.corners[3];
  const dy = (b.lat - a.lat) * 111.32;
  const dx = (b.lon - a.lon) * 111.32 * Math.cos(toRad((a.lat + b.lat) / 2));
  return Math.max(1e-3, Math.hypot(dx, dy));
}

/** Live footprint (beam base) at local time t: a fixed-length window riding the leading edge. */
function liveRing(r: PlannerRect, t: number, heightM: number): Cesium.Cartesian3[] {
  const f = rawProgressOf(r, t);
  const w = FOOTPRINT_HALF_LENGTH_KM / rectAlongKm(r);
  return ringRaw(r, f - w, f + w, heightM);
}

/** Rectangle used at local time t: active, else most recent, else first. */
function currentRect(list: PlannerRect[], t: number): PlannerRect | null {
  if (list.length === 0) return null;
  const active = list.find((r) => t >= r.startSec && t < r.endSec);
  if (active) return active;
  let last: PlannerRect | null = null;
  for (const r of list) if (r.endSec <= t) last = r;
  return last ?? list[0];
}

/** Rectangle whose time->position line is used for the beam (avoids tiny clipped slivers). */
function beamRect(list: PlannerRect[], t: number): PlannerRect | null {
  const r = currentRect(list, t);
  if (!r) return null;
  if (r.endSec - r.startSec >= 0.5) return r;
  return list.reduce((best, x) => (x.endSec - x.startSec > best.endSec - best.startSec ? x : best), r);
}

// ─── Timeline: one entry per orbit ─────────────────────────────────────

type OrbitModel = {
  orbit: StripOrbit;
  orbitIndex: number;
  leader: StripPass;
  tle: TleEntry; // leader TLE (the satellite that is flown)
  accent: string;
  members: { pass: StripPass; offsetSec: number }[];
  rects: PlannerRect[]; // every satellite's rectangles in this orbit
  leaderRects: PlannerRect[]; // the satellite that is flown
  durationSeconds: number; // leader mission start -> last mission end
  t0: number; // first capture (orbit-local)
  t1: number; // end of run-out (orbit-local)
  lastEnd: number; // when the leader's sensor leaves the AOI
  animSeconds: number;
  virtualStart: number;
  virtualEnd: number;
};

function buildTimeline(planResult: StripCapturePlanResult, tleByName: Record<string, TleEntry>, startIndex: number) {
  const out: OrbitModel[] = [];
  let cursor = 0;
  planResult.orbits.slice(startIndex).forEach((orbit) => {
    const leader = orbit.passes[0];
    const tle = tleByName[leader.satelliteName];
    if (!tle) return;

    const leaderMs = orbit.missionStart.getTime();
    const members = orbit.passes.map((pass) => ({ pass, offsetSec: (pass.missionStart.getTime() - leaderMs) / 1000 }));
    const rects: PlannerRect[] = [];
    for (const { pass, offsetSec } of members) {
      for (const seg of pass.segmentBreakdown) {
        for (const fp of seg.footprints) {
          if (!fp.corners || fp.corners.length < 4) continue;
          rects.push({
            satelliteName: fp.satelliteName,
            startSec: offsetSec + fp.tStartSec,
            endSec: offsetSec + fp.tEndSec,
            corners: fp.corners.slice(0, 4),
          });
        }
      }
    }
    const leaderOnly = rects.filter((r) => r.satelliteName === leader.satelliteName).sort((a, b) => a.startSec - b.startSec);
    const leaderRects = leaderOnly.length > 0 ? leaderOnly : [...rects].sort((a, b) => a.startSec - b.startSec);

    const durationSeconds = Math.max(1, ...members.map((m) => m.offsetSec + m.pass.captureSeconds));
    const firstStart = rects.length ? Math.min(...rects.map((r) => r.startSec)) : 0;
    const allEnd = rects.length ? Math.max(...rects.map((r) => r.endSec)) : durationSeconds;
    const lastEnd = leaderRects.length ? Math.max(...leaderRects.map((r) => r.endSec)) : allEnd;

    // Each orbit plays from its first capture until the beam leaves the AOI.
    const t0 = Math.max(0, firstStart);
    const t1 = Math.min(durationSeconds, Math.max(t0 + 1, allEnd, lastEnd));
    const animSeconds = Math.max(1, t1 - t0);

    out.push({
      orbit,
      orbitIndex: orbit.index,
      leader,
      tle,
      accent: orbitColor(orbit.index),
      members,
      rects,
      leaderRects,
      durationSeconds,
      t0,
      t1,
      lastEnd,
      animSeconds,
      virtualStart: cursor,
      virtualEnd: cursor + animSeconds,
    });
    cursor += animSeconds + PASS_TRANSITION_SECONDS;
  });
  return out;
}

type State = { pm: OrbitModel; localSec: number; frac: number };

function stateAt(timeline: OrbitModel[], e: number): State {
  for (let i = 0; i < timeline.length; i++) {
    const pm = timeline[i];
    if (e < pm.virtualStart) {
      const prev = timeline[i - 1];
      return prev ? { pm: prev, localSec: prev.t1, frac: 1 } : { pm, localSec: pm.t0, frac: 0 };
    }
    if (e <= pm.virtualEnd) {
      const k = e - pm.virtualStart;
      return { pm, localSec: pm.t0 + k, frac: clamp01(k / pm.animSeconds) };
    }
  }
  const last = timeline[timeline.length - 1];
  return { pm: last, localSec: last.t1, frac: 1 };
}

function makeStateGetter(timeline: OrbitModel[], elapsedAt: (t: Cesium.JulianDate) => number) {
  let cachedE: number | null = null;
  let cached: State | null = null;
  return (time: Cesium.JulianDate): State => {
    const e = elapsedAt(time);
    if (cachedE === e && cached) return cached;
    cachedE = e;
    cached = stateAt(timeline, e);
    return cached;
  };
}

/** Local seconds inside a specific orbit (clamped to its animated window). */
const localSecIn = (pm: OrbitModel, e: number) => Math.min(pm.t1, pm.t0 + Math.max(0, e - pm.virtualStart));

/** NEW AOI fraction added by this orbit up to local time t (planner's curves). */
function orbitNewAt(pm: OrbitModel, t: number): number {
  let total = 0;
  for (const { pass, offsetSec } of pm.members) {
    const c = pass.newCoverageCurve;
    if (!c || c.length === 0 || t <= offsetSec) continue;
    const x = Math.min(t - offsetSec, c.length - 1);
    const i = Math.floor(x);
    const j = Math.min(c.length - 1, i + 1);
    total += c[i] + (c[j] - c[i]) * (x - i);
  }
  return total;
}

/** Total AOI fraction covered so far (new area only -> no double counting). */
function totalFractionAt(timeline: OrbitModel[], base: number, e: number): number {
  let total = base;
  for (const pm of timeline) {
    if (e <= pm.virtualStart) continue;
    total += orbitNewAt(pm, localSecIn(pm, e));
  }
  return total;
}

/** The beam is shown from mission start until it leaves the AOI. */
function sensorOn(pm: OrbitModel, t: number): boolean {
  return t >= 0 && t < pm.t1 - 1e-3;
}

// ─── Ground tracks + planned bands ─────────────────────────────────────

function addPassGraphics(
  viewer: Cesium.Viewer,
  timeline: OrbitModel[],
  elapsedAt: (t: Cesium.JulianDate) => number,
  stateFor: (t: Cesium.JulianDate) => State,
) {
  timeline.forEach((pm) => {
    const base = Cesium.Color.fromCssColorString(pm.accent);
    const dark = Cesium.Color.multiplyByScalar(base, 0.55, new Cesium.Color()).withAlpha(0.6);
    const glowOutline = Cesium.Color.multiplyByScalar(base, 1.3, new Cesium.Color()).withAlpha(0.95);
    const covered = Cesium.Color.multiplyByScalar(base, 1.15, new Cesium.Color()).withAlpha(0.65);
    const height = BAND_BASE_HEIGHT_METERS + pm.orbitIndex * BAND_HEIGHT_STEP_METERS;

    // Capture bands only appear once the animation reaches this orbit.
    const reached = new Cesium.CallbackProperty((time) => elapsedAt(time as Cesium.JulianDate) >= pm.virtualStart, false);
    const isActive = new Cesium.CallbackProperty(
      (time) => stateFor(time as Cesium.JulianDate).pm.orbitIndex === pm.orbitIndex,
      false,
    );

    pm.rects.forEach((r, k) => {
      const ring = ringBetween(r, 0, 1, height);
      if (ring.length === 0) return;
      const prefix = `${ENTITY_PREFIX}orbit-${pm.orbitIndex}-rect-${k}`;

      viewer.entities.add({
        id: `${prefix}-band`,
        polygon: {
          show: reached,
          hierarchy: new Cesium.PolygonHierarchy(ring),
          material: dark,
          outline: true,
          outlineColor: glowOutline,
          outlineWidth: 2,
          perPositionHeight: true,
        },
      });

      viewer.entities.add({
        id: `${prefix}-covered`,
        polygon: {
          hierarchy: new Cesium.CallbackProperty((time) => {
            const e = elapsedAt(time as Cesium.JulianDate);
            if (e <= pm.virtualStart) return new Cesium.PolygonHierarchy([]);
            const t = localSecIn(pm, e);
            if (t <= r.startSec) return new Cesium.PolygonHierarchy([]);
            return new Cesium.PolygonHierarchy(ringBetween(r, 0, progressOf(r, t), height + 1));
          }, false),
          material: covered,
          perPositionHeight: true,
        },
      });
    });

    // ── COMPLETE ground track (full orbit) of the leader ──
    const center = new Date(pm.orbit.missionStart.getTime() + (pm.durationSeconds / 2) * 1000);
    const track = fullOrbitTrack(pm.tle, center);

    const notActive = new Cesium.CallbackProperty(
      (time) => stateFor(time as Cesium.JulianDate).pm.orbitIndex !== pm.orbitIndex,
      false,
    );
    viewer.entities.add({
      id: `${ENTITY_PREFIX}orbit-${pm.orbitIndex}-track-white`,
      polyline: {
        show: notActive,
        positions: track,
        width: 2,
        clampToGround: true,
        material: Cesium.Color.WHITE.withAlpha(0.7),
      },
    });
    viewer.entities.add({
      id: `${ENTITY_PREFIX}orbit-${pm.orbitIndex}-track-active`,
      polyline: {
        show: isActive,
        positions: track,
        width: 3.5,
        clampToGround: true,
        material: base.withAlpha(1),
      },
    });
  });
}

// ─── The traveling satellite: icon, forward beam, live box ─────────────

function addTravelingSatellite(
  viewer: Cesium.Viewer,
  stateFor: (t: Cesium.JulianDate) => State,
  elapsedAt: (t: Cesium.JulianDate) => number,
) {
  const prefix = `${ENTITY_PREFIX}sat-`;
  const dateFor = (s: State) => new Date(s.pm.orbit.missionStart.getTime() + s.localSec * 1000);

  const position = new Cesium.CallbackPositionProperty(
    (time) => {
      const s = stateFor(time as Cesium.JulianDate);
      const sp = subpointAt(s.pm.tle, dateFor(s));
      return sp ? cartesian(sp, sp.heightM) : undefined;
    },
    false,
    Cesium.ReferenceFrame.FIXED,
  );

  viewer.entities.add({
    id: `${prefix}body`,
    position,
    billboard: {
      image: SATELLITE_ICON_URL,
      width: 110,
      height: 110,
      verticalOrigin: Cesium.VerticalOrigin.CENTER,
      horizontalOrigin: Cesium.HorizontalOrigin.CENTER,
      disableDepthTestDistance: 0,
    },
    label: {
      text: new Cesium.CallbackProperty((time) => stateFor(time as Cesium.JulianDate).pm.tle.name, false) as unknown as Cesium.Property,
      font: `600 12px ${FONT}`,
      fillColor: Cesium.Color.WHITE,
      pixelOffset: new Cesium.Cartesian2(0, -54),
      showBackground: true,
      backgroundColor: Cesium.Color.fromCssColorString("#0b0d11").withAlpha(0.8),
      disableDepthTestDistance: 0,
    },
  });

  // Beam: solid pyramid satellite -> live footprint (always moves forward).
  let beamE: number | null = null;
  let beamCache: { apex: Cesium.Cartesian3; base: Cesium.Cartesian3[]; color: Cesium.Color } | null = null;

  const beamFrame = (time: Cesium.JulianDate) => {
    const e = elapsedAt(time);
    if (beamE === e) return beamCache;
    beamE = e;
    beamCache = null;

    const s = stateFor(time);
    if (!sensorOn(s.pm, s.localSec)) return null;

    const sp = subpointAt(s.pm.tle, dateFor(s));
    const r = beamRect(s.pm.leaderRects, s.localSec);
    if (!sp || !r) return null;

    beamCache = {
      apex: cartesian(sp, sp.heightM),
      base: liveRing(r, s.localSec, LIVE_BOX_HEIGHT_METERS),
      color: Cesium.Color.fromCssColorString(s.pm.accent),
    };
    return beamCache;
  };

  addBeamFrustum(viewer, prefix, beamFrame);

  // Live box riding the leading edge (keeps moving while the sensor is on).
  viewer.entities.add({
    id: `${prefix}footprint`,
    polygon: {
      hierarchy: new Cesium.CallbackProperty((time) => {
        const f = beamFrame(time as Cesium.JulianDate);
        return new Cesium.PolygonHierarchy(f ? f.base : []);
      }, false),
      material: new Cesium.ColorMaterialProperty(
        new Cesium.CallbackProperty((time) => {
          const s = stateFor(time as Cesium.JulianDate);
          const pulse = 0.82 + 0.18 * Math.sin(s.localSec / 1.2);
          return Cesium.Color.fromCssColorString(s.pm.accent).withAlpha(0.6 * pulse);
        }, false),
      ),
      outline: true,
      outlineColor: Cesium.Color.WHITE.withAlpha(0.85),
      perPositionHeight: true,
    },
  });
}

// ─── Camera: fixed framing (AOI + every orbit's rectangles) ────────────

function frameAll(viewer: Cesium.Viewer, plan: StripCapturePlanResult, timeline: OrbitModel[]) {
  const pts = [...rectangleRing(plan.bounds)];
  timeline.forEach((pm) => pm.rects.forEach((r) => r.corners.forEach((c) => pts.push(cartesian(c)))));
  const sphere = Cesium.BoundingSphere.fromPoints(pts);
  viewer.camera.flyToBoundingSphere(sphere, {
    offset: new Cesium.HeadingPitchRange(Cesium.Math.toRadians(-22), Cesium.Math.toRadians(-42), sphere.radius * 2.3),
    duration: 2.2,
    complete: () => viewer.scene.requestRender(),
  });
}

// ─── Overlays ──────────────────────────────────────────────────────────

const fmtTime = (d: Date) => d.toISOString().slice(11, 19);

function overlay(tag: string, css: string): HTMLDivElement {
  const el = document.createElement("div");
  el.className = `${OVERLAY_CLASS} ${OVERLAY_CLASS}-${tag}`;
  el.style.cssText = css;
  return el;
}

function buildBackButton(viewer: Cesium.Viewer, onClick: () => void) {
  const wrap = overlay("back", "position:absolute;top:12px;left:12px;z-index:21;");
  const btn = document.createElement("button");
  btn.type = "button";
  btn.textContent = "← Back to Globe";
  btn.style.cssText =
    `font:500 12px ${FONT};color:#e6f4ff;background:rgba(14,16,21,.9);border:1px solid rgba(255,255,255,.14);` +
    "border-radius:8px;padding:7px 13px;cursor:pointer;pointer-events:auto;box-shadow:0 4px 16px rgba(0,0,0,.5);";
  btn.addEventListener("click", onClick);
  wrap.appendChild(btn);
  viewer.container.appendChild(wrap);
}

function buildLegend(viewer: Cesium.Viewer, plan: StripCapturePlanResult, timeline: OrbitModel[]) {
  const host = document.getElementById(STRIP_VIZ_PANEL_ID);
  const legend = overlay(
    "legend",
    (host ? "" : "position:absolute;top:12px;right:12px;z-index:20;min-width:280px;pointer-events:none;") +
      `padding:12px 16px;font:13px/1.55 ${FONT};color:#e8ecf0;` +
      "background:linear-gradient(180deg,rgba(22,25,32,.85),rgba(12,14,18,.9));" +
      "border:1px solid rgba(255,255,255,.08);border-radius:10px;",
  );

  // One compact table: orbit · capture window · capture time · area added.
  const head = (t: string, right = false) =>
    `<span style="font-size:10.5px;color:#8a96a3;${right ? "text-align:right" : ""}">${t}</span>`;
  let html = `<div style="display:flex;justify-content:space-between;align-items:baseline;margin-bottom:8px">
<span style="font-weight:600;font-size:14px">Orbits</span>
<span style="font-size:12px;color:#8a96a3">AOI ${rectangleAreaKm2(plan.bounds).toLocaleString(undefined, { maximumFractionDigits: 0 })} km² · total
<strong style="color:${plan.fullyCovered ? "#6ee7b7" : "#e8ecf0"}">${formatCoveragePercent(plan.totalCoveredFraction)}</strong></span></div>
<div style="display:grid;grid-template-columns:auto 1fr auto auto;gap:4px 14px;align-items:center">
${head("Orbit")}${head("Capture window (UTC)")}${head("Time", true)}${head("Adds", true)}`;

  timeline.forEach((pm) => {
    const o = pm.orbit;
    const id = `${ENTITY_PREFIX}legend-row-${pm.orbitIndex}`;
    const cell = (inner: string, right = false) =>
      `<span class="${id}" style="opacity:.55;${right ? "text-align:right;" : ""}white-space:nowrap">${inner}</span>`;
    html +=
      cell(`<span style="display:inline-flex;align-items:center;gap:7px;font-weight:600">
<span style="width:11px;height:11px;border-radius:3px;background:${pm.accent}"></span>Orbit ${pm.orbitIndex + 1}${o.truncatedByLos ? ` <span title="LOS comes before mission end — sensor keeps capturing" style="color:#f3c46e">⚠</span>` : ""}</span>`) +
      cell(`<span style="font-family:${MONO}">${fmtTime(o.missionStart)} → ${fmtTime(o.aoiCaptureEnd)}</span>`) +
      cell(`<span style="font-family:${MONO};color:#7fe3ff">${fmtClock(Math.min(o.aoiCaptureSeconds, missionSecondsOf(o)))}</span>`, true) +
      cell(`<span style="font-family:${MONO};color:#6ee7b7">+${formatCoveragePercent(o.newlyCoveredFraction)}</span>`, true);
  });

  html += `</div>
<div style="display:flex;gap:16px;margin-top:10px;padding-top:8px;border-top:1px solid rgba(255,255,255,.08);font-size:11.5px;color:#aab4bd">
<span style="display:flex;align-items:center;gap:6px"><span style="width:18px;border-top:3px solid #4fb3e8"></span>Orbit being captured</span>
<span style="display:flex;align-items:center;gap:6px"><span style="width:18px;border-top:2px solid #fff"></span>Other orbits</span>
${plan.orbits.some((o) => o.truncatedByLos) ? `<span style="color:#f3c46e">⚠ LOS before mission end</span>` : ""}</div>`;
  legend.innerHTML = html;
  (host ?? viewer.container).appendChild(legend);
}

/** Bar layout: each orbit gets a share of the bar proportional to its animated time. */
function barLayout(timeline: OrbitModel[]) {
  const total = timeline.reduce((s, p) => s + p.animSeconds, 0) || 1;
  const map: Record<number, { left: number; width: number }> = {};
  let cum = 0;
  timeline.forEach((pm) => {
    const width = (pm.animSeconds / total) * 100;
    map[pm.orbitIndex] = { left: cum, width };
    cum += width;
  });
  return map;
}

const missionSecondsOf = (o: StripOrbit) => (o.missionEnd.getTime() - o.missionStart.getTime()) / 1000;

function buildStatusPanel(viewer: Cesium.Viewer, timeline: OrbitModel[]): StatusPanel {
  const layout = barLayout(timeline);
  return mountStatusPanel(viewer, {
    overlayClass: OVERLAY_CLASS,
    segments: timeline.map((pm) => ({
      id: String(pm.orbitIndex),
      title: `Orbit ${pm.orbitIndex + 1}`,
      subtitle: `+${formatCoveragePercent(pm.orbit.newlyCoveredFraction)}`,
      color: pm.accent,
      widthPct: layout[pm.orbitIndex].width,
    })),
    markers: [],
  });
}

function updateUi(
  plan: StripCapturePlanResult,
  timeline: OrbitModel[],
  base: number,
  s: State,
  e: number,
  totalVirtual: number,
  panel: StatusPanel,
) {
  const allDone = e >= totalVirtual - 0.01;
  const fraction = allDone ? plan.totalCoveredFraction : Math.min(1, totalFractionAt(timeline, base, e));
  const o = s.pm.orbit;
  const utc = new Date(o.missionStart.getTime() + s.localSec * 1000);
  const m = barLayout(timeline)[s.pm.orbitIndex];
  const orbitDone = s.localSec >= s.pm.t1 - 1e-3;
  const afterLos = utc.getTime() > o.los.getTime();
  panel.update({
    title: `Orbit ${s.pm.orbitIndex + 1} of ${plan.orbits.length} · ${o.leaderName}`,
    fraction: formatCoveragePercent(fraction),
    utc,
    captureSec: s.localSec,
    captureTotalSec: Math.min(o.aoiCaptureSeconds, missionSecondsOf(o)),
    activeSegmentId: String(s.pm.orbitIndex),
    playheadPct: m ? m.left + m.width * s.frac : 0,
    status: allDone ? "Plan complete" : orbitDone ? "Beam left the AOI" : afterLos ? "Past LOS" : "Capturing",
    tone: allDone || orbitDone ? "done" : afterLos ? "warn" : "live",
    times: {
      aos: o.aos,
      missionStart: o.missionStart,
      coverageDone: o.aoiCaptureEnd,
      missionEnd: o.missionEnd,
      los: o.los,
      losBeforeEnd: o.truncatedByLos,
    },
  });

  timeline.forEach((pm) => {
    const active = pm.orbitIndex === s.pm.orbitIndex;
    document.querySelectorAll<HTMLElement>(`.${ENTITY_PREFIX}legend-row-${pm.orbitIndex}`).forEach((el) => {
      el.style.opacity = active ? "1" : "0.55";
    });
  });
}

// ─── Main entry ────────────────────────────────────────────────────────

export type StripVisualizationOptions = {
  tleByName: Record<string, TleEntry>;
  /** Orbit the tour STARTS from (then continues through the rest). Default 0. */
  primaryPassIndex?: number;
};

export function visualizeStripCapture(
  viewer: Cesium.Viewer,
  planResult: StripCapturePlanResult,
  options: StripVisualizationOptions,
  callbacks?: StripVisualizationCallbacks,
) {
  if (viewer.isDestroyed() || planResult.orbits.length === 0) return;

  clearStripVisualization(viewer);

  const startIndex = Math.min(Math.max(options.primaryPassIndex ?? 0, 0), planResult.orbits.length - 1);
  const timeline = buildTimeline(planResult, options.tleByName, startIndex);
  if (timeline.length === 0 || timeline.every((p) => p.rects.length === 0)) {
    console.error("Plan has no footprints to animate.");
    return;
  }
  const base = startIndex > 0 ? planResult.orbits[startIndex - 1].cumulativeCoveredFraction : 0;

  hidePlanningEntities(viewer);

  // AOI
  viewer.entities.add({
    id: `${ENTITY_PREFIX}aoi`,
    polygon: {
      hierarchy: new Cesium.PolygonHierarchy(rectangleRing(planResult.bounds)),
      material: Cesium.Color.WHITE.withAlpha(0.035),
      outline: true,
      outlineColor: Cesium.Color.fromCssColorString("#ff5577").withAlpha(0.95),
      outlineWidth: 2,
      height: 0,
    },
  });
  viewer.entities.add({
    id: `${ENTITY_PREFIX}aoi-label`,
    position: cartesian({ lon: (planResult.bounds.west + planResult.bounds.east) / 2, lat: planResult.bounds.north }),
    label: {
      text: "AOI",
      font: `600 12px ${FONT}`,
      fillColor: Cesium.Color.WHITE,
      pixelOffset: new Cesium.Cartesian2(0, -18),
      showBackground: true,
      backgroundColor: Cesium.Color.fromCssColorString("#ff4d6d").withAlpha(0.9),
      disableDepthTestDistance: 0,
    },
  });

  // Virtual clock (real hour-long gaps between orbits are compressed).
  const epoch = Cesium.JulianDate.now();
  const totalVirtual = timeline[timeline.length - 1].virtualEnd;
  const elapsedAt = (t: Cesium.JulianDate) => Cesium.JulianDate.secondsDifference(t, epoch);
  const stateFor = makeStateGetter(timeline, elapsedAt);

  const start = Cesium.JulianDate.addSeconds(epoch, -MISSION_PRE_ROLL_SECONDS, new Cesium.JulianDate());
  viewer.clock.startTime = start.clone();
  viewer.clock.stopTime = Cesium.JulianDate.addSeconds(epoch, totalVirtual + TAIL_OUT_SECONDS, new Cesium.JulianDate());
  viewer.clock.currentTime = start.clone();
  viewer.clock.clockRange = Cesium.ClockRange.LOOP_STOP;
  viewer.clock.multiplier = CLOCK_MULTIPLIER;
  viewer.clock.shouldAnimate = true;

  addPassGraphics(viewer, timeline, elapsedAt, stateFor);
  addTravelingSatellite(viewer, stateFor, elapsedAt);

  const panel = buildStatusPanel(viewer, timeline);
  buildLegend(viewer, planResult, timeline);
  buildBackButton(viewer, () => {
    clearStripVisualization(viewer);
    callbacks?.onBack?.();
  });

  frameAll(viewer, planResult, timeline);
  vizStarted("strip-plan");

  clockTickListener = viewer.clock.onTick.addEventListener(() => {
    viewer.scene.requestRender();
    const e = elapsedAt(viewer.clock.currentTime);
    const s = stateFor(viewer.clock.currentTime);
    updateUi(planResult, timeline, base, s, e, totalVirtual, panel);
  });
}
