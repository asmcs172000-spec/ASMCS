// GeoReferenceStripModeAnimation.ts
//
// STRIP MODE — "Visualize on Map" (frequency sweep of ONE orbit, ALL satellites)
//
// SOURCE OF TRUTH  : planResult.orbits[selected].passes[].segmentBreakdown[].footprints[]
//                    (one swept rectangle per frequency segment per satellite,
//                    from GeoReferenceStripModeRange.ts)
// TIME             : t = 0 at the LEADER's mission start. Every satellite is shown
//                    at its real TLE position at that same real time; a member's
//                    rectangles are shifted by its offset from the leader.
//                    The sensor runs for the whole frequency plan (mission end);
//                    LOS before mission end is shown as an alert only.
// SATELLITES       : real TLE positions (marker + COMPLETE solid coloured ground track)
// SENSOR BEAMS     : real satellite -> leading edge of ITS OWN planner rectangle,
//                    extrapolated before / after the rectangle so the sensor never stops
// FOOTPRINTS       : full planned band (dark) + growing "captured" part + live box,
//                    coloured by FREQUENCY segment
// FREQUENCY / TIME : bottom bar = frequency segments over the mission, with playhead
// AREA CAPTURED %  : AOI covered so far (earlier orbits + this orbit's new area)
//
// Planner corner order for each footprint:
//   [0] alongMin/crossMin  [1] alongMin/crossMax
//   [2] alongMax/crossMax  [3] alongMax/crossMin
// "Reveal" moves the end edge from (0,1) towards (3,2).

import * as Cesium from "cesium";
import * as satellite from "satellite.js";

import { FREQUENCY_PRESETS, type FrequencySegment } from "./FrequencyAndTime";
import { fallbackColorForName, OTHER_SAT_FALLBACK_COLORS, type TleEntry } from "./satelliteRangeUtils";
import {
  formatCoveragePercent,
  type StripCapturePlanResult,
  type StripOrbit,
  type StripPass,
} from "./GeoReferenceStripModeRange";
import { STRIP_VIZ_PANEL_ID, addBeamFrustum, mountStatusPanel, type StatusPanel } from "./stripVizPanel";
import { isVizPaused, vizStarted, vizStopped } from "./vizPlayback";

const ENTITY_PREFIX = "strip-real-viz-";
const OVERLAY_CLASS = "strip-real-viz-overlay";
const SATELLITE_ICON_URL = "/satellite.png";
const FONT = `"Roboto", "Segoe UI", system-ui, sans-serif`;
const MONO = `"Roboto Mono", ui-monospace, Consolas, monospace`;

const STRIP_SECONDS_PER_REAL_SECOND = 22;
const TRACK_PAD_SECONDS = 240;
const TRACK_STEP_SECONDS = 10;
const SECONDARY_ALPHA_SCALE = 0.85;
const SHARED_BAND_HEIGHT_METERS = 5;
const COMBINED_COVERAGE_HEIGHT_METERS = 300;
/** Half along-track length of the moving live footprint (= beam base), km. */
const FOOTPRINT_HALF_LENGTH_KM = 14;
const PER_SATELLITE_FOOTPRINT_BASE_HEIGHT_METERS = 220;
const PER_SATELLITE_FOOTPRINT_HEIGHT_STEP_METERS = 18;

type Bounds = StripCapturePlanResult["bounds"];
type LatLon = { lat: number; lon: number };
type Subpoint = LatLon & { heightM: number };

type SatelliteRuntime = {
  tle: TleEntry;
  satrec: satellite.SatRec;
  color: string;
  isPrimary: boolean;
};

let rafHandle: number | null = null;
let hiddenPlanningEntityIds: string[] = [];
const satrecCache = new Map<string, satellite.SatRec>();

const toRad = (d: number) => (d * Math.PI) / 180;
const clamp01 = (x: number) => Math.min(1, Math.max(0, x));

// ============================================================================
// SATELLITE PROPAGATION (real TLE)
// ============================================================================

function satrecFor(tle: TleEntry): satellite.SatRec {
  const key = `${tle.tle1}|${tle.tle2}`;
  const cached = satrecCache.get(key);
  if (cached) return cached;
  const rec = satellite.twoline2satrec(tle.tle1, tle.tle2);
  satrecCache.set(key, rec);
  return rec;
}

function subpointAt(rec: satellite.SatRec, date: Date): Subpoint | null {
  const pv = satellite.propagate(rec, date);
  if (!pv?.position || typeof pv.position === "boolean") return null;
  const geo = satellite.eciToGeodetic(pv.position, satellite.gstime(date));
  return {
    lon: satellite.degreesLong(geo.longitude),
    lat: satellite.degreesLat(geo.latitude),
    heightM: geo.height * 1000,
  };
}

/** Short ground track (used only for camera framing). */
function sampleRealGroundTrack(
  record: satellite.SatRec, missionStart: Date, fromSeconds: number, toSeconds: number,
): Cesium.Cartesian3[] {
  const pts: Cesium.Cartesian3[] = [];
  const duration = Math.max(0, toSeconds - fromSeconds);
  const steps = Math.max(32, Math.ceil(duration / TRACK_STEP_SECONDS));
  for (let i = 0; i <= steps; i++) {
    const elapsed = fromSeconds + (duration * i) / steps;
    const current = subpointAt(record, new Date(missionStart.getTime() + elapsed * 1000));
    if (current) pts.push(cartesian(current));
  }
  return pts;
}

/** One COMPLETE orbit (full revolution around the globe) centred on `center`. */
function sampleFullOrbitTrack(record: satellite.SatRec, center: Date, points = 400): Cesium.Cartesian3[] {
  const noRadPerMin = record.no;
  const periodSec =
    Number.isFinite(noRadPerMin) && noRadPerMin > 0 ? ((2 * Math.PI) / noRadPerMin) * 60 : 95 * 60;
  const startMs = center.getTime() - (periodSec * 1000) / 2;
  const pts: Cesium.Cartesian3[] = [];
  for (let i = 0; i <= points; i++) {
    const sp = subpointAt(record, new Date(startMs + (periodSec * 1000 * i) / points));
    if (sp) pts.push(cartesian(sp));
  }
  return pts;
}

// ============================================================================
// CESIUM HELPERS
// ============================================================================

function cartesian(p: LatLon, heightM = 0): Cesium.Cartesian3 {
  return Cesium.Cartesian3.fromDegrees(p.lon, p.lat, heightM);
}

function rectangleRing(bounds: Bounds): Cesium.Cartesian3[] {
  return [
    cartesian({ lon: bounds.west, lat: bounds.north }),
    cartesian({ lon: bounds.east, lat: bounds.north }),
    cartesian({ lon: bounds.east, lat: bounds.south }),
    cartesian({ lon: bounds.west, lat: bounds.south }),
  ];
}

// ============================================================================
// PLANNER RECTANGLES  (exact geometry from the range code)
// ============================================================================

type PlannerRect = {
  satelliteName: string;
  segIndex: number;
  color: string;
  /** Leader-relative mission seconds at which the sensor reaches the two ends. */
  startSec: number;
  endSec: number;
  corners: LatLon[]; // 4 planner corners, see header
};

type PlannerMember = { pass: StripPass; offsetSec: number };

type PlannerModel = {
  rects: PlannerRect[];
  bySat: Map<string, PlannerRect[]>;
  members: PlannerMember[];
  /** AOI fraction already covered before this orbit. */
  baseFraction: number;
  finalFraction: number;
};

function buildPlannerModel(orbit: StripOrbit, baseFraction: number): PlannerModel {
  const rects: PlannerRect[] = [];
  const leaderMs = orbit.missionStart.getTime();
  const members: PlannerMember[] = orbit.passes.map((pass) => ({
    pass,
    offsetSec: (pass.missionStart.getTime() - leaderMs) / 1000,
  }));

  for (const { pass, offsetSec } of members) {
    pass.segmentBreakdown.forEach((seg, segIndex) => {
      const preset = FREQUENCY_PRESETS[seg.presetId];
      if (!preset) return;
      for (const fp of seg.footprints) {
        if (!fp.corners || fp.corners.length < 4) continue;
        rects.push({
          satelliteName: fp.satelliteName,
          segIndex,
          color: preset.color,
          startSec: offsetSec + fp.tStartSec,
          endSec: offsetSec + fp.tEndSec,
          corners: fp.corners.slice(0, 4),
        });
      }
    });
  }

  const bySat = new Map<string, PlannerRect[]>();
  for (const r of rects) {
    const list = bySat.get(r.satelliteName) ?? [];
    list.push(r);
    bySat.set(r.satelliteName, list);
  }
  bySat.forEach((list) => list.sort((a, b) => a.startSec - b.startSec));

  return { rects, bySat, members, baseFraction, finalFraction: orbit.cumulativeCoveredFraction };
}

const lerpLL = (a: LatLon, b: LatLon, f: number): LatLon => ({
  lat: a.lat + (b.lat - a.lat) * f,
  lon: a.lon + (b.lon - a.lon) * f,
});

/** Progress 0..1 of a rectangle's reveal at mission time `e`. */
function progressOf(r: PlannerRect, e: number): number {
  return clamp01(rawProgressOf(r, e));
}
/** UNclamped progress: < 0 before the rectangle, > 1 after it (beam keeps moving). */
function rawProgressOf(r: PlannerRect, e: number): number {
  return (e - r.startSec) / Math.max(0.001, r.endSec - r.startSec);
}

/** The two ends (cross-min side, cross-max side) of the line at fraction f (f may extrapolate). */
function edgeAt(r: PlannerRect, f: number): { left: LatLon; right: LatLon } {
  const c = r.corners;
  return { left: lerpLL(c[0], c[3], f), right: lerpLL(c[1], c[2], f) };
}

/** Polygon covering the part of the rectangle between fractions f0..f1 (clamped to the rectangle). */
function ringBetween(r: PlannerRect, f0: number, f1: number, heightM: number): Cesium.Cartesian3[] {
  const a = clamp01(Math.min(f0, f1));
  const b = clamp01(Math.max(f0, f1));
  if (b - a < 1e-6) return [];
  return ringRaw(r, a, b, heightM);
}

/** Same, NOT clamped: used for the live box so it keeps moving before / after the rectangle. */
function ringRaw(r: PlannerRect, a: number, b: number, heightM: number): Cesium.Cartesian3[] {
  const s = edgeAt(r, a);
  const t = edgeAt(r, b);
  return [cartesian(s.left, heightM), cartesian(s.right, heightM), cartesian(t.right, heightM), cartesian(t.left, heightM)];
}

/** Along-track length of a rectangle (km). */
function rectAlongKm(r: PlannerRect): number {
  const a = r.corners[0];
  const b = r.corners[3];
  const dy = (b.lat - a.lat) * 111.32;
  const dx = (b.lon - a.lon) * 111.32 * Math.cos(toRad((a.lat + b.lat) / 2));
  return Math.max(1e-3, Math.hypot(dx, dy));
}

/** Rectangle a satellite is using at time e (active, else most recent, else first). */
function currentRect(list: PlannerRect[] | undefined, e: number): PlannerRect | null {
  if (!list || list.length === 0) return null;
  const active = list.find((r) => e >= r.startSec && e < r.endSec);
  if (active) return active;
  let last: PlannerRect | null = null;
  for (const r of list) if (r.endSec <= e) last = r;
  return last ?? list[0];
}

/** Total AOI covered at leader time `e`: earlier orbits + each member's NEW area so far. */
function coverageFractionAt(m: PlannerModel, e: number): number {
  let total = m.baseFraction;
  for (const { pass, offsetSec } of m.members) {
    const c = pass.newCoverageCurve;
    if (!c || c.length === 0 || e <= offsetSec) continue;
    const x = Math.min(e - offsetSec, c.length - 1);
    const i = Math.floor(x);
    const j = Math.min(c.length - 1, i + 1);
    total += c[i] + (c[j] - c[i]) * (x - i);
  }
  return Math.min(total, m.finalFraction);
}

// ============================================================================
// HIDE / RESTORE PLANNING ENTITIES
// ============================================================================

function hidePlanningEntities(viewer: Cesium.Viewer) {
  hiddenPlanningEntityIds = [];
  for (const e of viewer.entities.values) {
    const id = typeof e.id === "string" ? e.id : "";
    if (id.startsWith(ENTITY_PREFIX)) continue;
    if (!(e.billboard || e.point || e.label || e.model || e.path || e.polyline || e.polygon)) continue;
    hiddenPlanningEntityIds.push(id);
    e.show = false;
  }
}

function restorePlanningEntities(viewer?: Cesium.Viewer) {
  if (viewer && !viewer.isDestroyed()) {
    for (const id of hiddenPlanningEntityIds) {
      const e = viewer.entities.getById(id);
      if (e) e.show = true;
    }
    viewer.scene.requestRender();
  }
  hiddenPlanningEntityIds = [];
}

export type StripFrequencyCallbacks = { onBack?: () => void };

export function clearStripFrequencyVisualization(viewer: Cesium.Viewer) {
  vizStopped("strip-frequency");
  if (rafHandle !== null) {
    cancelAnimationFrame(rafHandle);
    rafHandle = null;
  }
  document.querySelectorAll(`.${OVERLAY_CLASS}`).forEach((el) => el.remove());
  if (viewer.isDestroyed()) {
    restorePlanningEntities();
    return;
  }
  for (const e of [...viewer.entities.values]) {
    if (e.id?.toString().startsWith(ENTITY_PREFIX)) viewer.entities.remove(e);
  }
  restorePlanningEntities(viewer);
}

// ============================================================================
// PLANNED BANDS + GROWING "CAPTURED" PART  (one set per planner rectangle)
// ============================================================================

function addPlannerBands(viewer: Cesium.Viewer, model: PlannerModel, elapsedSecondsNow: () => number) {
  model.rects.forEach((r, i) => {
    const baseColor = Cesium.Color.fromCssColorString(r.color);
    const darkFill = Cesium.Color.multiplyByScalar(baseColor, 0.55, new Cesium.Color()).withAlpha(0.75);
    const glowOutline = Cesium.Color.multiplyByScalar(baseColor, 1.3, new Cesium.Color()).withAlpha(1);
    const coveredFill = Cesium.Color.multiplyByScalar(baseColor, 1.15, new Cesium.Color()).withAlpha(0.6);

    const fullRing = ringBetween(r, 0, 1, SHARED_BAND_HEIGHT_METERS);
    if (fullRing.length === 0) return;

    viewer.entities.add({
      id: `${ENTITY_PREFIX}band-glow-${i}`,
      polygon: {
        hierarchy: new Cesium.PolygonHierarchy(fullRing),
        material: baseColor.withAlpha(0.18),
        perPositionHeight: true,
      },
    });

    viewer.entities.add({
      id: `${ENTITY_PREFIX}band-${i}`,
      polygon: {
        hierarchy: new Cesium.PolygonHierarchy(fullRing),
        material: darkFill,
        outline: true,
        outlineColor: glowOutline,
        outlineWidth: 3,
        perPositionHeight: true,
      },
    });

    viewer.entities.add({
      id: `${ENTITY_PREFIX}band-covered-${i}`,
      polygon: {
        hierarchy: new Cesium.CallbackProperty(() => {
          const e = elapsedSecondsNow();
          if (e <= r.startSec) return new Cesium.PolygonHierarchy([]);
          return new Cesium.PolygonHierarchy(ringBetween(r, 0, progressOf(r, e), SHARED_BAND_HEIGHT_METERS));
        }, false),
        material: coveredFill,
        perPositionHeight: true,
      },
    });
  });
}

// ============================================================================
// SATELLITE: marker + beam + live footprint + real ground track
// ============================================================================

function addStripSweepSatellite(
  viewer: Cesium.Viewer,
  cfg: {
    runtime: SatelliteRuntime;
    missionStart: Date;
    missionDurationSec: number;
    /** The beam is switched off once the formation leaves the AOI. */
    sensorEndSec: number;
    model: PlannerModel;
    elapsedSecondsNow: () => number;
    index: number;
  },
) {
  const { runtime, missionStart, missionDurationSec, sensorEndSec, model, elapsedSecondsNow, index } = cfg;
  const safeName = runtime.tle.name.replace(/[^a-zA-Z0-9_-]/g, "_");
  const prefix = `${ENTITY_PREFIX}${safeName}-`;
  const alpha = (a: number) => (runtime.isPrimary ? a : a * SECONDARY_ALPHA_SCALE);
  const myRects = model.bySat.get(runtime.tle.name);

  // ---- REAL satellite position (TLE, never moved toward the AOI) ------------
  const satellitePositionAt = (elapsedSec: number): Cesium.Cartesian3 | null => {
    const current = subpointAt(runtime.satrec, new Date(missionStart.getTime() + elapsedSec * 1000));
    return current ? cartesian(current, current.heightM) : null;
  };

  viewer.entities.add({
    id: `${prefix}body`,
    position: new Cesium.CallbackPositionProperty(
      () => satellitePositionAt(elapsedSecondsNow()) ?? undefined,
      false,
      Cesium.ReferenceFrame.FIXED,
    ),
    billboard: {
      image: SATELLITE_ICON_URL,
      width: runtime.isPrimary ? 112 : 82,
      height: runtime.isPrimary ? 112 : 82,
      verticalOrigin: Cesium.VerticalOrigin.CENTER,
      horizontalOrigin: Cesium.HorizontalOrigin.CENTER,
      disableDepthTestDistance: 0,
    },
    label: {
      text: runtime.tle.name,
      font: runtime.isPrimary ? `600 12px ${FONT}` : `11px ${FONT}`,
      fillColor: Cesium.Color.fromCssColorString(runtime.color),
      showBackground: true,
      backgroundColor: Cesium.Color.fromCssColorString("#0b0d11").withAlpha(0.85),
      pixelOffset: new Cesium.Cartesian2(0, runtime.isPrimary ? -54 : -40 - index * 4),
      disableDepthTestDistance: 0,
    },
  });

  // The sensor works from mission start until mission end (never stopped by LOS).
  const sensorOn = (e: number) => !!myRects && myRects.length > 0 && e < sensorEndSec - 1e-3;

  // ---- Live footprint riding the leading edge (keeps moving, frequency colour) ---
  const footprintHeightM =
    PER_SATELLITE_FOOTPRINT_BASE_HEIGHT_METERS + index * PER_SATELLITE_FOOTPRINT_HEIGHT_STEP_METERS;
  const liveRing = (heightM: number) => {
    const e = elapsedSecondsNow();
    if (!sensorOn(e)) return [];
    const r = currentRect(myRects, e);
    if (!r) return [];
    // Unclamped: before / after the rectangle the footprint keeps moving with the satellite.
    const f = rawProgressOf(r, e);
    const w = FOOTPRINT_HALF_LENGTH_KM / rectAlongKm(r);
    return ringRaw(r, f - w, f + w, heightM);
  };

  // ---- Sensor beam: solid pyramid satellite -> live footprint, frequency colour ---
  let cachedElapsed: number | null = null;
  let cachedFrame: { apex: Cesium.Cartesian3; base: Cesium.Cartesian3[]; color: Cesium.Color } | null = null;
  const beamFrame = () => {
    const elapsed = elapsedSecondsNow();
    if (cachedElapsed === elapsed) return cachedFrame;
    cachedElapsed = elapsed;
    cachedFrame = null;
    const apex = sensorOn(elapsed) ? satellitePositionAt(elapsed) : null;
    const r = currentRect(myRects, elapsed);
    const base = liveRing(footprintHeightM);
    if (!apex || !r || base.length < 4) return null;
    cachedFrame = { apex, base, color: Cesium.Color.fromCssColorString(r.color) };
    return cachedFrame;
  };
  addBeamFrustum(viewer, prefix, beamFrame, { strength: runtime.isPrimary ? 1.1 : 0.85 });

  viewer.entities.add({
    id: `${prefix}footprint`,
    polygon: {
      hierarchy: new Cesium.CallbackProperty(() => new Cesium.PolygonHierarchy(liveRing(footprintHeightM)), false),
      material: new Cesium.ColorMaterialProperty(
        new Cesium.CallbackProperty(() => {
          const e = elapsedSecondsNow();
          const r = currentRect(myRects, e);
          if (!r) return Cesium.Color.WHITE.withAlpha(0);
          const pulse = 0.82 + 0.18 * Math.sin(e / 1.2 + index * 0.6);
          return Cesium.Color.fromCssColorString(r.color).withAlpha(alpha(0.6 * pulse));
        }, false),
      ),
      outline: true,
      outlineColor: Cesium.Color.fromCssColorString(runtime.isPrimary ? "#ffffff" : runtime.color).withAlpha(alpha(0.9)),
      perPositionHeight: true,
    },
  });

  // ---- Combined-coverage pulse (white), one live window per satellite --------
  if (model.bySat.size > 1) {
    viewer.entities.add({
      id: `${prefix}combined-coverage`,
      polygon: {
        hierarchy: new Cesium.CallbackProperty(
          () => new Cesium.PolygonHierarchy(liveRing(COMBINED_COVERAGE_HEIGHT_METERS)),
          false,
        ),
        material: new Cesium.ColorMaterialProperty(
          new Cesium.CallbackProperty(() => {
            const pulse = 0.35 + 0.35 * (0.5 + 0.5 * Math.sin(elapsedSecondsNow() / 0.8));
            return Cesium.Color.WHITE.withAlpha(pulse);
          }, false),
        ),
        outline: true,
        outlineColor: Cesium.Color.WHITE.withAlpha(0.95),
        outlineWidth: 2,
        perPositionHeight: true,
      },
    });
  }

  // ---- COMPLETE ground track: full orbit, solid, in the satellite's colour ----
  viewer.entities.add({
    id: `${prefix}real-track`,
    polyline: {
      positions: sampleFullOrbitTrack(
        runtime.satrec,
        new Date(missionStart.getTime() + (missionDurationSec / 2) * 1000),
      ),
      width: runtime.isPrimary ? 3.5 : 2.5,
      clampToGround: true,
      material: Cesium.Color.fromCssColorString(runtime.color).withAlpha(alpha(1)),
    },
  });
}

// ============================================================================
// FORMAT
// ============================================================================

function formatDuration(sec: number) {
  const s = Math.max(0, Math.round(sec));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
}


function fmtOffset(ms: number) {
  const s = Math.round(Math.abs(ms) / 1000);
  return `${ms < 0 ? "−" : "+"}${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
}

// ============================================================================
// OVERLAY  (legend goes under the globe when the panel host exists)
// ============================================================================

function addOverlay(
  viewer: Cesium.Viewer, orbit: StripOrbit, segments: FrequencySegment[], runtimes: SatelliteRuntime[],
) {
  const used = [...new Set(segments.map((s) => s.presetId))];
  const host = document.getElementById(STRIP_VIZ_PANEL_ID);

  const legend = document.createElement("div");
  legend.className = OVERLAY_CLASS;
  legend.style.cssText =
    (host
      ? ""
      : "position:absolute;top:12px;right:12px;z-index:20;min-width:260px;pointer-events:none;") +
    "padding:12px 16px;border:1px solid rgba(255,255,255,.08);border-radius:10px;" +
    "background:linear-gradient(180deg,rgba(22,25,32,.85),rgba(12,14,18,.9));" +
    `color:#e8ecf0;font:13px/1.55 ${FONT};`;

  // Times live in the status panel above; this legend only explains colours.
  const head = (t: string, right = false) =>
    `<span style="font-size:10.5px;color:#8a96a3;${right ? "text-align:right" : ""}">${t}</span>`;
  const members = orbit.passes
    .map((p) => {
      const color = runtimes.find((r) => r.tle.name === p.satelliteName)?.color ?? "#5fd4ff";
      return `<span style="display:flex;align-items:center;gap:7px;font-weight:500;white-space:nowrap">
<span style="width:8px;height:8px;border-radius:50%;background:${color}"></span>${p.satelliteName}${p.truncatedByLos ? ` <span title="LOS before mission end" style="color:#f3c46e">⚠</span>` : ""}</span>
<span style="font-family:${MONO};color:#aab4bd">${p.isLeader ? "leader" : fmtOffset(p.offsetFromLeaderMs)}</span>
<span style="font-family:${MONO};color:#7fe3ff;text-align:right">${formatDuration(Math.min(p.aoiCaptureSeconds, p.missionSeconds))}</span>
<span style="font-family:${MONO};color:#6ee7b7;text-align:right">+${formatCoveragePercent(p.newlyCoveredFraction)}</span>`;
    })
    .join("");

  legend.innerHTML = `
<div style="font-weight:600;font-size:14px;margin-bottom:8px">Frequencies</div>
<div style="display:flex;flex-wrap:wrap;gap:6px 14px;margin-bottom:12px">
${used.map((id) => {
  const p = FREQUENCY_PRESETS[id];
  return p
    ? `<span style="display:flex;align-items:center;gap:7px;font-size:12.5px"><span style="width:12px;height:12px;border-radius:3px;background:${p.color}"></span>${p.label} <span style="color:#8a96a3">${p.swathKm} km swath</span></span>`
    : "";
}).join("")}
</div>
<div style="font-weight:600;font-size:14px;margin-bottom:6px">Satellites</div>
<div style="display:grid;grid-template-columns:1fr auto auto auto;gap:4px 14px;align-items:center;font-size:12.5px">
${head("Name")}${head("Offset")}${head("Time", true)}${head("Adds", true)}
${members}
</div>
${orbit.truncatedByLos ? `<div style="margin-top:10px;font-size:11.5px;color:#f3c46e">⚠ LOS comes before mission end — sensor keeps capturing.</div>` : ""}`;
  (host ?? viewer.container).appendChild(legend);

  const back = document.createElement("button");
  back.type = "button";
  back.className = OVERLAY_CLASS;
  back.textContent = "← Back to Globe";
  back.style.cssText =
    "position:absolute;left:12px;top:12px;z-index:22;padding:7px 13px;" +
    "border:1px solid rgba(255,255,255,.14);border-radius:8px;background:rgba(14,16,21,.9);" +
    `color:#eaf6ff;font:500 12px ${FONT};cursor:pointer`;
  viewer.container.appendChild(back);

  return back;
}

// ============================================================================
// BOTTOM SEGMENT BAR  (frequency segments over time + playhead)
// ============================================================================

/** Readout + frequency / time bar UNDER the globe (segments = frequency plan of the leader). */
function buildFrequencyStatusPanel(
  viewer: Cesium.Viewer, orbit: StripOrbit, segments: FrequencySegment[], barDurationSec: number,
): StatusPanel {
  const aoiSec = Math.min(orbit.aoiCaptureSeconds, barDurationSec);
  return mountStatusPanel(viewer, {
    overlayClass: OVERLAY_CLASS,
    segments: segments
      .filter((seg) => FREQUENCY_PRESETS[seg.presetId])
      .map((seg) => {
        const p = FREQUENCY_PRESETS[seg.presetId];
        return {
          id: seg.id,
          title: p.label,
          subtitle: `${formatDuration(seg.startSeconds)}–${formatDuration(seg.startSeconds + seg.durationSeconds)}`,
          color: p.color,
          widthPct: (seg.durationSeconds / barDurationSec) * 100,
        };
      }),
    markers: aoiSec < barDurationSec - 1
      ? [{ leftPct: (aoiSec / barDurationSec) * 100, label: `Coverage done ${formatDuration(aoiSec)}` }]
      : [],
  });
}

function activeSegmentId(segments: FrequencySegment[], e: number): string | null {
  const s = segments.find((x) => e >= x.startSeconds && e < x.startSeconds + x.durationSeconds);
  return (s ?? segments[segments.length - 1])?.id ?? null;
}

// ============================================================================
// MAIN VISUALIZATION
// ============================================================================

export type StripFrequencyOptions = {
  tleByName: Record<string, TleEntry>;
  /** Orbit to show (index into planResult.orbits). Default 0 = first orbit. */
  primaryPassIndex?: number;
};

export function visualizeStripFrequencySweep(
  viewer: Cesium.Viewer,
  planResult: StripCapturePlanResult,
  segments: FrequencySegment[],
  options: StripFrequencyOptions,
  callbacks?: StripFrequencyCallbacks,
) {
  if (viewer.isDestroyed() || planResult.orbits.length === 0) return;

  clearStripFrequencyVisualization(viewer);

  const orbitIndex = Math.min(Math.max(options.primaryPassIndex ?? 0, 0), planResult.orbits.length - 1);
  const orbit = planResult.orbits[orbitIndex];
  if (!options.tleByName[orbit.leaderName]) {
    console.error(`No TLE found for orbit leader: ${orbit.leaderName}`);
    return;
  }

  // Leader time 0 .. last satellite's mission end (sensor runs the full frequency plan).
  const leaderMs = orbit.missionStart.getTime();
  const missionDurationSec = Math.max(
    ...orbit.passes.map((p) => (p.missionStart.getTime() - leaderMs) / 1000 + p.captureSeconds),
  );
  if (missionDurationSec <= 0) return;
  const barDurationSec = Math.max(missionDurationSec, planResult.missionSeconds);
  /** The animation ends when the formation's beams leave the AOI. */
  const endSec = Math.max(1, Math.min(missionDurationSec, orbit.aoiCaptureSeconds));

  const baseFraction = orbitIndex > 0 ? planResult.orbits[orbitIndex - 1].cumulativeCoveredFraction : 0;
  const model = buildPlannerModel(orbit, baseFraction);
  if (model.rects.length === 0) {
    console.error("Planner orbit has no footprints to animate.");
    return;
  }

  hidePlanningEntities(viewer);

  // All satellites of the constellation group; the leader is the primary one.
  const runtimes: SatelliteRuntime[] = Object.values(options.tleByName).map((tle) => ({
    tle,
    satrec: satrecFor(tle),
    color: tle.color ?? fallbackColorForName(tle.name, OTHER_SAT_FALLBACK_COLORS),
    isPrimary: tle.name === orbit.leaderName,
  }));
  runtimes.sort((a, b) => Number(b.isPrimary) - Number(a.isPrimary));

  // ---- AOI -------------------------------------------------------------------
  viewer.entities.add({
    id: `${ENTITY_PREFIX}aoi`,
    polygon: {
      hierarchy: new Cesium.PolygonHierarchy(rectangleRing(planResult.bounds)),
      material: Cesium.Color.WHITE.withAlpha(0.035),
      outline: true,
      outlineColor: Cesium.Color.fromCssColorString("#ff5577").withAlpha(0.95),
      outlineWidth: 2,
      height: 0,
    },
  });

  viewer.entities.add({
    id: `${ENTITY_PREFIX}aoi-label`,
    position: cartesian({
      lon: (planResult.bounds.west + planResult.bounds.east) / 2,
      lat: planResult.bounds.north,
    }),
    label: {
      text: "AOI",
      font: `600 12px ${FONT}`,
      fillColor: Cesium.Color.WHITE,
      showBackground: true,
      backgroundColor: Cesium.Color.fromCssColorString("#ff4d6d").withAlpha(0.9),
      pixelOffset: new Cesium.Cartesian2(0, -18),
    },
  });

  // ---- animation clock -------------------------------------------------------
  let elapsedAnimationSeconds = 0;
  const elapsedSecondsNow = () => elapsedAnimationSeconds;

  addPlannerBands(viewer, model, elapsedSecondsNow);

  const trackPositionsBySat: Cesium.Cartesian3[][] = [];

  runtimes.forEach((runtime, index) => {
    addStripSweepSatellite(viewer, {
      runtime,
      missionStart: orbit.missionStart,
      missionDurationSec,
      sensorEndSec: endSec,
      model,
      elapsedSecondsNow,
      index,
    });
    // Short track only for camera framing (the drawn track is the full orbit).
    trackPositionsBySat.push(
      sampleRealGroundTrack(runtime.satrec, orbit.missionStart, -TRACK_PAD_SECONDS, missionDurationSec + TRACK_PAD_SECONDS),
    );
  });

  // ---- UI --------------------------------------------------------------------
  const back = addOverlay(viewer, orbit, segments, runtimes);
  back.addEventListener("click", () => {
    clearStripFrequencyVisualization(viewer);
    callbacks?.onBack?.();
  });
  const panel = buildFrequencyStatusPanel(viewer, orbit, segments, barDurationSec);
  const losSec = (orbit.los.getTime() - orbit.missionStart.getTime()) / 1000;

  // ---- animation loop: runs until the beams leave the AOI ---------------------
  let lastFrameTimestamp: number | null = null;

  const frame = (timestamp: number) => {
    if (lastFrameTimestamp !== null && !isVizPaused()) {
      const deltaSeconds = Math.min((timestamp - lastFrameTimestamp) / 1000, 0.05);
      elapsedAnimationSeconds = Math.min(endSec, elapsedAnimationSeconds + deltaSeconds * STRIP_SECONDS_PER_REAL_SECOND);
    }
    lastFrameTimestamp = timestamp;

    const e = elapsedAnimationSeconds;
    const done = e >= endSec;
    const afterLos = e > losSec;

    // AREA captured (planner's numbers) — NOT elapsed-time %.
    panel.update({
      title: `Orbit ${orbit.index + 1} · ${orbit.passes.length} satellites · leader ${orbit.leaderName}`,
      fraction: formatCoveragePercent(done ? model.finalFraction : coverageFractionAt(model, e)),
      utc: new Date(orbit.missionStart.getTime() + e * 1000),
      captureSec: e,
      captureTotalSec: endSec,
      activeSegmentId: activeSegmentId(segments, e),
      playheadPct: clamp01(e / barDurationSec) * 100,
      status: done ? "Beam left the AOI" : isVizPaused() ? "Paused" : afterLos ? "Past LOS" : "Capturing",
      tone: done ? "done" : afterLos || isVizPaused() ? "warn" : "live",
      times: {
        aos: orbit.aos,
        missionStart: orbit.missionStart,
        coverageDone: orbit.aoiCaptureEnd,
        missionEnd: orbit.missionEnd,
        los: orbit.los,
        losBeforeEnd: orbit.truncatedByLos,
      },
    });
    viewer.scene.requestRender();

    if (!done) rafHandle = requestAnimationFrame(frame);
  };

  rafHandle = requestAnimationFrame(frame);
  vizStarted("strip-frequency");

  // ---- camera: ground tracks + AOI + every planner rectangle ------------------
  const framingPoints = trackPositionsBySat.flat();
  framingPoints.push(...rectangleRing(planResult.bounds));
  model.rects.forEach((r) => framingPoints.push(...r.corners.map((c) => cartesian(c))));

  if (framingPoints.length > 0) {
    const sphere = Cesium.BoundingSphere.fromPoints(framingPoints);
    viewer.camera.flyToBoundingSphere(sphere, {
      offset: new Cesium.HeadingPitchRange(Cesium.Math.toRadians(-22), Cesium.Math.toRadians(-43), sphere.radius * 2.15),
      duration: 2,
      complete: () => viewer.scene.requestRender(),
    });
  }
}
