// areaFromBounds.ts
//
// Single source of truth for "how big is the rectangle the user drew".
// Uses the spherical-earth formula for a lat/lon box, so the number shown
// in the panel is exactly the number the animation will fill toward.

const EARTH_RADIUS_KM = 6371.0088;
const toRad = (d: number) => (d * Math.PI) / 180;

export function rectangleAreaKm2(bounds: {
  north: number;
  south: number;
  east: number;
  west: number;
}): number {
  const dLonRad = toRad(Math.abs(bounds.east - bounds.west));
  return (
    EARTH_RADIUS_KM ** 2 *
    dLonRad *
    Math.abs(Math.sin(toRad(bounds.north)) - Math.sin(toRad(bounds.south)))
  );
}