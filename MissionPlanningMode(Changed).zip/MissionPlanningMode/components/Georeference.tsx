import { useEffect, useMemo, useRef, useState } from "react";
import { ChevronDown, Satellite as SatelliteIcon, Radio, Crosshair, AlertCircle, SlidersHorizontal, MapPin, Square, Waypoints, Play, Pause, Info } from "lucide-react";
import * as Cesium from "cesium";
import { useTargetPicker, type RectangleBounds } from "./useTargetPicker";
import StripMode from "./GeoReferenceStripMode";
import { clearStripVisualization } from "./GeoReferenceStripOrbitPlanAnimation";
import {
  visualizeStripFrequencySweep,
  clearStripFrequencyVisualization,
} from "./GeoReferenceStripModeAnimation";
import {
  visualizeSpotFrequencyPlan,
  clearSpotFrequencyVisualization,
  showSpotOrbitPreview,
  clearSpotOrbitPreview,
  type SpotSatelliteInput,
  type SpotPassPlan,
} from "./spotAnimation";
import { stripGateSummary, type StripCapturePlanResult } from "./GeoReferenceStripModeRange";
import {
  findPasses,
  findSpotOrbits,
  planMissionAcrossPasses,
  missionDurationFromSegments,
  deriveSpotLimit,
  defaultSpotLimitValue,
  spotLimitBounds,
  ORBIT_HEIGHT_KM,
  DEFAULT_SPOT_LIMIT,
  DUMMY_AOS_LEAD_MINUTES,
  formatUtc,
  fallbackColorForName,
  OTHER_SAT_FALLBACK_COLORS,
  DEFAULT_GROUND_STATIONS,
  MIN_LINK_RANGE_KM,
  MAX_LINK_RANGE_KM,
  type TleEntry,
  type GroundStation,
  type GroundPoint,
  type SpotOrbit,
  type SpotLimitMode,
  type SpotLimitGeometry,
} from "./SpotModeRange";
import { FrequencyPlanTable, FrequencyVisualizeNav, MIN_FREQUENCY_SWATH_KM, type FrequencySegment } from "./FrequencyAndTime";
import {
  ACCURACY_DEBUG,
  ACCURACY_STEP_DEFAULT_KM,
  ACCURACY_STEP_MAX_KM,
  ACCURACY_STEP_MIN_KM,
  ACCURACY_COLOR_LEGEND,
  accuracyColor,
  accuracySwathBounds,
  createAccuracyGrid,
  effectiveAccuracyStepKm,
  estimateGeolocationAccuracyAsync,
  formatAccuracy,
  type AccuracySample,
} from "./geolocationAccuracy";
import { startGeolocationAnimation } from "./geolocationAnimation";
import { setVizPaused, useVizPlayback } from "./vizPlayback";
import GeoSpotModeLosResolutionBox, { type LosChoice } from "./GeoSpotModeLosResolutionBox";

const ORBIT_SCAN_HOURS = 36;
const MAX_ORBITS_SHOWN_COLLAPSED = 3;
const MAX_PASSES_SHOWN_COLLAPSED = 3;

const RANGE_FILTER_FLOOR_KM = MIN_LINK_RANGE_KM;
const DEFAULT_MIN_RANGE_KM = MIN_LINK_RANGE_KM;
const DEFAULT_MAX_RANGE_KM = MAX_LINK_RANGE_KM;
/** Smallest allowed gap between min and max range (km). */
const RANGE_STEP_KM = 1;

const SCAN_DEBOUNCE_MS = 400;

export type SelectedOrbitInfo = { satelliteName: string; aos: Date; los: Date };
export type SelectedGsPassInfo = { station: string; aos: Date; los: Date };

/** Which wizard step's blocks are visible. Hidden blocks stay mounted so
 *  scans and selections survive step changes. Omit to show everything. */
export type MissionPanelSection = "reference" | "orbits" | "downlink";

type Props = {
  section?: MissionPanelSection;
  lat: number | null;
  lon: number | null;
  onLatChange: (v: number | null) => void;
  onLonChange: (v: number | null) => void;
  lookAngleDeg?: number;
  /** Operations mode chosen in step 1: spot / slip use a marker, strip an area. */
  operationMode?: "spot" | "slip" | "strip" | null;

  satelliteIds: string[];
  tleData: TleEntry[];
    groundStations?: GroundStation[];

  selectedOrbitIndex: number | null;
  onSelectOrbit: (index: number) => void;

  downloadInGsPass: boolean;
  onToggleDownloadInGsPass: (checked: boolean) => void;

  selectedGsName: string | null;
  onSelectGsName: (name: string) => void;

  onOrbitTimeChange?: (info: SelectedOrbitInfo | null) => void;
  onGsPassTimeChange?: (info: SelectedGsPassInfo | null) => void;

  viewerRef: React.MutableRefObject<Cesium.Viewer | null>;
  viewerReady: boolean;
  onTargetRectangleChange?: (bounds: RectangleBounds | null) => void;

  frequencySegments: FrequencySegment[];
  onFrequencySegmentsChange: (segments: FrequencySegment[]) => void;
  onVisualizeFrequency?: (segments: FrequencySegment[]) => void;
  onBackFromFrequency?: () => void;
  onSaveConfiguration?: () => void;
  isSaving?: boolean;
  saveError?: string | null;
};

function formatOffset(ms: number) {
  const sign = ms < 0 ? "-" : "+";
  const totalSec = Math.round(Math.abs(ms) / 1000);
  const h = Math.floor(totalSec / 3600);
  const m = Math.floor((totalSec % 3600) / 60);
  const s = totalSec % 60;
  return `${sign}${h.toString().padStart(2, "0")}h ${m.toString().padStart(2, "0")}m ${s.toString().padStart(2, "0")}s`;
}

function formatDuration(ms: number) {
  const totalSec = Math.max(0, Math.round(ms / 1000));
  const h = Math.floor(totalSec / 3600);
  const m = Math.floor((totalSec % 3600) / 60);
  const s = totalSec % 60;
  if (h > 0) return `${h}h ${m.toString().padStart(2, "0")}m`;
  return `${m}m ${s.toString().padStart(2, "0")}s`;
}

/**
 * Number box for a slant range (km). Commits on blur / Enter (so typing is not
 * clamped mid-way) and shows the tilt the range gives, or the validation error.
 */
export function RangeBox({
  label,
  value,
  tiltDeg,
  onCommit,
  invalid,
}: {
  label: string;
  value: number;
  tiltDeg?: number;
  onCommit: (v: number) => void;
  invalid: (v: number) => string | null;
}) {
  const [draft, setDraft] = useState(String(value));
  useEffect(() => setDraft(String(value)), [value]);
  const n = Number(draft);
  const error = draft.trim() === "" || !Number.isFinite(n) || n <= 0 ? "Enter a range in km" : invalid(n);
  const commit = () => {
    if (!error) onCommit(Math.round(n));
    else setDraft(String(value));
  };
  return (
    <label className="rounded-md border border-white/5 bg-white/[0.02] px-2.5 py-2">
      <span className="block text-[10px] font-medium uppercase tracking-wider text-[var(--gm-muted)]">{label}</span>
      <span className="mt-0.5 flex items-baseline gap-1">
        <input
          type="number"
          min={1}
          step={1}
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onBlur={commit}
          onKeyDown={(e) => {
            if (e.key === "Enter") (e.target as HTMLInputElement).blur();
          }}
          className={`w-20 rounded border px-1.5 py-0.5 text-sm font-semibold text-[oklch(0.95_0_0)] ${
            error ? "border-red-500/50" : "border-white/10"
          }`}
        />
        <span className="text-xs text-[var(--gm-muted)]">km</span>
      </span>
      {(error || tiltDeg !== undefined) && (
        <span className={`mt-1 block font-mono text-[11px] ${error ? "text-red-300" : "text-[var(--gm-muted)]"}`}>
          {error ?? `tilt ${tiltDeg!.toFixed(1)}°`}
        </span>
      )}
    </label>
  );
}

/**
 * Capture limits card: min / max slant range and min elevation as inputs,
 * and the tilt those ranges give (tilt = acos(H / range)) in its own
 * highlighted bar. Used by Spot (marker) and Strip (rectangle) mode.
 */
export function CaptureLimits({
  minRangeKm,
  maxRangeKm,
  minElevationDeg,
  onMinRangeChange,
  onMaxRangeChange,
  onMinElevationChange,
  minRangeInvalid,
  maxRangeInvalid,
  gate,
  singleRange = false,
  children,
}: {
  minRangeKm: number;
  maxRangeKm: number;
  minElevationDeg: number;
  onMinRangeChange: (v: number) => void;
  onMaxRangeChange: (v: number) => void;
  onMinElevationChange: (v: number) => void;
  minRangeInvalid: (v: number) => string | null;
  maxRangeInvalid: (v: number) => string | null;
  gate: ReturnType<typeof stripGateSummary>;
  /** Spot mode: one "Range" input (the max slant range); min stays at the floor. */
  singleRange?: boolean;
  children?: React.ReactNode;
}) {
  const tiltMax = gate.limitedByElevation ? gate.effectiveMaxTiltDeg : gate.maxTiltDeg;
  return (
    <div className="rounded-lg border border-white/5 bg-[oklch(0.13_0.02_255)] p-3.5">
      <div className="mb-3 flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wider text-[var(--gm-muted)]">
        <SlidersHorizontal className="size-3.5 text-[oklch(0.75_0.12_220)]" />
        Range, elevation and tilt
      </div>

      <div className={`grid gap-2 ${singleRange ? "grid-cols-2" : "grid-cols-3"}`}>
        {singleRange ? (
          <RangeBox label="Range" value={maxRangeKm} onCommit={onMaxRangeChange} invalid={maxRangeInvalid} />
        ) : (
          <>
            <RangeBox label="Min range" value={minRangeKm} onCommit={onMinRangeChange} invalid={minRangeInvalid} />
            <RangeBox label="Max range" value={maxRangeKm} onCommit={onMaxRangeChange} invalid={maxRangeInvalid} />
          </>
        )}
        <label className="rounded-md border border-white/5 bg-white/[0.02] px-2.5 py-2">
          <span className="block text-[10px] font-medium uppercase tracking-wider text-[var(--gm-muted)]">Min elevation</span>
          <span className="mt-0.5 flex items-baseline gap-1">
            <input
              type="number"
              min={0}
              max={89}
              step={1}
              value={minElevationDeg}
              onChange={(e) => {
                const n = Number(e.target.value);
                if (Number.isFinite(n)) onMinElevationChange(Math.min(89, Math.max(0, n)));
              }}
              className="w-14 rounded border border-white/10 px-1.5 py-0.5 text-sm font-semibold text-[oklch(0.95_0_0)]"
            />
            <span className="text-xs text-[var(--gm-muted)]">°</span>
          </span>
        </label>
      </div>

      {/* Tilt — follows from the range, shown in its own highlighted blocks. */}
      <div className={`mt-2 grid gap-2 ${singleRange ? "grid-cols-1" : "grid-cols-2"}`}>
        {(singleRange
          ? [{ label: "Tilt", value: tiltMax }]
          : [
              { label: "Min tilt", value: gate.minTiltDeg },
              { label: "Max tilt", value: tiltMax },
            ]
        ).map((t) => (
          <div key={t.label} className="rounded-md border border-[rgba(77,163,255,.35)] bg-[rgba(77,163,255,.08)] px-2.5 py-2">
            <span className="block text-[10px] font-semibold uppercase tracking-wider text-[var(--mp-accent)]">{t.label}</span>
            <span className="mt-0.5 block font-mono text-sm font-semibold text-[var(--mp-text)]">{t.value.toFixed(1)}°</span>
          </div>
        ))}
      </div>

      {gate.limitedByElevation && (
        <p className="mt-2 text-[11px] text-amber-200/80">
          Elevation limits range to {gate.effectiveMaxRangeKm.toFixed(0)} km ({gate.effectiveMaxTiltDeg.toFixed(1)}° tilt).
        </p>
      )}
      {children}
    </div>
  );
}

/**
 * Spot mode: the user enters ONE limit — a minimum elevation OR a maximum
 * slant range — and the other one plus the tilt are calculated from it with
 * the pass-geometry formulas (see SpotModeRange.ts).
 */
export function SpotLimitInput({
  mode,
  value,
  geometry,
  onModeChange,
  onValueCommit,
  children,
}: {
  mode: SpotLimitMode;
  value: number;
  geometry: SpotLimitGeometry;
  onModeChange: (m: SpotLimitMode) => void;
  onValueCommit: (v: number) => void;
  children?: React.ReactNode;
}) {
  const bounds = spotLimitBounds(mode, geometry.orbitHeightKm);
  const unit = mode === "elevation" ? "°" : "km";
  const [draft, setDraft] = useState(String(value));
  useEffect(() => setDraft(String(value)), [value, mode]);
  const n = Number(draft);
  const error =
    draft.trim() === "" || !Number.isFinite(n)
      ? mode === "elevation"
        ? "Enter an elevation in degrees"
        : "Enter a range in km"
      : n < bounds.min || n > bounds.max
        ? `Allowed ${bounds.min}–${bounds.max} ${unit}`
        : null;
  const commit = () => {
    if (!error) onValueCommit(mode === "elevation" ? Math.round(n * 10) / 10 : Math.round(n));
    else setDraft(String(value));
  };

  const derived = [
    { label: "Min elevation", value: `${geometry.minElevationDeg.toFixed(1)}°`, warn: geometry.elevationBelowFloor },
    { label: "Max range", value: `${geometry.maxRangeKm.toFixed(0)} km`, warn: geometry.rangeAboveCeiling },
    { label: "Tilt", value: `${geometry.maxTiltDeg.toFixed(1)}°`, warn: false },
  ];

  return (
    <div className="rounded-lg border border-white/5 bg-[oklch(0.13_0.02_255)] p-3.5">
      <div className="mb-3 flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wider text-[var(--gm-muted)]">
        <SlidersHorizontal className="size-3.5 text-[oklch(0.75_0.12_220)]" />
        Pass limit (enter either)
      </div>

      {/* Which limit the user enters */}
      <div className="mb-2 grid grid-cols-2 gap-1 rounded-md border border-white/10 bg-white/[0.02] p-1" role="radiogroup" aria-label="Pass limit">
        {(
          [
            { m: "elevation" as const, label: "Min elevation", hint: `≥ ${spotLimitBounds("elevation").min}°` },
            { m: "range" as const, label: "Max range", hint: `≤ ${spotLimitBounds("range").max} km` },
          ]
        ).map(({ m, label, hint }) => (
          <button
            key={m}
            type="button"
            role="radio"
            aria-checked={mode === m}
            onClick={() => onModeChange(m)}
            className={`rounded px-2 py-1.5 text-xs font-semibold transition-colors ${
              mode === m
                ? "bg-[oklch(0.75_0.12_220)]/20 text-[oklch(0.88_0.1_220)] shadow-[inset_0_0_0_1px_oklch(0.75_0.12_220/0.5)]"
                : "text-[oklch(0.7_0_0)] hover:bg-white/[0.04]"
            }`}
          >
            {label} <span className="font-normal text-[var(--gm-muted)]">{hint}</span>
          </button>
        ))}
      </div>

      {/* The one value box */}
      <label className="block rounded-md border border-white/5 bg-white/[0.02] px-2.5 py-2">
        <span className="block text-[10px] font-medium uppercase tracking-wider text-[var(--gm-muted)]">
          {mode === "elevation" ? "Minimum elevation" : "Maximum slant range"}
        </span>
        <span className="mt-0.5 flex items-baseline gap-1">
          <input
            type="number"
            min={bounds.min}
            max={bounds.max}
            step={mode === "elevation" ? 0.5 : 1}
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onBlur={commit}
            onKeyDown={(e) => {
              if (e.key === "Enter") (e.target as HTMLInputElement).blur();
            }}
            className={`w-24 rounded border px-1.5 py-0.5 text-sm font-semibold text-[oklch(0.95_0_0)] ${
              error ? "border-red-500/50" : "border-white/10"
            }`}
          />
          <span className="text-xs text-[var(--gm-muted)]">{unit}</span>
        </span>
        {error && <span className="mt-1 block font-mono text-[11px] text-red-300">{error}</span>}
      </label>

      {/* Min elevation, max range and tilt (the other two follow from the one entered). */}
      <div className="mt-2 grid grid-cols-3 gap-2">
        {derived.map((d) => (
          <div
            key={d.label}
            className={`rounded-md border px-2.5 py-2 ${
              d.warn ? "border-amber-400/40 bg-amber-400/10" : "border-[rgba(77,163,255,.35)] bg-[rgba(77,163,255,.08)]"
            }`}
          >
            <span className="block text-[10px] font-semibold uppercase tracking-wider text-[var(--mp-accent)]">
              {d.label}
            </span>
            <span className="mt-0.5 block font-mono text-sm font-semibold text-[var(--mp-text)]">{d.value}</span>
          </div>
        ))}
      </div>
      {geometry.rangeAboveCeiling && (
        <p className="mt-1 text-[11px] text-amber-200/80">
          Calculated range is above the {MAX_LINK_RANGE_KM} km link limit.
        </p>
      )}
      {geometry.elevationBelowFloor && (
        <p className="mt-1 text-[11px] text-amber-200/80">
          Calculated elevation is below the {spotLimitBounds("elevation").min}° minimum.
        </p>
      )}
      {children}
    </div>
  );
}

export default function Georeference({
  section,
  lat,
  lon,
  onLatChange,
  onLonChange,
  lookAngleDeg,
  operationMode = null,
  satelliteIds,
  tleData,
  groundStations = DEFAULT_GROUND_STATIONS,
  selectedOrbitIndex,
  onSelectOrbit,
  downloadInGsPass,
  onToggleDownloadInGsPass,
  selectedGsName,
  onSelectGsName,
  onOrbitTimeChange,
  onGsPassTimeChange,
  viewerRef,
  viewerReady,
  onTargetRectangleChange,
  frequencySegments,
  onFrequencySegmentsChange,
  onBackFromFrequency,
  onSaveConfiguration,
  isSaving,
  saveError,
}: Props) {
  const hideFor = (s: MissionPanelSection) => !!section && section !== s;
  const [showAllOrbits, setShowAllOrbits] = useState(false);
  const [showAllPasses, setShowAllPasses] = useState(false);

  const [selectedStripPassIndex, setSelectedStripPassIndex] = useState<number | null>(0);
  const [stripPlanResult, setStripPlanResult] = useState<StripCapturePlanResult | null>(null);
  const [minRangeKm, setMinRangeKm] = useState(DEFAULT_MIN_RANGE_KM);
  const [maxRangeKm, setMaxRangeKm] = useState(DEFAULT_MAX_RANGE_KM);
  // Spot mode: ONE entered limit (min elevation OR max range); the rest is calculated.
  // Each limit keeps its own value: set elevation 6°, switch to range and back → still 6°.
  const [spotLimitMode, setSpotLimitMode] = useState<SpotLimitMode>(DEFAULT_SPOT_LIMIT.mode);
  const [spotLimitValues, setSpotLimitValues] = useState<Record<SpotLimitMode, number>>(() => ({
    elevation: defaultSpotLimitValue("elevation"),
    range: defaultSpotLimitValue("range"),
  }));
  const spotLimitValue = spotLimitValues[spotLimitMode];
  const setSpotLimitValue = (v: number) => setSpotLimitValues((prev) => ({ ...prev, [spotLimitMode]: v }));
  const handleSpotLimitModeChange = (m: SpotLimitMode) => setSpotLimitMode(m);
  // Mission duration = sum of the frequency segments (≤ 10 min; 10 min until a plan exists).
  const missionDurationSeconds = useMemo(
    () => missionDurationFromSegments(frequencySegments),
    [frequencySegments],
  );
  const [accuracyStepKm, setAccuracyStepKm] = useState(ACCURACY_STEP_DEFAULT_KM);
  const [accuracyRequested, setAccuracyRequested] = useState(false);
  const hoveredAccuracyEntityRef = useRef<Cesium.Entity | null>(null);
  const accuracyPrimitiveRef = useRef<Cesium.Primitive | null>(null);
  const accuracyGridBorderPrimitiveRef = useRef<Cesium.Primitive | null>(null);

  const handleMinRangeChange = (v: number) => {
    setMinRangeKm(Math.min(v, maxRangeKm - RANGE_STEP_KM));
  };
  const handleMaxRangeChange = (v: number) => {
    setMaxRangeKm(Math.max(v, minRangeKm + RANGE_STEP_KM));
  };

  const latOutOfRange = lat !== null && (lat < -90 || lat > 90);
  const lonOutOfRange = lon !== null && (lon < -180 || lon > 180);
  const isIncomplete = lat === null || lon === null;

  const parseCoord = (raw: string): number | null => {
    if (raw.trim() === "") return null;
    const n = Number(raw);
    return Number.isNaN(n) ? null : n;
  };

  const {
    mode: pickerMode,
    setMode: setPickerMode,
    shapeKind,
    rectangleBounds,
    applyRectangleBounds,
    markAsPoint,
  } = useTargetPicker({
    viewerRef,
    viewerReady,
    lat,
    lon,
    onLatChange,
    onLonChange,
    onRectangleChange: onTargetRectangleChange,
  });

  // Spot mode has one range input (the max); the min stays at the nadir floor.
  useEffect(() => {
    if (shapeKind !== "rectangle" && minRangeKm !== RANGE_FILTER_FLOOR_KM) setMinRangeKm(RANGE_FILTER_FLOOR_KM);
  }, [shapeKind, minRangeKm]);

  const handleBoundsFieldChange = (field: keyof RectangleBounds, raw: string) => {
    const n = parseCoord(raw);
    if (n === null || !rectangleBounds) return;
    applyRectangleBounds({ ...rectangleBounds, [field]: n });
  };

  const target: GroundPoint | null = useMemo(
    () =>
      lat !== null && lon !== null && !latOutOfRange && !lonOutOfRange
        ? { name: "Spot Target", lat, lon }
        : null,
    [lat, lon, latOutOfRange, lonOutOfRange],
  );

  const [debouncedTarget, setDebouncedTarget] = useState(target);
  useEffect(() => {
    const id = setTimeout(() => setDebouncedTarget(target), SCAN_DEBOUNCE_MS);
    return () => clearTimeout(id);
  }, [target]);

  const [debouncedSpotLimit, setDebouncedSpotLimit] = useState({ mode: spotLimitMode, value: spotLimitValue });
  useEffect(() => {
    const id = setTimeout(() => setDebouncedSpotLimit({ mode: spotLimitMode, value: spotLimitValue }), SCAN_DEBOUNCE_MS);
    return () => clearTimeout(id);
  }, [spotLimitMode, spotLimitValue]);

  const isScanPending =
    debouncedTarget !== target ||
    debouncedSpotLimit.mode !== spotLimitMode ||
    debouncedSpotLimit.value !== spotLimitValue;

  const groupTles = useMemo(
    () => tleData.filter((t) => satelliteIds.includes(t.name)),
    [tleData, satelliteIds],
  );

  const tleByName = useMemo(
    () => Object.fromEntries(groupTles.map((t) => [t.name, t])),
    [groupTles],
  );

  // Calculated limit (other value + tilt) for the orbit height.
  // Fixed orbit height (550 km, ORBIT_HEIGHT_KM in GeoReferenceStripModeRange.tsx).
  const spotOrbitHeightKm = ORBIT_HEIGHT_KM;
  const spotLimit = useMemo(
    () => deriveSpotLimit({ mode: spotLimitMode, value: spotLimitValue }, spotOrbitHeightKm),
    [spotLimitMode, spotLimitValue, spotOrbitHeightKm],
  );
  const scanSpotLimit = useMemo(
    () => deriveSpotLimit(debouncedSpotLimit, spotOrbitHeightKm),
    [debouncedSpotLimit, spotOrbitHeightKm],
  );

  const now = useMemo(() => new Date(), []);
  const scanEnd = useMemo(() => new Date(now.getTime() + ORBIT_SCAN_HOURS * 60 * 60 * 1000), [now]);

  // ═══════════════════════════════════════════════════════════════════
  // SPOT MODE — mission start = elevation ≥ min elevation (or range ≤ max
  // range); LOS = that limit lost; mission end = start + Σ frequency
  // durations; AOS (dummy) = start − 5 min.
  // ═══════════════════════════════════════════════════════════════════

  const qualifyingPassesBySat = useMemo(() => {
    if (!debouncedTarget) return [];
    return groupTles.map((tle) => ({
      tle,
      passes: findSpotOrbits(tle, debouncedTarget, now, scanEnd, scanSpotLimit, { missionDurationSeconds }),
    }));
  }, [groupTles, debouncedTarget, now, scanEnd, scanSpotLimit, missionDurationSeconds]);

  const leadingSatName = useMemo(() => {
    let best: { name: string; aos: number } | null = null;
    for (const { tle, passes } of qualifyingPassesBySat) {
      if (passes.length === 0) continue;
      const soonest = passes[0].aos.getTime();
      if (!best || soonest < best.aos) best = { name: tle.name, aos: soonest };
    }
    return best?.name ?? groupTles[0]?.name ?? null;
  }, [qualifyingPassesBySat, groupTles]);

  const leadingTle = groupTles.find((t) => t.name === leadingSatName) ?? null;
  const leadingOrbits: SpotOrbit[] = useMemo(
    () => qualifyingPassesBySat.find((s) => s.tle.name === leadingSatName)?.passes ?? [],
    [qualifyingPassesBySat, leadingSatName],
  );

  // Short pass (LOS before mission end) → chain the following passes of the
  // leading satellite until the full mission duration is covered.
  const missionPlansByOrbit = useMemo(
    () => leadingOrbits.map((o, i) => (o.shortPass ? planMissionAcrossPasses(leadingOrbits, i) : null)),
    [leadingOrbits],
  );

  // ── LOS before mission end: the operator picks, per pass, whether to finish
  //    on upcoming passes or shorten the frequency plan to fit this pass.
  //    Choices are keyed by the pass's mission-start time (indices shift
  //    when the plan length changes and the orbits are re-scanned). ──
  const passKey = (o: SpotOrbit) => Math.round(o.missionStart.getTime() / 1000);
  const [losChoices, setLosChoices] = useState<Record<number, LosChoice>>({});
  const [losDialogIndex, setLosDialogIndex] = useState<number | null>(null);
  const reselectPassRef = useRef<number | null>(null);
  useEffect(() => {
    const want = reselectPassRef.current;
    if (want === null) return;
    // Mission start can move by a few seconds after a re-scan; match within a minute.
    const idx = leadingOrbits.findIndex((o) => Math.abs(passKey(o) - want) <= 60);
    if (idx >= 0) {
      reselectPassRef.current = null;
      onSelectOrbit(idx);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [leadingOrbits]);
  const losDialogOrbit = losDialogIndex !== null ? leadingOrbits[losDialogIndex] : undefined;

  // Accuracy calculations are explicitly anchored to the operator-selected
  // mission window: a chosen orbit in Spot mode, or the active pass in the
  // confirmed strip capture plan in rectangle mode.
  const accuracyAnchorOrbit = useMemo(() => {
    if (shapeKind === "rectangle") {
      const orbit = stripPlanResult
        ? stripPlanResult.orbits[selectedStripPassIndex ?? 0] ?? stripPlanResult.orbits[0] ?? null
        : null;

      if (!orbit) return null;

      // Anchor on the imaging window: mission start -> end of capture (mission end or LOS).
      return {
        aos: orbit.missionStart,
        los: orbit.captureEnd,
        label: `${orbit.leaderName} · ${orbit.missionStart.toISOString().slice(11, 19)}–${orbit.captureEnd.toISOString().slice(11, 19)} UTC`,
      };
    }

    if (selectedOrbitIndex !== null && leadingOrbits[selectedOrbitIndex]) {
      return leadingOrbits[selectedOrbitIndex];
    }
    return null;
  }, [shapeKind, selectedStripPassIndex, stripPlanResult, selectedOrbitIndex, leadingOrbits]);

  const accuracyTargetBounds = useMemo(() => {
    if (shapeKind === "rectangle") return rectangleBounds;
    if (shapeKind === "point" && target) {
      return accuracySwathBounds(target.lat, target.lon, MIN_FREQUENCY_SWATH_KM);
    }
    return null;
  }, [rectangleBounds, shapeKind, target]);

  const accuracyEffectiveStepKm = accuracyTargetBounds
    ? effectiveAccuracyStepKm(accuracyTargetBounds, accuracyStepKm)
    : accuracyStepKm;

  const accuracyGrid = useMemo(() => {
    return accuracyTargetBounds
      ? createAccuracyGrid(accuracyTargetBounds, accuracyEffectiveStepKm)
      : [];
  }, [accuracyEffectiveStepKm, accuracyTargetBounds]);

  const accuracyTargetReady = accuracyTargetBounds !== null;

  const [accuracySamples, setAccuracySamples] = useState<AccuracySample[]>([]);
  const [accuracyCalculating, setAccuracyCalculating] = useState(false);
  const [accuracyProgress, setAccuracyProgress] = useState({ completed: 0, total: 0, solved: 0 });
  const [accuracyError, setAccuracyError] = useState<string | null>(null);
  const [accuracyAnimationPlaying, setAccuracyAnimationPlaying] = useState(false);
  const [accuracyAnimationTime, setAccuracyAnimationTime] = useState<Date | null>(null);
  const animatedAccuracyKeyRef = useRef<string | null>(null);
  const accuracyAnimationKey = useMemo(
    () => JSON.stringify({
      bounds: rectangleBounds,
      point: shapeKind === "point" && target ? [target.lat, target.lon] : null,
      shapeKind,
      aos: accuracyAnchorOrbit?.aos.getTime(),
      los: accuracyAnchorOrbit?.los.getTime(),
      step: accuracyEffectiveStepKm,
      satellites: groupTles.map((tle) => [tle.name, tle.tle1, tle.tle2]),
    }),
    [accuracyAnchorOrbit, accuracyEffectiveStepKm, groupTles, rectangleBounds, shapeKind, target],
  );

  // Static accuracy mode evaluates the selected orbit at AOS. During playback
  // this effect yields sample ownership to the interval animator, which uses
  // prepared TLEs and a cached grid to update accuracy at each simulation time.
  // Neither path depends on the frequency plan or sensor swath width.
  useEffect(() => {
    if (accuracyAnimationPlaying) return;
    if (animatedAccuracyKeyRef.current === accuracyAnimationKey) return;
    animatedAccuracyKeyRef.current = null;

    if (
      !accuracyRequested ||
      shapeKind === null ||
      !accuracyTargetReady ||
      groupTles.length < 3 ||
      !accuracyAnchorOrbit
    ) {
      const reset = window.setTimeout(() => {
        setAccuracySamples([]);
        setAccuracyCalculating(false);
      }, 0);
      return () => window.clearTimeout(reset);
    }

    let cancelled = false;
    const initialGrid = accuracyGrid;
    const estimateBounds = accuracyTargetBounds!;

    const calculation = window.setTimeout(() => {
      setAccuracySamples([]);
      setAccuracyCalculating(true);
      setAccuracyError(null);
      setAccuracyProgress({ completed: 0, total: initialGrid.length, solved: 0 });
      void estimateGeolocationAccuracyAsync(
        estimateBounds,
        groupTles,
        {
          aos: accuracyAnchorOrbit.aos,
          los: accuracyAnchorOrbit.los,
          label: shapeKind === "rectangle"
            ? `Selected capture plan · ${accuracyAnchorOrbit.aos.toISOString().slice(11, 19)} UTC`
            : `Selected orbit · ${accuracyAnchorOrbit.aos.toISOString().slice(11, 19)} UTC`,
        },
        accuracyEffectiveStepKm,
        (completed, total) => {
          if (!cancelled) {
            setAccuracyProgress((previous) => ({ ...previous, completed, total }));
          }
        },
        (startIndex, batch) => {
          if (cancelled) return;
          const batchSolved = batch.filter((sample) => sample.accuracyMeters !== null).length;
          setAccuracyProgress((previous) => ({
            ...previous,
            completed: startIndex + batch.length,
            solved: previous.solved + batchSolved,
          }));
          if (ACCURACY_DEBUG) {
            console.groupCollapsed(`[accuracy] cells ${startIndex + 1}–${startIndex + batch.length} of ${initialGrid.length}`);
            console.table(batch.map((sample, offset) => ({
              cell: startIndex + offset + 1,
              sourceCellLat: Number(((sample.south + sample.north) / 2).toFixed(6)),
              sourceCellLon: Number(((sample.west + sample.east) / 2).toFixed(6)),
              estimatorLat: Number(sample.lat.toFixed(6)),
              estimatorLon: Number(sample.lon.toFixed(6)),
              accuracy: sample.accuracyMeters === null
                ? "No 3-satellite solution"
                : `${sample.accuracyMeters.toFixed(2)} m`,
              visibleSatellites: sample.visibleSatellites,
              pass: sample.passLabel || "No pass assigned",
            })));
            console.groupEnd();
          }
        },
        initialGrid,
      ).then((samples) => {
        if (cancelled) return;
        setAccuracySamples(samples);
        setAccuracyProgress({
          completed: samples.length,
          total: samples.length,
          solved: samples.filter((sample) => sample.accuracyMeters !== null).length,
        });
        setAccuracyCalculating(false);
      }).catch((error: unknown) => {
        if (cancelled) return;
        setAccuracyCalculating(false);
        setAccuracyError(error instanceof Error ? error.message : "Accuracy calculation failed");
      });
    }, 30);

    return () => {
      cancelled = true;
      window.clearTimeout(calculation);
    };
  }, [
    accuracyAnchorOrbit,
    accuracyAnimationKey,
    accuracyAnimationPlaying,
    accuracyRequested,accuracyGrid,
    accuracyTargetReady,
    accuracyTargetBounds,
    accuracyEffectiveStepKm,
    accuracyStepKm,
    groupTles,
    rectangleBounds,
    shapeKind,
    target,
  ]);

  useEffect(() => {
    const viewer = viewerRef.current;
    if (
      !accuracyAnimationPlaying ||
      !viewerReady ||
      !viewer ||
      viewer.isDestroyed() ||
      !accuracyTargetReady ||
      !accuracyAnchorOrbit ||
      groupTles.length < 3
    ) return;

    animatedAccuracyKeyRef.current = accuracyAnimationKey;

    return startGeolocationAnimation({
      viewer,
      bounds: accuracyTargetBounds!,
      point: shapeKind === "point" && target ? { lat: target.lat, lon: target.lon } : undefined,
      grid: accuracyGrid,
      satellites: groupTles,
      startTime: accuracyAnchorOrbit.aos,
      endTime: accuracyAnchorOrbit.los,
      stepKm: accuracyEffectiveStepKm,
      onSamples: setAccuracySamples,
      onTimeChange: setAccuracyAnimationTime,
    });
  }, [
    accuracyAnimationPlaying,
    accuracyAnchorOrbit,
    accuracyAnimationKey,
    accuracyGrid,
    accuracyEffectiveStepKm,
    groupTles,
    accuracyTargetReady,
    accuracyTargetBounds,
    rectangleBounds,
    shapeKind,
    target,
    viewerReady,
    viewerRef,
  ]);

  const accuracyStats = useMemo(() => {
    const values = accuracySamples.flatMap((sample) =>
      sample.accuracyMeters === null ? [] : [sample.accuracyMeters],
    );
    return {
      minimum: values.length > 0 ? Math.min(...values) : null,
      maximum: values.length > 0 ? Math.max(...values) : null,
      solved: values.length,
      generated: accuracySamples.length,
    };
  }, [accuracySamples]);

  // The Spot animation runs on its own: the accuracy grid is not drawn while it plays.
  const vizPlayback = useVizPlayback();
  const spotAnimating = vizPlayback.active === "spot";

  // Render heatmap on Cesium.
  useEffect(() => {
    const viewer = viewerRef.current;
    if (!viewer || viewer.isDestroyed()) return;

    viewer.entities.values
      .filter((entity) => typeof entity.id === "string" && entity.id.startsWith("geo-accuracy-cell-"))
      .forEach((entity) => viewer.entities.remove(entity));

    if (accuracyPrimitiveRef.current) {
      viewer.scene.primitives.remove(accuracyPrimitiveRef.current);
      accuracyPrimitiveRef.current = null;
    }

    if (accuracyGridBorderPrimitiveRef.current) {
      viewer.scene.primitives.remove(accuracyGridBorderPrimitiveRef.current);
      accuracyGridBorderPrimitiveRef.current = null;
    }

    if (accuracySamples.length > 0 && !spotAnimating) {
      const instances = accuracySamples.map((sample, index) => new Cesium.GeometryInstance({
        id: `geo-accuracy-cell-${index}`,
        geometry: new Cesium.PolygonGeometry({
          polygonHierarchy: new Cesium.PolygonHierarchy(Cesium.Cartesian3.fromDegreesArray([
            sample.west, sample.south,
            sample.east, sample.south,
            sample.east, sample.north,
            sample.west, sample.north,
          ])),
          height: 500,
          vertexFormat: Cesium.PerInstanceColorAppearance.VERTEX_FORMAT,
        }),
        attributes: {
          color: Cesium.ColorGeometryInstanceAttribute.fromColor(
            sample.computed
              ? Cesium.Color.fromCssColorString(accuracyColor(sample.accuracyMeters)).withAlpha(0.9)
              : Cesium.Color.TRANSPARENT,
          ),
        },
      }));
      accuracyPrimitiveRef.current = viewer.scene.primitives.add(new Cesium.Primitive({
        geometryInstances: instances,
        appearance: new Cesium.PerInstanceColorAppearance({
          translucent: true,
          closed: false,
          flat: true,
        }),
        asynchronous: false,
      }));
      const borderInstances = accuracySamples.map((sample, index) => new Cesium.GeometryInstance({
        id: `geo-accuracy-outline-${index}`,
        geometry: new Cesium.PolygonOutlineGeometry({
          polygonHierarchy: new Cesium.PolygonHierarchy(Cesium.Cartesian3.fromDegreesArray([
            sample.west, sample.south,
            sample.east, sample.south,
            sample.east, sample.north,
            sample.west, sample.north,
          ])),
          height: 510,
        }),
        attributes: {
          color: Cesium.ColorGeometryInstanceAttribute.fromColor(
            Cesium.Color.fromCssColorString("#0b1220").withAlpha(0.85),
          ),
        },
      }));
      accuracyGridBorderPrimitiveRef.current = viewer.scene.primitives.add(new Cesium.Primitive({
        geometryInstances: borderInstances,
        appearance: new Cesium.PerInstanceColorAppearance({
          translucent: true,
          closed: false,
          flat: true,
        }),
        asynchronous: false,
      }));
    }
    viewer.scene.requestRender();

    const tooltip = document.createElement("div");
    tooltip.style.cssText = [
      "position:absolute",
      "display:none",
      "pointer-events:none",
      "z-index:20",
      "padding:7px 9px",
      "border:1px solid rgba(255,255,255,.2)",
      "border-radius:5px",
      "background:rgba(15,23,42,.95)",
      "box-shadow:0 4px 14px rgba(0,0,0,.45)",
      "color:white",
      "font:600 12px/1.35 sans-serif",
      "white-space:nowrap",
    ].join(";");
    (viewer.container as HTMLElement).style.position = "relative";
    viewer.container.appendChild(tooltip);

    const handler = new Cesium.ScreenSpaceEventHandler(viewer.scene.canvas);
    handler.setInputAction((movement: Cesium.ScreenSpaceEventHandler.MotionEvent) => {
      const picked = viewer.scene.drillPick(movement.endPosition, 8);
      const pickedObject = picked.find((candidate) => {
        const id = (candidate as { id?: unknown }).id;
        return typeof id === "string" && id.startsWith("geo-accuracy-cell-");
      });
      const pickedId = pickedObject && (pickedObject as { id?: unknown }).id;

      if (hoveredAccuracyEntityRef.current?.label) {
        hoveredAccuracyEntityRef.current.label.show = new Cesium.ConstantProperty(false);
      }
      hoveredAccuracyEntityRef.current = null;

      if (typeof pickedId === "string" && pickedId.startsWith("geo-accuracy-cell-")) {
        const sampleIndex = Number(pickedId.replace("geo-accuracy-cell-", ""));
        const sample = accuracySamples[sampleIndex];
        if (sample) {
          const passLine = sample.passIndex >= 0
            ? `<br><span style="font-weight:400;color:#cbd5e1">${sample.passLabel}</span>`
            : "";
          tooltip.innerHTML = sample.computed
            ? `${formatAccuracy(sample.accuracyMeters)}<br><span style="font-weight:400;color:#cbd5e1">${sample.visibleSatellites} sats${passLine}</span>`
            : `Calculating…<br><span style="font-weight:400;color:#cbd5e1">Cell not evaluated yet</span>`;
          tooltip.style.left = `${movement.endPosition.x + 14}px`;
          tooltip.style.top = `${movement.endPosition.y + 14}px`;
          tooltip.style.display = "block";
        }
      } else {
        tooltip.style.display = "none";
      }
      viewer.scene.requestRender();
    }, Cesium.ScreenSpaceEventType.MOUSE_MOVE);

    return () => {
      handler.destroy();
      tooltip.remove();
      hoveredAccuracyEntityRef.current = null;
      if (accuracyPrimitiveRef.current && !viewer.isDestroyed()) {
        viewer.scene.primitives.remove(accuracyPrimitiveRef.current);
        accuracyPrimitiveRef.current = null;
      }
      if (accuracyGridBorderPrimitiveRef.current && !viewer.isDestroyed()) {
        viewer.scene.primitives.remove(accuracyGridBorderPrimitiveRef.current);
        accuracyGridBorderPrimitiveRef.current = null;
      }
      if (viewer.isDestroyed()) return;
      viewer.entities.values
        .filter((entity) => typeof entity.id === "string" && entity.id.startsWith("geo-accuracy-cell-"))
        .forEach((entity) => viewer.entities.remove(entity));
    };
  }, [accuracySamples, spotAnimating, viewerReady, viewerRef]);

  const otherSatPassLists = useMemo(() => {
    return qualifyingPassesBySat
      .filter((s) => s.tle.name !== leadingSatName)
      .map((s, i) => ({
        name: s.tle.name,
        color:
          s.tle.color ??
          OTHER_SAT_FALLBACK_COLORS[i % OTHER_SAT_FALLBACK_COLORS.length] ??
          fallbackColorForName(s.tle.name, OTHER_SAT_FALLBACK_COLORS),
        passes: s.passes,
      }));
  }, [qualifyingPassesBySat, leadingSatName]);

  const otherSatOffsetsByOrbit = useMemo(() => {
    return leadingOrbits.map((orbit) =>
      otherSatPassLists.map(({ name, color, passes }) => {
        if (passes.length === 0) return { name, color, aos: null as Date | null, offsetMs: null as number | null };
        const closest = passes.reduce((a, b) =>
          Math.abs(a.aos.getTime() - orbit.aos.getTime()) < Math.abs(b.aos.getTime() - orbit.aos.getTime()) ? a : b,
        );
        return { name, color, aos: closest.aos, offsetMs: closest.aos.getTime() - orbit.aos.getTime() };
      }),
    );
  }, [leadingOrbits, otherSatPassLists]);

  const orbitCutoffTime = useMemo(() => {
    if (selectedOrbitIndex !== null && leadingOrbits[selectedOrbitIndex]) {
      return leadingOrbits[selectedOrbitIndex].los;
    }
    return leadingOrbits[0]?.los ?? now;
  }, [selectedOrbitIndex, leadingOrbits, now]);

  const gsPassesForLeadingSat = useMemo(() => {
    if (!leadingTle) return [];
    return groundStations
      .flatMap((gs) =>
        findPasses(leadingTle, gs, now, scanEnd).map((p) => ({
          station: gs,
          aos: p.aos,
          los: p.los,
        })),
      )
      .filter((p) => p.aos.getTime() >= orbitCutoffTime.getTime())
      .sort((a, b) => a.aos.getTime() - b.aos.getTime());
  }, [leadingTle, groundStations, now, scanEnd, orbitCutoffTime]);

  const visibleOrbits = showAllOrbits ? leadingOrbits : leadingOrbits.slice(0, MAX_ORBITS_SHOWN_COLLAPSED);
  const visiblePasses = showAllPasses ? gsPassesForLeadingSat : gsPassesForLeadingSat.slice(0, MAX_PASSES_SHOWN_COLLAPSED);

  useEffect(() => {
    onSelectGsName("");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [minRangeKm, maxRangeKm, spotLimitMode, spotLimitValue]);

  useEffect(() => {
    if (!onOrbitTimeChange) return;
    if (selectedOrbitIndex === null || !leadingSatName) {
      onOrbitTimeChange(null);
      return;
    }
    const orbit = leadingOrbits[selectedOrbitIndex];
    if (!orbit) {
      onOrbitTimeChange(null);
      return;
    }
    onOrbitTimeChange({ satelliteName: leadingSatName, aos: orbit.aos, los: orbit.los });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedOrbitIndex, leadingOrbits, leadingSatName]);

  useEffect(() => {
    if (!onGsPassTimeChange) return;
    if (shapeKind === "rectangle") return;
    if (!selectedGsName) {
      onGsPassTimeChange(null);
      return;
    }
    const pass = gsPassesForLeadingSat.find((p) => p.station.name === selectedGsName);
    if (!pass) {
      onGsPassTimeChange(null);
      return;
    }
    onGsPassTimeChange({ station: pass.station.name, aos: pass.aos, los: pass.los });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedGsName, gsPassesForLeadingSat, shapeKind]);

  // ═══════════════════════════════════════════════════════════════════
  // VISUALIZE — Georeference.tsx now owns just two of the three cases:
  //   1) Spot mode → visualizeSpotFrequencyPlan() (spotanimation.ts,
  //      UNCHANGED file) + a locally-built back button.
  //   2) Strip "Visualize on Map (frequency)" → visualizeStripFrequencySweep()
  //      (GeoReferenceStripAnimation.ts).
  //   Strip "Visualize Capture Plan" (the third case) is now triggered
  //   directly inside GeoReferenceStripMode.tsx, via
  //   GeoReferenceStripOrbitPlanAnimation.ts — not routed through here.
  // ═══════════════════════════════════════════════════════════════════

  const handleBackFromViz = () => {
    const viewer = viewerRef.current;
    if (viewer && !viewer.isDestroyed()) {
      clearStripVisualization(viewer);
      clearStripFrequencyVisualization(viewer);
      clearSpotFrequencyVisualization(viewer);
    }
    onBackFromFrequency?.();
  };

  // ── Orbit preview: when an upcoming orbit is selected (and no animation is
  //    playing), the satellite icons move to their positions at that orbit's
  //    mission start and the ground tracks are redrawn — like Orbit reference
  //    does when a date / time is picked. ──
  const previewOrbit =
    shapeKind !== "rectangle" && selectedOrbitIndex !== null ? leadingOrbits[selectedOrbitIndex] ?? null : null;
  const lastPreviewKeyRef = useRef<string | null>(null);
  useEffect(() => {
    const viewer = viewerRef.current;
    if (!viewerReady || !viewer || viewer.isDestroyed()) return;
    if (!previewOrbit || !target || spotAnimating || groupTles.length === 0) {
      clearSpotOrbitPreview(viewer);
      lastPreviewKeyRef.current = null;
      return;
    }
    // Fly the camera only when a different orbit / target is picked, not on every refresh.
    const key = `${passKey(previewOrbit)}|${target.lat}|${target.lon}`;
    const flyTo = key !== lastPreviewKeyRef.current;
    lastPreviewKeyRef.current = key;
    showSpotOrbitPreview(viewer, {
      satellites: groupTles.map((tle) => ({
        name: tle.name,
        tle1: tle.tle1,
        tle2: tle.tle2,
        color: tle.color ?? fallbackColorForName(tle.name, OTHER_SAT_FALLBACK_COLORS),
      })),
      time: previewOrbit.missionStart,
      targetLat: target.lat,
      targetLon: target.lon,
      flyTo,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [viewerReady, previewOrbit, target, spotAnimating, groupTles]);
  useEffect(() => () => clearSpotOrbitPreview(viewerRef.current), [viewerRef]);

  const handleVisualizeSpot = (segments: FrequencySegment[]) => {
    const viewer = viewerRef.current;
    if (!viewer || !target || groupTles.length === 0) return;
    // The animation takes over the globe: remove the orbit preview first, and
    // stop the geolocation-accuracy animation (the two never run together).
    clearSpotOrbitPreview(viewer);
    setAccuracyAnimationPlaying(false);
    lastPreviewKeyRef.current = null;

    const referenceTime =
      selectedOrbitIndex !== null && leadingOrbits[selectedOrbitIndex]
        ? new Date(
            (leadingOrbits[selectedOrbitIndex].aos.getTime() +
              leadingOrbits[selectedOrbitIndex].los.getTime()) /
              2,
          )
        : undefined;

    const satellites: SpotSatelliteInput[] = groupTles.map((tle) => ({
      name: tle.name,
      tle1: tle.tle1,
      tle2: tle.tle2,
      color: tle.color ?? fallbackColorForName(tle.name, OTHER_SAT_FALLBACK_COLORS),
    }));

    const chosen = selectedOrbitIndex !== null ? leadingOrbits[selectedOrbitIndex] : undefined;

    // "Complete on upcoming passes" chosen for this pass → animate every pass
    // of the multi-pass plan: pass 1, then pass 2, …
    const multiPlan =
      chosen && selectedOrbitIndex !== null && chosen.shortPass && losChoices[passKey(chosen)] === "multi"
        ? missionPlansByOrbit[selectedOrbitIndex]
        : null;
    const passes: SpotPassPlan[] | null =
      multiPlan && multiPlan.allocations.length > 1
        ? multiPlan.allocations.map((a) => ({
            orbit: leadingOrbits[a.orbitIndex],
            planOffsetSeconds: a.planOffsetSeconds,
            durationSeconds: a.durationSeconds,
          }))
        : null;

    visualizeSpotFrequencyPlan(viewer, segments, {
      targetLat: target.lat,
      targetLon: target.lon,
      satellites,
      referenceTime,
      // Animate the selected upcoming orbit: AOS → start → end / LOS.
      orbit: chosen ?? leadingOrbits[0] ?? null,
      leaderName: leadingSatName,
      limit: spotLimit,
      passes,
      // Same alert as the orbit list: LOS before mission end.
      warning: passes
        ? `LOS before mission end — the plan is captured over ${passes.length} passes` +
          (multiPlan && !multiPlan.completed
            ? ` (${formatDuration(multiPlan.remainingSeconds * 1000)} still uncovered in the scan window).`
            : ".")
        : chosen?.shortPass
        ? `LOS comes ${formatDuration(chosen.missionEnd.getTime() - chosen.los.getTime())} before mission end — ${formatDuration(chosen.remainingSeconds * 1000)} must be captured on later passes.`
        : null,
      onBack: () => onBackFromFrequency?.(),
    });

  };

  const handlePauseViz = (paused: boolean) => setVizPaused(viewerRef.current, paused);

  const handleVisualizeStripFrequency = (segments: FrequencySegment[]) => {
    if (!viewerRef.current || !stripPlanResult) return;
    visualizeStripFrequencySweep(
      viewerRef.current,
      stripPlanResult,
      segments,
      { tleByName, primaryPassIndex: selectedStripPassIndex ?? 0 },
      { onBack: handleBackFromViz },
    );
  };

  // Clear every globe overlay whenever the user leaves rectangle mode, and
  // on unmount — including Spot's animation and both Strip animations, so
  // nothing leaks between modes.
  useEffect(() => {
    if (shapeKind !== "rectangle" && viewerRef.current && !viewerRef.current.isDestroyed()) {
      clearStripVisualization(viewerRef.current);
      clearStripFrequencyVisualization(viewerRef.current);
    }
    if (shapeKind === "rectangle" && viewerRef.current && !viewerRef.current.isDestroyed()) {
      clearSpotFrequencyVisualization(viewerRef.current);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [shapeKind]);

  useEffect(() => {
    return () => {
      if (viewerRef.current && !viewerRef.current.isDestroyed()) {
        clearStripVisualization(viewerRef.current);
        clearStripFrequencyVisualization(viewerRef.current);
        clearSpotFrequencyVisualization(viewerRef.current);
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className={`${section ? "" : "mt-3 "}space-y-4`}>
      {losDialogOrbit && missionPlansByOrbit[losDialogIndex!] && (
        <GeoSpotModeLosResolutionBox
          satelliteName={leadingSatName ?? "—"}
          orbit={losDialogOrbit}
          plan={missionPlansByOrbit[losDialogIndex!]!}
          segments={frequencySegments}
          initialChoice={losChoices[passKey(losDialogOrbit)] ?? null}
          onClose={() => setLosDialogIndex(null)}
          onChooseMulti={() => {
            setLosChoices((c) => ({ ...c, [passKey(losDialogOrbit)]: "multi" }));
            setLosDialogIndex(null);
          }}
          onApplyPlan={(segments) => {
            const key = passKey(losDialogOrbit);
            setLosChoices((c) => ({ ...c, [key]: "edit" }));
            // The new plan re-scans the orbits; keep this same pass selected.
            reselectPassRef.current = key;
            onFrequencySegmentsChange(segments);
            setLosDialogIndex(null);
          }}
        />
      )}
      {/* Set target on map */}
      <div hidden={hideFor("reference")} className="rounded-lg border border-white/5 bg-[oklch(0.13_0.02_255)] p-3.5">
        <div className="mb-3 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-[oklch(0.7_0.02_250)]">
          <MapPin className="size-3.5 text-[oklch(0.75_0.12_220)]" />
          Set Target On Map
        </div>

        <div className={`grid gap-2 ${operationMode ? "grid-cols-1" : "grid-cols-2"}`}>
          {operationMode !== "strip" && (
          <button
            type="button"
            onClick={() => setPickerMode(pickerMode === "marker" ? null : "marker")}
            className={`flex items-center justify-center gap-1.5 rounded-lg border px-3 py-2 text-xs font-semibold transition-colors ${
              pickerMode === "marker"
                ? "border-[oklch(0.75_0.12_220)]/60 bg-[oklch(0.75_0.12_220)]/15 text-[oklch(0.85_0.1_220)] shadow-[0_0_12px_-2px_oklch(0.75_0.12_220/0.5)]"
                : "border-white/10 bg-white/[0.02] text-[oklch(0.75_0_0)] hover:border-white/20"
            }`}
          >
            <MapPin className="size-3.5" />
            Drop Marker
          </button>
          )}
          {operationMode !== "spot" && operationMode !== "slip" && (
          <button
            type="button"
            onClick={() => setPickerMode(pickerMode === "rectangle" ? null : "rectangle")}
            className={`flex items-center justify-center gap-1.5 rounded-lg border px-3 py-2 text-xs font-semibold transition-colors ${
              pickerMode === "rectangle"
                ? "border-[oklch(0.75_0.12_220)]/60 bg-[oklch(0.75_0.12_220)]/15 text-[oklch(0.85_0.1_220)] shadow-[0_0_12px_-2px_oklch(0.75_0.12_220/0.5)]"
                : "border-white/10 bg-white/[0.02] text-[oklch(0.75_0_0)] hover:border-white/20"
            }`}
          >
            <Square className="size-3.5" />
            Select Area
          </button>
          )}
        </div>
      </div>

      {/* Target coordinates (spot mode point target) */}
      {shapeKind !== "rectangle" && (
        <div hidden={hideFor("reference")} className="rounded-lg border border-white/5 bg-[oklch(0.13_0.02_255)] p-3.5">
          <div className="mb-3 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-[oklch(0.7_0.02_250)]">
            <Crosshair className="size-3.5 text-[oklch(0.75_0.12_220)]" />
            Target Coordinates
          </div>

          <div className="grid grid-cols-2 gap-3">
            <label className="block">
              <span className="mb-1 block text-[10px] font-bold uppercase tracking-wider text-[oklch(0.5_0.02_250)]">
                Latitude
              </span>
              <input
                type="text"
                inputMode="decimal"
                placeholder="e.g. 33.6167"
                value={lat === null ? "" : String(lat)}
                onChange={(e) => {
                  markAsPoint();
                  onLatChange(parseCoord(e.target.value));
                }}
                onFocus={() => setPickerMode(null)}
                className={`w-full rounded border bg-[oklch(0.14_0.03_250)]/70 px-2.5 py-2 text-sm font-semibold text-[oklch(0.9_0_0)] focus:outline-none focus:ring-1 ${
                  latOutOfRange ? "border-red-500/40 focus:ring-red-500/40" : "border-white/10 focus:ring-[oklch(0.75_0.12_220)]/40"
                }`}
              />
            </label>

            <label className="block">
              <span className="mb-1 block text-[10px] font-bold uppercase tracking-wider text-[oklch(0.5_0.02_250)]">
                Longitude
              </span>
              <input
                type="text"
                inputMode="decimal"
                placeholder="e.g. 73.0992"
                value={lon === null ? "" : String(lon)}
                onChange={(e) => {
                  markAsPoint();
                  onLonChange(parseCoord(e.target.value));
                }}
                onFocus={() => setPickerMode(null)}
                className={`w-full rounded border bg-[oklch(0.14_0.03_250)]/70 px-2.5 py-2 text-sm font-semibold text-[oklch(0.9_0_0)] focus:outline-none focus:ring-1 ${
                  lonOutOfRange ? "border-red-500/40 focus:ring-red-500/40" : "border-white/10 focus:ring-[oklch(0.75_0.12_220)]/40"
                }`}
              />
            </label>
          </div>

          {(latOutOfRange || lonOutOfRange) && (
            <div className="mt-2.5 flex items-center gap-2 rounded-lg border border-red-500/30 bg-red-500/10 px-3 py-2 text-xs text-red-300">
              <AlertCircle className="size-3.5 shrink-0" />
              Latitude must be between -90 and 90, longitude between -180 and 180.
            </div>
          )}

          {isIncomplete && !latOutOfRange && !lonOutOfRange && (
            <p className="mt-2.5 text-[11px] leading-snug text-[var(--gm-muted)]">
              Enter both coordinates to lock the target point for this mission.
            </p>
          )}

          {shapeKind === "point" && !isIncomplete && !latOutOfRange && !lonOutOfRange && (
            <div className="mt-2.5 rounded-lg border border-white/5 bg-white/[0.02] px-3.5 py-3">
              <div className="mb-1.5 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-[oklch(0.6_0.02_250)]">
                <Waypoints className="size-3.5 text-[oklch(0.75_0.12_220)]" />
                Operations Mode
                {!operationMode && (
                  <span className="rounded-full border border-[oklch(0.75_0.12_220)]/30 bg-[oklch(0.75_0.12_220)]/10 px-1.5 py-0.5 text-[9px] font-semibold normal-case tracking-normal text-[oklch(0.75_0.12_220)]">
                    auto
                  </span>
                )}
              </div>
              <div className="text-sm font-semibold text-[oklch(0.9_0_0)]">
                {operationMode === "slip" ? "Slip" : "Spot"}
              </div>
              <p className="mt-0.5 text-[11px] leading-snug text-[var(--gm-muted)]">
                {operationMode === "slip"
                  ? "Point target with a longer dwell as the satellite passes."
                  : "Captures a single fixed point target."}
              </p>
            </div>
          )}
        </div>
      )}

      {shapeKind === "rectangle" && rectangleBounds && (
        <StripMode
          section={section}
          rectangleBounds={rectangleBounds}
          onBoundsFieldChange={handleBoundsFieldChange}
          onFieldFocus={() => setPickerMode(null)}
          satelliteIds={satelliteIds}
          tleData={tleData}
          minRangeKm={minRangeKm}
          maxRangeKm={maxRangeKm}
          onMinRangeChange={handleMinRangeChange}
          onMaxRangeChange={handleMaxRangeChange}
          scanHours={ORBIT_SCAN_HOURS}
          frequencySegments={frequencySegments}
          onFrequencySegmentsChange={onFrequencySegmentsChange}
          selectedPassIndex={selectedStripPassIndex}
          onSelectPass={setSelectedStripPassIndex}
          viewerRef={viewerRef}
          onBack={handleBackFromViz}
          onPlanResultChange={setStripPlanResult}
          groundStations={groundStations}
          downloadInGsPass={downloadInGsPass}
          onToggleDownloadInGsPass={onToggleDownloadInGsPass}
          selectedGsName={selectedGsName}
          onSelectGsName={onSelectGsName}
          onGsPassTimeChange={onGsPassTimeChange}
        />
      )}

      {shapeKind !== "rectangle" && (
        <div hidden={hideFor("reference")}>
          <SpotLimitInput
            mode={spotLimitMode}
            value={spotLimitValue}
            geometry={spotLimit}
            onModeChange={handleSpotLimitModeChange}
            onValueCommit={setSpotLimitValue}
          >
            <p className="mt-2 text-[10px] leading-snug text-[oklch(0.5_0.02_250)]">
              Mission duration {formatDuration(missionDurationSeconds * 1000)}
              {frequencySegments.length === 0 ? " (default until a frequency plan is set)" : " (sum of frequency segments)"}
            </p>
          </SpotLimitInput>
        </div>
      )}

      {shapeKind !== "rectangle" && (
        <div hidden={hideFor("orbits")}>
          <div className="mb-2 flex items-center gap-1.5">
            <h3 className="text-[11px] font-bold uppercase tracking-wider text-[oklch(0.6_0.02_250)]">
              Select Upcoming Orbit
            </h3>
            <span className="text-[10px] font-semibold normal-case text-[oklch(0.5_0.02_250)]">
              (next {ORBIT_SCAN_HOURS}h)
            </span>
            <span
              title={
                `Leading satellite: ${leadingSatName ?? "—"} · ` +
                (spotLimit.mode === "elevation"
                  ? `Mission start: elevation ≥ ${spotLimit.minElevationDeg.toFixed(1)}° · LOS: elevation < ${spotLimit.minElevationDeg.toFixed(1)}° · `
                  : `Mission start: range ≤ ${spotLimit.maxRangeKm.toFixed(0)} km · LOS: range > ${spotLimit.maxRangeKm.toFixed(0)} km · `) +
                `AOS: start − ${DUMMY_AOS_LEAD_MINUTES} min · Mission end: start + ${formatDuration(missionDurationSeconds * 1000)} (sum of frequency durations)`
              }
            >
              <Info className="size-3 shrink-0 text-[oklch(0.45_0.02_250)]" />
            </span>
          </div>

          {groupTles.length === 0 ? (
            <div className="flex flex-col items-center gap-2 py-10 text-center">
              <SatelliteIcon className="size-5 text-[oklch(0.45_0.02_250)]" />
              <p className="text-sm text-[oklch(0.5_0.02_250)]">No satellites selected in this Constellation Group yet.</p>
            </div>
          ) : isScanPending ? (
            <p className="py-4 text-center text-xs text-[oklch(0.5_0.02_250)]">Scanning for qualifying orbits…</p>
          ) : (
            <>
              <div className="space-y-2">
                {visibleOrbits.map((orbit, i) => {
                  const active = selectedOrbitIndex === i;
                  const others = otherSatOffsetsByOrbit[i] ?? [];

                  const losChoice = losChoices[passKey(orbit)] ?? null;

                  return (
                    <div
                      key={i}
                      className={`rounded-lg border transition-colors ${
                        active
                          ? "border-[oklch(0.75_0.12_220)]/50 bg-[oklch(0.75_0.12_220)]/10"
                          : orbit.shortPass
                            ? "border-amber-400/40 bg-amber-400/[0.04]"
                            : "border-white/5 bg-white/[0.02]"
                      }`}
                      style={orbit.shortPass ? { boxShadow: "inset 3px 0 0 #e2b04a" } : undefined}
                    >
                      <button
                        type="button"
                        onClick={() => {
                          onSelectOrbit(i);
                          // Selecting an orbit only previews it on the globe; the
                          // accuracy map runs only from its own buttons.
                          // First time a short pass is picked: ask how to complete it.
                          if (orbit.shortPass && !losChoice) setLosDialogIndex(i);
                        }}
                        className="flex w-full flex-col gap-1.5 px-3.5 py-3 text-left"
                      >
                        <div className="flex items-center justify-between gap-2">
                          <div className="flex min-w-0 items-center gap-2">
                            <SatelliteIcon className={`size-4 shrink-0 ${active ? "text-[oklch(0.85_0.1_220)]" : "text-emerald-400"}`} />
                            <span className="truncate text-sm font-semibold text-[oklch(0.92_0_0)]">{leadingSatName ?? "—"}</span>
                            {orbit.shortPass && (
                              <span className="flex shrink-0 items-center gap-1 rounded border border-amber-400/40 bg-amber-400/10 px-1.5 py-px text-[10px] font-semibold text-amber-200">
                                <AlertCircle className="size-3" /> LOS BEFORE END
                              </span>
                            )}
                          </div>
                        </div>
                        <div className="flex flex-wrap items-center justify-between gap-x-3 gap-y-0.5 pl-6 text-xs">
                          <span className="text-[var(--gm-muted)]">
                            At start: el {orbit.elevationAtStartDeg.toFixed(1)}° · range {orbit.rangeAtAosKm.toFixed(0)} km · tilt{" "}
                            {orbit.tiltAtStartDeg.toFixed(1)}°
                          </span>
                          <span className="whitespace-nowrap text-[oklch(0.5_0.1_160)]">
                            {formatDuration(orbit.availableSeconds * 1000)} / {formatDuration(orbit.missionDurationSeconds * 1000)}
                          </span>
                        </div>
                        <div className="grid grid-cols-[auto_1fr] gap-x-3 gap-y-0.5 pl-6 text-xs">
                          <span className="text-[var(--gm-muted)]">AOS</span>
                          <span className="font-mono text-[oklch(0.6_0.02_250)]">{formatUtc(orbit.dummyAos)}</span>
                          <span className="text-[var(--gm-muted)]">Mission start</span>
                          <span className="font-mono font-medium text-[oklch(0.8_0_0)]">{formatUtc(orbit.missionStart)}</span>
                          <span className="text-[var(--gm-muted)]">Mission end</span>
                          <span className="font-mono font-medium text-[oklch(0.8_0_0)]">{formatUtc(orbit.missionEnd)}</span>
                          <span className="text-[var(--gm-muted)]">LOS</span>
                          <span className={`font-mono font-medium ${orbit.shortPass ? "text-amber-300" : "text-[oklch(0.8_0_0)]"}`}>
                            {formatUtc(orbit.los)}
                          </span>
                        </div>
                        <div className="pl-6 text-[11px] text-[var(--gm-muted)]">
                          Closest: el {orbit.maxElevationDeg.toFixed(1)}° · range {orbit.minRangeKm.toFixed(0)} km · tilt{" "}
                          {orbit.tiltAtClosestDeg.toFixed(1)}° at {orbit.closestApproach.toISOString().slice(11, 19)} UTC
                        </div>
                      </button>

                      {/* LOS before mission end: highlight + how this pass is completed. */}
                      {orbit.shortPass && (
                        <div className="mx-3.5 mb-3 flex flex-wrap items-center gap-2 rounded border border-amber-400/30 bg-amber-400/10 px-2.5 py-2 text-[11px] leading-snug text-amber-200">
                          <AlertCircle className="size-3.5 shrink-0" />
                          <span className="min-w-0 flex-1">
                            LOS comes {formatDuration(orbit.missionEnd.getTime() - orbit.los.getTime())} before mission end
                            {" · "}
                            {losChoice === "multi"
                              ? `completing on ${missionPlansByOrbit[i]?.allocations.length ?? 0} passes`
                              : `${formatDuration(orbit.remainingSeconds * 1000)} not covered by this pass`}
                          </span>
                          <button
                            type="button"
                            onClick={() => {
                              onSelectOrbit(i);
                              setLosDialogIndex(i);
                            }}
                            className="shrink-0 rounded border border-amber-400/50 px-2 py-1 font-semibold text-amber-100 hover:bg-amber-400/15"
                          >
                            {losChoice ? "Change option" : "Choose how to complete"}
                          </button>
                        </div>
                      )}

                      {others.length > 0 && (
                        <div className="border-t border-white/5 px-3.5 py-2.5">
                          <div className="mb-1.5 text-[10px] font-bold uppercase tracking-wider text-[oklch(0.5_0.02_250)]">
                            Other qualifying satellites in this constellation group
                          </div>
                          <div className="space-y-2">
                            {others.map((o) => (
                              <div key={o.name} className="flex flex-col gap-0.5 text-xs">
                                <div className="flex min-w-0 items-center gap-1.5">
                                  <span className="size-1.5 shrink-0 rounded-full" style={{ background: o.color }} />
                                  <span className="truncate font-medium text-[oklch(0.85_0_0)]">{o.name}</span>
                                </div>
                                <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5 pl-3 text-[oklch(0.6_0.02_250)]">
                                  {o.aos ? (
                                    <>
                                      <span className="whitespace-nowrap">{formatUtc(o.aos)}</span>
                                      <span className="whitespace-nowrap text-[oklch(0.5_0.1_160)]">({formatOffset(o.offsetMs!)})</span>
                                    </>
                                  ) : (
                                    <span className="whitespace-nowrap text-[oklch(0.5_0.02_250)]">
                                      No qualifying pass in next {ORBIT_SCAN_HOURS}h
                                    </span>
                                  )}
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>

              {leadingOrbits.length > MAX_ORBITS_SHOWN_COLLAPSED && (
                <button
                  type="button"
                  onClick={() => setShowAllOrbits((v) => !v)}
                  className="mt-2 flex w-full items-center justify-center gap-1 text-xs font-semibold text-[oklch(0.7_0.1_220)] hover:text-[oklch(0.85_0.1_220)]"
                >
                  {showAllOrbits ? "Show fewer orbits" : "View more orbits"}
                  <ChevronDown className={`size-3.5 transition-transform ${showAllOrbits ? "rotate-180" : ""}`} />
                </button>
              )}

              {target && leadingOrbits.length === 0 && (
                <p className="py-4 text-center text-xs text-[oklch(0.5_0.02_250)]">
                  No qualifying orbits (
                  {spotLimit.mode === "elevation"
                    ? `elevation ≥ ${spotLimit.minElevationDeg.toFixed(1)}°`
                    : `range ≤ ${spotLimit.maxRangeKm.toFixed(0)} km`}
                  ) found over the target in the next {ORBIT_SCAN_HOURS}h.
                </p>
              )}

              {!target && (
                <p className="py-4 text-center text-xs text-[oklch(0.5_0.02_250)]">
                  Enter target coordinates above to see qualifying orbits.
                </p>
              )}
            </>
          )}
        </div>
      )}

      {shapeKind !== "rectangle" && (
        <div hidden={hideFor("downlink")}>
          <label className="mb-2 flex cursor-pointer items-center gap-2 text-[11px] font-bold uppercase tracking-wider text-[oklch(0.6_0.02_250)]">
            <input
              type="checkbox"
              checked={downloadInGsPass}
              onChange={(e) => onToggleDownloadInGsPass(e.target.checked)}
              className="size-3.5 shrink-0 rounded accent-[oklch(0.75_0.12_220)]"
            />
            <span>Download data in upcoming Ground Station pass and schedule now</span>
          </label>

          {downloadInGsPass && (
            <>
              <div className="mb-2 flex items-center gap-1.5">
                <h3 className="text-[11px] font-bold uppercase tracking-wider text-[oklch(0.6_0.02_250)]">
                  Select Upcoming Ground Station Pass
                </h3>
                <span className="text-[10px] font-semibold normal-case text-[oklch(0.5_0.02_250)]">
                  (next {ORBIT_SCAN_HOURS}h, after the upcoming orbit)
                </span>
              </div>

              {!leadingTle ? (
                <p className="py-4 text-center text-xs text-[oklch(0.5_0.02_250)]">No satellites selected in this Constellation Group yet.</p>
              ) : (
                <>
                  <div className="space-y-2" role="radiogroup" aria-label="Ground station pass">
                    {visiblePasses.map((p, idx) => {
                      const checked = selectedGsName === p.station.name;
                      return (
                        <label
                          key={`${p.station.name}-${p.aos.getTime()}-${idx}`}
                          className={`flex cursor-pointer flex-col gap-1.5 rounded-lg border px-3.5 py-3 transition-colors ${
                            checked ? "border-[oklch(0.75_0.12_220)]/50 bg-[oklch(0.75_0.12_220)]/10" : "border-white/5 bg-white/[0.02] hover:border-white/15"
                          }`}
                        >
                          <div className="flex items-center gap-2">
                            <input
                              type="radio"
                              name="georef-gs-pass-selection"
                              checked={checked}
                              onChange={() => onSelectGsName(p.station.name)}
                              className="size-4 shrink-0 accent-[oklch(0.75_0.12_220)]"
                            />
                            <Radio className="size-4 shrink-0 text-[oklch(0.7_0.02_250)]" />
                            <span className="min-w-0 flex-1 truncate text-sm font-semibold text-[oklch(0.9_0_0)]">
                              {p.station.name}
                            </span>
                            <span
                              className="inline-block size-1.5 shrink-0 rounded-full"
                              style={{ background: p.station.color ?? "#7dd3fc" }}
                            />
                          </div>

                          <div className="flex items-center gap-1.5 pl-6 text-xs">
                            <SatelliteIcon className="size-3.5 shrink-0 text-emerald-400" />
                            <span className="min-w-0 truncate font-semibold text-[oklch(0.85_0_0)]">{leadingSatName}</span>
                            <span className="ml-auto whitespace-nowrap text-[oklch(0.6_0.02_250)]">
                              {formatDuration(p.los.getTime() - p.aos.getTime())}
                            </span>
                          </div>

                          <div className="pl-6 text-[11px] text-[var(--gm-muted)]">
                            {p.station.lat.toFixed(4)}° N, {p.station.lon.toFixed(4)}° E
                          </div>

                          <div className="pl-6 text-xs font-medium text-[oklch(0.75_0_0)]">{formatUtc(p.aos)}</div>
                          <div className="pl-6 text-center text-[11px] text-[var(--gm-muted)]">
                            AOS {p.aos.toISOString().slice(11, 19)} · LOS {p.los.toISOString().slice(11, 19)}
                          </div>
                        </label>
                      );
                    })}
                  </div>

                  {gsPassesForLeadingSat.length > MAX_PASSES_SHOWN_COLLAPSED && (
                    <button
                      type="button"
                      onClick={() => setShowAllPasses((v) => !v)}
                      className="mt-2 flex w-full items-center justify-center gap-1 text-xs font-semibold text-[oklch(0.7_0.1_220)] hover:text-[oklch(0.85_0.1_220)]"
                    >
                      {showAllPasses ? "Show fewer passes" : "View more passes"}
                      <ChevronDown className={`size-3.5 transition-transform ${showAllPasses ? "rotate-180" : ""}`} />
                    </button>
                  )}

                  {gsPassesForLeadingSat.length === 0 && (
                    <p className="py-4 text-center text-xs text-[oklch(0.5_0.02_250)]">
                      No ground station passes found for {leadingSatName} after the upcoming orbit in the next {ORBIT_SCAN_HOURS}h.
                    </p>
                  )}
                </>
              )}
            </>
          )}
        </div>
      )}

      {/* Accuracy sits after the upcoming orbits / coverage plan, before the visualization controls. */}
      {shapeKind !== null && (
        <div hidden={hideFor("orbits")} className="rounded-lg border border-[oklch(0.75_0.12_220)]/20 bg-[oklch(0.75_0.12_220)]/[0.04] px-3.5 py-3">
          <div className="mb-2 flex items-center justify-between gap-2">
            <div className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-[oklch(0.7_0.02_250)]">
              <SlidersHorizontal className="size-3.5 text-[oklch(0.75_0.12_220)]" />
              {shapeKind === "point" ? "Minimum-Swath Accuracy" : "Accuracy Grid"}
            </div>
            <span className="text-xs font-semibold text-[oklch(0.85_0.1_220)]">
              {shapeKind === "point"
                ? `Minimum frequency · ${MIN_FREQUENCY_SWATH_KM} km swath`
                : accuracyEffectiveStepKm > accuracyStepKm
                  ? `${Math.round(accuracyEffectiveStepKm)} km actual · ${accuracyStepKm} km requested`
                  : `${accuracyStepKm} km cells`}
            </span>
          </div>

          {shapeKind === "rectangle" ? (
            <>
              <input
                type="range"
                min={ACCURACY_STEP_MIN_KM}
                max={ACCURACY_STEP_MAX_KM}
                step={5}
                value={accuracyStepKm}
                onChange={(event) => setAccuracyStepKm(Number(event.target.value))}
                aria-label="Accuracy grid step size in kilometres"
                className="w-full accent-[oklch(0.75_0.12_220)]"
              />

              <div className="mt-1 flex justify-between text-[10px] text-[oklch(0.5_0.02_250)]">
                <span>{ACCURACY_STEP_MIN_KM} km detail</span>
                <span>{ACCURACY_STEP_MAX_KM} km overview</span>
              </div>
            </>
          ) : (
            <p className="text-[10px] leading-snug text-[oklch(0.55_0.02_250)]">
              Accuracy is mapped across the minimum-frequency swath, centered on the target marker.
            </p>
          )}

          <button
            type="button"
            onClick={() => setAccuracyRequested(true)}
            disabled={accuracyCalculating || !accuracyTargetReady || !accuracyAnchorOrbit || groupTles.length < 3}
            className="mt-3 flex w-full items-center justify-center gap-2 rounded-lg border border-[oklch(0.75_0.12_220)]/45 bg-[oklch(0.75_0.12_220)]/12 px-3 py-2 text-xs font-bold uppercase tracking-wider text-[oklch(0.86_0.1_220)] transition-colors hover:bg-[oklch(0.75_0.12_220)]/20 disabled:cursor-not-allowed disabled:opacity-40"
          >
            <Waypoints className="size-3.5" />
            {accuracyCalculating
              ? "Calculating accuracy…"
              : accuracyRequested
                ? shapeKind === "point" ? "Recalculate swath estimate" : "Recalculate accuracy map"
                : shapeKind === "point" ? "Calculate swath estimate" : "Calculate accuracy map"}
          </button>

          <button
            type="button"
            onClick={() => {
              if (accuracyAnimationPlaying) {
                setAccuracyAnimationPlaying(false);
              } else {
                setAccuracyRequested(true);
                setAccuracyCalculating(false);
                setAccuracyAnimationPlaying(true);
              }
            }}
            disabled={!accuracyTargetReady || !accuracyAnchorOrbit || groupTles.length < 3}
            className="mt-2 flex w-full items-center justify-center gap-2 rounded-lg border border-emerald-400/35 bg-emerald-400/10 px-3 py-2 text-xs font-bold uppercase tracking-wider text-emerald-200 transition-colors hover:bg-emerald-400/20 disabled:cursor-not-allowed disabled:opacity-40"
          >
            {accuracyAnimationPlaying ? <Pause className="size-3.5" /> : <Play className="size-3.5" />}
            {accuracyAnimationPlaying
              ? shapeKind === "rectangle"
                ? "Pause capture-plan animation"
                : "Pause orbit animation"
              : shapeKind === "rectangle"
                ? "Animate selected capture plan"
                : "Animate minimum-swath estimate"}
          </button>

          {accuracyAnimationPlaying && (
            <p className="mt-1.5 flex items-center justify-between text-[10px] text-emerald-200/80">
              <span>~10 s pass intervals</span>
              <span className="whitespace-nowrap font-mono">
                {accuracyAnimationTime?.toISOString().slice(11, 19) ?? "Starting"} UTC
              </span>
            </p>
          )}

          {!accuracyAnchorOrbit && (
            <p className="mt-1.5 text-[10px] text-[oklch(0.55_0.02_250)]">
              {shapeKind === "rectangle"
                ? "Select a capture-plan pass first. The accuracy map uses that pass window for the estimate."
                : "Select an upcoming orbit first. Selecting another orbit refreshes the estimate for that pass."}
            </p>
          )}

          {groupTles.length === 0 ? (
            <p className="mt-2 text-[11px] leading-snug text-amber-300/80">
              Select satellites in the constellation group to generate the accuracy grid.
            </p>
          ) : (
            <>
              {accuracyCalculating && (
                <div className="mt-2 rounded border border-[oklch(0.75_0.12_220)]/25 bg-[oklch(0.75_0.12_220)]/10 px-2.5 py-2">
                  <div className="flex items-center justify-between text-[11px] text-[oklch(0.8_0.1_220)]">
                    <span className="flex items-center gap-2">
                      <span className="size-3 animate-spin rounded-full border-2 border-[oklch(0.75_0.12_220)]/30 border-t-[oklch(0.85_0.1_220)]" />
                      Calculating accuracy map…
                    </span>
                    <span>
                      {accuracyProgress.total > 0
                        ? `${accuracyProgress.completed}/${accuracyProgress.total}`
                        : "Starting"}
                    </span>
                  </div>
                  <div className="mt-1.5 h-1 overflow-hidden rounded-full bg-white/10">
                    <div
                      className="h-full rounded-full bg-[oklch(0.75_0.12_220)] transition-[width] duration-100"
                      style={{
                        width: `${
                          accuracyProgress.total > 0
                            ? (accuracyProgress.completed / accuracyProgress.total) * 100
                            : 8
                        }%`,
                      }}
                    />
                  </div>
                  <p className="mt-1 text-[10px] text-[oklch(0.6_0.02_250)]">Fine grids can take a few seconds.</p>
                </div>
              )}

              {accuracyError && (
                <p className="mt-2 rounded border border-red-400/25 bg-red-500/10 px-2.5 py-2 text-[11px] text-red-200">
                  {accuracyError}
                </p>
              )}

              {groupTles.length < 3 && (
                <p className="mt-2 text-[11px] leading-snug text-amber-300/80">
                  Select at least 3 satellites for a solved accuracy estimate; unresolved cells remain gray.
                </p>
              )}

              <div className="mt-2 flex items-center justify-between gap-2 text-[11px] text-[var(--gm-muted)]">
                <span>
                  {accuracyStats.minimum !== null && accuracyStats.maximum !== null
                    ? `${formatAccuracy(accuracyStats.minimum)} – ${formatAccuracy(accuracyStats.maximum)}`
                    : "Waiting for satellite geometry"}
                </span>
              </div>

              <div className="mt-3 grid grid-cols-2 gap-x-3 gap-y-1.5 text-[10px] text-[oklch(0.7_0.02_250)]">
                {ACCURACY_COLOR_LEGEND.map(({ color, label }) => (
                  <span key={label} className="flex items-center gap-1.5">
                    <span className="size-2.5 rounded-sm" style={{ backgroundColor: color }} />
                    {label}
                  </span>
                ))}
              </div>

              <p className="mt-2 text-[10px] leading-snug text-[oklch(0.5_0.02_250)]">
                {accuracyAnchorOrbit
                  ? shapeKind === "rectangle"
                    ? `Anchored to selected capture-plan pass (${accuracyAnchorOrbit.aos.toISOString().slice(11, 19)}–${accuracyAnchorOrbit.los.toISOString().slice(11, 19)} UTC)`
                    : `Minimum-frequency swath · selected orbit (${accuracyAnchorOrbit.aos.toISOString().slice(11, 19)}–${accuracyAnchorOrbit.los.toISOString().slice(11, 19)} UTC)`
                  : shapeKind === "rectangle"
                    ? "Select a capture-plan pass to anchor the estimate."
                    : "Select an upcoming orbit to anchor the estimate."}
              </p>
            </>
          )}
        </div>
      )}

      {shapeKind === "rectangle" ? (
        <div hidden={hideFor("orbits")}>
          <FrequencyVisualizeNav
            segments={frequencySegments}
            onVisualize={handleVisualizeStripFrequency}
            onBack={handleBackFromViz}
            onPauseChange={handlePauseViz}
            disabledReason={!stripPlanResult || stripPlanResult.orbits.length === 0 ? "Confirm the frequency plan and find a coverage orbit first" : null}
          />
        </div>
      ) : (
        <>
          <div hidden={hideFor("reference")} className={section ? "" : "border-t border-white/5 pt-4"}>
            {!section && (
              <h3 className="mb-2 text-[11px] font-bold uppercase tracking-wider text-[oklch(0.6_0.02_250)]">
                Frequency and Time
              </h3>
            )}
            <FrequencyPlanTable segments={frequencySegments} onSegmentsChange={onFrequencySegmentsChange} />
          </div>
          <div hidden={hideFor("orbits")}>
            <FrequencyVisualizeNav
              segments={frequencySegments}
              onVisualize={handleVisualizeSpot}
              onBack={handleBackFromViz}
              onPauseChange={handlePauseViz}
              disabledReason={!target ? "Set a target first" : groupTles.length === 0 ? "No satellites in this group" : null}
            />
          </div>
        </>
      )}

      {onSaveConfiguration && (
        <div hidden={hideFor("downlink")} className="border-t border-white/5 pt-4">
          {saveError && (
            <div
              role="alert"
              className="mb-3 flex min-w-0 items-start gap-2 rounded-md border border-red-400/25 bg-red-500/10 px-3 py-2.5 text-xs leading-4 text-red-200"
            >
              <AlertCircle className="mt-0.5 size-3.5 shrink-0 text-red-300" aria-hidden="true" />
              <span className="min-w-0 break-words">{saveError}</span>
            </div>
          )}
          <button
            type="button"
            onClick={onSaveConfiguration}
            disabled={isSaving}
            className="flex w-full items-center justify-center gap-2 rounded-lg border border-[oklch(0.75_0.12_220)]/40 bg-[oklch(0.75_0.12_220)]/10 py-2 text-xs font-bold uppercase tracking-wider text-[oklch(0.85_0.1_220)] transition-colors hover:bg-[oklch(0.75_0.12_220)]/20 disabled:cursor-not-allowed disabled:opacity-50"
          >
            {isSaving ? "Saving…" : "Save Configuration File"}
          </button>
        </div>
      )}
    </div>
  );
}