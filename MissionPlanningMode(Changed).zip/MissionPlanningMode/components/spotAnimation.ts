import * as Cesium from "cesium";
import * as satellite from "satellite.js";
import { FREQUENCY_PRESETS, type FrequencySegment } from "./FrequencyAndTime";
import {
  addBeamFrustum,
  fmtUtc,
  mountBackToGlobeButton,
  mountFrequencyPanel,
  STRIP_VIZ_PANEL_ID,
  type BeamFrame,
  type FrequencyPanel,
} from "./stripVizPanel";
import { isVizPaused, vizStarted, vizStopped } from "./vizPlayback";
import {
  DEFAULT_SPOT_LIMIT,
  DUMMY_AOS_LEAD_MINUTES,
  findSpotOrbits,
  isInsideSpotLimit,
  ORBIT_HEIGHT_KM,
  resolveSpotLimit,
  sampleSpotProfile,
  spotGeometryAt,
  type GroundPoint,
  type SpotLimit,
  type SpotLimitGeometry,
  type SpotOrbit,
  type SpotSnapshot,
  type TleEntry,
} from "./SpotModeRange";

// ─── Spot-mode animation ──────────────────────────────────────────────────
//
// The target is fixed. Every satellite of the constellation group flies along
// its real (SGP4) ground track; all satellites are drawn at the SAME UTC
// instant, so a formation (e.g. a 4-satellite rhombus, 40–60 km apart) keeps
// its real shape. Sensor pointing, per satellite:
//   before AOS                 → sensor at nadir (beam straight down)
//   AOS → AOS + SLEW_SECONDS   → slews from nadir to the target
//   … → capture end / LOS      → stays on the target (imaging from mission start)
//   then                       → slews back to nadir
// The globe shows only satellites, beams, footprints, ground tracks and the
// AOS / mission start / mission end / LOS markers (pinned to the ground).
// Geometry helper lines (SHOW_GEOMETRY_OVERLAYS, off by default) and every
// number live in the panels under the globe. Camera presets: Target view
// (default, static), Follow formation, Whole pass.
// Every frame (with SHOW_GEOMETRY_OVERLAYS on) shows:
//   • the satellite model (glTF) oriented along its boresight
//   • a volumetric sensor BEAM per satellite down to its ground footprint
//     (frequency colour + swath while imaging, small idle spot otherwise)
//   • the NADIR line       satellite → sub-satellite point (yellow)
//   • the SLANT RANGE line satellite → target (green inside the limit, red outside)
//   • the ground line      sub-satellite point → target (grey)
//   • the tilt arc (at the satellite) and the elevation arc (at the target)
// The globe only carries NAMES (Slant range, Nadir, Tilt, Elevation, Target).
// All numbers sit UNDER the globe, like the Strip animation: the frequency
// panel (bar + legend) and below it the pass-geometry panel with live
// elevation / tilt / range for every satellite, AOS / start / end / LOS and
// a chart of the leading satellite's pass with the valid window and playhead.
//
// Timeline of the leading satellite (the selected upcoming orbit):
//   AOS (dummy) = mission start − 5 min → mission start → mission end / LOS
// Multi-pass mission (LOS before mission end, "complete on upcoming passes"):
// `options.passes` lists the passes; the animation plays pass 1, then pass 2,
// … each with its own ground track, markers and pass-geometry panel, and the
// frequency clock continues from one pass to the next.
// The frequency swath is only drawn while the satellite is imaging
// (mission start → min(mission end, LOS)).

// ─── Types ────────────────────────────────────────────────────────────────

export type SpotSatelliteInput = {
  name: string;
  tle1: string;
  tle2: string;
  color: string;
};

export type SpotVisualizationOptions = {
  targetLat: number;
  targetLon: number;
  satellites: SpotSatelliteInput[];
  referenceTime?: Date;
  /** Amber alert under the globe, e.g. LOS before mission end. */
  warning?: string | null;
  /** "Back to Globe" on the globe: called after the animation is cleared. */
  onBack?: () => void;
  /** The upcoming orbit selected in the list (leading satellite). */
  orbit?: SpotOrbit | null;
  /** Name of the satellite `orbit` belongs to. Default: first satellite. */
  leaderName?: string | null;
  /** The limit the user entered (min elevation OR max range). */
  limit?: SpotLimit | SpotLimitGeometry | null;
  /**
   * Multi-pass mission ("complete on upcoming passes"): the passes of the
   * leading satellite that together cover the frequency plan, in order. The
   * animation plays pass 1, then pass 2, … and the mission clock continues
   * from one pass to the next. Omit (or pass one item) for a single pass.
   */
  passes?: SpotPassPlan[] | null;
};

/** One pass of a multi-pass mission. */
export type SpotPassPlan = {
  orbit: SpotOrbit;
  /** Seconds into the frequency plan where this pass starts capturing. */
  planOffsetSeconds: number;
  /** Seconds of the plan captured on this pass (mission start → start + this). */
  durationSeconds: number;
};

// ─── Constants ────────────────────────────────────────────────────────────

/**
 * How satellites are drawn:
 *   "gltf"  = 3D model file SATELLITE_MODEL_URL (public/models/satellite.glb)
 *   "boxes" = simple procedural model (no file needed)
 *   "icon"  = the old /satellite.png billboard
 */
const SATELLITE_STYLE: "gltf" | "boxes" | "icon" = "gltf";
/** glTF 2.0 model (.glb). Cesium cannot load .dae — convert Collada with e.g. Blender → .glb. */
const SATELLITE_MODEL_URL = "/models/satellite.glb";
/** The model is real-size (~8 m); it is drawn at least this many pixels tall. */
const MODEL_MIN_PIXEL_SIZE = 56;
const MODEL_MAX_SCALE = 20000;
const SATELLITE_ICON_URL = "/satellite.png";
const ENTITY_PREFIX = "spotviz__";
const OVERLAY_CLASS = "spot-viz-overlay";
/** Kept across passes of a multi-pass mission (removed with everything else on clear). */
const FORMATION_NAME_ID = `${ENTITY_PREFIX}__formation_name`;
const SATELLITE_ICON_COLOR = Cesium.Color.WHITE;
/** Upper bound of the mission clock; the actual length is the sum of the segments. */
const MAX_MISSION_DURATION_SECONDS = 10 * 60;
const MISSION_SECONDS_PER_REAL_SECOND = 35;
const TRACK_SAMPLE_COUNT = 90;
const TRACK_MARGIN_FRACTION_OF_PERIOD = 0.5;
const GROUND_TRACK_WIDTH = 4;
const GROUND_TRACK_GLOW_POWER = 0.35;
const GROUND_TRACK_ALPHA = 1.0;
const PASS_SWING_EXTENSION = 1.25;
const EARTH_RADIUS_KM = 6371;
const SWATH_NATURAL_OFFSET_FRACTION = 0.4;
/** Seconds shown after LOS / mission end before the loop restarts. */
const TIMELINE_TAIL_SECONDS = 90;
/** Samples in the live chart. */
const CHART_SAMPLES = 160;
/** Range axis of the live chart (km). */
const CHART_RANGE_MAX_KM = 3000;

// Satellite model — exaggerated so it is visible from orbit-scale views.
const MODEL_BODY_M = { x: 60_000, y: 60_000, z: 90_000 };
const MODEL_PANEL_M = { x: 70_000, y: 200_000, z: 4_000 };
const MODEL_PANEL_OFFSET_M = 135_000;
/** Sensor slew time: nadir → target after AOS, and target → nadir after capture. */
const SLEW_SECONDS = 60;
/** Seconds shown before AOS (sensor at nadir). */
const PRE_AOS_SECONDS = 90;
/** Footprint size when the sensor is not imaging (nadir / slewing). */
const IDLE_FOOTPRINT_KM = 40;
const BEAM_COLOR_NADIR = Cesium.Color.fromCssColorString("#9fb6ff");
const BEAM_COLOR_SLEW = Cesium.Color.fromCssColorString("#ffb454");
/** Camera "follow formation": behind the formation, looking toward the target. The
 *  camera moves with the formation each frame; you can still rotate / zoom. */
const FOLLOW_RANGE_M = 420_000;
const FOLLOW_PITCH_DEG = -24;
const TILT_ARC_RADIUS_M = 260_000;
const ELEV_ARC_RADIUS_M = 320_000;

const COLOR_OK = Cesium.Color.fromCssColorString("#3ddc97");
const COLOR_BAD = Cesium.Color.fromCssColorString("#ff5d6c");
const COLOR_NADIR = Cesium.Color.fromCssColorString("#ffd24a");
const COLOR_GROUND = Cesium.Color.fromCssColorString("#9aa7bd");
const COLOR_ELEV = Cesium.Color.fromCssColorString("#5aa9ff");
const COLOR_TILT = Cesium.Color.fromCssColorString("#ffb454");

// Single quotes: these are also written inside HTML style="…" attributes.
const FONT = "'Roboto', 'Segoe UI', system-ui, sans-serif";
const MONO = "'Roboto Mono', ui-monospace, Consolas, monospace";

/** Draw the geometry helpers on the globe (slant-range / nadir / ground lines,
 *  tilt + elevation arcs and their labels). Off: the globe shows only the
 *  satellites, their beams and footprints — the numbers are in the panel. */
const SHOW_GEOMETRY_OVERLAYS = false;
/** Points / labels are drawn on top (never cut by the globe surface); whether
 *  they are on the visible side of the Earth is decided by `onVisibleSide()`. */
const NEAR_DEPTH_OFF_M = Number.POSITIVE_INFINITY;
/** Height of the pole that carries an AOS / Mission start / Mission end / LOS label in 3D. */
const MARKER_POLE_HEIGHT_M = 70_000;

/**
 * Show a point / label only while its position is on the side of the Earth
 * facing the camera. Without this, markers drawn "on top" stay visible through
 * the globe when it is turned and look like they float.
 */
function onVisibleSide(viewer: Cesium.Viewer, position: () => Cesium.Cartesian3 | undefined): Cesium.CallbackProperty {
  return new Cesium.CallbackProperty(() => isOnVisibleSide(viewer, position()), false);
}

function isOnVisibleSide(viewer: Cesium.Viewer, p: Cesium.Cartesian3 | undefined): boolean {
  if (!p || viewer.isDestroyed()) return false;
  // 2D map: nothing is behind the Earth.
  if (viewer.scene.mode !== Cesium.SceneMode.SCENE3D) return true;
  // Polar radius (slightly inside the ellipsoid) so points on the visible limb stay shown.
  const R2 = 6_356_000 * 6_356_000;
  const c = viewer.camera.positionWC;
  // Hidden when the straight line camera → point passes through the Earth.
  const vx = p.x - c.x, vy = p.y - c.y, vz = p.z - c.z;
  const vv = vx * vx + vy * vy + vz * vz;
  if (vv === 0) return true;
  const t = -(c.x * vx + c.y * vy + c.z * vz) / vv;
  if (t <= 0 || t >= 1) return true;
  const x = c.x + t * vx, y = c.y + t * vy, z = c.z + t * vz;
  return x * x + y * y + z * z > R2;
}

/** Satellite names: plain white text with a thin dark outline (no tags, no colours). */
function satelliteNameLabel(
  text: string,
  offset: Cesium.Cartesian2,
  show: Cesium.CallbackProperty,
  translucencyByDistance?: Cesium.NearFarScalar,
): Cesium.LabelGraphics.ConstructorOptions {
  return {
    text,
    show,
    font: `600 13px ${FONT}`,
    fillColor: Cesium.Color.WHITE,
    outlineColor: Cesium.Color.fromCssColorString("#05080d"),
    outlineWidth: 3,
    style: Cesium.LabelStyle.FILL_AND_OUTLINE,
    horizontalOrigin: Cesium.HorizontalOrigin.LEFT,
    verticalOrigin: Cesium.VerticalOrigin.CENTER,
    pixelOffset: offset,
    disableDepthTestDistance: NEAR_DEPTH_OFF_M,
    translucencyByDistance,
  };
}
const LABEL_BG = Cesium.Color.fromCssColorString("#0d1117").withAlpha(0.8);
const LABEL_TEXT = Cesium.Color.fromCssColorString("#e6edf3");

/** One label style for everything on the globe (professional, white on dark). */
function globeLabel(
  text: string,
  offset: Cesium.Cartesian2,
  clamp = false,
  translucencyByDistance?: Cesium.NearFarScalar,
  show?: Cesium.CallbackProperty,
): Cesium.LabelGraphics.ConstructorOptions {
  return {
    show,
    translucencyByDistance,
    text,
    font: `500 11px ${FONT}`,
    fillColor: LABEL_TEXT,
    showBackground: true,
    backgroundColor: LABEL_BG,
    backgroundPadding: new Cesium.Cartesian2(6, 3),
    horizontalOrigin: Cesium.HorizontalOrigin.LEFT,
    verticalOrigin: Cesium.VerticalOrigin.CENTER,
    pixelOffset: offset,
    heightReference: clamp ? Cesium.HeightReference.CLAMP_TO_GROUND : Cesium.HeightReference.NONE,
    disableDepthTestDistance: NEAR_DEPTH_OFF_M,
  };
}

/** Camera presets of the spot animation. */
export type SpotCameraMode = "target" | "formation" | "pass";
const CAMERA_MODES: { id: SpotCameraMode; label: string }[] = [
  { id: "target", label: "Target view" },
  { id: "formation", label: "Follow formation" },
  { id: "pass", label: "Whole pass" },
];
/** Target view: oblique view across the target toward the pass. */
const TARGET_VIEW_PITCH_DEG = -34;
const TARGET_VIEW_RANGE_FACTOR = 1.75;
/** Formation labels: individual names close up, one "formation" name when far
 *  away (several satellites 40–60 km apart would otherwise overlap). */
const NAMES_FADE = new Cesium.NearFarScalar(0.9e6, 1.0, 1.3e6, 0.0);
const FORMATION_NAME_FADE = new Cesium.NearFarScalar(0.9e6, 0.0, 1.3e6, 1.0);

// ─── Generic geometry helpers ───────────────────────────────────────────

const toDeg = (rad: number) => (rad * 180) / Math.PI;

function wrapLon(lon: number) {
  let l = lon;
  if (l > 180) l -= 360;
  if (l < -180) l += 360;
  return l;
}

function haversineKm(lat1: number, lon1: number, lat2: number, lon2: number) {
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = (wrapLon(lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLon / 2) ** 2;
  return 2 * EARTH_RADIUS_KM * Math.asin(Math.min(1, Math.sqrt(a)));
}

function subPointAt(
  satrec: satellite.SatRec,
  date: Date,
): { lat: number; lon: number; heightKm: number } | null {
  const pv = satellite.propagate(satrec, date);
  if (!pv?.position || typeof pv.position === "boolean") return null;
  const gmst = satellite.gstime(date);
  const geo = satellite.eciToGeodetic(pv.position, gmst);
  return { lat: toDeg(geo.latitude), lon: wrapLon(toDeg(geo.longitude)), heightKm: geo.height };
}

function headingRadAt(satrec: satellite.SatRec, date: Date): number {
  const deltaMs = 1000;
  const before = subPointAt(satrec, new Date(date.getTime() - deltaMs));
  const after = subPointAt(satrec, new Date(date.getTime() + deltaMs));
  if (!before || !after) return 0;
  const dLat = after.lat - before.lat;
  const dLon = wrapLon(after.lon - before.lon) * Math.cos((before.lat * Math.PI) / 180);
  return Math.atan2(dLon, dLat);
}

function orbitalPeriodSeconds(satrec: satellite.SatRec): number {
  const rec = satrec as unknown as { no_kozai?: number; no?: number };
  const meanMotionRadPerMin = rec.no_kozai ?? rec.no ?? 0;
  if (!meanMotionRadPerMin) return 5400;
  return ((2 * Math.PI) / meanMotionRadPerMin) * 60;
}

function elevationDegAt(
  satrec: satellite.SatRec,
  date: Date,
  targetLatDeg: number,
  targetLonDeg: number,
): number | null {
  const pv = satellite.propagate(satrec, date);
  if (!pv?.position || typeof pv.position === "boolean") return null;
  const gmst = satellite.gstime(date);
  const positionEcf = satellite.eciToEcf(pv.position, gmst);
  const observerGd = {
    latitude: (targetLatDeg * Math.PI) / 180,
    longitude: (targetLonDeg * Math.PI) / 180,
    height: 0,
  };
  const look = satellite.ecfToLookAngles(observerGd, positionEcf);
  return (look.elevation * 180) / Math.PI;
}

function activeOrHeldIndexAt(
  segments: FrequencySegment[],
  elapsedSeconds: number,
  missionSeconds: number,
): number {
  if (segments.length === 0) return -1;

  const elapsed = Math.max(0, Math.min(missionSeconds, elapsedSeconds));

  for (let i = 0; i < segments.length; i++) {
    const s = segments[i];
    const start = Math.max(0, s.startSeconds);
    const end = Math.min(missionSeconds, s.startSeconds + s.durationSeconds);

    if (elapsed >= start && elapsed < end) return i;
  }

  if (elapsed >= missionSeconds) {
    return segments.length - 1;
  }

  return -1;
}

/** Lays the segments back to back with their real durations. Mission length
 *  = sum of the segment durations, capped at 10 min (later segments are
 *  trimmed / dropped past the cap). */
function normalizeSegmentsToMission(segments: FrequencySegment[]): {
  plan: FrequencySegment[];
  missionSeconds: number;
} {
  const ordered = [...segments]
    .filter((s) => Number.isFinite(s.durationSeconds) && s.durationSeconds > 0)
    .sort((a, b) => a.startSeconds - b.startSeconds);

  const plan: FrequencySegment[] = [];
  let cursor = 0;
  for (const segment of ordered) {
    if (cursor >= MAX_MISSION_DURATION_SECONDS) break;
    const duration = Math.min(segment.durationSeconds, MAX_MISSION_DURATION_SECONDS - cursor);
    plan.push({ ...segment, startSeconds: cursor, durationSeconds: duration });
    cursor += duration;
  }

  return { plan, missionSeconds: cursor > 0 ? cursor : MAX_MISSION_DURATION_SECONDS };
}

function squareHalfDegrees(lat: number, sideKm: number): { halfLatDeg: number; halfLonDeg: number } {
  const halfLatDeg = sideKm / 2 / 111.32;
  const metersPerDegLon = 111.32 * Math.cos((lat * Math.PI) / 180);
  const halfLonDeg = sideKm / 2 / Math.max(metersPerDegLon, 1);
  return { halfLatDeg, halfLonDeg };
}

const smoothStep = (x: number) => (x <= 0 ? 0 : x >= 1 ? 1 : x * x * (3 - 2 * x));

/** Square footprint on the ground: centre `c`, sides along `along` and across, half side in metres. */
function groundSquare(c: Cesium.Cartesian3, along: Cesium.Cartesian3, halfM: number): Cesium.Cartesian3[] {
  const up = Cesium.Ellipsoid.WGS84.geodeticSurfaceNormal(c, new Cesium.Cartesian3());
  const across = Cesium.Cartesian3.normalize(Cesium.Cartesian3.cross(up, along, new Cesium.Cartesian3()), new Cesium.Cartesian3());
  const corner = (a: number, b: number) => {
    const p = Cesium.Cartesian3.add(
      c,
      Cesium.Cartesian3.add(
        Cesium.Cartesian3.multiplyByScalar(along, a * halfM, new Cesium.Cartesian3()),
        Cesium.Cartesian3.multiplyByScalar(across, b * halfM, new Cesium.Cartesian3()),
        new Cesium.Cartesian3(),
      ),
      new Cesium.Cartesian3(),
    );
    return Cesium.Ellipsoid.WGS84.scaleToGeodeticSurface(p, new Cesium.Cartesian3()) ?? p;
  };
  return [corner(1, 1), corner(1, -1), corner(-1, -1), corner(-1, 1)];
}

function naturalSwathCenter(
  anchorLat: number,
  anchorLon: number,
  targetLat: number,
  targetLon: number,
): { lat: number; lon: number } {
  const dLat = anchorLat - targetLat;
  const dLon = wrapLon(anchorLon - targetLon);
  return {
    lat: targetLat + dLat * SWATH_NATURAL_OFFSET_FRACTION,
    lon: wrapLon(targetLon + dLon * SWATH_NATURAL_OFFSET_FRACTION),
  };
}

// ── Vector helpers (Cesium Cartesian3, ECEF metres) ──

const V = Cesium.Cartesian3;

function dirTo(from: Cesium.Cartesian3, to: Cesium.Cartesian3): Cesium.Cartesian3 {
  const d = V.subtract(to, from, new V());
  return V.magnitude(d) > 0 ? V.normalize(d, d) : new V(0, 0, 1);
}

function along(p: Cesium.Cartesian3, dir: Cesium.Cartesian3, meters: number): Cesium.Cartesian3 {
  return V.add(p, V.multiplyByScalar(dir, meters, new V()), new V());
}

/** Arc of `n` points around `center` from direction v1 to v2 at radius r. */
function arcPoints(center: Cesium.Cartesian3, v1: Cesium.Cartesian3, v2: Cesium.Cartesian3, r: number, n = 16) {
  const out: Cesium.Cartesian3[] = [];
  for (let i = 0; i <= n; i++) {
    const t = i / n;
    const v = V.add(V.multiplyByScalar(v1, 1 - t, new V()), V.multiplyByScalar(v2, t, new V()), new V());
    if (V.magnitude(v) === 0) continue;
    V.normalize(v, v);
    out.push(along(center, v, r));
  }
  return out;
}

/** Body frame: +z boresight (toward target), +x along velocity, +y = z × x. */
function bodyOrientation(
  sat: Cesium.Cartesian3,
  target: Cesium.Cartesian3,
  velocityDir: Cesium.Cartesian3,
): { q: Cesium.Quaternion; x: Cesium.Cartesian3; y: Cesium.Cartesian3; z: Cesium.Cartesian3 } {
  const z = dirTo(sat, target);
  let x = V.subtract(velocityDir, V.multiplyByScalar(z, V.dot(velocityDir, z), new V()), new V());
  if (V.magnitude(x) < 1e-6) x = V.cross(z, V.UNIT_Z, new V());
  if (V.magnitude(x) < 1e-6) x = V.cross(z, V.UNIT_X, new V());
  V.normalize(x, x);
  const y = V.normalize(V.cross(z, x, new V()), new V());
  const m = new Cesium.Matrix3();
  Cesium.Matrix3.setColumn(m, 0, x, m);
  Cesium.Matrix3.setColumn(m, 1, y, m);
  Cesium.Matrix3.setColumn(m, 2, z, m);
  return { q: Cesium.Quaternion.fromRotationMatrix(m), x, y, z };
}

// ─── Real per-satellite pass geometry (fully TLE-derived) ────────────────

type SpotSatellitePass = {
  satrec: satellite.SatRec;
  anchorTime: Date;
  anchorLat: number;
  anchorLon: number;
  missDistanceKm: number;
  periodSeconds: number;
  halfPassSeconds: number;
  halfSwingSeconds: number;
  headingRad: number;
};

function computeSpotPass(
  sat: SpotSatelliteInput,
  targetLat: number,
  targetLon: number,
  referenceTime: Date,
): SpotSatellitePass {
  const satrec = satellite.twoline2satrec(sat.tle1, sat.tle2);
  const period = orbitalPeriodSeconds(satrec);
  const halfWindow = period / 2;

  const coarseStep = Math.max(period / 200, 5);
  let bestTime = referenceTime;
  let bestDist = Infinity;
  for (let t = -halfWindow; t <= halfWindow; t += coarseStep) {
    const date = new Date(referenceTime.getTime() + t * 1000);
    const sp = subPointAt(satrec, date);
    if (!sp) continue;
    const d = haversineKm(sp.lat, sp.lon, targetLat, targetLon);
    if (d < bestDist) {
      bestDist = d;
      bestTime = date;
    }
  }
  const fineStep = Math.max(coarseStep / 10, 1);
  const fineStart = new Date(bestTime.getTime() - coarseStep * 1000);
  for (let t = 0; t <= coarseStep * 2; t += fineStep) {
    const date = new Date(fineStart.getTime() + t * 1000);
    const sp = subPointAt(satrec, date);
    if (!sp) continue;
    const d = haversineKm(sp.lat, sp.lon, targetLat, targetLon);
    if (d < bestDist) {
      bestDist = d;
      bestTime = date;
    }
  }

  const anchorSp = subPointAt(satrec, bestTime);

  const elevationStep = Math.max(period / 1000, 1);
  const findEdgeSeconds = (direction: 1 | -1): number => {
    let seconds = 0;
    while (seconds < halfWindow) {
      seconds += elevationStep;
      const date = new Date(bestTime.getTime() + direction * seconds * 1000);
      const elev = elevationDegAt(satrec, date, targetLat, targetLon);
      if (elev === null || elev <= 0) return seconds;
    }
    return seconds;
  };
  const riseSeconds = findEdgeSeconds(-1);
  const setSeconds = findEdgeSeconds(1);
  const halfPassSeconds = Math.max((riseSeconds + setSeconds) / 2, elevationStep);

  return {
    satrec,
    anchorTime: bestTime,
    anchorLat: anchorSp?.lat ?? targetLat,
    anchorLon: anchorSp?.lon ?? targetLon,
    missDistanceKm: bestDist,
    periodSeconds: period,
    halfPassSeconds,
    halfSwingSeconds: halfPassSeconds * PASS_SWING_EXTENSION,
    headingRad: headingRadAt(satrec, bestTime),
  };
}

/** Timeline one satellite is animated over. */
type SatTimeline = {
  /** First / last instant drawn. */
  windowStart: Date;
  windowEnd: Date;
  /** Null when no window inside the limit was found near the reference time. */
  orbit: SpotOrbit | null;
};

/** The satellite's qualifying window closest to `referenceTime`. */
function nearestSpotOrbit(
  tle: TleEntry,
  target: GroundPoint,
  limit: SpotLimitGeometry,
  referenceTime: Date,
  periodSeconds: number,
  missionDurationSeconds: number,
): SpotOrbit | null {
  const from = new Date(referenceTime.getTime() - periodSeconds * 1000);
  const to = new Date(referenceTime.getTime() + periodSeconds * 1000);
  const orbits = findSpotOrbits(tle, target, from, to, limit, { missionDurationSeconds, stepSeconds: 20 });
  if (orbits.length === 0) return null;
  const ref = referenceTime.getTime();
  const dist = (o: SpotOrbit) =>
    ref >= o.missionStart.getTime() && ref <= o.los.getTime()
      ? 0
      : Math.min(Math.abs(o.missionStart.getTime() - ref), Math.abs(o.los.getTime() - ref));
  return orbits.reduce((a, b) => (dist(b) < dist(a) ? b : a));
}

function timelineFor(orbit: SpotOrbit | null, pass: SpotSatellitePass, captureSeconds: number): SatTimeline {
  if (orbit) {
    const captureEnd = orbit.missionStart.getTime() + captureSeconds * 1000;
    const end = Math.max(orbit.los.getTime(), captureEnd) + TIMELINE_TAIL_SECONDS * 1000;
    return { windowStart: new Date(orbit.dummyAos.getTime() - PRE_AOS_SECONDS * 1000), windowEnd: new Date(end), orbit };
  }
  const a = pass.anchorTime.getTime();
  return {
    windowStart: new Date(a - pass.halfSwingSeconds * 1000),
    windowEnd: new Date(a + pass.halfSwingSeconds * 1000),
    orbit: null,
  };
}

// ─── Hide/restore the real-time "current position" satellite markers ────

let hiddenPlanningSatEntityIds: string[] = [];

function hidePlanningSatelliteEntities(viewer: Cesium.Viewer) {
  hiddenPlanningSatEntityIds = [];
  viewer.entities.values.forEach((e) => {
    const id = typeof e.id === "string" ? e.id : "";
    if (!id.startsWith("mp__")) return;
    if (!(id.endsWith("__ground") || id.endsWith("__current"))) return;
    hiddenPlanningSatEntityIds.push(id);
    e.show = false;
  });
}

function restorePlanningSatelliteEntities(viewer?: Cesium.Viewer) {
  if (viewer && !viewer.isDestroyed()) {
    hiddenPlanningSatEntityIds.forEach((id) => {
      const entity = viewer.entities.getById(id);
      if (entity) entity.show = true;
    });
    viewer.scene.requestRender();
  }
  hiddenPlanningSatEntityIds = [];
}

// ─── Live pass-geometry panel (under the globe, like the Strip readout) ────

type GeometryRow = {
  name: string;
  color: string;
  snap: SpotSnapshot | null;
  inside: boolean;
  sensor: "nadir" | "slewing" | "target";
};

type GeometryPanel = {
  update: (u: { phase: string; phaseTone: "ok" | "warn" | "idle"; rows: GeometryRow[]; leaderTime: Date }) => void;
  dispose: () => void;
};

const fmtMmSs = (sec: number) => {
  const s = Math.max(0, Math.round(Math.abs(sec)));
  return `${Math.floor(s / 60).toString().padStart(2, "0")}:${(s % 60).toString().padStart(2, "0")}`;
};

function mountGeometryPanel(
  viewer: Cesium.Viewer,
  opts: {
    limit: SpotLimitGeometry;
    leaderName: string;
    profile: { t: Date; snap: SpotSnapshot }[];
    windowStart: Date;
    windowEnd: Date;
    orbit: SpotOrbit | null;
    /** Mission end of this pass (start + this pass's share of the plan). */
    captureEnd: Date | null;
    /** e.g. "Pass 1 of 2 · 2026-10-15" — shown in the title on multi-pass missions. */
    passLabel: string | null;
  },
): GeometryPanel {
  const { limit } = opts;
  // Same place and look as the Strip readout: a card UNDER the globe, right
  // below the frequency panel. Falls back to the bottom of the globe if the
  // host element is missing.
  const host = document.getElementById(STRIP_VIZ_PANEL_ID);
  const root = document.createElement("div");
  root.className = OVERLAY_CLASS;
  root.style.cssText =
    (host ? "margin-bottom:10px;" : "position:absolute;left:12px;right:12px;bottom:12px;z-index:20;") +
    "padding:14px 16px;border:1px solid rgba(255,255,255,.08);border-radius:12px;" +
    "background:linear-gradient(180deg,rgba(24,28,36,.9),rgba(12,14,18,.94));" +
    `color:#e8ecf0;font:13px/1.45 ${FONT};box-shadow:0 10px 30px rgba(0,0,0,.35);`;

  const entered =
    limit.mode === "elevation"
      ? `Min elevation ${limit.minElevationDeg.toFixed(1)}° → max range ${limit.maxRangeKm.toFixed(0)} km`
      : `Max range ${limit.maxRangeKm.toFixed(0)} km → min elevation ${limit.minElevationDeg.toFixed(1)}°`;

  const big = (key: string, label: string, color: string) =>
    `<div style="display:flex;flex-direction:column;gap:2px;min-width:0">
<span data-k="${key}" style="font:600 20px ${MONO};color:${color};line-height:1.15;white-space:nowrap">—</span>
<span style="font-size:11px;color:#8a96a3">${label}</span></div>`;
  const timeCell = (label: string, d: Date | null, color = "#e8ecf0") =>
    `<div style="display:flex;flex-direction:column;min-width:0"><span style="font-size:10.5px;color:#8a96a3;white-space:nowrap">${label}</span>` +
    `<span style="font:500 12.5px ${MONO};color:${color}">${d ? fmtUtc(d) : "—"}</span></div>`;
  const legendItem = (color: string, label: string, mark = "■") =>
    `<span style="display:flex;align-items:center;gap:6px"><span style="color:${color}">${mark}</span>${label}</span>`;
  const o = opts.orbit;
  const losEarly = !!(o && opts.captureEnd && o.los.getTime() < opts.captureEnd.getTime());

  root.innerHTML = `
<div style="display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:12px">
<span style="font-weight:600;font-size:14px;color:#f1f5f8">${opts.passLabel ? `<span style="color:#7fe3ff">${opts.passLabel}</span> · ` : ""}Pass geometry · ${opts.leaderName} · ${entered} · tilt ≤ ${limit.maxTiltDeg.toFixed(1)}°</span>
<span data-k="status" style="font-size:11.5px;font-weight:600;padding:3px 9px;border-radius:999px;white-space:nowrap"></span></div>
<div style="display:grid;grid-template-columns:repeat(3,minmax(0,1fr)) 1.6fr;gap:12px;align-items:end;margin-bottom:12px">
${big("el", "Elevation", "#5aa9ff")}
${big("tilt", "Tilt (off-nadir)", "#ffb454")}
${big("rg", "Slant range", "#ff6bd6")}
<div style="display:flex;flex-direction:column;gap:2px;min-width:0">
<span data-k="phase" style="font-size:12.5px;font-weight:600;line-height:1.3"></span>
<span style="font-size:11px;color:#8a96a3">Phase</span></div>
</div>
<canvas data-k="chart" style="width:100%;height:150px;display:block;border-radius:7px;border:1px solid rgba(255,255,255,.12);background:rgba(0,0,0,.25)"></canvas>
<div style="display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:6px;margin-top:8px;padding-top:10px;border-top:1px solid rgba(255,255,255,.08)">
${timeCell("AOS", o?.dummyAos ?? null)}
${timeCell("Mission start", o?.missionStart ?? null, "#6ee7b7")}
${timeCell("Mission end", opts.captureEnd)}
${timeCell(losEarly ? "LOS ⚠" : "LOS", o?.los ?? null, losEarly ? "#f3c46e" : "#e8ecf0")}
</div>
<table style="width:100%;border-collapse:collapse;font-size:12.5px;margin-top:10px;padding-top:8px;border-top:1px solid rgba(255,255,255,.08)">
<thead><tr style="color:#8a96a3;font-size:10.5px">
<th style="text-align:left;font-weight:500;padding:6px 0 2px">Satellite</th><th style="text-align:right;font-weight:500">Elevation</th>
<th style="text-align:right;font-weight:500">Tilt</th><th style="text-align:right;font-weight:500">Range</th>
<th style="text-align:right;font-weight:500">Limit</th><th style="text-align:right;font-weight:500">Sensor</th></tr></thead>
<tbody data-k="rows"></tbody></table>
<div style="display:flex;flex-wrap:wrap;gap:6px 14px;font-size:12px;color:#aab4bd;margin-top:10px;padding-top:10px;border-top:1px solid rgba(255,255,255,.08)">
${legendItem("#5aa9ff", "Elevation °")}${legendItem("#ffb454", "Tilt °")}${legendItem("#ff6bd6", "Range km (right axis)")}
${legendItem("#3ddc97", "Inside limit", "▒")}
${legendItem("#ffd24a", "Nadir line", "━")}${legendItem("#3ddc97", "Slant range (inside)", "━")}
${legendItem("#ff5d6c", "Slant range (outside)", "━")}${legendItem("#9aa7bd", "Ground line", "━")}
${legendItem("#9fb6ff", "Beam: nadir", "▲")}${legendItem("#ffb454", "Beam: slewing", "▲")}${legendItem("#7fe3ff", "Beam: imaging (frequency colour)", "▲")}
</div>`;

  if (host) {
    // Directly under the frequency panel (mounted first, at the top of the host).
    const freq = host.querySelector(`.${OVERLAY_CLASS}`);
    host.insertBefore(root, freq ? freq.nextSibling : host.firstChild);
  } else {
    viewer.container.appendChild(root);
  }

  const q = (k: string) => root.querySelector(`[data-k="${k}"]`) as HTMLElement;
  const canvas = q("chart") as HTMLCanvasElement;
  const rowsEl = q("rows");
  const chipBase = "font-size:11.5px;font-weight:600;padding:3px 9px;border-radius:999px;white-space:nowrap";
  const chip = {
    ok: "color:#6ee7b7;background:rgba(52,211,153,.12);border:1px solid rgba(52,211,153,.35)",
    bad: "color:#ff8b95;background:rgba(255,93,108,.12);border:1px solid rgba(255,93,108,.35)",
  };

  const t0 = opts.windowStart.getTime();
  const span = Math.max(1, opts.windowEnd.getTime() - t0);

  const drawChart = (now: Date) => {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const w = Math.max(1, (canvas.clientWidth || 600) * dpr);
    const h = 150 * dpr;
    if (canvas.width !== w) canvas.width = w;
    if (canvas.height !== h) canvas.height = h;
    const x = canvas.getContext("2d");
    if (!x) return;
    x.clearRect(0, 0, w, h);
    const L = 30 * dpr, R = 40 * dpr, T = 8 * dpr, B = 16 * dpr;
    const X = (t: number) => L + ((t - t0) / span) * (w - L - R);
    const Y = (deg: number) => h - B - (Math.max(0, Math.min(95, deg)) / 90) * (h - T - B);
    const Yr = (km: number) => Y((km / CHART_RANGE_MAX_KM) * 90);

    // Window inside the limit.
    x.fillStyle = "rgba(61,220,151,.16)";
    let runStart: number | null = null;
    opts.profile.forEach((p, i) => {
      const inside = isInsideSpotLimit(limit, p.snap);
      if (inside && runStart === null) runStart = p.t.getTime();
      const last = i === opts.profile.length - 1;
      if ((!inside || last) && runStart !== null) {
        x.fillRect(X(runStart), T, X(p.t.getTime()) - X(runStart), h - T - B);
        runStart = null;
      }
    });

    x.font = `${10 * dpr}px ${MONO}`;
    x.lineWidth = 1;
    [0, 30, 60, 90].forEach((v) => {
      x.strokeStyle = "rgba(143,161,189,.18)";
      x.beginPath();
      x.moveTo(L, Y(v));
      x.lineTo(w - R, Y(v));
      x.stroke();
      x.fillStyle = "#8a96a3";
      x.fillText(`${v}°`, 3 * dpr, Y(v) + 3 * dpr);
    });
    [0, 1000, 2000, 3000].forEach((v) => x.fillText(`${v}`, w - R + 4 * dpr, Yr(v) + 3 * dpr));

    // Limit lines.
    x.setLineDash([4 * dpr, 4 * dpr]);
    x.strokeStyle = "#5aa9ff";
    x.beginPath();
    x.moveTo(L, Y(limit.minElevationDeg));
    x.lineTo(w - R, Y(limit.minElevationDeg));
    x.stroke();
    x.strokeStyle = "#ff6bd6";
    x.beginPath();
    x.moveTo(L, Yr(limit.maxRangeKm));
    x.lineTo(w - R, Yr(limit.maxRangeKm));
    x.stroke();
    x.setLineDash([]);

    const curves: [string, (s: SpotSnapshot) => number][] = [
      ["#5aa9ff", (s) => Y(s.elevationDeg)],
      ["#ffb454", (s) => Y(s.tiltDeg)],
      ["#ff6bd6", (s) => Yr(s.rangeKm)],
    ];
    x.lineWidth = 1.8 * dpr;
    curves.forEach(([col, fy]) => {
      x.strokeStyle = col;
      x.beginPath();
      opts.profile.forEach((p, i) => {
        const px = X(p.t.getTime());
        const py = fy(p.snap);
        if (i === 0) x.moveTo(px, py);
        else x.lineTo(px, py);
      });
      x.stroke();
    });

    if (o) {
      const marks: [Date, string][] = [
        [o.dummyAos, "AOS"],
        [o.missionStart, "Mission start"],
        [opts.captureEnd ?? o.missionEnd, "Mission end"],
        [o.los, "LOS"],
      ];
      x.lineWidth = 1;
      marks.forEach(([d, label], k) => {
        const px = X(d.getTime());
        x.strokeStyle = "rgba(110,231,183,.6)";
        x.setLineDash([3 * dpr, 3 * dpr]);
        x.beginPath();
        x.moveTo(px, T);
        x.lineTo(px, h - B);
        x.stroke();
        x.setLineDash([]);
        x.fillStyle = "#6ee7b7";
        const tw = x.measureText(label).width;
        const lx = Math.max(L, Math.min(w - R - tw, px - tw / 2));
        x.fillText(label, lx, k % 2 === 0 ? h - 3 * dpr : T + 9 * dpr);
      });
    }

    const px = X(now.getTime());
    x.strokeStyle = "#ffffff";
    x.shadowColor = "#ffffff";
    x.shadowBlur = 6 * dpr;
    x.lineWidth = 2 * dpr;
    x.beginPath();
    x.moveTo(px, T);
    x.lineTo(px, h - B);
    x.stroke();
    x.shadowBlur = 0;
  };

  let lastInside: boolean | null = null;
  let lastDomUpdate = 0;

  return {
    update({ phase, phaseTone, rows, leaderTime }) {
      // DOM + chart at ~12 Hz is plenty for a readout.
      const nowMs = performance.now();
      if (nowMs - lastDomUpdate < 80) return;
      lastDomUpdate = nowMs;

      const lead = rows.find((r) => r.name === opts.leaderName) ?? rows[0];
      const s = lead?.snap ?? null;
      q("el").textContent = s ? `${s.elevationDeg.toFixed(1)}°` : "–";
      q("tilt").textContent = s ? `${s.tiltDeg.toFixed(1)}°` : "–";
      q("rg").textContent = s ? `${s.rangeKm.toFixed(0)} km` : "–";

      const inside = !!lead?.inside;
      if (inside !== lastInside) {
        const st = q("status");
        st.textContent = inside ? "Inside limit" : "Outside limit";
        st.setAttribute("style", `${chipBase};${inside ? chip.ok : chip.bad}`);
        lastInside = inside;
      }

      const phaseEl = q("phase");
      phaseEl.textContent = phase;
      phaseEl.style.color = phaseTone === "ok" ? "#6ee7b7" : phaseTone === "warn" ? "#f3c46e" : "#aab4bd";

      rowsEl.innerHTML = rows
        .map(
          (r) => `<tr>
<td style="padding:2px 0;white-space:nowrap">
<span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:${r.color};margin-right:7px"></span>${r.name}</td>
<td style="text-align:right;font-family:${MONO}">${r.snap ? r.snap.elevationDeg.toFixed(1) + "°" : "–"}</td>
<td style="text-align:right;font-family:${MONO}">${r.snap ? r.snap.tiltDeg.toFixed(1) + "°" : "–"}</td>
<td style="text-align:right;font-family:${MONO}">${r.snap ? r.snap.rangeKm.toFixed(0) + " km" : "–"}</td>
<td style="text-align:right;color:${r.inside ? "#6ee7b7" : "#ff8b95"}">${r.inside ? "inside" : "outside"}</td>
<td style="text-align:right;color:${r.sensor === "target" ? "#7fe3ff" : r.sensor === "slewing" ? "#ffb454" : "#9fb6ff"}">${r.sensor === "target" ? "on target" : r.sensor}</td></tr>`,
        )
        .join("");

      drawChart(leaderTime);
    },
    dispose() {
      root.remove();
    },
  };
}

const is2DMap = (viewer: Cesium.Viewer) => viewer.scene.mode !== Cesium.SceneMode.SCENE3D;

/** Camera presets (segmented control) next to "Back to Globe".
 *  3D globe: Target view / Follow formation / Whole pass.
 *  2D map: one option only — Target view showing the complete pass.
 *  Returns `refresh()` to repaint after the map switches between 2D and 3D. */
function mountCameraModes(viewer: Cesium.Viewer, initial: SpotCameraMode, onChange: (mode: SpotCameraMode) => void) {
  const bar = document.createElement("div");
  bar.className = OVERLAY_CLASS;
  bar.style.cssText =
    "position:absolute;left:160px;top:12px;z-index:22;display:flex;gap:2px;padding:3px;" +
    "border:1px solid rgba(255,255,255,.14);border-radius:9px;background:rgba(14,16,21,.9);" +
    "box-shadow:0 4px 16px rgba(0,0,0,.5)";
  let current = initial;
  const btnCss = `padding:5px 11px;border:0;border-radius:6px;font:500 12px ${FONT};`;
  const buttons = CAMERA_MODES.map(({ id, label }) => {
    const b = document.createElement("button");
    b.type = "button";
    b.textContent = label;
    b.dataset["mode"] = id;
    b.style.cssText = btnCss + "cursor:pointer;";
    b.addEventListener("click", () => {
      current = id;
      paint();
      onChange(id);
    });
    bar.appendChild(b);
    return b;
  });
  // 2D map: the single option.
  const only2D = document.createElement("span");
  only2D.textContent = "Target view \u00b7 complete pass";
  only2D.style.cssText =
    btnCss + "background:rgba(77,163,255,.22);color:#cfe6ff;box-shadow:inset 0 0 0 1px rgba(77,163,255,.55);";
  bar.appendChild(only2D);
  const paint = () => {
    const flat = is2DMap(viewer);
    only2D.style.display = flat ? "inline-block" : "none";
    buttons.forEach((b) => {
      const on = b.dataset["mode"] === current;
      b.style.display = flat ? "none" : "inline-block";
      b.style.background = on ? "rgba(77,163,255,.22)" : "transparent";
      b.style.color = on ? "#cfe6ff" : "#9aa7b4";
      b.style.boxShadow = on ? "inset 0 0 0 1px rgba(77,163,255,.55)" : "none";
    });
  };
  paint();
  viewer.container.appendChild(bar);
  return { refresh: paint };
}

// ─── Shared by the animation and the orbit preview ─────────────────────────

/** AOS / Mission start / Mission end / LOS markers on the ground track, pinned to the ground. */
function addPassMarkers(
  viewer: Cesium.Viewer,
  idPrefix: string,
  satrec: satellite.SatRec,
  o: SpotOrbit,
  missionEnd: Date,
  /** Extra switch, e.g. off in the Follow formation view. */
  enabled: () => boolean = () => true,
) {
  const marks: [string, Date, Cesium.Color][] = [
    ["AOS", o.dummyAos, Cesium.Color.fromCssColorString("#9aa7bd")],
    ["Mission start", o.missionStart, COLOR_OK],
    ["Mission end", missionEnd, Cesium.Color.fromCssColorString("#7fe3ff")],
    ["LOS", o.los, o.los.getTime() < missionEnd.getTime() ? Cesium.Color.fromCssColorString("#f3c46e") : COLOR_BAD],
  ];
  const in3D = new Cesium.CallbackProperty(
    () => !viewer.isDestroyed() && viewer.scene.mode === Cesium.SceneMode.SCENE3D && enabled(),
    false,
  );
  const visible = (p: Cesium.Cartesian3) => new Cesium.CallbackProperty(() => enabled() && isOnVisibleSide(viewer, p), false);
  marks.forEach(([text, d, color], m) => {
    const sp = subPointAt(satrec, d);
    if (!sp) return;
    // Fixed on the ground track: they turn with the globe and hide behind it.
    const base = Cesium.Cartesian3.fromDegrees(sp.lon, sp.lat, 0);
    // In 3D a short pole stands on the ground point and carries the label, so the
    // marker reads clearly in oblique / follow views (it is drawn with depth, so
    // the Earth hides it like any real object). In 2D the label sits on the dot.
    const top = Cesium.Cartesian3.fromDegrees(sp.lon, sp.lat, MARKER_POLE_HEIGHT_M);
    viewer.entities.add({
      id: `${idPrefix}mark${m}`,
      position: base,
      point: {
        show: visible(base),
        pixelSize: 8,
        color,
        outlineColor: Cesium.Color.fromCssColorString("#0d1117"),
        outlineWidth: 2,
        disableDepthTestDistance: NEAR_DEPTH_OFF_M,
      },
    });
    viewer.entities.add({
      id: `${idPrefix}mark${m}_pole`,
      polyline: {
        show: in3D,
        positions: [base, top],
        width: 2,
        arcType: Cesium.ArcType.NONE,
        material: color.withAlpha(0.9),
      },
    });
    viewer.entities.add({
      id: `${idPrefix}mark${m}_label`,
      position: top,
      label: globeLabel(
        `${text} · ${d.toISOString().slice(11, 19)}`,
        new Cesium.Cartesian2(8, m % 2 === 0 ? -10 : 10),
        false,
        undefined,
        visible(top),
      ),
    });
  });
}

/** "Target view" framing: the leader at mission start, closest approach and LOS plus
 *  the target; the camera stands behind the target and faces the pass. */
function targetViewFor(
  satrec: satellite.SatRec,
  times: Date[],
  targetLat: number,
  targetLon: number,
): { sphere: Cesium.BoundingSphere; heading: number } {
  const pts: Cesium.Cartesian3[] = [Cesium.Cartesian3.fromDegrees(targetLon, targetLat, 0)];
  let mid: { lat: number; lon: number } | null = null;
  times.forEach((d, i) => {
    const sp = subPointAt(satrec, d);
    if (!sp) return;
    pts.push(Cesium.Cartesian3.fromDegrees(sp.lon, sp.lat, sp.heightKm * 1000));
    if (i === times.length - 2) mid = { lat: sp.lat, lon: sp.lon }; // closest approach
  });
  const m = mid as { lat: number; lon: number } | null;
  const r = Math.PI / 180;
  const heading = m
    ? Math.atan2(
        Math.sin((m.lon - targetLon) * r) * Math.cos(m.lat * r),
        Math.cos(targetLat * r) * Math.sin(m.lat * r) -
          Math.sin(targetLat * r) * Math.cos(m.lat * r) * Math.cos((m.lon - targetLon) * r),
      )
    : 0;
  // Camera behind the target, facing the pass: the target is in the foreground,
  // the ground track runs across the screen and the beams come down toward you.
  return { sphere: Cesium.BoundingSphere.fromPoints(pts), heading };
}

function flyToTargetView(viewer: Cesium.Viewer, view: { sphere: Cesium.BoundingSphere; heading: number }, duration: number) {
  viewer.camera.flyToBoundingSphere(view.sphere, {
    offset: new Cesium.HeadingPitchRange(
      view.heading,
      Cesium.Math.toRadians(TARGET_VIEW_PITCH_DEG),
      view.sphere.radius * TARGET_VIEW_RANGE_FACTOR,
    ),
    duration,
  });
}

// ─── Module state (one active spot animation at a time) ───────────────────

let rafHandle: number | null = null;
let removeMorphListener: (() => void) | null = null;

// ─── Public API ─────────────────────────────────────────────────────────

export function visualizeSpotFrequencyPlan(
  viewer: Cesium.Viewer,
  segments: FrequencySegment[],
  options: SpotVisualizationOptions,
) {
  clearSpotFrequencyVisualization(viewer);
  if (viewer.isDestroyed() || options.satellites.length === 0) return;

  const { targetLat, targetLon, satellites } = options;
  const target: GroundPoint = { name: "Spot Target", lat: targetLat, lon: targetLon };

  hidePlanningSatelliteEntities(viewer);

  const { plan, missionSeconds } = normalizeSegmentsToMission(segments);

  const leaderName =
    options.leaderName && satellites.some((s) => s.name === options.leaderName)
      ? options.leaderName
      : satellites[0].name;

  const limitInput = options.limit ?? options.orbit?.limit ?? DEFAULT_SPOT_LIMIT;
  const limit = resolveSpotLimit(limitInput, ORBIT_HEIGHT_KM);

  // Passes to play, in order. One pass normally; several when the mission is
  // completed on upcoming passes (LOS before mission end → "multiple orbits").
  type PassSpec = { orbit: SpotOrbit | null; planOffsetSeconds: number; durationSeconds: number };
  const passes: PassSpec[] =
    options.passes && options.passes.length > 0
      ? options.passes.map((p) => ({ ...p }))
      : [{ orbit: options.orbit ?? null, planOffsetSeconds: 0, durationSeconds: missionSeconds }];
  const multiPass = passes.length > 1;

  const targetPosition = Cesium.Cartesian3.fromDegrees(targetLon, targetLat, 0);
  const targetUp = Cesium.Ellipsoid.WGS84.geodeticSurfaceNormal(targetPosition, new V());

  let maxSwathKm = 10;
  plan.forEach((seg) => {
    maxSwathKm = Math.max(maxSwathKm, FREQUENCY_PRESETS[seg.presetId].swathKm);
  });

  type SensorState = "nadir" | "slewing" | "target";
  type SatState = {
    pos: Cesium.Cartesian3;
    sub: Cesium.Cartesian3;
    quat: Cesium.Quaternion;
    panelA: Cesium.Cartesian3;
    panelB: Cesium.Cartesian3;
    tiltArc: Cesium.Cartesian3[];
    elevArc: Cesium.Cartesian3[];
    snap: SpotSnapshot | null;
    inside: boolean;
    imaging: boolean;
    /** Where the sensor boresight hits the ground. */
    aim: Cesium.Cartesian3;
    /** Along-track unit vector on the ground at `aim` (orients the footprint). */
    along: Cesium.Cartesian3;
    sensor: SensorState;
    footprint: Cesium.Cartesian3[];
    beam: BeamFrame | null;
  };

  // ── Camera: target view (default, static), follow formation, or whole pass ──
  let cameraMode: SpotCameraMode = "target";
  let wholePassSphere: Cesium.BoundingSphere | null = null;
  /** 2D map: rectangle that holds the target and the complete pass. */
  let wholePassRect: Cesium.Rectangle | null = null;
  /** Target view framing of the current pass: sphere + heading toward the pass. */
  let targetView: { sphere: Cesium.BoundingSphere; heading: number } | null = null;
  let formationCenter = targetPosition;
  // The target is shown by the red pin of the target picker (no extra dot here).

  // ── One "formation" name at the formation centre, shown when zoomed out ──
  if (satellites.length > 1) {
    viewer.entities.add({
      id: FORMATION_NAME_ID,
      position: new Cesium.CallbackPositionProperty(() => formationCenter, false, Cesium.ReferenceFrame.FIXED),
      label: satelliteNameLabel(
        `${leaderName} formation · ${satellites.length} satellites`,
        new Cesium.Cartesian2(16, -14),
        onVisibleSide(viewer, () => formationCenter),
        FORMATION_NAME_FADE,
      ),
    });
  }

  /** Formation's local east-north-up frame at the previous frame (null = not following). */
  let lastFrame: Cesium.Matrix4 | null = null;
  /** Put the camera behind the formation, facing the target. */
  const setFollowView = () => {
    const c = Cesium.Cartographic.fromCartesian(formationCenter);
    const t = Cesium.Cartographic.fromCartesian(targetPosition);
    const dLon = t.longitude - c.longitude;
    const heading = Math.atan2(
      Math.sin(dLon) * Math.cos(t.latitude),
      Math.cos(c.latitude) * Math.sin(t.latitude) - Math.sin(c.latitude) * Math.cos(t.latitude) * Math.cos(dLon),
    );
    viewer.camera.lookAt(
      formationCenter,
      new Cesium.HeadingPitchRange(heading, Cesium.Math.toRadians(FOLLOW_PITCH_DEG), FOLLOW_RANGE_M),
    );
    viewer.camera.lookAtTransform(Cesium.Matrix4.IDENTITY);
    lastFrame = Cesium.Transforms.eastNorthUpToFixedFrame(formationCenter);
  };
  /** Each frame: carry the camera along with the formation's local frame, so the
   *  view angle stays the same over the whole pass (and any rotate / zoom the
   *  user made is kept). */
  const followStep = () => {
    if (cameraMode !== "formation" || !lastFrame || is2DMap(viewer)) return;
    const next = Cesium.Transforms.eastNorthUpToFixedFrame(formationCenter);
    const toLocal = Cesium.Matrix4.inverseTransformation(lastFrame, new Cesium.Matrix4());
    const m = Cesium.Matrix4.multiplyTransformation(next, toLocal, new Cesium.Matrix4());
    const cam = viewer.camera;
    const position = Cesium.Matrix4.multiplyByPoint(m, cam.position, new Cesium.Cartesian3());
    const direction = Cesium.Matrix4.multiplyByPointAsVector(m, cam.direction, new Cesium.Cartesian3());
    const up = Cesium.Matrix4.multiplyByPointAsVector(m, cam.up, new Cesium.Cartesian3());
    cam.setView({ destination: position, orientation: { direction, up } });
    lastFrame = next;
  };
  const applyCamera = (duration: number) => {
    if (viewer.isDestroyed()) return;
    if (is2DMap(viewer)) {
      // 2D map: one view — the target and the complete pass, seen from above.
      lastFrame = null;
      if (wholePassRect) viewer.camera.flyTo({ destination: wholePassRect, duration });
      return;
    }
    if (cameraMode === "formation") {
      setFollowView();
    } else if (cameraMode === "target" && targetView) {
      // Static oblique view: target in the foreground, the pass and its beams behind it.
      lastFrame = null;
      flyToTargetView(viewer, targetView, duration);
    } else {
      lastFrame = null;
      if (wholePassSphere) {
        viewer.camera.flyToBoundingSphere(wholePassSphere, {
          offset: new Cesium.HeadingPitchRange(
            Cesium.Math.toRadians(-20),
            Cesium.Math.toRadians(-35),
            wholePassSphere.radius * 2.4,
          ),
          duration,
        });
      }
    }
  };

  /** Builds the globe scene + pass-geometry panel for pass `k`. */
  const buildPass = (k: number) => {
    const spec = passes[k];
    const captureSeconds = spec.durationSeconds;
    const referenceTime =
      (k === 0 ? options.referenceTime : undefined) ??
      (spec.orbit
        ? new Date((spec.orbit.missionStart.getTime() + spec.orbit.los.getTime()) / 2)
        : new Date());

    const satPlans = satellites.map((sat, index) => {
      const pass = computeSpotPass(sat, targetLat, targetLon, referenceTime);
      const isLeader = sat.name === leaderName;
      const orbit =
        isLeader && spec.orbit
          ? spec.orbit
          : nearestSpotOrbit(sat, target, limit, referenceTime, pass.periodSeconds, missionSeconds);
      const timeline = timelineFor(orbit, pass, captureSeconds);
      const swathCenter = naturalSwathCenter(pass.anchorLat, pass.anchorLon, targetLat, targetLon);
      const safeName = sat.name.replace(/[^a-zA-Z0-9_-]/g, "_");
      return { ...sat, index, safeName, isLeader, pass, timeline, swathCenter };
    });

    if (satPlans.length > 0) {
      const avgLat = satPlans.reduce((sum, s) => sum + s.swathCenter.lat, 0) / satPlans.length;
      const refLon = satPlans[0].swathCenter.lon;
      const avgLonOffset =
        satPlans.reduce((sum, s) => sum + wrapLon(s.swathCenter.lon - refLon), 0) / satPlans.length;
      const avgLon = wrapLon(refLon + avgLonOffset);
      const recenterLat = targetLat - avgLat;
      const recenterLon = wrapLon(targetLon - avgLon);
      for (const sat of satPlans) {
        sat.swathCenter = {
          lat: sat.swathCenter.lat + recenterLat,
          lon: wrapLon(sat.swathCenter.lon + recenterLon),
        };
      }
    }

    const leader = satPlans.find((s) => s.isLeader) ?? satPlans[0];
    const leaderTl = leader.timeline;
    const loopSeconds = Math.max(1, (leaderTl.windowEnd.getTime() - leaderTl.windowStart.getTime()) / 1000);
    const captureEndOf = (o: SpotOrbit) => new Date(o.missionStart.getTime() + captureSeconds * 1000);
    /** Pointing window of a satellite: its own qualifying window, else the leader's. */
    const orbitOf = (sat: (typeof satPlans)[number]) => sat.timeline.orbit ?? leaderTl.orbit;

    /** 0 = sensor at nadir, 1 = sensor on the target. Nadir before AOS, slew to the
     *  target over SLEW_SECONDS after AOS, hold until capture end / LOS, slew back. */
    const pointingFraction = (o: SpotOrbit | null, t: number): number => {
      if (!o) return 0;
      const aos = o.dummyAos.getTime();
      const end = Math.min(captureEndOf(o).getTime(), o.los.getTime());
      if (t < aos) return 0;
      if (t <= end) return smoothStep((t - aos) / (SLEW_SECONDS * 1000));
      return 1 - smoothStep((t - end) / (SLEW_SECONDS * 1000));
    };

    const state: Record<string, SatState> = {};

    const updateSatState = (sat: (typeof satPlans)[number], t: Date) => {
      const snap = spotGeometryAt(sat, target, t);
      const st = state[sat.name];
      if (!snap) return;
      const pos = Cesium.Cartesian3.fromDegrees(snap.subLon, snap.subLat, snap.heightKm * 1000);
      const next = subPointAt(sat.pass.satrec, new Date(t.getTime() + 2000));
      const velDir = next
        ? dirTo(pos, Cesium.Cartesian3.fromDegrees(next.lon, next.lat, next.heightKm * 1000))
        : new V(0, 0, 1);
      const sub = Cesium.Cartesian3.fromDegrees(snap.subLon, snap.subLat, 0);
      const nadirDir = dirTo(pos, sub);

      // Sensor pointing: blend nadir → target, then intersect the boresight with the Earth.
      const o = orbitOf(sat);
      const f = pointingFraction(o, t.getTime());
      const aimGround = Cesium.Cartesian3.fromDegrees(sat.swathCenter.lon, sat.swathCenter.lat, 0);
      const boresight = V.normalize(V.lerp(nadirDir, dirTo(pos, aimGround), f, new V()), new V());
      const ray = new Cesium.Ray(pos, boresight);
      const hit = Cesium.IntersectionTests.rayEllipsoid(ray, Cesium.Ellipsoid.WGS84);
      const aim = hit ? Cesium.Ray.getPoint(ray, hit.start, new V()) : sub;

      const { q, y } = bodyOrientation(pos, aim, velDir);

      // Footprint frame on the ground: along-track (u) on the local tangent plane.
      const up = Cesium.Ellipsoid.WGS84.geodeticSurfaceNormal(aim, new V());
      let alongDir = V.subtract(velDir, V.multiplyByScalar(up, V.dot(velDir, up), new V()), new V());
      alongDir = V.magnitude(alongDir) > 1e-9 ? V.normalize(alongDir, alongDir) : V.clone(V.UNIT_X);

      // Elevation arc at the target: from the local horizontal toward the satellite.
      const toSat = dirTo(targetPosition, pos);
      const horiz = V.subtract(toSat, V.multiplyByScalar(targetUp, V.dot(toSat, targetUp), new V()), new V());
      if (V.magnitude(horiz) > 1e-6) V.normalize(horiz, horiz);

      st.pos = pos;
      st.sub = sub;
      st.quat = q;
      st.panelA = along(pos, y, MODEL_PANEL_OFFSET_M);
      st.panelB = along(pos, y, -MODEL_PANEL_OFFSET_M);
      st.tiltArc = arcPoints(pos, nadirDir, boresight, TILT_ARC_RADIUS_M);
      st.elevArc = V.magnitude(horiz) > 0 ? arcPoints(targetPosition, horiz, toSat, ELEV_ARC_RADIUS_M) : [];
      st.snap = snap;
      st.inside = isInsideSpotLimit(limit, snap);
      st.aim = aim;
      st.along = alongDir;
      st.sensor = f <= 0.001 ? "nadir" : f >= 0.999 ? "target" : "slewing";
      st.imaging = o
        ? t.getTime() >= o.missionStart.getTime() &&
          t.getTime() <= Math.min(captureEndOf(o).getTime(), o.los.getTime())
        : false;
    };

    for (const sat of satPlans) {
      const satColor = Cesium.Color.fromCssColorString(sat.color);
      const anchor = Cesium.Cartesian3.fromDegrees(sat.pass.anchorLon, sat.pass.anchorLat, 500_000);
      const anchorGround = Cesium.Cartesian3.fromDegrees(sat.pass.anchorLon, sat.pass.anchorLat, 0);
      state[sat.name] = {
        pos: anchor,
        sub: anchorGround,
        quat: Cesium.Quaternion.IDENTITY.clone(),
        panelA: anchor,
        panelB: anchor,
        tiltArc: [],
        elevArc: [],
        snap: null,
        inside: false,
        imaging: false,
        aim: anchorGround,
        along: V.clone(V.UNIT_X),
        sensor: "nadir",
        footprint: [],
        beam: null,
      };
      updateSatState(sat, leaderTl.windowStart);

      const prefix = `${ENTITY_PREFIX}${sat.safeName}__`;
      const st = () => state[sat.name];
      const posProp = (get: () => Cesium.Cartesian3) =>
        new Cesium.CallbackPositionProperty(() => get(), false, Cesium.ReferenceFrame.FIXED);
      const quatProp = new Cesium.CallbackProperty(() => st().quat, false);
      // Plain white name next to the satellite (hidden when the satellite is behind the Earth).
      const nameLabel = satelliteNameLabel(
        sat.name,
        new Cesium.Cartesian2(14, -12 - (sat.index % 2) * 18),
        onVisibleSide(viewer, () => st().pos),
        satellites.length > 1 ? NAMES_FADE : undefined,
      );

      // ── Satellite: glTF model (default), procedural boxes, or the icon ──
      if (SATELLITE_STYLE === "gltf") {
        viewer.entities.add({
          id: `${prefix}sat`,
          name: `${sat.name} (Spot)`,
          position: posProp(() => st().pos),
          orientation: quatProp,
          // The model keeps its own colours.
          model: {
            uri: SATELLITE_MODEL_URL,
            minimumPixelSize: MODEL_MIN_PIXEL_SIZE,
            maximumScale: MODEL_MAX_SCALE,
          },
          label: nameLabel,
        });
      } else if (SATELLITE_STYLE === "boxes") {
        viewer.entities.add({
          id: `${prefix}sat`,
          name: `${sat.name} (Spot)`,
          position: posProp(() => st().pos),
          orientation: quatProp,
          box: {
            dimensions: new Cesium.Cartesian3(MODEL_BODY_M.x, MODEL_BODY_M.y, MODEL_BODY_M.z),
            material: Cesium.Color.fromCssColorString("#cfd6e2"),
            outline: true,
            outlineColor: satColor,
          },
          label: nameLabel,
        });
        (["A", "B"] as const).forEach((side) => {
          viewer.entities.add({
            id: `${prefix}panel${side}`,
            position: posProp(() => (side === "A" ? st().panelA : st().panelB)),
            orientation: quatProp,
            box: {
              dimensions: new Cesium.Cartesian3(MODEL_PANEL_M.x, MODEL_PANEL_M.y, MODEL_PANEL_M.z),
              material: Cesium.Color.fromCssColorString("#2a4fb0"),
              outline: true,
              outlineColor: Cesium.Color.fromCssColorString("#9fb6ff"),
            },
          });
        });
      } else {
        viewer.entities.add({
          id: `${prefix}sat`,
          name: `${sat.name} (Spot)`,
          position: posProp(() => st().pos),
          billboard: {
            image: SATELLITE_ICON_URL,
            width: sat.isLeader ? 96 : 76,
            height: sat.isLeader ? 96 : 76,
            color: SATELLITE_ICON_COLOR,
            disableDepthTestDistance: NEAR_DEPTH_OFF_M,
            verticalOrigin: Cesium.VerticalOrigin.CENTER,
            horizontalOrigin: Cesium.HorizontalOrigin.CENTER,
          },
          label: nameLabel,
        });
      }

      // ── Sensor beam (same volumetric beam as Strip mode): satellite → footprint ──
      addBeamFrustum(viewer, prefix, () => st().beam, { strength: sat.isLeader ? 1.1 : 0.85 });

      // ── Footprint on the ground: frequency colour while imaging, faint otherwise ──
      viewer.entities.add({
        id: `${prefix}footprint`,
        polygon: {
          hierarchy: new Cesium.CallbackProperty(() => new Cesium.PolygonHierarchy(st().footprint), false),
          material: new Cesium.ColorMaterialProperty(
            new Cesium.CallbackProperty(() => {
              const b = st().beam;
              if (!b) return Cesium.Color.TRANSPARENT;
              return b.color.withAlpha(st().imaging ? 0.38 : 0.16);
            }, false),
          ),
          height: 0,
        },
      });
      viewer.entities.add({
        id: `${prefix}footprint-edge`,
        polyline: {
          positions: new Cesium.CallbackProperty(() => {
            const r = st().footprint;
            return r.length >= 4 ? [...r, r[0]] : [];
          }, false),
          width: sat.isLeader ? 2 : 1.4,
          arcType: Cesium.ArcType.NONE,
          material: new Cesium.ColorMaterialProperty(
            new Cesium.CallbackProperty(() => (st().beam?.color ?? satColor).withAlpha(0.95), false),
          ),
        },
      });

      // ── Geometry helpers (off by default, see SHOW_GEOMETRY_OVERLAYS) ──
      if (SHOW_GEOMETRY_OVERLAYS) {
        // Slant-range line: satellite → target (green inside the limit, red outside)
        viewer.entities.add({
          id: `${prefix}lookline`,
          name: `${sat.name} Slant Range`,
          polyline: {
            positions: new Cesium.CallbackProperty(() => [st().pos, targetPosition], false),
            width: sat.isLeader ? 1.8 : 1,
            arcType: Cesium.ArcType.NONE,
            material: new Cesium.PolylineDashMaterialProperty({
              color: new Cesium.CallbackProperty(
                () => (st().inside ? COLOR_OK : COLOR_BAD).withAlpha(sat.isLeader ? 0.85 : 0.5),
                false,
              ),
              dashLength: 16,
            }),
          },
        });

        // ── Nadir line: satellite → sub-satellite point ──
        viewer.entities.add({
          id: `${prefix}nadir`,
          name: `${sat.name} Nadir`,
          polyline: {
            positions: new Cesium.CallbackProperty(() => [st().pos, st().sub], false),
            width: sat.isLeader ? 1.6 : 1,
            arcType: Cesium.ArcType.NONE,
            material: new Cesium.PolylineDashMaterialProperty({
              color: COLOR_NADIR.withAlpha(sat.isLeader ? 0.9 : 0.5),
              dashLength: 10,
            }),
          },
        });

        // ── Names, ground line and angle arcs: leading satellite only (less clutter) ──
        if (sat.isLeader) {
          viewer.entities.add({
            id: `${prefix}groundline`,
            polyline: {
              positions: new Cesium.CallbackProperty(() => [st().sub, targetPosition], false),
              width: 1.5,
              arcType: Cesium.ArcType.GEODESIC,
              material: COLOR_GROUND.withAlpha(0.9),
            },
          });
          viewer.entities.add({
            id: `${prefix}tiltarc`,
            polyline: {
              positions: new Cesium.CallbackProperty(() => st().tiltArc, false),
              width: 2,
              arcType: Cesium.ArcType.NONE,
              material: COLOR_TILT,
            },
          });
          viewer.entities.add({
            id: `${prefix}elevarc`,
            polyline: {
              positions: new Cesium.CallbackProperty(() => st().elevArc, false),
              width: 2,
              arcType: Cesium.ArcType.NONE,
              material: COLOR_ELEV,
            },
          });

          const label = (key: string, pos: () => Cesium.Cartesian3, text: string, color: Cesium.Color, offsetY = 0) =>
            viewer.entities.add({
              id: `${prefix}lbl_${key}`,
              position: posProp(pos),
              label: {
                text,
                font: `600 12px ${FONT}`,
                fillColor: color,
                showBackground: true,
                backgroundColor: Cesium.Color.fromCssColorString("#0a0f1c").withAlpha(0.8),
                backgroundPadding: new Cesium.Cartesian2(5, 3),
                pixelOffset: new Cesium.Cartesian2(0, offsetY),
                disableDepthTestDistance: Number.POSITIVE_INFINITY,
              },
            });

          label("range", () => V.midpoint(st().pos, targetPosition, new V()), "Slant range", Cesium.Color.WHITE);
          label("nadir", () => st().sub, "Nadir", COLOR_NADIR, 14);
          label("tilt", () => st().tiltArc[Math.floor(st().tiltArc.length / 2)] ?? st().pos, "Tilt", COLOR_TILT);
          label(
            "elev",
            () => st().elevArc[Math.floor(st().elevArc.length / 2)] ?? targetPosition,
            "Elevation",
            COLOR_ELEV,
          );
        }
      }

      // ── Ground track (whole pass) ──
      const trackHalfWindow =
        sat.pass.halfPassSeconds + sat.pass.periodSeconds * TRACK_MARGIN_FRACTION_OF_PERIOD;
      const trackCenter = sat.timeline.orbit
        ? (sat.timeline.windowStart.getTime() + sat.timeline.windowEnd.getTime()) / 2
        : sat.pass.anchorTime.getTime();
      const trackStepSec = (trackHalfWindow * 2) / TRACK_SAMPLE_COUNT;
      const trackPositions: Cesium.Cartesian3[] = [];
      for (let t = -trackHalfWindow; t <= trackHalfWindow + 1e-6; t += trackStepSec) {
        const sp = subPointAt(sat.pass.satrec, new Date(trackCenter + t * 1000));
        if (sp) trackPositions.push(Cesium.Cartesian3.fromDegrees(sp.lon, sp.lat, 0));
      }

      viewer.entities.add({
        id: `${prefix}groundtrack`,
        name: `${sat.name} Ground Track`,
        polyline: {
          positions: trackPositions,
          width: GROUND_TRACK_WIDTH,
          material: new Cesium.PolylineGlowMaterialProperty({
            glowPower: GROUND_TRACK_GLOW_POWER,
            color: satColor.withAlpha(GROUND_TRACK_ALPHA),
          }),
          clampToGround: true,
        },
      });

      // ── Valid window on the ground track (mission start → LOS) + markers ──
      const o = sat.timeline.orbit;
      if (o) {
        const winPositions: Cesium.Cartesian3[] = [];
        const a = o.missionStart.getTime();
        const b = o.los.getTime();
        const n = 30;
        for (let i = 0; i <= n; i++) {
          const sp = subPointAt(sat.pass.satrec, new Date(a + ((b - a) * i) / n));
          if (sp) winPositions.push(Cesium.Cartesian3.fromDegrees(sp.lon, sp.lat, 0));
        }
        viewer.entities.add({
          id: `${prefix}window`,
          name: `${sat.name} Valid Window`,
          polyline: {
            positions: winPositions,
            width: sat.isLeader ? 9 : 6,
            material: new Cesium.PolylineGlowMaterialProperty({ glowPower: 0.25, color: COLOR_OK.withAlpha(0.9) }),
            clampToGround: true,
          },
        });

        // Follow formation looks along the track: the markers would all pile up on the
        // horizon next to the satellites, so that view leaves them out (their times
        // stay in the panel under the globe).
        if (sat.isLeader) {
          addPassMarkers(viewer, prefix, sat.pass.satrec, o, captureEndOf(o), () => cameraMode !== "formation" || is2DMap(viewer));
        }
      }
    }

    // Leader's pass profile for the live chart, and the panel under the globe.
    const profile = sampleSpotProfile(leader, target, leaderTl.windowStart, leaderTl.windowEnd, CHART_SAMPLES);
    const lo = leaderTl.orbit;
    const geoPanel = mountGeometryPanel(viewer, {
      limit,
      leaderName: leader.name,
      profile,
      windowStart: leaderTl.windowStart,
      windowEnd: leaderTl.windowEnd,
      orbit: lo,
      captureEnd: lo ? captureEndOf(lo) : null,
      passLabel: multiPass
        ? `Pass ${k + 1} of ${passes.length}${lo ? ` · ${lo.missionStart.toISOString().slice(0, 10)}` : ""}`
        : null,
    });

    // Whole-pass camera framing: the target and this pass's tracks.
    const framingPoints: Cesium.Cartesian3[] = [targetPosition];
    for (const sat of satPlans) {
      const a = sat.timeline.windowStart.getTime();
      const b = sat.timeline.windowEnd.getTime();
      for (const frac of [0, 0.25, 0.5, 0.75, 1]) {
        const sp = subPointAt(sat.pass.satrec, new Date(a + frac * (b - a)));
        if (sp) framingPoints.push(Cesium.Cartesian3.fromDegrees(sp.lon, sp.lat, sp.heightKm * 1000));
      }
      const { halfLatDeg, halfLonDeg } = squareHalfDegrees(sat.swathCenter.lat, maxSwathKm);
      framingPoints.push(
        Cesium.Cartesian3.fromDegrees(sat.swathCenter.lon - halfLonDeg, sat.swathCenter.lat - halfLatDeg, 0),
        Cesium.Cartesian3.fromDegrees(sat.swathCenter.lon + halfLonDeg, sat.swathCenter.lat + halfLatDeg, 0),
      );
    }
    wholePassSphere = Cesium.BoundingSphere.fromPoints(framingPoints);
    {
      const r = Cesium.Rectangle.fromCartesianArray(framingPoints);
      const padLon = Math.max(r.width * 0.25, Cesium.Math.toRadians(2));
      const padLat = Math.max(r.height * 0.25, Cesium.Math.toRadians(2));
      wholePassRect = new Cesium.Rectangle(
        r.west - padLon,
        Math.max(-Cesium.Math.PI_OVER_TWO, r.south - padLat),
        r.east + padLon,
        Math.min(Cesium.Math.PI_OVER_TWO, r.north + padLat),
      );
    }

    // Target view: the leader at mission start, closest approach and LOS, plus the target.
    targetView = targetViewFor(
      leader.pass.satrec,
      lo
        ? [lo.dummyAos, lo.missionStart, lo.closestApproach, captureEndOf(lo)]
        : [leaderTl.windowStart, new Date((leaderTl.windowStart.getTime() + leaderTl.windowEnd.getTime()) / 2), leaderTl.windowEnd],
      targetLat,
      targetLon,
    );

    /** Advance this pass to `elapsedLoopSeconds` into its timeline. */
    const tick = (elapsedLoopSeconds: number) => {
      // Every satellite at the SAME real UTC instant → the true formation shape.
      const leaderTime = new Date(leaderTl.windowStart.getTime() + elapsedLoopSeconds * 1000);

      // Mission clock: plan offset of this pass + seconds since its mission start.
      const sinceStart = lo
        ? (leaderTime.getTime() - lo.missionStart.getTime()) / 1000
        : (elapsedLoopSeconds / loopSeconds) * captureSeconds;
      const elapsed = Math.max(
        0,
        Math.min(missionSeconds, spec.planOffsetSeconds + Math.max(0, Math.min(captureSeconds, sinceStart))),
      );

      for (const sat of satPlans) {
        updateSatState(sat, leaderTime);
      }

      const leaderImaging = state[leader.name].imaging;
      const activeIndex = leaderImaging ? activeOrHeldIndexAt(plan, elapsed, missionSeconds) : -1;
      const activeSeg = activeIndex >= 0 ? plan[activeIndex] : null;
      const preset = activeSeg ? FREQUENCY_PRESETS[activeSeg.presetId] : null;

      // Beams + footprints: frequency colour and swath while imaging, small idle spot otherwise.
      let cx = 0, cy = 0, cz = 0;
      for (const sat of satPlans) {
        const st = state[sat.name];
        const imagingNow = st.imaging && !!preset;
        const halfKm = (imagingNow ? preset!.swathKm : IDLE_FOOTPRINT_KM) / 2;
        st.footprint = groundSquare(st.aim, st.along, halfKm * 1000);
        const color = imagingNow
          ? Cesium.Color.fromCssColorString(preset!.color)
          : st.sensor === "nadir"
            ? BEAM_COLOR_NADIR
            : st.sensor === "slewing"
              ? BEAM_COLOR_SLEW
              : Cesium.Color.fromCssColorString(sat.color);
        st.beam = st.footprint.length === 4 ? { apex: st.pos, base: st.footprint, color } : null;
        cx += st.pos.x; cy += st.pos.y; cz += st.pos.z;
      }
      formationCenter = new V(cx / satPlans.length, cy / satPlans.length, cz / satPlans.length);
      followStep();

      panel?.update({
        activeIndex,
        playheadPct: (elapsed / missionSeconds) * 100,
        utc: leaderTime,
        elapsedSec: elapsed,
        totalSec: missionSeconds,
        paused: isVizPaused(),
      });

      // Phase of the leading satellite's timeline.
      const passPrefix = multiPass ? `Pass ${k + 1}/${passes.length} · ` : "";
      const sensorText = { nadir: "sensor at nadir", slewing: "sensor slewing", target: "sensor on target" }[
        state[leader.name].sensor
      ];
      let phase = "Sweeping the pass";
      let tone: "ok" | "warn" | "idle" = "idle";
      if (lo) {
        const t = leaderTime.getTime();
        const captureEnd = captureEndOf(lo).getTime();
        const isLast = k === passes.length - 1;
        if (t < lo.dummyAos.getTime()) {
          phase = `Before AOS · ${fmtMmSs((lo.dummyAos.getTime() - t) / 1000)} to AOS`;
        } else if (t < lo.missionStart.getTime()) {
          phase = `AOS (start − ${DUMMY_AOS_LEAD_MINUTES} min) → mission start in ${fmtMmSs((lo.missionStart.getTime() - t) / 1000)}`;
        } else if (leaderImaging) {
          phase = `Imaging · T+${fmtMmSs(spec.planOffsetSeconds + sinceStart)} of ${fmtMmSs(missionSeconds)}`;
          tone = "ok";
        } else if (t > lo.los.getTime() && t < captureEnd) {
          phase = `LOS — limit lost ${fmtMmSs((captureEnd - lo.los.getTime()) / 1000)} before mission end`;
          tone = "warn";
        } else if (multiPass && !isLast) {
          const next = passes[k + 1].orbit;
          phase = `Pass ${k + 1} done · continues on pass ${k + 2}${next ? ` at ${next.missionStart.toISOString().slice(11, 19)} UTC` : ""}`;
          tone = "warn";
        } else if (multiPass) {
          phase = "Mission complete · all passes captured";
        } else {
          phase = lo.shortPass ? "After LOS — rest of the plan on later passes" : "Mission complete · after mission end";
          tone = lo.shortPass ? "warn" : "idle";
        }
      }

      geoPanel.update({
        phase: `${passPrefix}${leaderTime.toISOString().slice(11, 19)} UTC · ${phase} · ${sensorText}`,
        phaseTone: tone,
        rows: satPlans.map((s) => ({
          name: s.name,
          color: s.color,
          snap: state[s.name].snap,
          inside: state[s.name].inside,
          sensor: state[s.name].sensor,
        })),
        leaderTime,
      });

      viewer.scene.requestRender();
    };

    const dispose = () => {
      geoPanel.dispose();
      viewer.entities.values
        .filter((e) => typeof e.id === "string" && e.id.startsWith(ENTITY_PREFIX) && e.id !== FORMATION_NAME_ID)
        .forEach((e) => viewer.entities.remove(e));
    };

    return { satPlans, loopSeconds, tick, dispose };
  };

  // Frequency panel (whole plan) under the globe — mounted once for all passes.
  const limitText =
    limit.mode === "elevation"
      ? `min el ${limit.minElevationDeg.toFixed(1)}° → range ≤ ${limit.maxRangeKm.toFixed(0)} km`
      : `range ≤ ${limit.maxRangeKm.toFixed(0)} km → min el ${limit.minElevationDeg.toFixed(1)}°`;
  let panel: FrequencyPanel | null = null;
  panel = mountFrequencyPanel(viewer, {
    overlayClass: OVERLAY_CLASS,
    title:
      `Spot · ${satellites.length} satellite${satellites.length === 1 ? "" : "s"} · target ${targetLat.toFixed(2)}, ${targetLon.toFixed(2)} · ${limitText}` +
      (multiPass ? ` · ${passes.length} passes` : ""),
    segments: plan,
    satellites: satellites.map((s) => ({ name: s.name, color: s.color })),
    warning: options.warning,
  });

  let passIndex = 0;
  let scene = buildPass(passIndex);
  let elapsedLoopSeconds = 0;

  let lastFrameTimestamp: number | null = null;
  const frame = (timestamp: number) => {
    if (lastFrameTimestamp !== null && !isVizPaused()) {
      let deltaSeconds = (timestamp - lastFrameTimestamp) / 1000;
      deltaSeconds = Math.min(deltaSeconds, 0.05);

      elapsedLoopSeconds += deltaSeconds * MISSION_SECONDS_PER_REAL_SECOND;

      if (elapsedLoopSeconds >= scene.loopSeconds) {
        elapsedLoopSeconds = 0;
        if (!multiPass && cameraMode === "formation" && !is2DMap(viewer)) {
          // Loop restart: jump the camera back behind the formation.
          scene.tick(0);
          setFollowView();
        }
        if (multiPass) {
          // Next pass (after the last one, start again at pass 1).
          passIndex = (passIndex + 1) % passes.length;
          scene.dispose();
          scene = buildPass(passIndex);
          scene.tick(0);
          applyCamera(1.0);
        }
      }
    }

    lastFrameTimestamp = timestamp;
    scene.tick(elapsedLoopSeconds);
    rafHandle = requestAnimationFrame(frame);
  };

  mountBackToGlobeButton(viewer, OVERLAY_CLASS, () => {
    clearSpotFrequencyVisualization(viewer);
    options.onBack?.();
  });
  const cameraBar = mountCameraModes(viewer, cameraMode, (mode) => {
    cameraMode = mode;
    applyCamera(1.2);
  });
  // The map was switched between 2D and 3D while playing: show the matching
  // camera option(s) and frame the pass again.
  removeMorphListener = viewer.scene.morphComplete.addEventListener(() => {
    cameraBar.refresh();
    applyCamera(0.8);
  });
  vizStarted("spot");

  scene.tick(0);
  applyCamera(1.4);
  rafHandle = requestAnimationFrame(frame);
}

export function clearSpotFrequencyVisualization(viewer: Cesium.Viewer) {
  if (rafHandle !== null) {
    cancelAnimationFrame(rafHandle);
    rafHandle = null;
  }
  removeMorphListener?.();
  removeMorphListener = null;
  vizStopped("spot");
  document.querySelectorAll(`.${OVERLAY_CLASS}`).forEach((el) => el.remove());
  if (!viewer || viewer.isDestroyed()) {
    restorePlanningSatelliteEntities();
    return;
  }

  const toRemove = viewer.entities.values.filter(
    (e) => typeof e.id === "string" && e.id.startsWith(ENTITY_PREFIX),
  );
  toRemove.forEach((e) => viewer.entities.remove(e));

  restorePlanningSatelliteEntities(viewer);

  viewer.scene.requestRender();
}

// ─── Orbit preview (an upcoming orbit is selected, no animation running) ────
//
// Works like Orbit reference when a date / time is picked: the satellite icons
// already on the globe move to where they are at the selected orbit's mission
// start, and their ground tracks are redrawn around that time. No models, no
// beams, no markers — just the icons and the tracks at the new time.

const PREVIEW_PREFIX = "spotprev__";
/** Ground track drawn from 30 min before to 150 min after the selected time
 *  (3 h, the same length as the globe's normal ground track). */
const PREVIEW_TRACK_BEFORE_SECONDS = 30 * 60;
const PREVIEW_TRACK_AFTER_SECONDS = 150 * 60;
const PREVIEW_TRACK_STEP_SECONDS = 60;
/** Camera height when a new orbit is picked. */
const PREVIEW_CAMERA_HEIGHT_M = 9_000_000;
let previewHiddenIds: string[] = [];

export type SpotOrbitPreviewOptions = {
  satellites: SpotSatelliteInput[];
  /** Time the satellites are shown at (the selected orbit's mission start). */
  time: Date;
  /** Target, used to centre the camera when a new orbit is picked. */
  targetLat?: number;
  targetLon?: number;
  /** Move the camera (true when a different orbit was picked). */
  flyTo?: boolean;
};

export function showSpotOrbitPreview(viewer: Cesium.Viewer, opts: SpotOrbitPreviewOptions) {
  clearSpotOrbitPreview(viewer);
  if (viewer.isDestroyed() || opts.satellites.length === 0) return;

  const at = opts.time;
  let firstSub: { lat: number; lon: number } | null = null;

  opts.satellites.forEach((sat) => {
    const satrec = satellite.twoline2satrec(sat.tle1, sat.tle2);
    const safe = sat.name.replace(/[^a-zA-Z0-9_-]/g, "_");

    // The globe's own icon + ground track for this satellite ("now"): hidden while previewing.
    const icon = viewer.entities.getById(`mp__${sat.name}__current`);
    const ground = viewer.entities.getById(`mp__${sat.name}__ground`);
    [icon, ground].forEach((e) => {
      if (e && e.show) {
        previewHiddenIds.push(e.id);
        e.show = false;
      }
    });

    // Ground track around the selected time — same look as the globe's track.
    const track: Cesium.Cartesian3[] = [];
    const t0 = at.getTime() - PREVIEW_TRACK_BEFORE_SECONDS * 1000;
    const t1 = at.getTime() + PREVIEW_TRACK_AFTER_SECONDS * 1000;
    for (let t = t0; t <= t1; t += PREVIEW_TRACK_STEP_SECONDS * 1000) {
      const sp = subPointAt(satrec, new Date(t));
      if (sp) track.push(Cesium.Cartesian3.fromDegrees(sp.lon, sp.lat, 0));
    }
    viewer.entities.add({
      id: `${PREVIEW_PREFIX}${safe}__ground`,
      name: `${sat.name} Ground Track`,
      polyline: {
        positions: track,
        arcType: Cesium.ArcType.GEODESIC,
        width: 2.5,
        material:
          ground?.polyline?.material ??
          new Cesium.PolylineGlowMaterialProperty({ glowPower: 0.15, color: Cesium.Color.fromCssColorString(sat.color) }),
      },
    });

    // Satellite icon at its TLE position at the selected time — same icon as the globe's.
    const sp = subPointAt(satrec, at);
    if (!sp) return;
    if (!firstSub) firstSub = { lat: sp.lat, lon: sp.lon };
    viewer.entities.add({
      id: `${PREVIEW_PREFIX}${safe}__current`,
      name: `${sat.name} Position`,
      position: Cesium.Cartesian3.fromDegrees(sp.lon, sp.lat, sp.heightKm * 1000),
      billboard: icon?.billboard
        ? icon.billboard.clone()
        : {
            image: SATELLITE_ICON_URL,
            width: 110,
            height: 110,
            scaleByDistance: new Cesium.NearFarScalar(1.5e6, 1.0, 2.5e7, 0.4),
            disableDepthTestDistance: 0,
            verticalOrigin: Cesium.VerticalOrigin.CENTER,
            horizontalOrigin: Cesium.HorizontalOrigin.CENTER,
          },
      label: icon?.label
        ? icon.label.clone()
        : {
            text: sat.name,
            font: "13px sans-serif",
            style: Cesium.LabelStyle.FILL_AND_OUTLINE,
            fillColor: Cesium.Color.WHITE,
            outlineColor: Cesium.Color.BLACK,
            outlineWidth: 2,
            disableDepthTestDistance: 0,
            horizontalOrigin: Cesium.HorizontalOrigin.RIGHT,
            verticalOrigin: Cesium.VerticalOrigin.CENTER,
            pixelOffset: new Cesium.Cartesian2(-20, 0),
          },
    });
  });

  // New orbit picked: centre the camera between the target and the satellites.
  const sub = firstSub as { lat: number; lon: number } | null;
  if (opts.flyTo && sub) {
    const lat = opts.targetLat ?? sub.lat;
    const lon = opts.targetLon ?? sub.lon;
    viewer.camera.flyTo({
      destination: Cesium.Cartesian3.fromDegrees(
        wrapLon(lon + wrapLon(sub.lon - lon) / 2),
        (lat + sub.lat) / 2,
        PREVIEW_CAMERA_HEIGHT_M,
      ),
      duration: 1.2,
    });
  }
  viewer.scene.requestRender();
}

export function clearSpotOrbitPreview(viewer?: Cesium.Viewer | null) {
  if (!viewer || viewer.isDestroyed()) {
    previewHiddenIds = [];
    return;
  }
  viewer.entities.values
    .filter((e) => typeof e.id === "string" && e.id.startsWith(PREVIEW_PREFIX))
    .forEach((e) => viewer.entities.remove(e));
  previewHiddenIds.forEach((id) => {
    const e = viewer.entities.getById(id);
    if (e) e.show = true;
  });
  previewHiddenIds = [];
  viewer.scene.requestRender();
}
