import { useEffect, useMemo, useRef, useState } from "react";
import * as Cesium from "cesium";
import * as satellite from "satellite.js";
import {
  CheckCircle2,
  AlertTriangle,
} from "lucide-react";
import "../GlobeMode/globe-ui.css";
import "./MissionPlanningTheme.css";
import SatelliteSidebar from "../../components/SatelliteSidebar";
import { STRIP_VIZ_PANEL_ID } from "./components/GeoReferenceStripOrbitPlanAnimation";
import { useMissionPlanningGlobe } from "./components/useMissionPlanningGlobe";
import { useTLEFetcher } from "../GlobeMode/hooks/useTLEFetcher";
import ConstellationGroup, { type SavedGroup } from "./components/ConstellationGroup";
import MissionConfigFilesPanel from "./components/MissionConfig";
import MissionConfigurationPanel, { type TargetAreaMode } from "./components/MissionConfigurationPanel";
import { type FrequencySegment } from "./components/FrequencyAndTime";
import { visualizeFrequencyPlan, clearFrequencyVisualization } from "./components/missionVisualization";
import { visualizeSpotFrequencyPlan, clearSpotFrequencyVisualization } from "./components/spotAnimation";
import type { SelectedOrbitInfo } from "./components/Georeference";


// ─── Types ────────────────────────────────────────────────────────────────
const SATELLITE_ICON_URL = "/satellite.png";
const GROUND_STATION_ICON_URL = "/antenna.png";
const toDegrees = (rad: number) => (rad * 180) / Math.PI;

const SAT_COLORS = ["#f87171", "#fbbf24", "#38bdf8", "#4ade80", "#c084fc", "#f472b6"];

const getSatColor = (satId: string, tleList: { name: string }[]) => {
  const idx = tleList.findIndex((t) => t.name === satId);
  return SAT_COLORS[idx >= 0 ? idx % SAT_COLORS.length : 0];
};

type GroundStation = { name: string; lat: number; lon: number; color: string };

const groundStations: GroundStation[] = [
  { name: "Rawalpindi GS", lat: 33.6167, lon: 73.0992, color: "#7dd3fc" },
  { name: "Azerbaijan GS", lat: 40.3900, lon: 49.2900, color: "#fef08a" },
  { name: "Turkey GS",     lat: 41.1037, lon: 29.0261, color: "#f472b6" },
];
const API_BASE = "http://localhost:5000";

// Globe column width while a config file is open (px, user-resizable).
const DEFAULT_GLOBE_WIDTH = 380;
const MIN_GLOBE_WIDTH = 240;
const MIN_CONFIG_WIDTH = 640;
const GLOBE_WIDTH_KEY = "mp.globeWidth";

// ── Capture mission sub-types (TypeA / TypeB) ──
export type CaptureSubType = "ESLINT" | "COMINT" | null;

const getGeodeticAtTime = (
  satId: string,
  targetDate: Date,
  tleList: { name: string; tle1: string; tle2: string }[],
): { lon: number; lat: number; heightMeters: number } | null => {
  const tle = tleList.find((t) => t.name === satId);
  if (!tle) return null;

  const satrec = satellite.twoline2satrec(tle.tle1, tle.tle2);
  const pv = satellite.propagate(satrec, targetDate);
  if (!pv?.position) return null;

  const gmst = satellite.gstime(targetDate);
  const geo = satellite.eciToGeodetic(pv.position, gmst);

  let lon = toDegrees(geo.longitude);
  if (lon > 180) lon -= 360;
  if (lon < -180) lon += 360;

  return {
    lon,
    lat: toDegrees(geo.latitude),
    heightMeters: geo.height * 1000,
  };
};

// ── shape of the config we save/load ──
type MissionConfigPayload = {
  groupId: string;
  groupName: string;
  polarization: string;
  customPolarization: number;
  missionType: string | null;
  captureSubType: CaptureSubType;
  targetAreaMode: TargetAreaMode;
  georeference: { lat: number | null; lon: number | null } | null;
  orbitReference: {
    captureDate: string;
    hour24: number;
    minute: number;
    second: number;
    selectedOrbitIndex: number | null;
  } | null;
  downloadInGsPass: boolean;
  selectedGsName: string | null;
  frequencySegments: FrequencySegment[]
  ;
};

type Props = {
  onSwitchToOperations?: () => void;
  onNavigateGlobe?: (hash: string) => void;
  onOpenBuilder?: () => void;
  onSwitchToMissionPlanning?: () => void;
  canManage?: boolean;
};

// ─── Component ────────────────────────────────────────────────────────────
function UtcClock() {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(id);
  }, []);
  return (
    <div className="whitespace-nowrap font-['IBM_Plex_Mono',ui-monospace,monospace] text-xs text-[#8994a0]">
      UTC {now.toISOString().slice(11, 19)} •{" "}
      {now.toUTCString().split(" ").slice(1, 4).join(" ").toUpperCase()}
    </div>
  );
}


export default function MissionPlanningMode({
  onSwitchToOperations,
  onNavigateGlobe,
  onOpenBuilder,
  onSwitchToMissionPlanning,
  canManage,
}: Props) {
  const [selectedSatIds, setSelectedSatIds] = useState<Set<string>>(new Set());
  const [groups, setGroups] = useState<SavedGroup[]>([]);

  const [tleData, setTleData] = useState<{ name: string; tle1: string; tle2: string }[]>([]);
  const [tleLoaded, setTleLoaded] = useState(false);
  // The first entry in the fetched TLE feed is temporarily excluded from
  // Mission Planning groups and all mission-globe/mission-config views.
  const missionTleData = useMemo(() => tleData.slice(1), [tleData]);
  const missionTleNames = useMemo(
    () => new Set(missionTleData.map((tle) => tle.name)),
    [missionTleData],
  );
  const missionSelectedSatIds = useMemo(
    () => new Set(Array.from(selectedSatIds).filter((id) => missionTleNames.has(id))),
    [missionTleNames, selectedSatIds],
  );
  const missionSelectedSatIdsArray = useMemo(
    () => Array.from(missionSelectedSatIds),
    [missionSelectedSatIds],
  );
  const [targetLat, setTargetLat] = useState<number | null>(null);
  const [targetLon, setTargetLon] = useState<number | null>(null);

  const [targetAreaMode, setTargetAreaMode] = useState<TargetAreaMode>(null);
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [hour24, setHour24] = useState<number>(0);
  const [minute, setMinute] = useState<number>(0);
  const [second, setSecond] = useState<number>(0);

  const [selectedOrbitIndex, setSelectedOrbitIndex] = useState<number | null>(null);
  const [downloadInGsPass, setDownloadInGsPass] = useState<boolean>(false);
  const [selectedGsName, setSelectedGsName] = useState<string | null>(null);

  const [frequencySegments, setFrequencySegments] = useState<FrequencySegment[]>([]);
const [selectedOrbitTime, setSelectedOrbitTime] = useState<SelectedOrbitInfo | null>(null);

  // ── save-config state ──
  const [savingConfig, setSavingConfig] = useState(false);
  type ConfigStatus = "in-progress" | "completed";
  const [groupConfigStatus, setGroupConfigStatus] = useState<Record<string, ConfigStatus>>({});

  const isConfigComplete = (cfg: Partial<MissionConfigPayload>): boolean => {
    if (!cfg.polarization) return false;
    if (!cfg.missionType) return false;
    if (cfg.missionType === "capture" && !cfg.captureSubType) return false;
    if (!cfg.frequencySegments || cfg.frequencySegments.length === 0) return false;
    if (!cfg.targetAreaMode) return false;
    if (cfg.targetAreaMode === "georeference") {
      return cfg.georeference?.lat != null && cfg.georeference?.lon != null;
    }
    if (cfg.targetAreaMode === "orbit") {
      return cfg.orbitReference?.selectedOrbitIndex != null;
    }
    return false;
  };

  const [saveError, setSaveError] = useState<string | null>(null);
  const [saveSuccess, setSaveSuccess] = useState<string | null>(null);
  const [configBlockedMessage, setConfigBlockedMessage] = useState<string | null>(null);

  const savedCameraViewRef = useRef<{
    destination: Cesium.Cartesian3;
    direction: Cesium.Cartesian3;
    up: Cesium.Cartesian3;
  } | null>(null);

  const isPredictionModeRef = useRef(false);
  // NEW: tracks whether a config is currently being fetched/loaded for the open group,
  // so the live-status effect doesn't clobber status while load is in flight.
  const loadingConfigRef = useRef(false);

  const handleTimeChange = (h: number, m: number, s: number) => {
    setHour24(h);
    setMinute(m);
    setSecond(s);
  };

  useTLEFetcher((data: { name: string; tle1: string; tle2: string }[]) => {
    setTleData(data);
    setTleLoaded(true);
  });

  const [openConfigGroupId, setOpenConfigGroupId] = useState<string | null>(null);

  // Mission-config wizard position and the furthest step reached.
  const [step, setStep] = useState(0);
  const [maxStep, setMaxStep] = useState(0);
  const goToStep = (i: number) => {
    setStep(i);
    setMaxStep((m) => Math.max(m, i));
  };
  // Opening a different config file starts the wizard from the top.
  useEffect(() => {
    setStep(0);
    setMaxStep(0);
  }, [openConfigGroupId]);


  const [selectedPolarization, setSelectedPolarization] = useState<string>("45");
  const [customPolarization, setCustomPolarization] = useState<number>(45);
  const [selectedMissionType, setSelectedMissionType] = useState<string | null>(null);
  const [selectedCaptureSubType, setSelectedCaptureSubType] = useState<CaptureSubType>(null);

  // Fixed sensor off-nadir/incidence ("polarization") angle, in degrees.
  // Used for every Spot capture-range calculation — it stays constant
  // across all passes and never varies with elevation or orbit.
  const lookAngleDeg =
    selectedPolarization === "custom" ? customPolarization : Number(selectedPolarization) || 45;

  // Single point selected on the map (both coordinates present, no manual
  // orbit/date pick yet) → auto-switch into Spot (georeference) targeting.
  useEffect(() => {
    if (targetLat !== null && targetLon !== null && targetAreaMode !== "georeference") {
      setTargetAreaMode("georeference");
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [targetLat, targetLon]);

  

  const { ref: globeRef, viewerRef, viewerReady, isOnline, statusMsg, handleZoomIn, handleZoomOut } =
    useMissionPlanningGlobe();

  // ── Resizable globe column (config open): drag the divider on its left edge. ──
  const splitRef = useRef<HTMLDivElement>(null);
  const [globeWidth, setGlobeWidth] = useState<number>(() => {
    try {
      const saved = Number(localStorage.getItem(GLOBE_WIDTH_KEY));
      return saved > 0 ? saved : DEFAULT_GLOBE_WIDTH;
    } catch {
      return DEFAULT_GLOBE_WIDTH;
    }
  });
  useEffect(() => {
    try {
      localStorage.setItem(GLOBE_WIDTH_KEY, String(Math.round(globeWidth)));
    } catch {
      /* storage unavailable — width just isn't remembered */
    }
    const viewer = viewerRef.current;
    if (viewer && !viewer.isDestroyed()) {
      viewer.resize();
      viewer.scene.requestRender();
    }
  }, [globeWidth, viewerRef]);
  const startGlobeResize = (e: React.PointerEvent<HTMLDivElement>) => {
    const box = splitRef.current?.getBoundingClientRect();
    if (!box) return;
    e.preventDefault();
    const onMove = (ev: PointerEvent) => {
      // Keep at least MIN_CONFIG_WIDTH px for the step rail + step content.
      const max = Math.max(MIN_GLOBE_WIDTH, box.width - MIN_CONFIG_WIDTH);
      setGlobeWidth(Math.min(max, Math.max(MIN_GLOBE_WIDTH, box.right - ev.clientX)));
    };
    const onUp = () => {
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onUp);
      document.body.style.cursor = "";
      document.body.style.userSelect = "";
    };
    document.body.style.cursor = "col-resize";
    document.body.style.userSelect = "none";
    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onUp);
  };

  // 2D / 3D map view (same control as Globe mode).
  const [mapView, setMapView] = useState<"3D" | "2D">("3D");
  useEffect(() => {
    const viewer = viewerRef.current;
    if (!viewerReady || !viewer || viewer.isDestroyed()) return;
    const want = mapView === "2D" ? Cesium.SceneMode.SCENE2D : Cesium.SceneMode.SCENE3D;
    if (viewer.scene.mode === want) return;
    if (mapView === "2D") viewer.scene.morphTo2D(0.5);
    else viewer.scene.morphTo3D(0.5);
    viewer.scene.requestRender();
  }, [mapView, viewerReady, viewerRef]);

  useEffect(() => {
    const viewer = viewerRef.current;
    if (!viewerReady || !viewer || viewer.isDestroyed()) return;

    const toRemove = viewer.entities.values.filter((e) => {
      if (typeof e.id !== "string" || !e.id.startsWith("mp__")) return false;
      if (e.id === "mp__gs__antenna") return false;
      const name = e.id.replace(/^mp__/, "").replace(/__(ground|current)$/, "");
      return !missionSelectedSatIds.has(name);
    });
    toRemove.forEach((e) => viewer.entities.remove(e));

    for (const satId of missionSelectedSatIds) {
      const tle = missionTleData.find((t) => t.name === satId);
      if (!tle) continue;

      const groundId = `mp__${satId}__ground`;
      const currentId = `mp__${satId}__current`;
      if (viewer.entities.getById(groundId) && viewer.entities.getById(currentId)) continue;

      const satrec = satellite.twoline2satrec(tle.tle1, tle.tle2);
      const now = new Date();

      const path: Cesium.Cartesian3[] = [];
      for (let i = 0; i <= 180; i++) {
        const t = new Date(now.getTime() + i * 60 * 1000);
        const pv = satellite.propagate(satrec, t);
        if (!pv?.position) continue;
        const gmst = satellite.gstime(t);
        const geo = satellite.eciToGeodetic(pv.position, gmst);
        let lon = toDegrees(geo.longitude);
        if (lon > 180) lon -= 360;
        if (lon < -180) lon += 360;
        path.push(Cesium.Cartesian3.fromDegrees(lon, toDegrees(geo.latitude), 0));
      }

      viewer.entities.add({
        id: groundId,
        name: `${satId} Ground Track`,
        polyline: {
          positions: path,
          arcType: Cesium.ArcType.GEODESIC,
          width: 2.5,
          material: new Cesium.PolylineGlowMaterialProperty({
            glowPower: 0.15,
            color: Cesium.Color.fromCssColorString(getSatColor(satId, missionTleData)),
          }),
        },
      });

      const pv0 = satellite.propagate(satrec, now);
      if (pv0?.position) {
        const gmst = satellite.gstime(now);
        const geo = satellite.eciToGeodetic(pv0.position, gmst);

        viewer.entities.add({
          id: currentId,
          name: `${satId} Current Position`,
          position: Cesium.Cartesian3.fromDegrees(
            toDegrees(geo.longitude),
            toDegrees(geo.latitude),
            geo.height * 1000,
          ),
          billboard: {
            image: SATELLITE_ICON_URL,
            width: 110,
            height: 110,
            scaleByDistance: new Cesium.NearFarScalar(1.5e6, 1.0, 2.5e7, 0.4),
            disableDepthTestDistance: 0,
            verticalOrigin: Cesium.VerticalOrigin.CENTER,
            horizontalOrigin: Cesium.HorizontalOrigin.CENTER,
          },
          label: {
            text: satId,
            font: "13px sans-serif",
            style: Cesium.LabelStyle.FILL_AND_OUTLINE,
            fillColor: Cesium.Color.WHITE,
            outlineColor: Cesium.Color.BLACK,
            outlineWidth: 2,
            disableDepthTestDistance: 0,
            horizontalOrigin: Cesium.HorizontalOrigin.RIGHT,
            verticalOrigin: Cesium.VerticalOrigin.CENTER,
            pixelOffset: new Cesium.Cartesian2(-20, 0),
          },
        });
      }
    }

    viewer.scene.requestRender();
  }, [missionSelectedSatIds, missionTleData, viewerReady, viewerRef]);

  useEffect(() => {
    const id = setInterval(() => {
      if (isPredictionModeRef.current) return;

      const viewer = viewerRef.current;
      if (!viewer || viewer.isDestroyed()) return;

      for (const satId of missionSelectedSatIds) {
        const tle = missionTleData.find((t) => t.name === satId);
        if (!tle) continue;
        const satrec = satellite.twoline2satrec(tle.tle1, tle.tle2);
        const now = new Date();
        const pv = satellite.propagate(satrec, now);
        if (!pv?.position) continue;
        const gmst = satellite.gstime(now);
        const geo = satellite.eciToGeodetic(pv.position, gmst);
        const newPos = Cesium.Cartesian3.fromDegrees(
          toDegrees(geo.longitude),
          toDegrees(geo.latitude),
          geo.height * 1000,
        );
        const entity = viewer.entities.getById(`mp__${satId}__current`);
        if (entity) entity.position = new Cesium.ConstantPositionProperty(newPos);
      }

      viewer.scene.requestRender();
    }, 1000);

    return () => clearInterval(id);
  }, [missionSelectedSatIds, missionTleData, viewerRef]);

  useEffect(() => {
    const viewer = viewerRef.current;
    if (!viewerReady || !viewer || viewer.isDestroyed()) return;

        if (targetAreaMode !== "orbit") {
      isPredictionModeRef.current = false;
      return;
    }

    const targetDate = new Date(
      Date.UTC(
        selectedDate.getUTCFullYear(),
        selectedDate.getUTCMonth(),
        selectedDate.getUTCDate(),
        hour24,
        minute,
        second,
      ),
    );

    if (Number.isNaN(targetDate.getTime())) return;

    isPredictionModeRef.current = true;

    for (const satId of missionSelectedSatIds) {
      const geo = getGeodeticAtTime(satId, targetDate, missionTleData);
      if (!geo) continue;

      const currentId = `mp__${satId}__current`;
      const entity = viewer.entities.getById(currentId);
      const newPos = Cesium.Cartesian3.fromDegrees(geo.lon, geo.lat, geo.heightMeters);

      if (entity) {
        entity.position = new Cesium.ConstantPositionProperty(newPos);
      } else {
        viewer.entities.add({
          id: currentId,
          name: `${satId} Predicted Position`,
          position: newPos,
          billboard: {
            image: SATELLITE_ICON_URL,
            width: 110,
            height: 110,
            scaleByDistance: new Cesium.NearFarScalar(1.5e6, 1.0, 2.5e7, 0.4),
            disableDepthTestDistance: 0,
            verticalOrigin: Cesium.VerticalOrigin.CENTER,
            horizontalOrigin: Cesium.HorizontalOrigin.CENTER,
          },
          label: {
            text: satId,
            font: "13px sans-serif",
            style: Cesium.LabelStyle.FILL_AND_OUTLINE,
            fillColor: Cesium.Color.WHITE,
            outlineColor: Cesium.Color.BLACK,
            outlineWidth: 2,
            disableDepthTestDistance: 0,
            horizontalOrigin: Cesium.HorizontalOrigin.RIGHT,
            verticalOrigin: Cesium.VerticalOrigin.CENTER,
            pixelOffset: new Cesium.Cartesian2(-20, 0),
          },
        });
      }
    }

    viewer.scene.requestRender();
  }, [targetAreaMode, selectedDate, hour24, minute, second, missionSelectedSatIds, missionTleData, viewerReady, viewerRef]);

  useEffect(() => {
    const ANTENNA_ID = "mp__gs__antenna";

    const sync = () => {
      const viewer = viewerRef.current;
      if (!viewer || viewer.isDestroyed()) return;

      const existing = viewer.entities.getById(ANTENNA_ID);

      if (!selectedGsName) {
        if (existing) viewer.entities.remove(existing);
        return;
      }

      const gs = groundStations.find((g) => g.name === selectedGsName);
      if (!gs) {
        if (existing) viewer.entities.remove(existing);
        return;
      }

      const position = Cesium.Cartesian3.fromDegrees(gs.lon, gs.lat, 0);

      if (existing) {
        existing.position = new Cesium.ConstantPositionProperty(position);
        if (existing.billboard) {
          existing.billboard.show = new Cesium.ConstantProperty(true);
        }
      } else {
        viewer.entities.add({
          id: ANTENNA_ID,
          name: `${gs.name} Antenna`,
          position,
          billboard: {
            image: GROUND_STATION_ICON_URL,
            width: 56,
            height: 56,
            color: Cesium.Color.WHITE,
            scaleByDistance: new Cesium.NearFarScalar(1.5e6, 1.0, 2.5e7, 0.5),
            disableDepthTestDistance: 0,
            verticalOrigin: Cesium.VerticalOrigin.CENTER,
            horizontalOrigin: Cesium.HorizontalOrigin.CENTER,
          },
          label: {
            text: gs.name,
            font: "14px sans-serif",
            style: Cesium.LabelStyle.FILL_AND_OUTLINE,
            fillColor: Cesium.Color.WHITE,
            outlineColor: Cesium.Color.BLACK,
            outlineWidth: 2,
            verticalOrigin: Cesium.VerticalOrigin.TOP,
            pixelOffset: new Cesium.Cartesian2(0, 32),
          },
        });
      }

      viewer.scene.requestRender();
    };

        sync();
  }, [selectedGsName, viewerReady, viewerRef]);

  

  useEffect(() => {
    if (openConfigGroupId && !groups.some((g) => g.id === openConfigGroupId)) {
      setOpenConfigGroupId(null);
    }
  }, [groups, openConfigGroupId]);

  // ── load a saved config for the group instead of always resetting ──
  useEffect(() => {
    if (!openConfigGroupId) return;
    let cancelled = false;
    setSaveError(null);
    loadingConfigRef.current = true;

    const resetDefaults = () => {
      setSelectedPolarization("45");
      setCustomPolarization(45);
      setSelectedMissionType(null);
      setSelectedCaptureSubType(null);
      setTargetAreaMode(null);
      setTargetLat(null);
      setTargetLon(null);
      setSelectedDate(new Date());
      setHour24(0);
      setMinute(0);
      setSecond(0);
      setSelectedOrbitIndex(null);
      setDownloadInGsPass(false);
      setSelectedGsName(null);
      setFrequencySegments([]);
      // Fresh/never-saved group: stamp it as in-progress right away.
      setGroupConfigStatus((prev) => ({ ...prev, [openConfigGroupId]: "in-progress" }));
    setSelectedOrbitTime(null);
    };

    (async () => {
      try {
        const res = await fetch(`${API_BASE}/api/constellation-groups/${openConfigGroupId}/config`);
        if (res.status === 404) {
          if (!cancelled) resetDefaults();
          return;
        }
        if (!res.ok) throw new Error("Failed to load configuration");
        const cfg: MissionConfigPayload = await res.json();
        if (cancelled) return;

        setSelectedPolarization(cfg.polarization ?? "45");
        setCustomPolarization(cfg.customPolarization ?? 45);
        setSelectedMissionType(cfg.missionType ?? null);
        setSelectedCaptureSubType(cfg.captureSubType ?? null);
        setTargetAreaMode(cfg.targetAreaMode ?? null);
        setTargetLat(cfg.georeference?.lat ?? null);
        setTargetLon(cfg.georeference?.lon ?? null);
        if (cfg.orbitReference) {
          setSelectedDate(new Date(cfg.orbitReference.captureDate));
          setHour24(cfg.orbitReference.hour24);
          setMinute(cfg.orbitReference.minute);
          setSecond(cfg.orbitReference.second);
          setSelectedOrbitIndex(cfg.orbitReference.selectedOrbitIndex);
        } else {
          setSelectedDate(new Date());
          setHour24(0);
          setMinute(0);
          setSecond(0);
          setSelectedOrbitIndex(null);
        }
        setDownloadInGsPass(cfg.downloadInGsPass ?? false);
        setSelectedGsName(cfg.selectedGsName ?? null);
        setFrequencySegments(cfg.frequencySegments ?? []);
        setGroupConfigStatus((prev) => ({
          ...prev,
          [openConfigGroupId]: isConfigComplete(cfg) ? "completed" : "in-progress",
        }));
      } catch (err) {
        // Problem 1: don't surface this as a user-facing error, just start fresh.
        console.error("Config load failed, starting fresh:", err);
        if (!cancelled) resetDefaults();
      } finally {
        if (!cancelled) loadingConfigRef.current = false;
      }
    })();

    return () => {
      cancelled = true;
      loadingConfigRef.current = false;
    };
  }, [openConfigGroupId]);

  useEffect(() => {
    setSelectedOrbitIndex(null);
    setDownloadInGsPass(false);
  }, [targetAreaMode]);

  // Reset the capture sub-type whenever mission type changes away from "capture"
  useEffect(() => {
    if (selectedMissionType !== "capture") {
      setSelectedCaptureSubType(null);
    }
  }, [selectedMissionType]);

  const toggleSatellite = (id: string) => {
    // Guard the mission selection even if a stale group or UI callback tries
    // to add the intentionally excluded first TLE entry. Still allow removing
    // it if it was already present in a legacy selection.
    setSelectedSatIds((prev) => {
      if (!missionTleNames.has(id) && !prev.has(id)) return prev;
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  // Problem 2: every fetched satellite must belong to some constellation group
    // Problem 2: every fetched satellite must belong to some constellation group
  const allSatellitesGrouped =
    missionTleData.length > 0 &&
    missionTleData.every((t) => groups.some((g) => g.satelliteIds.includes(t.name)));

  // Auto-clear the "create group first" toast once grouping is actually complete
  useEffect(() => {
    if (allSatellitesGrouped) setConfigBlockedMessage(null);
  }, [allSatellitesGrouped]);

  const openConfigGroup = (groupId: string) => {
    // Always allow closing/toggling whatever is currently open — the block
    // only applies when trying to OPEN a (different) config panel.
    if (openConfigGroupId === groupId) {
      setOpenConfigGroupId(null);
      return;
    }

    // Every fetched satellite must belong to some constellation group before
    // a mission config file can be opened.
    if (!allSatellitesGrouped) {
      setConfigBlockedMessage(
        "Create group first only then you can open Mission Config File",
      );
      return;
    }

    setOpenConfigGroupId(groupId);
  };

// NEW: keep the globe's selected satellites (and therefore ground tracks)
// in sync with whichever group's config panel is currently open.
useEffect(() => {
  if (!openConfigGroupId) return;
  const group = groups.find((g) => g.id === openConfigGroupId);
  if (!group) return;
  setSelectedSatIds(new Set(group.satelliteIds.filter((id) => missionTleNames.has(id))));
  // eslint-disable-next-line react-hooks/exhaustive-deps
}, [openConfigGroupId, groups]);

  useEffect(() => {
    const viewer = viewerRef.current;
    if (viewer && !viewer.isDestroyed()) {
      requestAnimationFrame(() => {
        viewer.resize();
        viewer.scene.requestRender();
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [openConfigGroupId]);

  // ── Strip/Orbit-mode visualization: satellite continues moving, the
  // swath sweeps along the ground track it's flying over. ──
  const handleVisualizeFrequency = (segments: FrequencySegment[]) => {
    const viewer = viewerRef.current;
    if (!viewer || viewer.isDestroyed()) return;

    const primaryId = missionSelectedSatIdsArray[0];
    const primaryTle = missionTleData.find((t) => t.name === primaryId);
    if (!primaryTle) return;

    const captureTime = new Date(
      Date.UTC(
        selectedDate.getUTCFullYear(),
        selectedDate.getUTCMonth(),
        selectedDate.getUTCDate(),
        hour24,
        minute,
        second,
      ),
    );

    savedCameraViewRef.current = {
      destination: viewer.camera.position.clone(),
      direction: viewer.camera.direction.clone(),
      up: viewer.camera.up.clone(),
    };

    visualizeFrequencyPlan(
      viewer,
      segments,
      {
        primaryTle,
        captureTime,
        otherSatellites: missionTleData.filter((t) => missionSelectedSatIds.has(t.name)),
      },
      { onBack: () => handleBackFromFrequency() },
    );
  };

  const handleBackFromFrequency = () => {
    const viewer = viewerRef.current;
    if (!viewer || viewer.isDestroyed()) return;

    clearFrequencyVisualization(viewer);

    if (savedCameraViewRef.current) {
      viewer.camera.flyTo({
        destination: savedCameraViewRef.current.destination,
        orientation: {
          direction: savedCameraViewRef.current.direction,
          up: savedCameraViewRef.current.up,
        },
        duration: 1.2,
      });
      savedCameraViewRef.current = null;
    } else {
      viewer.camera.flyTo({
        destination: Cesium.Cartesian3.fromDegrees(0, 20, 30_000_000),
        duration: 1.2,
      });
    }

    viewer.scene.requestRender();
  };

  // ── Spot-mode (Georeference) visualization: the target is fixed, every
  // satellite in the constellation swings past it like a pendulum, and
  // their square swaths overlap on that same fixed target — only size and
  // color change as the active frequency segment changes. ──
   const handleVisualizeSpotFrequency = (segments: FrequencySegment[]) => {
    const viewer = viewerRef.current;
    if (!viewer || viewer.isDestroyed()) return;
    if (targetLat === null || targetLon === null) return;

    const constellationSats = missionTleData
      .filter((t) => missionSelectedSatIds.has(t.name))
      .map((t) => ({
        name: t.name,
        tle1: t.tle1,
        tle2: t.tle2,
        color: getSatColor(t.name, missionTleData),
      }));

    if (constellationSats.length === 0) return;

    savedCameraViewRef.current = {
      destination: viewer.camera.position.clone(),
      direction: viewer.camera.direction.clone(),
      up: viewer.camera.up.clone(),
    };

    // If the user picked an "Upcoming Orbit" in Georeference, center the
    // whole predicted-pass animation on that orbit's AOS→LOS midpoint
    // instead of on the current moment.
    const referenceTime = selectedOrbitTime
      ? new Date((selectedOrbitTime.aos.getTime() + selectedOrbitTime.los.getTime()) / 2)
      : undefined;

    visualizeSpotFrequencyPlan(viewer, segments, {
      targetLat,
      targetLon,
      satellites: constellationSats,
      referenceTime,
    });
  };

  const handleBackFromSpotFrequency = () => {
    const viewer = viewerRef.current;
    if (!viewer || viewer.isDestroyed()) return;

    clearSpotFrequencyVisualization(viewer);

    if (savedCameraViewRef.current) {
      viewer.camera.flyTo({
        destination: savedCameraViewRef.current.destination,
        orientation: {
          direction: savedCameraViewRef.current.direction,
          up: savedCameraViewRef.current.up,
        },
        duration: 1.2,
      });
      savedCameraViewRef.current = null;
    } else {
      viewer.camera.flyTo({
        destination: Cesium.Cartesian3.fromDegrees(0, 20, 30_000_000),
        duration: 1.2,
      });
    }

    viewer.scene.requestRender();
  };

  const activeConfigGroup = groups.find((g) => g.id === openConfigGroupId) ?? null;
  const isConfigOpen = !!activeConfigGroup;

  // Problem 3: orbit reference only offered when the group has 1–2 satellites
  const activeGroupSatCount = activeConfigGroup?.satelliteIds.length ?? 0;
  const allowOrbitReference = activeGroupSatCount > 0 && activeGroupSatCount <= 2;

  useEffect(() => {
    if (!allowOrbitReference && targetAreaMode === "orbit") {
      setTargetAreaMode("georeference");
    }
  }, [allowOrbitReference, targetAreaMode]);

  // ── Build the config payload from current state ──
  const buildConfigPayload = (groupId: string, groupName: string): MissionConfigPayload => ({
    groupId,
    groupName,
    polarization: selectedPolarization,
    customPolarization,
    missionType: selectedMissionType,
    captureSubType: selectedMissionType === "capture" ? selectedCaptureSubType : null,
    targetAreaMode,
    georeference: targetAreaMode === "georeference" ? { lat: targetLat, lon: targetLon } : null,
    orbitReference:
      targetAreaMode === "orbit"
        ? { captureDate: selectedDate.toISOString(), hour24, minute, second, selectedOrbitIndex }
        : null,
    downloadInGsPass,
    selectedGsName,
    frequencySegments,
  });

  // Live status: reflect edits to the currently open group's config in real time,
  // so switching to a different group leaves this one correctly marked "in-progress"
  // (or "completed") instead of only updating on load/save.
  useEffect(() => {
    if (!openConfigGroupId || loadingConfigRef.current) return;
    const payload = buildConfigPayload(openConfigGroupId, "");
    setGroupConfigStatus((prev) => ({
      ...prev,
      [openConfigGroupId]: isConfigComplete(payload) ? "completed" : "in-progress",
    }));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    openConfigGroupId,
    selectedPolarization,
    customPolarization,
    selectedMissionType,
    selectedCaptureSubType,
    targetAreaMode,
    targetLat,
    targetLon,
    selectedDate,
    hour24,
    minute,
    second,
    selectedOrbitIndex,
    downloadInGsPass,
    selectedGsName,
    frequencySegments,
  ]);

  // ── block saving until required fields are filled in ──
  const validateConfigForSave = (): string | null => {
    if (!selectedPolarization) return "Select a polarization before saving.";
    if (!selectedMissionType) return "Select a mission type before saving.";
    if (selectedMissionType === "capture" && !selectedCaptureSubType) {
      return "Select Type A or Type B before saving.";
    }
    if (frequencySegments.length === 0) return "Add at least one frequency segment before saving.";
    return null;
  };

  // ── save handler wired to the panel's "Save Configuration File" button ──
  const handleSaveConfiguration = async () => {
    if (!activeConfigGroup) return;

    const validationError = validateConfigForSave();
    if (validationError) {
      setSaveError(validationError);
      return;
    }
    setSaveError(null);
    setSaveSuccess(null);

    const payload = buildConfigPayload(activeConfigGroup.id, activeConfigGroup.name);
    setSavingConfig(true);
    try {
      const res = await fetch(`${API_BASE}/api/constellation-groups/${activeConfigGroup.id}/config`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      if (!res.ok) throw new Error("Failed to save configuration");

      setGroupConfigStatus((prev) => ({ ...prev, [activeConfigGroup.id]: "completed" }));
      setSaveSuccess(`MissionConfig_${activeConfigGroup.name.trim().replace(/\s+/g, "_")}.txt saved`);
      setOpenConfigGroupId(null); // closes right sidebar only — left Constellation Group panel stays open
    } catch (err) {
      console.error(err);
      setSaveError("Something went wrong while saving. Please try again.");
    } finally {
      setSavingConfig(false);
    }
  };

  const navigateToGlobe = (hash: string) => {
    if (onNavigateGlobe) {
      onNavigateGlobe(hash);
    }
  };

  // ── Display-only values for the stepper header + globe legend ──
  const activeConfigCompleted =
    !!openConfigGroupId && groupConfigStatus[openConfigGroupId] === "completed";
  const configStatusText = activeConfigCompleted ? "READY TO SAVE" : "IN PROGRESS";
  const referenceName =
    targetAreaMode === "orbit" ? "Orbit Reference" : targetAreaMode === "georeference" ? "Geo Reference" : null;
  const satelliteColors = Object.fromEntries(
    missionSelectedSatIdsArray.map((name) => [name, getSatColor(name, missionTleData)]),
  );
  const configStatusColor = activeConfigCompleted ? "#34c48a" : "#e2b04a";

 
 
  return (
    <div className="globe-mode-root mp-theme flex h-screen w-full overflow-hidden text-base selection:bg-[oklch(0.75_0.12_220)]/30">
      {saveSuccess && (
        <div
          role="status"
          className="pointer-events-none fixed right-5 top-5 z-50 flex max-w-[min(100vw-2.5rem,360px)] items-start gap-2.5 rounded-lg border border-emerald-300/30 bg-[oklch(0.16_0.04_160)]/95 px-4 py-3 text-sm text-emerald-100 shadow-2xl shadow-black/30 backdrop-blur"
        >
          <CheckCircle2 className="mt-0.5 size-4 shrink-0 text-emerald-300" aria-hidden="true" />
          <span className="break-words">{saveSuccess}</span>
        </div>
      )}
      {configBlockedMessage && (
        <div
          role="alert"
          className="pointer-events-none fixed right-5 top-5 z-50 flex max-w-[min(100vw-2.5rem,360px)] items-start gap-2.5 rounded-lg border border-red-400/30 bg-[oklch(0.16_0.04_20)]/95 px-4 py-3 text-sm text-red-100 shadow-2xl shadow-black/30 backdrop-blur"
        >
          <AlertTriangle className="mt-0.5 size-4 shrink-0 text-red-300" aria-hidden="true" />
          <span className="break-words">{configBlockedMessage}</span>
        </div>
      )}
      <SatelliteSidebar
        activeRoute={window.location.hash || "#/mission-planning"}
        onNavigateMap={() => { navigateToGlobe("#/map"); }}
        onNavigatePasses={() => navigateToGlobe("#/passes")}
        onNavigateModem={() => navigateToGlobe("#/modem")}
        onNavigateConnections={() => navigateToGlobe("#/connections")}
        onSwitchToOperations={onSwitchToOperations ?? (() => undefined)}
        onSwitchToMissionPlanning={onSwitchToMissionPlanning ?? (() => undefined)}
        onOpenBuilder={onOpenBuilder}
        canManage={canManage}
        onFileUpload={() => undefined}
        onRefreshTLEs={() => undefined}
        tleFetchStatus="idle"
      />

      {/* Kept mounted while a config file is open (the stepper rail takes its
          place) so constellation-group state isn't lost. */}
      <aside
        hidden={isConfigOpen}
        className="globe-side-panel relative flex min-h-0 w-[288px] shrink-0 flex-col overflow-hidden border-r"
      >
        <div className="flex min-h-0 flex-[2] flex-col border-b border-[var(--gm-border)]">
          <ConstellationGroup
            selectedSatIds={selectedSatIds}
            onToggleSatellite={toggleSatellite}
            onGroupsChange={setGroups}
            tleData={missionTleData}
            tleLoaded={tleLoaded}
            groupConfigStatus={groupConfigStatus}
            openConfigGroupId={openConfigGroupId}
          />
        </div>

        <div className="mt-3 flex min-h-0 flex-1 flex-col">
          <MissionConfigFilesPanel
            groups={groups}
            activeGroupId={openConfigGroupId}
            onOpenFile={openConfigGroup}
          />
        </div>
      </aside>

      <main className="relative flex min-w-0 flex-1 flex-col">
        <header className="mp-chrome flex h-12 min-w-0 shrink-0 items-center gap-5 border-b border-[var(--mp-border)] px-4">
          <div className="flex flex-none items-center gap-2.5">
            <div
              className="size-2 rounded-full"
              style={{
                background: isOnline ? "var(--mp-ok)" : "var(--mp-err)",
                boxShadow: isOnline ? "0 0 0 3px rgba(52,196,138,.18)" : "0 0 0 3px rgba(229,103,90,.18)",
              }}
            />
            <span className="mp-mono whitespace-nowrap text-xs font-semibold tracking-[0.08em] text-[var(--mp-text)]">
              MISSION PLANNING
            </span>
          </div>
          {isConfigOpen && (
            <span className="min-w-0 truncate font-medium text-[var(--mp-text)]">
              Mission Configuration{" "}
              <span className="font-normal text-[var(--mp-text-3)]">
                · {activeConfigGroup!.name}
                {referenceName ? ` · ${referenceName}` : ""}
              </span>
            </span>
          )}
          <div className="flex-1" />
          <UtcClock />
          {isConfigOpen && (
            <span
              className="mp-mono whitespace-nowrap rounded border px-2 py-1 text-[11px] font-medium"
              style={{ color: configStatusColor, borderColor: configStatusColor }}
            >
              {configStatusText}
            </span>
          )}
        </header>

        <div ref={splitRef} className="flex min-h-0 flex-1">
          {isConfigOpen && activeConfigGroup ? (
            <MissionConfigurationPanel
              groupName={activeConfigGroup.name}
              onClose={() => setOpenConfigGroupId(null)}
              allowOrbitReference={allowOrbitReference}
              step={step}
              maxStep={maxStep}
              onStepChange={goToStep}
              satelliteColors={satelliteColors}
              selectedPolarization={selectedPolarization}
              onSelectPolarization={setSelectedPolarization}
              customPolarization={customPolarization}
              onCustomPolarizationChange={setCustomPolarization}
              lookAngleDeg={lookAngleDeg}
              selectedMissionType={selectedMissionType}
              onSelectMissionType={setSelectedMissionType}
              selectedCaptureSubType={selectedCaptureSubType}
              onSelectCaptureSubType={setSelectedCaptureSubType}
              targetAreaMode={targetAreaMode}
              onSelectTargetAreaMode={setTargetAreaMode}
              targetLat={targetLat}
              targetLon={targetLon}
              onTargetLatChange={setTargetLat}
              onTargetLonChange={setTargetLon}
              selectedDate={selectedDate}
              onSelectedDateChange={setSelectedDate}
              hour24={hour24}
              minute={minute}
              second={second}
              onTimeChange={handleTimeChange}
              satelliteIds={missionSelectedSatIdsArray}
              tleData={missionTleData}
              selectedOrbitIndex={selectedOrbitIndex}
              onSelectOrbit={setSelectedOrbitIndex}
              downloadInGsPass={downloadInGsPass}
              onToggleDownloadInGsPass={setDownloadInGsPass}
              selectedGsName={selectedGsName}
              onSelectGsName={setSelectedGsName}
              frequencySegments={frequencySegments}
              onFrequencySegmentsChange={setFrequencySegments}
              onVisualizeFrequency={handleVisualizeFrequency}
              onBackFromFrequency={handleBackFromFrequency}
              onVisualizeSpotFrequency={handleVisualizeSpotFrequency}
              onBackFromSpotFrequency={handleBackFromSpotFrequency}
              onSaveConfiguration={handleSaveConfiguration}
              isSaving={savingConfig}
              saveError={saveError}
              viewerRef={viewerRef}
              viewerReady={viewerReady}
              onOrbitTimeChange={setSelectedOrbitTime}
            />
          ) : null}

          {/* Globe column — same tree position in both layouts so the Cesium
              viewer is never remounted; it narrows into the preview column
              while a config file is open. */}
          <div
            className={
              isConfigOpen
                ? "mp-globe-col relative flex shrink-0 flex-col"
                : "flex min-w-0 flex-1 flex-col"
            }
            style={isConfigOpen ? { width: globeWidth } : undefined}
          >
            {/* Drag to widen / narrow the globe. Double-click resets. */}
            {isConfigOpen && (
              <div
                role="separator"
                aria-orientation="vertical"
                aria-label="Resize globe"
                title="Drag to resize the globe · double-click to reset"
                onPointerDown={startGlobeResize}
                onDoubleClick={() => setGlobeWidth(DEFAULT_GLOBE_WIDTH)}
                className="group absolute inset-y-0 -left-[5px] z-40 flex w-[10px] cursor-col-resize items-center justify-center"
              >
                <span className="h-full w-px bg-[var(--mp-border)] transition-colors group-hover:bg-[var(--mp-accent)]" />
                <span className="absolute flex h-12 w-[10px] flex-col items-center justify-center gap-[3px] rounded-full border border-[var(--mp-border-input)] bg-[#12161b] group-hover:border-[var(--mp-accent)]">
                  <span className="size-[3px] rounded-full bg-[var(--mp-text-3)]" />
                  <span className="size-[3px] rounded-full bg-[var(--mp-text-3)]" />
                  <span className="size-[3px] rounded-full bg-[var(--mp-text-3)]" />
                </span>
              </div>
            )}
            <div
              className={`relative flex min-h-0 flex-1 items-center justify-center ${
                isConfigOpen ? "mp-globe-well" : "bg-[oklch(0.1_0.03_250)] p-4"
              }`}
            >
              <div className={`relative h-full w-full overflow-hidden bg-[oklch(0.12_0.01_260)] ${isConfigOpen ? "" : "rounded-[min(1vw,24px)] outline outline-1 -outline-offset-1 outline-white/5"}`}>
                {isConfigOpen && (
                  <div className="pointer-events-none absolute left-3 top-3 z-10 font-['IBM_Plex_Mono',ui-monospace,monospace] text-[10.5px] font-semibold tracking-[0.08em] text-[#8994a0]">
                    PREVIEW
                  </div>
                )}
                <div className="absolute right-3 top-3 z-30 flex items-center rounded-md border border-white/10 bg-[rgba(12,14,18,0.85)] p-0.5 backdrop-blur">
                  {(["3D", "2D"] as const).map((v) => (
                    <button
                      key={v}
                      type="button"
                      onClick={() => setMapView(v)}
                      className={`rounded px-3 py-1 text-xs font-semibold transition-colors ${
                        mapView === v
                          ? "bg-[rgba(79,179,232,0.22)] text-white shadow-sm"
                          : "text-[#929ba6] hover:text-white"
                      }`}
                    >
                      {v === "3D" ? "3D VIEW" : "2D"}
                    </button>
                  ))}
                </div>
                <div className="absolute bottom-6 right-6 z-10 flex flex-col gap-2">
                  <button
                    type="button"
                    title="Zoom in"
                    onClick={handleZoomIn}
                    className="flex size-8 items-center justify-center rounded border border-[oklch(0.22_0.01_260)] bg-[oklch(0.13_0.01_260)]/80 text-[oklch(0.8_0_0)] backdrop-blur transition-colors hover:text-white"
                  >
                    +
                  </button>
                  <button
                    type="button"
                    title="Zoom out"
                    onClick={handleZoomOut}
                    className="flex size-8 items-center justify-center rounded border border-[oklch(0.22_0.01_260)] bg-[oklch(0.13_0.01_260)]/80 text-[oklch(0.8_0_0)] backdrop-blur transition-colors hover:text-white"
                  >
                    −
                  </button>
                </div>

                {statusMsg && (
                  <div className="pointer-events-none absolute bottom-20 left-1/2 z-10 -translate-x-1/2 rounded border border-[oklch(0.75_0.15_200)]/30 bg-[oklch(0.13_0.01_260)]/90 px-5 py-2 text-xs text-[oklch(0.95_0_0)]">
                    {statusMsg}
                  </div>
                )}

                {!isOnline && (
                  <div className="absolute bottom-20 right-6 z-10 max-w-[200px] rounded border border-red-500/30 bg-red-500/10 px-3.5 py-1.5 text-center text-[11px] leading-snug text-red-300">
                    Zoom limited to 500 km altitude.
                    <br />
                    Connect to enable street-level detail.
                  </div>
                )}

                <div ref={globeRef} className="globe-cesium-host absolute inset-0 h-full w-full" />
              </div>
            </div>

            {/* Strip-capture animation readout is mounted here (under the globe,
                so it never covers the globe). Empty -> takes no space. */}
            <div
              id={STRIP_VIZ_PANEL_ID}
              className={`shrink-0 overflow-y-auto empty:hidden ${isConfigOpen ? "max-h-[45%] px-3 pb-3" : "max-h-[40%] px-4 pb-4"}`}
            />

          </div>
        </div>
      </main>
    </div>
  );
}
