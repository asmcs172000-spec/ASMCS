# Handoff: Mission Planning Mode (Stepper Redesign)

## Overview
This is a redesign of **Mission Planning mode** (`frontend/src/modes/MissionPlanningMode/MissionPlanningMode.tsx`).

In the current UI the Cesium globe takes up most of the screen and the mission parameters are hard to see. The redesign puts the parameters first:
- A **5-step wizard**: a numbered step rail on the left, two parameter boxes per step in the center, and Back/Next navigation.
- The **globe** moves to a preview column on the right.
- The look is a dark, translucent "glass" UI with soft gradients.

## About the Design Files
`Mission Planning Stepper.dc.html` is a **design reference built in HTML**. It is a prototype that shows the intended look and behavior; it is not production code to copy.

The task is to **recreate it inside the existing React + TypeScript + Tailwind + Cesium codebase** (`Docker-MPS/frontend`), using its patterns:
- Tailwind classes
- the `lucide-react` icons
- the existing components and hooks

To view the reference, open it in a browser with `support.js` next to it. Its logic class (the `renderVals()` function) contains all the sample data and state transitions.

## Fidelity
**High-fidelity.** Match the colors, spacing, typography, radii and translucency below. The sample data (satellite names, orbits, AOS/LOS times) is placeholder and should be replaced with real app data.

## Keep vs. change
**Keep, with no logic changes:**
- All existing state in `MissionPlanningMode.tsx`: `selectedSatIds`, `selectedPolarization`, `customPolarization`, `selectedMissionType`, `selectedCaptureSubType`, `targetAreaMode`, `targetLat/Lon`, `selectedDate`, `hour24/minute/second`, `selectedOrbitIndex`, `downloadInGsPass`, `selectedGsName`, `frequencySegments`
- `buildConfigPayload`, `isConfigComplete`, `validateConfigForSave`, `handleSaveConfiguration`
- `useMissionPlanningGlobe`, the visualization handlers, `FREQUENCY_PRESETS`, the 10-minute mission duration, and the rule that Orbit Reference is only allowed for groups of 1–2 satellites

**Change:**
- Replace the current layout (the 288px aside plus a full-size globe in `<main>`) with the layout below.
- Split `MissionConfigurationPanel` into per-step box components.
- Add `const [step, setStep] = useState(0)` and `const [maxStep, setMaxStep] = useState(0)`.

## Layout
- **Root:** full viewport height (`h-screen`, minimum height 760px), CSS grid with rows `48px 1fr`.
- **Body:** grid with columns `clamp(200px,18vw,260px) minmax(0,1fr) clamp(200px,26vw,380px)`.
  - **Left:** the step rail.
  - **Center:** the step workspace, which scrolls on its own.
  - **Right:** the globe preview plus its legend.
- `SatelliteSidebar` (the existing far-left nav) stays outside this grid, unchanged.

### Header (48px)
- Contents, left to right:
  - an 8px status dot (`#34c48a` when online, red when offline)
  - "MISSION PLANNING" in IBM Plex Mono 600 12px, letter-spacing .08em
  - "Mission Configuration · {groupName}"
  - a spacer
  - the `UtcClock` in mono 12px, color `#8994a0`
  - a status pill: mono 11px, 1px border in the status color, radius 4px, padding 4px 8px. It reads "IN PROGRESS" (`#e2b04a`) or "READY TO SAVE" (`#34c48a`).
- Background: `rgba(16,22,29,.55)` with `backdrop-filter: blur(16px) saturate(140%)`, a bottom border of 1px `rgba(255,255,255,.08)`, and a box shadow of `0 1px 0 rgba(95,184,240,.10)`.

### Left: step rail
- **Glass:** background `rgba(14,20,27,.45)`, blur 18px, right border 1px `rgba(255,255,255,.08)`.
- **Top block:** padding 16px 16px 12px.
  - Label "MISSION CONFIG FILE": mono 600 10.5px, letter-spacing .08em, color `#8994a0`.
  - Value `MissionConfig_<Group_Name>.txt`: 600 weight, single line with an ellipsis (`truncate`), full name in the `title` attribute.
- **Step items:** gap 4px, each a grid with columns `30px 1fr`, gap 12px, padding 10px, radius 6px.
  - **Circle:** 28px, mono 600 12px. It shows the step number, or ✓ when done.
    - Current: background `#5fb8f0`, text `#05202f`.
    - Done: background `#163326`, text `#34c48a`, border `#2a6247`.
    - Upcoming: transparent background, text `#8994a0`, border `#33404b`.
  - **Current item:** background `#1a2632`, border `#2c4a60`.
  - **Text:** the title in 600 weight, and a one-line summary at 11.5px in `#8994a0` (for example "3 satellites" or "45° · Capture · ESLINT"). Upcoming steps show "Not started".
  - Clicking any item jumps to that step.
- **Bottom:**
  - "Progress" with a count such as "2 / 5".
  - A 6px bar on a `#0d1115` track, filled with `linear-gradient(90deg,#4aa6e0,#a58cf0)`.

### Center: workspace
- **Step header:** padding 20px 24px 14px, bottom border.
  - "STEP n OF 5": mono 600 10.5px in `#5fb8f0`.
  - Title: 21px, 600.
  - Hint: 13px in `#8994a0`.
- **Box grid:** `repeat(auto-fit, minmax(min(300px,100%), 1fr))`, gap 16px, padding 20px 24px, `overflow-y:auto`, `overflow-x:hidden`. The two boxes sit side by side when there's room and stack when there isn't.
- **Box (glass card):**
  - Background `linear-gradient(180deg, rgba(255,255,255,.055), rgba(255,255,255,.02))` with `backdrop-filter: blur(14px)`.
  - Border 1px `rgba(255,255,255,.08)`, radius 12px.
  - Box shadow `inset 0 1px 0 rgba(255,255,255,.07), 0 10px 30px rgba(0,0,0,.28)`.
  - Header: padding 12px 16px, bottom border, title 600 weight, optional right-aligned status label in mono 11px with `nowrap`.
- **Inputs:** mono 13px, padding 9px 11px, background `rgba(5,9,13,.45)`, border 1px `rgba(255,255,255,.09)`, radius 5px. The unit sits at the right in `#8994a0` (for example "km" or "°N").
- **Selectable option** (radio card or chip):
  - Unselected: background `rgba(255,255,255,.025)`, border `rgba(255,255,255,.08)`, text `#aab4bd`.
  - Selected: background `#16222c`, border `#3a6f8f`, text `#e4e8ec`.
- **Footer:** padding 14px 24px, glass background `rgba(14,20,27,.5)` with blur 16px.
  - **Back:** outline button with border `#33404b`, radius 6px, padding 9px 16px. At 35% opacity on step 1.
  - **Pips:** centered, 6px tall; 22px wide in `#5fb8f0` for the current step, 8px wide otherwise.
  - **Next:** background `linear-gradient(180deg,#7cc8f4,#4aa6e0)`, text `#05202f`, 600 weight, box shadow `0 4px 14px rgba(95,184,240,.3)`. The label reads "Next: {next step title} →", and on step 5 it becomes "Save configuration file", which calls `handleSaveConfiguration`.

### Steps (two boxes each)
| # | Title | Hint | Box 1 | Box 2 |
|---|---|---|---|---|
| 1 | Constellation | Choose the satellites this config file is for. | **Constellation group**: group name field, satellite checklist (14px checkbox, 8px color dot from `SAT_COLORS`, name, altitude). Header shows "N SELECTED". Reuse the `ConstellationGroup` logic. | **Config file**: rows for File, Satellites, Orbit Reference (Available or Not available), and Status. Info note: "Orbit Reference is only offered for groups with 1–2 satellites." |
| 2 | Mission type | Set the sensor polarization and what the mission does. | **Polarization**: radio list from `POLARIZATION_OPTIONS`, with an AUTO badge on 45°. Custom shows a 0–90 range slider. Header shows "Look angle {lookAngleDeg}°". | **Type of mission**: three equal tiles (Capture, Download, Both). When Capture is selected, a "CAPTURE TYPE" row adds ESLINT/COMINT tiles. A note below explains the selected type. |
| 3 | Planning reference | Define where and when to capture. | **Planning reference**: two tiles, Georeference ("Spot / strip on a target") and Orbit Reference ("1–2 satellites only"; hidden when not allowed). Georeference shows a 2×2 grid of target lat/lon and min/max range in km, plus a hint about picking on the globe. Orbit Reference shows capture date and time (HH:MM:SS). | **Upcoming orbits**: selectable list of satellite, orbit number, AOS/LOS and max elevation. Drives `selectedOrbitIndex` / `onOrbitTimeChange`. |
| 4 | Frequency & time | Build the frequency plan for the 10-minute mission window. | **Frequency segments**: table (PRESET with a color swatch, START mm:ss, DURATION mm:ss, × to remove) and "+ Add segment". Below it: "Mission time used X / 10:00" and a 22px bar with each segment drawn at its start/duration in the preset color. | **Presets**: four cards from `FREQUENCY_PRESETS`, each with a 4px color stripe, label, bandwidth label, and swath in km. Clicking a card appends a segment. |
| 5 | Downlink & save | Pick a download station, review, and save the config file. | **Download in GS pass**: toggle in the header (38×22 track, `#5fb8f0` when on, `#33404b` when off), list of `groundStations` (dot, name, coordinates, next pass). The list is at 40% opacity when the toggle is off. | **Review**: one row per setting (Satellites, Polarization, Mission type, Reference, Frequency plan, GS download). Clicking a row jumps to its step. Messages from `validateConfigForSave` appear in a red box (background `#2a1715`, border `#5a2a24`, text `#f1b3a9`). |

### Right: globe preview
- **Top:** mount the existing Cesium viewer (`globeRef`). Overlays:
  - "PREVIEW" label at the top left.
  - 3D / 2D / ⤢ segmented control at the top right.
  - Zoom +/− at the bottom right, 30px each.
  - Optional glow behind the viewer: `radial-gradient(circle at 50% 45%, rgba(95,184,240,.16), transparent 55%)`.
- **Bottom:**
  - "ON GLOBE" legend chips: the selected satellites, the target, and the selected ground station.
  - An outline button, "Visualize plan on globe", that calls `handleVisualizeSpotFrequency` or `handleVisualizeFrequency` depending on `targetAreaMode`.

## Interactions & Behavior
- **Next:** `setStep(s+1)` and `setMaxStep(max(maxStep, s+1))`.
- **Back:** `setStep(s-1)`.
- **Rail:** clicking a step jumps straight to it.
- **Rail summaries:** update live from state.
- **Steps-done count:** `maxStep`, plus 1 when on step 5.
- **Header status:** "READY TO SAVE" when on step 5 and `validateConfigForSave()` returns null; otherwise "IN PROGRESS".
- **Mission type:** leaving Capture clears `selectedCaptureSubType`. This is existing behavior.
- **Picking a point on the globe:** switches to Georeference. This is existing behavior.
- **On save success:** keep the current toast and close behavior.
- **Hover and transitions:** cards lighten slightly on hover (`rgba(255,255,255,.04)`). Use 150ms transitions on background and border colors.

## Design Tokens
- **Background:** `radial-gradient(1100px 620px at 30% -10%, rgba(95,184,240,.20), transparent 60%), radial-gradient(900px 560px at 105% 105%, rgba(165,140,240,.16), transparent 60%), radial-gradient(700px 500px at -10% 90%, rgba(52,196,138,.08), transparent 60%), linear-gradient(180deg,#0a0e14,#070a0f)`
- **Text:** primary `#e4e8ec`, secondary `#aab4bd`, muted `#8994a0`
- **Accent:** `#5fb8f0` (gradient `#7cc8f4` to `#4aa6e0`); secondary accent `#a58cf0`
- **Status:** OK `#34c48a`, warning `#e2b04a`, error `#e5675a` / `#f1b3a9`
- **Borders and dividers:** `rgba(255,255,255,.08)` and `rgba(255,255,255,.06)`; outline buttons `#33404b`
- **Satellite colors:** `#f87171 #fbbf24 #38bdf8 #4ade80 #c084fc #f472b6` (the existing `SAT_COLORS`)
- **Frequency colors:** 20 MHz `#b5730a`, 50 MHz `#0e7f95`, 120 MHz `#6d3fc4`, 80 MHz `#1f9d52`
- **Fonts:** IBM Plex Sans (UI text) and IBM Plex Mono (labels, values, numbers)
- **Type scale:** step title 21px/600, body 13px, field label 11.5px, section label 10.5px/600 uppercase with letter-spacing .08em
- **Radii:** cards 12px, buttons and options 6px, inputs 5px, pills 4px
- **Spacing:** steps of 4, 6, 8, 10, 12, 14, 16, 20 and 24px
- **Blur:** 14–18px `backdrop-filter`, with a `-webkit-` prefix

## Assets
No new assets. Keep using `/satellite.png` and `/antenna.png` on the globe. For icons, use `lucide-react`: RadioTower, Target, MapPin, Check, AlertCircle, Plus, Trash2, ChevronLeft, ChevronRight.

## Files
- `Mission Planning Stepper.dc.html`: the interactive design reference
- `support.js`: runtime for the reference (only needed to view it)
