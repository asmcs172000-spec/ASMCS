# Mission Planning: stepper redesign

This is a design reference for `frontend/src/modes/MissionPlanningMode`.

To view it, open `Mission Planning Stepper.dc.html` in a browser. Keep `support.js` in the same folder.

## Layout

The screen has a header and three columns:

- **Header:** mission status, the open config group, a UTC clock, and a status badge.
- **Left: step rail (260 px).** Steps 1–5, each with a one-line summary of its current values, plus a progress bar. Any step can be clicked to jump to it.
- **Center: workspace.** Each step shows two boxes side by side. Back and Next sit in the footer, and on the last step Next becomes the Save button.
- **Right: globe preview.** This is your existing Cesium viewer from `useMissionPlanningGlobe`, with a legend underneath.

## How the steps map to your code

| Step | Box 1 | Box 2 | Code |
|---|---|---|---|
| 1 Constellation | Group + satellite picker | Config file info | ConstellationGroup, MissionConfig |
| 2 Mission type | Polarization (0/45 AUTO/90/Custom/Free Fly) | Capture/Download/Both + ESLINT/COMINT | MissionConfigurationPanel |
| 3 Planning reference | Georeference / Orbit Reference + inputs | Upcoming orbits | Georeference, OrbitReference |
| 4 Frequency & time | Segment table + 10:00 timeline | FREQUENCY_PRESETS | FrequencyAndTime |
| 5 Downlink & save | Download in GS pass + stations | Review + validation | handleSaveConfiguration |

The existing state, including `buildConfigPayload` and `validateConfigForSave`, does not need to change. Only the layout changes: add a `step` state to `MissionPlanningMode.tsx` and render the matching pair of boxes for the current step.
